"""Feature modules.

`ENABLED` is the single source of truth for which features are mounted. As the rebuild
progresses, each phase adds its modules here (data, knowledge, research, generation,
simulation, super, analytics, entitlement, …).
"""

ENABLED = [
    "health",
    "meta",
    "session",
    "data",
    "knowledge",
    "research",
    "generate",
    "simulate",
    "analytics",
    "super",
    "settings",
    "strategy",
    "regions",
    "operators",
    "tier",
    "vault",
    "autopilot",
    "pyalpha",
    "notify",
    "prompts",
    "superpilot",
    "harness_engine",
    "harness_vault",
    "osmosis",
    "catalog",
    "whip",
]
# NOTE: "update" (the auto-pull-from-upstream self-updater) is intentionally not mounted.
# This fork is updated manually by its owner only — see app/modules/update/__init__.py
# for the original, which is left in the tree (unregistered) for reference.
