# Alpha Sentry — User Guide

From installation to every screen. Alpha Sentry is a local-first research studio for WorldQuant BRAIN: it runs on your own computer, uses your own BRAIN login and your own AI (LLM) keys, and never submits an alpha to BRAIN on its own.

---

## 1. What you need

| Need | Why |
|---|---|
| Windows 10/11 (macOS/Linux also work with `run.sh`) | The app runs on your computer |
| Internet | To reach BRAIN and your LLM provider |
| A WorldQuant BRAIN account | Alpha Sentry uses *your* session; nothing is stored on any server |
| At least one LLM API key (Claude, Gemini, OpenAI, DeepSeek, Groq, …) | Ideas, templates and translations are written by an LLM |
| Python 3.11 or 3.12 and Node.js 18+ | `run.bat` installs both for you if they are missing (Windows may ask permission — accept) |

---

## 2. Installation

1. **Unzip** the Alpha Sentry folder somewhere you will keep it (for example `Documents\Alpha Sentry`). Do not run it from inside the zip.
2. **Double-click `run.bat`** in the folder. The first start is slow (a few minutes): it finds or installs Python and Node, creates a private Python environment, and installs the backend and frontend packages. Later starts take seconds.
3. Two windows open (a backend and a frontend). Your browser opens **http://localhost:5173**. Keep both windows open while you work; closing them stops the app.
4. **Optional desktop icon:** double-click `Install Desktop Icon.bat`. It creates **Alpha Sentry** and **Stop Alpha Sentry** on your Desktop.
   - **Alpha Sentry** starts the app quietly in the background (one port, 8766), builds the interface the first time, and opens it in its own window.
   - Closing that window leaves the app (and any running Autosentry) going. **Stop Alpha Sentry** ends it.
   - Logs are in the `logs` folder. If you move the folder, run `Install Desktop Icon.bat` again.
5. **Very long folder paths:** Windows breaks setup when the folder path is long (for example inside a WhatsApp transfers folder). Run.bat now detects this and copies the app to a short folder (`%LOCALAPPDATA%\AlphaSentry\app` or `C:\AlphaSentry`) automatically. Best practice: unzip to something short like `C:\AlphaSentry`. If setup still fails, send `logs\setup_error.txt` and `logs\pip.log`.
6. **Upgrading:** unzip the new version over the old folder. Your data is kept (see section 11). If you upgrade from an older build, delete any leftover `ACE Studio.vbs` and `Stop ACE Studio.vbs` and run `Install Desktop Icon.bat` again.

**If something does not start**
- A backend window that closes at once: open `logs\` and read the last lines.
- "network error — is the Alpha Sentry server running?" in the app: the backend window is closed or crashed; start it again.
- `ECONNREFUSED 8766` in the frontend window: the backend is not running. `run.bat` starts both.

---

## 3. First-time setup (5 minutes)

Open **Settings** (gear icon in the top bar).

1. **Add an LLM key.** Paste a key for one provider, press **Test key**, and wait for a green result. You can add several; the app falls back from one to the next.
2. **Log in to BRAIN.** Complete the login (your own session). If your account asks for the biometrics scan, follow the link shown. The session lasts about **4 hours**; Alpha Sentry shows the time left and can ask you to renew it (see Telegram, section 9).
3. **Choose light or dark** and set your own **tags** (the labels put on the alphas you simulate).
4. Optional: **Telegram** (section 9) so you can control runs and receive winners from your phone.

The colours follow an eye-comfort scheme: soft charcoal in dark mode, warm cream in light mode, and a muted teal accent used only on small controls.

---

## 4. The layout

A sidebar on the left groups the screens; the top bar holds Settings and the BRAIN session status. Everything on a screen follows your **context** (region, universe, delay) chosen in Data Explorer.

| Sidebar group | Screens |
|---|---|
| Overview | Command Center |
| Research | Data Explorer · Strategy Lab · Prompt Library |
| Build | Template Studio · Alpha Lab · **Autosentry** · **Supersentry** · Alpha Translation · BRAIN Prompts |
| Run | Simulation · SuperAlpha · **SentryEngine** |
| Analyse | Results & Analytics · Alpha Vault · Correlation & Portfolio · Operator Atlas · R & U Atlas |

**The names:** Alpha Sentry is the whole app. **Autosentry** is the autonomous alpha finder. **Supersentry** is its SuperAlpha version. **SentryEngine** is the batch engine with its labs, tasks and planning.

---

## 5. The research workflow, step by step

### 5.1 Command Center
Your dashboard: live success rate, how many alphas are submittable, diversity, and the next best actions. Start here each day.

### 5.2 Data Explorer — choose what to work on
1. Pick the **context**: region, universe, delay.
2. **Fetch** datasets and fields from BRAIN (they are always read live; MATRIX and VECTOR fields are marked).
3. Narrow with the family prefix filter and presets, then **select** the fields you want (select-all and random are available).
Your selection is what Autosentry and the generators build around.

### 5.3 Strategy Lab and Prompt Library
- **Strategy Lab:** per-field and per-category hypotheses and suggested operators, which you can send straight to Alpha Lab.
- **Prompt Library:** save the dataset-focused prompts you like and export them.

### 5.4 Template Studio
Write templates with `{field}` and `{field2}` placeholders. It checks the syntax as you type, completes operators with Tab, and can ask the LLM for variants.

### 5.5 Alpha Lab
Turns a hypothesis (typed, or from a research paper) into validated expressions. It repairs invalid ones and steers away from ideas you already have, then lets you push them to Simulation.

### 5.6 Simulation — test expressions
1. Paste or send expressions in.
2. Choose universes, neutralizations, tags and concurrency.
3. Run. Results are judged against the **success gate** (section 12).
Nothing is submitted to BRAIN from here; submitting is always your own action on the BRAIN site.

### 5.7 SuperAlpha
Builds selections of at least 10 components, counts them, and simulates combos, in its own separate workspace.

### 5.8 BRAIN Prompts
Build the prompt text for BRAIN's LLM-prompt submissions, check the sample output, and keep the form fields.

---

## 6. Autosentry — the autonomous finder

**Winners are always kept and announced:** every alpha Autosentry finds is tagged in BRAIN, saved to the Alpha Vault (from its stored result, or from what Autosentry has if that is missing), added to the library and sent to your Telegram chat as a normal, non-silent message with Sharpe, fitness, turnover, prod and self correlation and the expression. A step that fails never stops the others, and the log says which one failed. No Telegram message is sent until the bot token and chat ID are saved in Telegram setup. **Prod rescue limit:** when an alpha fails only on production correlation, Autosentry tries to fix it, but not when the correlation is above 0.74 (setting "Skip prod rescue above"); those are logged and skipped.

**Pace:** each round tests one batch of 10 alphas ("Batches per round" = 1; raise it to run several batches of 10 side by side). Production-correlation checks run one at a time with a wait before each ("Prod check delay", 60 seconds by default; 0 turns the wait off and checks up to 4 at once). With the wait on, a round that has several passers takes that many minutes longer, which is the point: it keeps BRAIN from being asked for many correlation checks at once.

Region, Delay and Universe are dropdowns at the top of Autosentry, Supersentry and every SentryEngine screen. They list the markets you have data for on this computer (datasets pulled in the Data Catalog, alphas already simulated, fields downloaded), plus BRAIN's own list when it is loaded, so they work offline.

Autosentry runs by itself: it forms hypotheses from your selected fields, writes templates, simulates batches of 10, runs the full BRAIN check (including correlations), asks the LLM to refine, and repeats until an alpha passes **everything**. It keeps going until you press **Stop**.

**To use it**
1. Select fields in Data Explorer first.
2. Open **Autosentry** and press **Start Autosentry**.
3. Watch the phase, cycle and round, the current hypothesis, how many alphas were simulated, and the winners list.
4. Use **Stop** to end it after the current step.
5. **Reverse and boost rule:** an alpha is reversed only when its Sharpe is below −1, and every alpha with Sharpe above 1 is boosted (that one threshold is the rule; a booster's own limit is ignored). These follow-ups never run on their own. They ride along in the next standard batch of 10, with at least 20% to 40% of the slots kept for new ideas (fewer when strong candidates are waiting).
6. **Boosters:** a booster wraps an alpha, for example `group_neutralize({alpha}, industry)`. If your Library has no booster for the region, Autosentry uses built-in starters (neutralize industry, subindustry and sector; decay 5 and 10; rank; zscore; liquid days only). They live in the program, never in your Library, and yours replace them as soon as you add any. Each alpha gets the 3 most promising boosters, ranked by what each has actually added before and by the check the alpha failed (turnover → smoothing, correlation → neutralization, and so on), plus one less-tested booster so new ones still get a chance. A booster that keeps hurting is retired. A boosted alpha that gained at least 0.1 Sharpe can be boosted once more (never more than twice). Promising alphas also get two **window nudges** (shorter and longer first window). Optional switches: boost passing alphas too, and boost near-misses.
7. **Test many ideas:** each idea gets one batch of 10. If the best alpha in it has |Sharpe| below 0.5 (a strongly negative one still counts, it can be reversed), the idea is dropped and the next one starts; promising ideas keep going for up to 4 rounds. The LLM is asked for 8 ideas at a time. If you have used the Osmosis Planner, the ideas are steered toward datasets and mechanisms your scope is short of.
9. **Clone and swap (method switch):** at the top of the Autosentry panel, switch from *Explore ideas* to *Clone and swap*. It takes your old alphas (submitted and/or the Alpha Vault, in this region and delay, above a minimum Sharpe), keeps each one's operators and windows, and swaps its datafield for **similar** datafields from the Data Catalog: similarity is a text match on the field id and description, only fields of the same type (MATRIX or VECTOR) are used. The **similarity slider** runs from "same dataset" (closest idea, likely correlated with the original) to "other datasets" (more likely to pass prod correlation). Swaps run in batches of 10, with the usual reverse, boost and nudge follow-ups, then the full BRAIN check including prod and self correlation. **My own working alphas:** paste alphas of your own into the box in the Clone panel (one per line; a blank line separates alphas, and an alpha may span several lines while its brackets are open or its lines end in `;`; anything after `#` is ignored). They are cloned first, whatever their Sharpe, are not limited by region, delay or the alpha-id filter, and can be used on their own by switching Submitted alphas and Alpha Vault off. A live line under the box says how many can be swapped (an alpha needs at least one datafield that is in the Data Catalog for this region and delay). Your pasted text is remembered on this computer. Winners go to the vault with a note such as "cloned from ABC123: field_a -> field_b". You do not need to pick datafields in Data Explorer for this mode, but the Data Catalog must hold the datafields for the scope. It ends when every planned swap has been tested.
8. **Reading the log:** after every batch a line says how many alphas were above the threshold, how many boosters were used and where they came from, and how many reversals, boosts and nudges were queued, or why nothing was. When the run stops, a summary lists ideas tested, boosts that helped, and the best booster. Three failed cycles in a row send you a Telegram message.

**Library (inside Autosentry).** Your personal library of alphas and boosters, plus lessons learned.
- Each alpha and booster has a row of **region ticks**. All ticked (the default) means it is used everywhere; untick regions to restrict it; untick all to park it.
- The bar above the list ticks or unticks a region for everything at once (the n/total pills show the state; a dashed pill means "some").
- **Show only those used in <region>** filters the list.
- When you add something, choose its regions on the spot.
- A new installation starts with an **empty** library and no lessons, so yours grows from your own work.

**Supersentry** is the same idea for SuperAlphas (selections and combos). It shares BRAIN's simulation slots with Autosentry, so run one at a time.

**Supersentry prod check.** Every alpha that clears your minimum Sharpe and fitness is checked for production correlation, the same way Autosentry does it: one at a time, waiting *Prod check delay (s)* (default 60) before each; 0 checks up to 4 at once. An alpha whose prod correlation is already in Results is not checked again; the stored value is used.

---

## 7. Alpha Translation — Fast Expression to Python Alpha

1. Paste a **Fast Expression**.
2. Set the simulation settings (they default to your context; keep them the same as the original so the comparison is fair).
3. Press **Translate to Python**. It works in **one click**: the translation guidelines are built in (your checklist plus the full BRAIN article, included word for word).
4. The Python code appears (you can edit it) with a **port checklist** under it: field types, operators the guideline does not cover, and the cold-start days.
5. **Simulate** the Python alpha and the original side by side; the table shows both and the difference.
6. If BRAIN reports an error, press **Send error back to the LLM to fix**.

**Guideline:** "View / edit guideline" shows the built-in text. Save your own to override it; **Restore built-in** brings the original back.
Remember to tag the translated alpha with the original alpha's ID.

---

## 8. SentryEngine — batch engine, labs, tasks, planning

SentryEngine is an optional power layer. Everything in it is **off by default** and **never submits** anything to BRAIN: it only simulates, scores and queues. Results land in Results & Analytics with the tag `harness`.

### 8.1 Control tab
- **Feature flags:** turn on "SentryEngine + labs" first. Other switches enable the returns vault, LLM labs, planning and the options below.
- **Batch engine:** Start / Stop, the queue (queued, running, done, scored), and the 8 shared BRAIN slots.
- **Reset engine:** a clean slate in one press. It cancels everything queued or running in SentryEngine, stops all its search tasks, clears its region focus, crash journal and learned slot limit, gives back its slots and starts a fresh engine. Your results, the vault, your library and Autosentry's own running batches are not touched, and nothing is submitted. Simulations already sent to BRAIN are abandoned (BRAIN finishes them on its own). Tasks stay listed as stopped; create them again to rerun.
- **Follow Autosentry's region (on by default):** SentryEngine always works on the region chosen in Autosentry. When you change that region, and at every engine tick after, queued simulations for any other region are dropped immediately and their search tasks are paused (the engine log says how many). Batches already running at BRAIN finish normally. Untick "Always follow the region chosen in Autosentry" in Queue by region to go back to parking other regions instead (kept, not dropped), or to work on a region by hand.
- **Queue by region:** the queue is shared by every region, and one BRAIN batch can only hold one region. Pick the region you are working on and press **Work on this region**: the engine then only starts that market, other regions are *parked* (kept, not lost), and with the tick box on their queued simulations are dropped and their search tasks paused (Resume brings a task back). **Drop** on a row (or **Drop everything**) removes that region's queued simulations and abandons the ones already sent to BRAIN: the engine stops waiting for them, frees their slots and ignores their results (BRAIN itself finishes what it started, and a dropped simulation can never come back into the queue). Autosentry's own batches are never touched. If the engine ever looked stuck after a region change, this is why: it was still working through the old region's queue.
- **Yield by lab:** how many passing alphas each lab produced recently.
- **Autosentry speed:** with "Autosentry via engine" on, each Autosentry round can run more batches side by side (up to 8, versus Alpha Sentry's own 3). It lowers itself when BRAIN says it is busy, and lets a very slow batch finish on its own so a round is not held back.
- **Shipped data:** every version carries a copy of the dataset and field catalogue, and the operator reference. It contains no one's alphas, results, vault or library. On start, rows your database lacks are added (never changed or removed), after a one-time backup in the data folder. This does **not** include any Library data.

### 8.2 Tasks
Create a search task: write one template with `$variables`; a sampler (random, grid, Sobol, NSGA-II/III, TPE, CMA-ES) chooses which combinations to simulate and learns from results. **Power Pool** mode keeps every alpha within 8 operators and 3 data fields. Preview first: it shows the size of the space, sample alphas and any problems before anything is queued. Tasks can be paused, resumed or stopped.

### 8.3 Deepen
Takes one winning alpha and builds a template exploring around it (neighbouring windows and wrappers). Use it to find out whether a winner is real or a lucky setting.

### 8.4 Evolution
A genetic search from your winners: swaps operators and fields, changes windows, crosses two alphas, and keeps the best under your objectives and limits.

### 8.5 Invent
Your LLM proposes new templates or ideas. Each is checked before it can be queued; invalid ones are listed with the reason.

### 8.6 Labs
| Lab | What it does | Use it when |
|---|---|---|
| Relocate | Runs formulas that work in one market in the others (skips markets lacking a needed field) | A winner exists in one market |
| Repair | One targeted fix per near-miss, chosen from the check it failed | Many alphas almost pass |
| Harden | Nudges a winner's windows and wrappers to see if it holds | Before trusting a winner |
| Harvest | Sensible patterns over the best fields of each dataset | Cheap, broad exploration |
| Diversify | Uses only fields from datasets none of your alphas use | Your alphas are too alike |
| Pair | Cross-dataset field pairs in a few relational shapes | You want combinations of signals |

Every lab has **Preview** (nothing queued) and **Run** (queues simulations in the engine).

### 8.7 Mixing
Finds alphas that combine well, using stored daily returns and their correlations, and can queue the mixes as simulations.

### 8.8 Planning
Splits each day's simulation budget between labs according to how well each has produced passing alphas, keeping a share for exploration. The daily plan explains itself in words and lists alpha shapes already answered so labs do not repeat them.

### 8.9 Guide tab
A built-in explanation of every feature: what it does, when to use it, what it needs, and what it produces.

### 8.10 Slots, Results and prod checks
**Simulation slots (Control).** Eight tiles show who holds each slot: an engine task, Autosentry or Supersentry, with region, number of simulations and time elapsed. A tile turns amber when its batch has run for over 20 minutes. Click a busy engine tile to abandon that batch (BRAIN finishes it, the engine ignores the result). The queue per region sits just below.

**Results tab → Missing results.** Lists every engine simulation that never reached Results with one plain-English reason (rejected by BRAIN with its message, timed out, dropped by you, reset, never scored, and so on), counts per reason, and a search by alpha id or expression. **Score now** reads BRAIN (no simulation quota); **Requeue** puts it back in the queue.

**How engine results are scored.** As soon as a batch finishes the engine pulls the stats of every alpha in it: Sharpe, fitness, turnover, returns, drawdown, margin, BRAIN's own tests and the self correlation, but NOT the production correlation. The alphas that pass the gate wait in **Ready for prod check**; the rest go to **Did not pass**. You run prod only on the first group (Check prod / Check selected), and an alpha that clears it moves to **Passed incl. prod** and only then gets your winner tag. An alpha that fails prod moves to **Did not pass** with the reason. The Results tab shows SentryEngine results on their own by default; Autosentry and Supersentry results are a separate choice in the source box.

**Results tab → Alpha stats.** All alphas with region, delay, universe, neutralization, Sharpe, fitness, turnover, returns, drawdown, margin, self / prod / power-pool correlation, failed checks and source (engine task, Autosentry or Supersentry). **Colours:** grey = no stats yet (use Score now), yellow = passed the gate, prod not checked yet, green = passed everything including prod, purple = failed (gate or prod, the reason is shown). The batch box limits the table to one batch and shows how many of its alphas are in each colour. If a Score button reports failures, the toast now names the alpha and the reason. Click a column to sort; filter by region, passing, prod state, source; search. Alphas BRAIN made that are not in Results show in red at the top.
- **Check prod** on a row runs one BRAIN submission check and saves it to Results. No simulation is used and nothing is submitted.
- **Check selected** checks the ticked rows one after another, waiting 60 s (editable) before each, with **Stop**. Already-checked alphas are skipped unless "Re-check already checked" is ticked.
- Prod correlation above 0.70 is red; above 0.74 it is marked "too high" (not worth fixing).

**Autosentry and the BRAIN session.** When the session ends, Autosentry stops completely (everything in flight is abandoned), sends you ONE Telegram link, and restarts by itself with the same settings once you verify. Pressing Stop while it waits cancels the restart. **Stop if stuck for (min)** (default 30, 0 = off): if one step makes no progress for that long, Autosentry stops, abandons everything in flight and sends you the details on Telegram (what it was doing, the last events, the batches abandoned). It does not restart by itself after a stall.

**Filters and pages.** Alpha stats and the Missing list both filter by region and by From / To date (Alpha stats: the date the result was stored; Missing: the date of the last activity). When there are more than 200 results a page bar appears with First, Previous, Next and the range shown. **Pull stats now (up to 2000)** pulls every missing alpha matching the current filters, up to 2000 in one run, not only the page you see.

**Prod check log.** Under the prod check buttons a black log window shows every step with the time: the wait before each alpha, the call to BRAIN, then prod, self and power-pool correlation with GREEN or PURPLE and any failed checks, or the exact error. It also shows when a run is stopped or done.

**Pull stats now (Results → Missing).** Pulls the stats of the alphas shown in the Missing list from BRAIN, one at a time, without any correlations (Sharpe, fitness, turnover, returns, drawdown, margin and BRAIN's own tests). A black log window under the buttons shows every step: which alpha is being asked, its Sharpe and fitness, the resulting colour (or the exact reason it failed) and how long it took. Stop ends it after the current alpha. Alphas without an alpha id cannot be pulled; use Requeue for those.

**Operator Atlas.** Autosentry now gives the LLM every REGULAR operator of the Operator Atlas when it designs templates (your edited rows first, with your examples and notes; `bucket` and `vec_*` are left out because they are handled elsewhere). Supersentry already used the atlas for combos and now also for selections. Edit an operator in the Atlas and the next prompt uses it.

**Osmosis allocator.** Only the best 10 alphas of each region and delay (each scope separately, after removing highly correlated ones) get points ("Best alphas per scope", 0 = no limit). Set **Consultant since** and USA alphas submitted before that date are treated as uncompensated: they get no points, and any points they hold are released at once (not moved gradually). Until the date is set the plan says so and the rule is off.

**More LLM providers (Settings → LLM providers).** The key list now has a "Free and extra providers" group: Cerebras, SambaNova, NVIDIA NIM, Cohere, GitHub Models, Cloudflare Workers AI (also needs your account ID), Zhipu/GLM, SiliconFlow, Moonshot (Kimi), Alibaba DashScope (Qwen), Fireworks, DeepInfra, Hyperbolic, Nebius, Novita, Perplexity, MiniMax, Chutes, Kluster.ai, glhf.chat, and local servers: 9Router, Ollama, LM Studio, vLLM and llama.cpp. Pick one, paste its key, Save. Each shows a short note about its free tier (these change, check the provider's page). For a local server no real key is needed: type any word as the key to switch it on. The address of any of them can be changed (for example 9Router or Ollama on another computer) and reset. **Your own provider** adds any OpenAI-compatible service by name, address, optional key and model. Pick the provider and its model in the same screen, then press Test Key. Autosentry and Supersentry use whichever provider is active. Not covered: Azure OpenAI, Amazon Bedrock and Google Vertex AI (they need different sign-in).

**Clone and swap** now ignores Python alphas (submitted, vault and pasted) and logs "skipped N Python alpha(s)".

**Typical first session:** Control → turn on "SentryEngine + labs" → Labs → pick one lab → **Preview** → **Run** → Control → **Start** the engine → watch Results.

---

## 9. Telegram remote control

Set it up once in the Autosentry panel (Telegram setup): create a bot with BotFather, paste its token, use **Find my chat ID**, and send a test. Only your own chat is obeyed; anyone else is ignored.

| Command | What it does |
|---|---|
| `/menu` | Buttons for everything below |
| `/status` | What is running, round, winners, session time left, and the SentryEngine line |
| `/winners` | Latest winners |
| `/start regular` · `/start super` | Start Autosentry or Supersentry with their last settings |
| `/stop` · `/restart` | Stop, or stop and start again |
| `/switch regular` · `/switch super` | Stop the running one and start the other |
| `/settings` · `/set <setting> <value>` | View or change settings (`/neut FAST,SLOW`, `/region DEU`) |
| `/refresh` · `/session` | Renew the BRAIN session now · time left |
| `/engine` | SentryEngine status: switch, running, slots, queue, running tasks |
| `/engine on` · `/engine off` | The "SentryEngine + labs" switch |
| `/engine start` · `/engine stop` | Start or stop the batch engine (stop lets running batches finish) |
| `/engine score` | Score finished simulations into Results now |
| `/tasks` · `/task pause|resume|stop <id>` | List tasks · control one |

When your BRAIN session expires, Autosentry pauses and Telegram sends the biometrics link. Nothing is ever submitted to BRAIN from Telegram.

---

## 10. Analysing results

- **Results & Analytics:** every simulation with per-metric verdicts; filter, sort, export CSV, and see which operators perform.
- **Alpha Vault:** the alphas you keep, with their returns.
- **Correlation & Portfolio:** pairwise PnL correlation, and the largest set you can submit together.
- **Operator Atlas** and **R & U Atlas:** operators with your own usage overlaid; regions and universes with market notes and cross-region transfer.
- **Data Catalog:** see below.
- **Osmosis Planner:** see below.

### Data Catalog

A one-time download of datasets and datafields from BRAIN, by region, delay and category, kept on your computer in the database that Autosentry, Clone and swap and SentryEngine all read. The app ships with USA, GLB and GBR delay 1 only; use this to add the others (USA delay 0, ASI, IND, and so on).

1. Open **Data Catalog**, press **Load regions** and tick the region and delay combinations you want.
2. Optional: **Load categories for selected**, then tick the categories you want. None ticked means all.
3. Press **Download from BRAIN**. Datasets you already downloaded are skipped, so it is a one-time download; stop it any time and run it again to resume. Tick "download again" to refresh everything. It only adds and updates rows, never deletes yours.
4. **Browse** by region, delay, type, category, dataset or text, and **Export CSV / Excel** for what the filters show.

### Osmosis Planner

Reads every submitted alpha on your BRAIN account and proposes the Osmosis point allocation. Reading is read-only. The only thing it ever writes to BRAIN is the Osmosis points on your alphas, and only when you press **Implement on BRAIN**. It never submits an alpha.

1. Open **Osmosis Planner** (Analyse) and press **Read my alphas from BRAIN**. It lists your submitted alphas and downloads their daily PnL. Later reads only re-download PnL older than about a day; **Full refresh** re-downloads everything.
2. The planner groups alphas by scope (region and delay) and screens each one: it drops alphas that lose about 60% of their Sharpe under investability constraints (unless they are the only alpha on their dataset), alphas with turnover above 20% unless their constrained Sharpe is robust, and alphas too correlated (above 0.70) with a better one.
3. A scope **qualifies** when at least 10 alphas pass. Only qualifying scopes get an allocation of exactly 100,000 points, spread by inverse volatility with caps per alpha, dataset, category, neutralization, operator and high-turnover share.
4. BRAIN needs at least 3 allocated scopes. Only allocated scopes count toward your daily Osmosis rank, so a weak scope (combo Sharpe below 1) is left out unless it is needed to reach 3.
5. Scopes that do not qualify show how many alphas they are short and which datasets they use, so you know what to find next.
6. **Edit and implement.** The points in each scope are suggestions you can change. Each scope shows its total live (it must be exactly 100,000 over at least 10 alphas); **Balance to 100,000** rescales your numbers to fit, and **Reset to suggestion** goes back. Tick the scopes you want (at least 3). **Implement on BRAIN** asks you to confirm, checks everything again, writes the points, then reads BRAIN back and shows each scope's total. The first write is read back before the rest are sent; if BRAIN does not keep it, nothing else is changed. Alphas in those scopes that are not in your allocation have their points cleared. **Undo last** restores the previous points.
7. **Download plan (CSV)** gives scope, alpha id, points and previous points if you prefer to enter them yourself.

Notes: BRAIN may not return your current points; paste them under Settings if you want the plan to move gradually (at most 20,000 points per scope at a time). Dataset names are inferred from the first datafield in each expression, and the investability-constrained Sharpe is used only when BRAIN returns it. The plan is an estimate from your own alphas' PnL; it cannot reproduce your rank against other consultants. Allocations lock every Sunday 23:59 EST.

---

## 11. Your data, backups and privacy

| What | Where |
|---|---|
| Database (results, library, settings) | the `data` folder, file `ace_studio_v2.db` (the name is kept so existing data keeps working) |
| Backups before a data merge | `data\backups` |
| Logs | `logs` |
| BRAIN session | `session.pkl` (outside the database, never leaves your computer) |
| API keys | your user folder, in a keys file outside the app |

- Everything stays on your computer. Only your LLM provider and BRAIN receive requests.
- To back up: copy the `data` folder while the app is stopped.
- To start completely fresh: stop the app and move the `data` folder away.

---

## 12. The success gate

An alpha counts as a verified success only when **every** check passes, in absolute value: Sharpe, Fitness, Turnover below 0.70, no in-sample test failures, and (with the submission check) self, production and power-pool correlation all below 0.70. Defaults depend on delay (delay 0: Sharpe 2.69 and Fitness 1.5; otherwise 1.58 and 1.0) and can be edited.

---

## 13. Troubleshooting

| Problem | What to do |
|---|---|
| App will not open | Make sure the backend window is open; run `run.bat` again |
| "Session expired" or missing | Settings → log in to BRAIN again, or `/refresh` in Telegram |
| A key test fails | Re-paste the key, check the provider's credit, try another provider |
| Autosentry rounds are slow | SentryEngine → Control → turn on "Autosentry via engine" and review its speed |
| SentryEngine buttons do nothing | Turn on "SentryEngine + labs" in Control first |
| Telegram does not answer | Check the token and chat ID in Telegram setup; only the private chat you registered is answered |
| SentryEngine is stuck and nothing helps | Control → Reset engine (clean slate; your results are kept) |
| SentryEngine seems stuck after changing region | Control → Queue by region → pick the region and press "Work on this region" (or "Drop" for the old one). A batch BRAIN never finishes is now given up after 90 minutes so its slot is freed |
| Clone and swap stops with "Nothing to swap" | The log now says why: the source alphas' datafields are not in the Data Catalog for this region/delay (download that category), every swap was already simulated (raise swaps per alpha or move the slider), or no similar field exists. It widens the search once before stopping |
| 429 / "slots busy" from BRAIN | You are at BRAIN's limit; the app slows down by itself; do not run Autosentry and Supersentry together |
| Desktop icon does nothing | Run `Install Desktop Icon.bat` again from the current folder |

---

## 14. Quick reference

**Daily routine:** Command Center → Data Explorer (pick fields) → Autosentry Start → check Telegram `/status` → review winners in Results → Correlation & Portfolio before you decide what to submit on BRAIN.

**Rules that never change:** nothing is submitted to BRAIN by the app; your keys and session stay on your computer; SentryEngine is off until you turn it on.
