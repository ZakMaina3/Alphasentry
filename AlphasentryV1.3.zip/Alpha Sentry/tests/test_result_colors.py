"""Colour code of Results rows, batch grouping and visible scoring errors."""
import sys, tempfile, time, json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from app.harness import alphas as AL
from app.harness import scoring as SC


def test_colour_rules():
    c = AL.color_state
    assert c({"sharpe": None, "fitness": None}) == "grey"
    assert c({"sharpe": 1.5, "fitness": 1.1, "passed_gate": 1, "prod_corr": None}) == "yellow"
    assert c({"sharpe": 1.5, "fitness": 1.1, "passed_gate": 1, "prod_corr": 0.4}) == "green"
    assert c({"sharpe": 1.5, "fitness": 1.1, "passed_gate": 1, "prod_corr": -0.4}) == "green"
    assert c({"sharpe": 1.5, "fitness": 1.1, "passed_gate": 1, "prod_corr": 0.8}) == "purple"       # failed on prod
    assert c({"sharpe": 0.5, "fitness": 0.2, "passed_gate": 0, "prod_corr": None}) == "purple"      # missed the gate


def test_rows_carry_state_and_batch_and_batch_summary():
    from ace_db import make_store
    with tempfile.TemporaryDirectory() as t:
        s = make_store(t)
        now = time.time()
        for aid, sh, passed, prod in (("A", 1.5, 1, None), ("B", 1.6, 1, 0.3), ("C", 0.4, 0, None)):
            s.execute("INSERT INTO sim_results (created_at, alpha_id, expression, region, delay, universe, neutralization, sharpe, fitness, prod_corr, passed_gate)"
                      " VALUES (?,?,?,?,?,?,?,?,?,?,?)", (now, aid, "x", "USA", 1, "TOP3000", "SUBINDUSTRY", sh, 1.1, prod, passed))
        for i, aid in enumerate(("A", "B", "C", "D")):      # D finished but has no stats yet
            s.execute("INSERT INTO harness_sim_record (task, payload_hash, payload, status, batch_id, alpha_id, created, updated) VALUES (?,?,?,?,?,?,?,?)",
                      ("t1", "h" + aid, "{}", "done", "b1", aid, now, now))
        rows = {r["alpha_id"]: r for r in AL.list_alphas(s, source="engine")["rows"]}
        assert [rows[k]["state"] for k in "ABC"] == ["yellow", "green", "purple"] and rows["A"]["batch"] == "b1"
        assert [r["alpha_id"] for r in AL.list_alphas(s, batch="b1")["rows"]] != []
        assert AL.list_alphas(s, batch="nope")["total"] == 0
        b = AL.batches(s, "engine")[0]
        assert (b["batch_id"], b["size"], b["yellow"], b["green"], b["purple"], b["grey"]) == ("b1", 4, 1, 1, 1, 1)


def test_scoring_failures_are_reported_with_their_reason():
    from ace_db import make_store
    with tempfile.TemporaryDirectory() as t:
        s = make_store(t)
        s.execute("INSERT INTO harness_sim_record (task, payload_hash, payload, status, batch_id, alpha_id, created, updated) VALUES (?,?,?,?,?,?,?,?)",
                  ("t1", "hz", json.dumps({"regular": "rank(x)"}), "done", "b1", "ZZ", time.time(), time.time()))
        def boom(aid, sd):
            raise RuntimeError("session expired")
        errs = []
        r = SC.score_pending(10, fetch=boom, store=s, learn=None, winner={}, tagger=lambda *a: None, errors_out=errs)
        assert r == {"scored": 0, "failed": 1} and "session expired" in errs[0]["error"] and errs[0]["alpha_id"] == "ZZ"


def test_pull_run_pulls_one_by_one_logs_and_skips_records_without_alpha_id():
    from ace_db import make_store
    with tempfile.TemporaryDirectory() as t:
        s = make_store(t)
        now = time.time()
        for aid in ("P1", "P2", ""):
            s.execute("INSERT INTO harness_sim_record (task, payload_hash, payload, status, batch_id, alpha_id, created, updated) VALUES (?,?,?,?,?,?,?,?)",
                      ("t1", "h" + aid + "x", json.dumps({"regular": "rank(x)", "settings": {"delay": 1}}), "error" if aid == "P2" else "done", "b", aid, now, now))
        ids = [r["id"] for r in s.query("SELECT id FROM harness_sim_record ORDER BY id")]
        calls = []

        def fetch(aid, sd):
            calls.append(aid)
            if aid == "P2":
                raise RuntimeError("BRAIN said no")
            import pandas as pd
            return {"is_stats": pd.DataFrame([{"sharpe": 1.6, "fitness": 1.2, "turnover": 0.2, "returns": 0.1, "margin": 5, "drawdown": 0.05}]),
                    "is_tests": pd.DataFrame(), "check_submission": pd.DataFrame()}

        def score(limit, errs, only):
            return SC.score_pending(limit, fetch=fetch, store=s, learn=None, winner={}, tagger=lambda *a: None, errors_out=errs, only_ids=only)

        pr = AL.PullRun()
        st = pr.run(s, ids, score=score, delay=0, sleep=lambda x: None)
        assert calls == ["P1", "P2"]                                   # one by one, the id-less record is skipped
        assert (st["ok"], st["failed"], st["total"], st["running"]) == (1, 2, 3, False)
        log = "\n".join(st["log"])
        assert "P1" in log and "YELLOW" in log and "BRAIN said no" in log and "no alpha id" in log
        assert s.query("SELECT 1 FROM sim_results WHERE alpha_id='P1'") and not s.query("SELECT 1 FROM sim_results WHERE alpha_id='P2'")


def test_a_not_null_column_without_default_does_not_break_scoring():
    """The real Alpha Sentry table has submitted NOT NULL with no default: scoring must still store the row."""
    import sqlite3
    from app.harness.store import Store
    with tempfile.TemporaryDirectory() as t:
        from ace_db import make_store
        s = make_store(t)
        with s.connect() as c:
            c.execute("DROP TABLE sim_results")
            c.execute("CREATE TABLE sim_results (id INTEGER PRIMARY KEY, created_at FLOAT NOT NULL, alpha_id VARCHAR NOT NULL, expression VARCHAR NOT NULL DEFAULT '', "
                      "sharpe FLOAT, fitness FLOAT, passed_gate BOOLEAN, submitted BOOLEAN NOT NULL, note VARCHAR NOT NULL)")
        d = s.required_defaults("sim_results")
        assert d["submitted"] == 0 and d["note"] == "" and "expression" not in d and "id" not in d
        s.execute("INSERT INTO harness_sim_record (task, payload_hash, payload, status, batch_id, alpha_id, created, updated) VALUES (?,?,?,?,?,?,?,?)",
                  ("t1", "h", json.dumps({"regular": "rank(x)"}), "done", "b", "Q1", time.time(), time.time()))
        import pandas as pd
        fetch = lambda a, sd: {"is_stats": pd.DataFrame([{"sharpe": 1.6, "fitness": 1.2, "turnover": 0.2, "returns": 0.1, "margin": 5, "drawdown": 0.05}]),
                               "is_tests": pd.DataFrame(), "check_submission": pd.DataFrame()}
        errs = []
        r = SC.score_pending(5, fetch=fetch, store=s, learn=None, winner={}, tagger=lambda *a: None, errors_out=errs)
        assert r == {"scored": 1, "failed": 0} and errs == [] and s.query("SELECT submitted FROM sim_results WHERE alpha_id='Q1'")[0]["submitted"] == 0


def test_prod_check_run_keeps_a_readable_log():
    from ace_db import make_store
    import pandas as pd
    with tempfile.TemporaryDirectory() as t:
        s = make_store(t)
        for aid in ("G1", "P1", "E1"):
            s.execute("INSERT INTO sim_results (created_at, alpha_id, expression, region, delay, universe, neutralization, sharpe, fitness, passed_gate) VALUES (?,?,?,?,?,?,?,?,?,?)",
                      (time.time(), aid, "x", "USA", 1, "TOP3000", "SUBINDUSTRY", 1.6, 1.2, 1))

        def fetch(aid):
            if aid == "E1":
                raise RuntimeError("timeout")
            v = 0.3 if aid == "G1" else 0.8
            return pd.DataFrame([{"name": "PROD_CORRELATION", "result": "PASS", "value": v, "limit": 0.7}, {"name": "SELF_CORRELATION", "result": "PASS", "value": 0.2, "limit": 0.7}])

        run = AL.CheckRun()
        st = run.run(s, ["G1", "P1", "E1"], delay=2, recheck=False, fetch=fetch, sleep=lambda x: None)
        log = "\n".join(st["log"])
        assert "waiting 2 s" in log and "G1: prod 0.300" in log and "GREEN" in log and "P1: prod 0.800" in log and "PURPLE" in log
        assert "E1: ERROR" in log and "timeout" in log and "done: 3 checked" in log


def test_date_and_region_filters_and_paging_in_results_and_missing():
    from ace_db import make_store
    from app.harness import diagnose as DG
    from app.harness.store import day_epoch
    with tempfile.TemporaryDirectory() as t:
        s = make_store(t)
        d1, d2 = day_epoch("2026-10-01") + 3600, day_epoch("2026-10-10") + 3600
        for aid, reg, ts in (("A", "USA", d1), ("B", "EUR", d1), ("C", "USA", d2)):
            s.execute("INSERT INTO sim_results (created_at, alpha_id, expression, region, delay, universe, neutralization, sharpe, fitness, passed_gate) VALUES (?,?,?,?,?,?,?,?,?,?)",
                      (ts, aid, "x", reg, 1, "TOP3000", "SUBINDUSTRY", 1.6, 1.2, 1))
        ids = lambda **k: sorted(r["alpha_id"] for r in AL.list_alphas(s, **k)["rows"])
        assert ids(date_from="2026-10-05") == ["C"] and ids(date_to="2026-10-05") == ["A", "B"]
        assert ids(date_from="2026-10-01", date_to="2026-10-01", region="usa") == ["A"] and ids(date_from="garbage") == ["A", "B", "C"]
        assert [r["alpha_id"] for r in AL.list_alphas(s, limit=1, offset=1, sort="created_at", desc=False)["rows"]] != [] and AL.list_alphas(s, limit=1)["total"] == 3
        for i, (reg, ts) in enumerate((("USA", d1), ("EUR", d1), ("USA", d2))):
            s.execute("INSERT INTO harness_sim_record (task, payload_hash, payload, status, alpha_id, created, updated) VALUES (?,?,?,?,?,?,?)",
                      ("t", f"m{i}", json.dumps({"regular": "x", "settings": {"region": reg}}), "done", f"M{i}", ts, ts))
        m = lambda **k: sorted(i["alpha_id"] for i in DG.missing(s, **k)["items"])
        assert m() == ["M0", "M1", "M2"] and m(region="usa") == ["M0", "M2"] and m(date_from="2026-10-05") == ["M2"]
        assert len(DG.missing(s, limit=2)["items"]) == 2 and len(DG.missing(s, limit=2, offset=2)["items"]) == 1 and DG.missing(s, limit=2)["total"] == 3
