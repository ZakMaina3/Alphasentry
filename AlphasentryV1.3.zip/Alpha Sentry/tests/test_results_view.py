"""Missing-results reasons and the alpha stats table with one-by-one prod checks."""
import sys, tempfile, time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from app.harness import diagnose as DG
from app.harness import alphas as AL


def test_reasons_are_plain_and_actionable():
    now = time.time()
    r = lambda **k: DG.reason_for({"updated": now, **k}, k.pop("in_results", False), now)
    assert DG.reason_for({"status": "scored", "alpha_id": "A", "updated": now}, True, now)["ok"]
    assert DG.reason_for({"status": "scored", "alpha_id": "A", "updated": now}, False, now)["code"] == "scored_missing"
    assert DG.reason_for({"status": "done", "alpha_id": "A", "updated": now}, False, now)["action"] == "score"
    old = now - 3 * 3600
    assert DG.reason_for({"status": "running", "updated": old}, False, now)["code"] == "running_stale"
    assert DG.reason_for({"status": "cancelled", "error": "engine reset", "updated": now}, False, now)["code"] == "reset"
    assert DG.reason_for({"status": "cancelled", "updated": now}, False, now)["code"] == "dropped"
    x = DG.reason_for({"status": "error", "error": "Invalid operator foo", "updated": now}, False, now)
    assert x["code"] == "rejected" and "Invalid operator" in x["label"]
    assert DG.reason_for({"status": "error", "error": "timed out after 90m", "updated": now}, False, now)["code"] == "timed_out"
    s = DG.summarize([DG.reason_for({"status": "cancelled", "updated": now}, False, now)] * 2)
    assert s == {"dropped": 2}


def _store(tmp):
    from ace_db import make_store
    return make_store(tmp)


def _add(s, aid, prod=None, region="USA", passed=1, tagged=""):
    s.execute("INSERT INTO sim_results (created_at, alpha_id, expression, region, delay, universe, neutralization, sharpe, prod_corr, passed_gate, tagged)"
              " VALUES (?,?,?,?,?,?,?,?,?,?,?)", (time.time(), aid, f"rank({aid})", region, 1, "TOP3000", "SUBINDUSTRY", 1.5, prod, passed, tagged))


def test_table_filters_and_prod_states():
    with tempfile.TemporaryDirectory() as t:
        s = _store(t)
        _add(s, "A", None); _add(s, "B", 0.5); _add(s, "C", 0.72); _add(s, "D", 0.9, region="EUR")
        s.execute("INSERT INTO harness_sim_record (task, payload_hash, payload, status, alpha_id, created, updated) VALUES ('t','h','{}','scored','A',1,1)")
        assert AL.list_alphas(s)["total"] == 4
        st = {r["alpha_id"]: r["prod_state"] for r in AL.list_alphas(s)["rows"]}
        assert st == {"A": "unchecked", "B": "ok", "C": "high", "D": "too_high"}
        assert [r["alpha_id"] for r in AL.list_alphas(s, prod="unchecked")["rows"]] == ["A"]
        assert AL.list_alphas(s, region="eur")["total"] == 1
        assert AL.list_alphas(s, q="rank(B")["total"] == 1
        assert AL.list_alphas(s, source="engine")["total"] == 1
        assert AL.list_alphas(s, sort="prod_corr", desc=True)["rows"][0]["alpha_id"] == "D"


class DF:
    def __init__(self, rows): self.rows = rows; self.empty = not rows; self.columns = ["name", "value", "result"] if rows else []
    def iterrows(self):
        for i, r in enumerate(self.rows): yield i, r
    def __getitem__(self, k): return [r[k] for r in self.rows]


def test_check_one_saves_and_handles_pending_and_errors():
    with tempfile.TemporaryDirectory() as t:
        s = _store(t)
        _add(s, "A"); _add(s, "B")
        ok = DF([{"name": "SELF_CORRELATION", "value": 0.3, "result": "PASS"}, {"name": "PROD_CORRELATION", "value": 0.8, "result": "FAIL"}])
        r = AL.check_one(s, "A", lambda a: ok)
        assert r["state"] == "too_high" and r["failed"] == ["PROD_CORRELATION"]
        row = s.query("SELECT prod_corr, self_corr, passed_gate FROM sim_results WHERE alpha_id='A'")[0]
        assert row["prod_corr"] == 0.8 and row["self_corr"] == 0.3 and row["passed_gate"] == 0
        assert AL.check_one(s, "B", lambda a: DF([]))["state"] == "pending"
        def boom(a): raise RuntimeError("down")
        assert AL.check_one(s, "B", boom)["state"] == "error"
        assert s.query("SELECT prod_corr FROM sim_results WHERE alpha_id='B'")[0]["prod_corr"] is None


def test_missing_view_counts_searches_and_per_simulation_errors():
    import json
    from app.harness.engine.match import match_errors
    pl = [{"regular": "a"}, {"regular": "b"}, {"regular": "c"}]
    rows = [{"alpha_id": "X", "simulate_data": {"regular": "a"}}, {"error": "bad op", "simulate_data": {"regular": "b"}}, {"error": "other"}]
    assert match_errors(pl, rows) == ["", "bad op", "other"]
    with tempfile.TemporaryDirectory() as t:
        s = _store(t)
        _add(s, "IN")
        def rec(status, aid="", err="", expr="x"):
            s.execute("INSERT INTO harness_sim_record (task, payload_hash, payload, status, alpha_id, error, created, updated) VALUES ('t',?,?,?,?,?,?,?)",
                      (expr + status, json.dumps({"regular": expr}), status, aid, err, time.time(), time.time()))
        rec("scored", "IN"); rec("cancelled", expr="drop-me"); rec("error", err="Invalid operator", expr="bad"); rec("done", "GONE")
        m = DG.missing(s)
        assert m["counts"] == {"dropped": 1, "rejected": 1, "done_unscored": 1} and m["total"] == 3
        assert DG.missing(s, q="drop-me")["total"] == 1
        assert DG.missing(s, code="rejected")["items"][0]["error"] == "Invalid operator"
        assert DG.missing(s, q="GONE")["items"][0]["action"] == "score"


def test_running_batches_and_abandon():
    import json
    from app.harness.engine.tracker import Tracker
    with tempfile.TemporaryDirectory() as t:
        s = _store(t)
        tr = Tracker(s, Path(t) / "j.jsonl")
        ids = tr.register_running("autopilot", [{"regular": "a", "settings": {"region": "USA", "delay": 1}}] * 2, "b1")
        b = tr.running_batches()
        assert len(b) == 1 and b[0]["size"] == 2 and b[0]["region"] == "USA" and b[0]["task"] == "autopilot"
        assert tr.abandon_batch("b1") == 2 and tr.running_batches() == []


def test_check_run_waits_before_each_check_skips_checked_and_stops():
    with tempfile.TemporaryDirectory() as t:
        s = _store(t)
        _add(s, "A"); _add(s, "B", 0.5); _add(s, "C"); _add(s, "D")
        ok = DF([{"name": "SELF_CORRELATION", "value": 0.3, "result": "PASS"}, {"name": "PROD_CORRELATION", "value": 0.4, "result": "PASS"}])
        naps, calls = [], []
        run = AL.CheckRun()
        def fetch(a): calls.append(a); return ok
        st = run.run(s, ["A", "B", "C"], delay=3, recheck=False, fetch=fetch, sleep=lambda n: naps.append(n))
        assert calls == ["A", "C"] and st["skipped"] == 1 and st["done"] == 2
        assert len(naps) == 6                       # 3 s before EACH check, the first included
        calls.clear()
        AL.CheckRun().run(s, ["B"], delay=0, recheck=True, fetch=fetch, sleep=lambda n: None)
        assert calls == ["B"]
        r2 = AL.CheckRun()
        n = []
        def nap(x):
            n.append(x)
            if len(n) == 2: r2.stop()
        st = r2.run(s, ["D", "A", "B"], delay=1, recheck=True, fetch=fetch, sleep=nap)
        assert st["message"] == "stopped" and st["done"] == 1


def test_known_alphas_missing_from_results_are_listed():
    import json
    with tempfile.TemporaryDirectory() as t:
        s = _store(t)
        _add(s, "IN")
        s.execute("INSERT INTO harness_sim_record (task, payload_hash, payload, status, alpha_id, created, updated) VALUES ('autopilot','h',?,'external','LOST',1,1)",
                  (json.dumps({"regular": "rank(x)"}),))
        m = AL.missing_rows(s, [{"alpha_id": "W1", "expr": "rank(y)", "prod_corr": 0.8}, {"alpha_id": "IN"}])
        ids = {r["alpha_id"]: r for r in m}
        assert set(ids) == {"LOST", "W1"} and ids["LOST"]["source"] == "Autosentry" and ids["W1"]["prod_state"] == "too_high"
        assert [r["alpha_id"] for r in AL.missing_rows(s, [], q="rank(x")] == ["LOST"]


def test_known_alphas_missing_from_results_are_listed():
    import json
    with tempfile.TemporaryDirectory() as t:
        s = _store(t)
        _add(s, "IN")
        s.execute("INSERT INTO harness_sim_record (task, payload_hash, payload, status, alpha_id, created, updated) VALUES ('autopilot','h',?,'external','LOST',1,1)",
                  (json.dumps({"regular": "rank(x)"}),))
        m = AL.missing_rows(s, [{"alpha_id": "W1", "expr": "rank(y)", "prod_corr": 0.8}, {"alpha_id": "IN"}])
        ids = {r["alpha_id"]: r for r in m}
        assert set(ids) == {"LOST", "W1"} and ids["LOST"]["source"] == "Autosentry" and ids["W1"]["prod_state"] == "too_high"
        assert [r["alpha_id"] for r in AL.missing_rows(s, [], q="rank(x")] == ["LOST"]


def test_scoring_without_prod_marks_ready_for_prod_and_does_not_tag_a_winner():
    import pandas as pd
    from tests.test_harness_engine import _fake_stats, sim
    from app.harness.engine.tracker import Tracker
    from app.harness.scoring import score_pending
    with tempfile.TemporaryDirectory() as t:
        s = _store(t)
        tr = Tracker(s, Path(t) / "j.jsonl")
        ids = [tr.enqueue("harden", sim(f"rank(z{i})"))["record_id"] for i in range(2)]
        tr.claim(ids, "B")
        for i, rid in enumerate(ids):
            tr.complete(rid, f"E{i}")
        def stats(aid, sd):
            st = _fake_stats(sharpe=2.0 if aid == "E0" else 0.2)                      # E1 fails the Sharpe gate
            st["check_submission"] = pd.DataFrame([{"name": "SELF_CORRELATION", "result": "PASS", "value": 0.2}])   # no prod row
            return st
        tagged = []
        score_pending(fetch=stats, store=s, winner={"winner_tag": "win", "winner_color": "GREEN", "tag_winners_above": 1.0}, tagger=lambda *a: tagged.append(a))
        assert tagged == []                                                          # no winner tag before prod is known
        assert AL.counts(s, "engine") == {"ready": 1, "cleared": 0, "failed": 1}
        assert [r["alpha_id"] for r in AL.list_alphas(s, gate="ready", source="engine")["rows"]] == ["E0"]
        assert [r["alpha_id"] for r in AL.list_alphas(s, gate="failed", source="engine")["rows"]] == ["E1"]
        # the prod check clears E0 -> it is tagged as a winner then
        ok = DF([{"name": "SELF_CORRELATION", "value": 0.2, "result": "PASS"}, {"name": "PROD_CORRELATION", "value": 0.3, "result": "PASS"}])
        AL.check_one(s, "E0", lambda a: ok, after_pass=lambda a: AL.winner_after_check(s, a, tagger=lambda *x: tagged.append(x),
                                                                                        wcfg={"winner_tag": "win", "winner_color": "GREEN", "tag_winners_above": 1.0}))
        assert tagged == [("E0", "win", "GREEN")]
        assert AL.counts(s, "engine") == {"ready": 0, "cleared": 1, "failed": 1}


def test_a_failing_prod_check_moves_the_alpha_to_failed_and_says_why():
    with tempfile.TemporaryDirectory() as t:
        s = _store(t)
        _add(s, "A")
        bad = DF([{"name": "PROD_CORRELATION", "value": 0.8, "result": "FAIL"}])
        AL.check_one(s, "A", lambda a: bad)
        import json
        r = s.query("SELECT passed_gate, gate_reasons FROM sim_results WHERE alpha_id='A'")[0]
        assert r["passed_gate"] == 0 and any("prod-corr 0.80" in x for x in json.loads(r["gate_reasons"]))
        assert AL.winner_after_check(s, "A", tagger=lambda *x: 1 / 0) == ""


def test_engine_results_are_separate_from_autosentrys():
    with tempfile.TemporaryDirectory() as t:
        s = _store(t)
        _add(s, "ENG"); _add(s, "AUTO")
        for aid, task in (("ENG", "harden"), ("AUTO", "autopilot")):
            s.execute("INSERT INTO harness_sim_record (task, payload_hash, payload, status, alpha_id, created, updated) VALUES (?,?,?,?,?,1,1)",
                      (task, aid, '{"regular":"x"}', "scored", aid))
        assert [r["alpha_id"] for r in AL.list_alphas(s, source="engine")["rows"]] == ["ENG"]
        assert [r["alpha_id"] for r in AL.list_alphas(s, source="autosentry")["rows"]] == ["AUTO"]
        assert AL.counts(s, "engine")["ready"] == 1 and AL.counts(s, "autosentry")["ready"] == 1
        s.execute("INSERT INTO harness_sim_record (task, payload_hash, payload, status, alpha_id, created, updated) VALUES ('autopilot','h','{}','external','LOST',1,1)")
        assert AL.missing_rows(s, [], "", "engine") == [] and [r["alpha_id"] for r in AL.missing_rows(s, [], "", "autosentry")] == ["LOST"]


def test_alpha_stats_leaves_out_prod_and_adds_self_correlation():
    import pandas as pd
    from app.harness import brain_port as BP
    seen = {}
    class Ace:
        def get_specified_alpha_stats(self, s, aid, sd, **kw):
            seen.update(kw)
            return {"is_stats": pd.DataFrame([{"sharpe": 2}]),
                    "is_tests": pd.DataFrame([{"name": "LOW_SHARPE", "result": "PASS", "value": 2},
                                              {"name": "PROD_CORRELATION", "result": "PENDING"}, {"name": "SELF_CORRELATION", "result": "PENDING"}])}
        def get_self_corr(self, s, aid):
            return pd.DataFrame({"correlation": [0.4, 0.55]})
    old = (BP._ace, BP.session)
    BP._ace, BP.session = (lambda: (None, Ace())), (lambda: "S")
    try:
        out = BP.alpha_stats("A", {})
    finally:
        BP._ace, BP.session = old
    tbl = out["check_submission"]
    assert seen["check_submission"] is False and seen["check_prod_corr"] is False
    assert list(tbl["name"]) == ["LOW_SHARPE", "SELF_CORRELATION"] and float(tbl.iloc[-1]["value"]) == 0.55
