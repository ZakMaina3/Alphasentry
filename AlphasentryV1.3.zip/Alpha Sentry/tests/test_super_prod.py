"""Supersentry: which alphas are checked for production correlation."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.superpilot import prod as PRD

THR = {"sharpe": 1.25, "fitness": 1.0}


def r(aid, sh, fit, passed=False):
    return {"alpha_id": aid, "sharpe": sh, "fitness": fit, "passed": passed, "expr": aid}


def test_every_alpha_clearing_min_sharpe_and_fitness_is_checked_even_if_it_failed_something_else():
    rows = [r("A", 1.5, 1.2, True), r("B", 1.4, 1.1, False), r("C", 0.9, 1.2), r("D", 1.5, 0.5), r("E", -1.6, -1.3), r("", 2, 2, True)]
    todo, reuse = PRD.split_for_prod(rows, THR, {})
    assert [x["alpha_id"] for x in todo] == ["A", "E", "B"] or [x["alpha_id"] for x in todo][0] == "A"
    assert {x["alpha_id"] for x in todo} == {"A", "B", "E"} and reuse == []          # C and D miss a minimum; the id-less row is skipped
    assert todo[0]["alpha_id"] == "A"                                                  # gate passers first


def test_alphas_whose_prod_is_already_stored_are_not_checked_again_but_reused():
    rows = [r("A", 1.5, 1.2, True), r("B", 1.4, 1.1)]
    todo, reuse = PRD.split_for_prod(rows, THR, {"A": {"prod_corr": 0.42, "self_corr": 0.3}, "B": {"prod_corr": None}})
    assert [x["alpha_id"] for x in todo] == ["B"] and [x["alpha_id"] for x in reuse] == ["A"]


def test_stored_numbers_become_a_check_result():
    ok = PRD.chk_from_stored({"prod_corr": 0.42, "self_corr": 0.3, "powerpool_corr": None}, 0.7)
    assert ok["ok"] and ok["failed"] == [] and ok["stored"] and ok["prod_corr"] == 0.42
    bad = PRD.chk_from_stored({"prod_corr": 0.81, "self_corr": 0.3}, 0.7)
    assert not bad["ok"] and bad["failed"] == ["PROD_CORR>=max"]


def test_metric_gate_uses_either_sign_and_survives_junk():
    assert PRD.passes_metrics({"sharpe": -1.3, "fitness": -1.1}, 1.25, 1.0)
    assert not PRD.passes_metrics({"sharpe": None, "fitness": None}, 1.25, 1.0)
    assert not PRD.passes_metrics({"sharpe": "x", "fitness": 1}, 1.25, 1.0)
