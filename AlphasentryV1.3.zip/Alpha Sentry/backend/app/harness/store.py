"""SentryEngine DB gateway: plain `sqlite3` against Alpha Sentry's own single-file database. No SQLAlchemy.

Alpha Sentry keeps everything in one local SQLite file. The harness adds three `harness_*` tables to it and READS
(and, for the scorer, inserts into) Alpha Sentry's `sim_results`, `datasets` and `fields`. A connection is opened per
operation (SQLite is happy with short-lived connections) and the journal mode is left as Alpha Sentry has it.
"""
from __future__ import annotations

import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator, Sequence

DDL = [
    """CREATE TABLE IF NOT EXISTS harness_sim_record (
        id INTEGER PRIMARY KEY AUTOINCREMENT, task TEXT NOT NULL DEFAULT '', payload_hash TEXT NOT NULL,
        payload TEXT NOT NULL DEFAULT '{}', status TEXT NOT NULL DEFAULT 'queued', batch_id TEXT NOT NULL DEFAULT '',
        sim_url TEXT NOT NULL DEFAULT '', alpha_id TEXT NOT NULL DEFAULT '', error TEXT NOT NULL DEFAULT '',
        created REAL NOT NULL, updated REAL NOT NULL)""",
    "CREATE INDEX IF NOT EXISTS ix_hsr_task ON harness_sim_record(task)",
    "CREATE INDEX IF NOT EXISTS ix_hsr_hash ON harness_sim_record(payload_hash)",
    "CREATE INDEX IF NOT EXISTS ix_hsr_status ON harness_sim_record(status)",
    "CREATE INDEX IF NOT EXISTS ix_hsr_batch ON harness_sim_record(batch_id)",
    "CREATE INDEX IF NOT EXISTS ix_hsr_alpha ON harness_sim_record(alpha_id)",
    """CREATE TABLE IF NOT EXISTS harness_alpha_info (
        alpha_id TEXT PRIMARY KEY, settings_json TEXT NOT NULL DEFAULT '{}', checks_json TEXT NOT NULL DEFAULT '[]',
        status TEXT NOT NULL DEFAULT '', fetched REAL NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS harness_task (
        id INTEGER PRIMARY KEY AUTOINCREMENT, lab TEXT NOT NULL, name TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'running',
        sampler TEXT NOT NULL, directions TEXT NOT NULL, objectives TEXT NOT NULL, space TEXT NOT NULL, template TEXT NOT NULL DEFAULT '{}',
        scope TEXT NOT NULL, budget INTEGER NOT NULL, batch INTEGER NOT NULL DEFAULT 10, cores INTEGER NOT NULL DEFAULT 2, seed INTEGER,
        backend TEXT NOT NULL DEFAULT 'auto', params TEXT NOT NULL DEFAULT '{}', notes TEXT NOT NULL DEFAULT '[]',
        error TEXT NOT NULL DEFAULT '', created REAL NOT NULL, updated REAL NOT NULL)""",
    "CREATE INDEX IF NOT EXISTS ix_htask_status ON harness_task(status)",
    """CREATE TABLE IF NOT EXISTS harness_trial (
        id INTEGER PRIMARY KEY AUTOINCREMENT, task_id INTEGER NOT NULL, number INTEGER NOT NULL, params TEXT NOT NULL,
        record_id INTEGER, alpha_id TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'queued', values_json TEXT,
        constraint_json TEXT NOT NULL DEFAULT '{}', summary TEXT NOT NULL DEFAULT '{}', error TEXT NOT NULL DEFAULT '',
        created REAL NOT NULL, updated REAL NOT NULL)""",
    "CREATE INDEX IF NOT EXISTS ix_htrial_task ON harness_trial(task_id, status)",
    """CREATE TABLE IF NOT EXISTS harness_saved_search (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, template TEXT NOT NULL, sampler TEXT NOT NULL DEFAULT '',
        objectives TEXT NOT NULL DEFAULT '[]', budget INTEGER NOT NULL DEFAULT 50, batch INTEGER NOT NULL DEFAULT 10,
        cores INTEGER NOT NULL DEFAULT 2, seed INTEGER, scope TEXT NOT NULL DEFAULT '{}', created REAL NOT NULL, updated REAL NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS harness_llm_usage (
        id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL, day TEXT NOT NULL, lab TEXT NOT NULL DEFAULT '', provider TEXT NOT NULL DEFAULT '',
        model TEXT NOT NULL DEFAULT '', prompt_tokens INTEGER NOT NULL DEFAULT 0, completion_tokens INTEGER NOT NULL DEFAULT 0,
        ok INTEGER NOT NULL DEFAULT 1, error TEXT NOT NULL DEFAULT '', ms INTEGER NOT NULL DEFAULT 0)""",
    "CREATE INDEX IF NOT EXISTS ix_hllm_day ON harness_llm_usage(day)",
    """CREATE TABLE IF NOT EXISTS harness_plan_run (
        id INTEGER PRIMARY KEY AUTOINCREMENT, created REAL NOT NULL, day TEXT NOT NULL, scope TEXT NOT NULL DEFAULT '',
        budget INTEGER NOT NULL, planned INTEGER NOT NULL, queued INTEGER NOT NULL, plan TEXT NOT NULL, results TEXT NOT NULL,
        notes TEXT NOT NULL DEFAULT '[]')""",
    "CREATE INDEX IF NOT EXISTS ix_hplanrun_day ON harness_plan_run(day)",
    """CREATE TABLE IF NOT EXISTS harness_alpha_pnl (
        alpha_id TEXT NOT NULL, date TEXT NOT NULL, pnl REAL NOT NULL DEFAULT 0, PRIMARY KEY (alpha_id, date))""",
]

#: What the harness expects to find in Alpha Sentry's own tables. Checked at startup so a layout change fails loudly.
REQUIRED_ACE_COLUMNS = {
    "sim_results": ["created_at", "alpha_id", "expression", "region", "delay", "universe", "neutralization", "sharpe",
                    "fitness", "turnover", "passed_gate", "gate_reasons", "tagged", "submitted"],
    "datasets": ["dataset_id", "region", "delay", "instrument", "universe", "coverage", "alpha_count"],
    "fields": ["field_id", "dataset_id", "region", "delay", "type", "alpha_count", "description"],
}

#: Speed-ups for the market-scoped reads the Planning tab and the labs make on every region change. They only add indexes
#: (IF NOT EXISTS) to Alpha Sentry's own tables; without them each region switch scanned the whole results/fields tables.
INDEXES = [
    "CREATE INDEX IF NOT EXISTS ix_hx_simres_scope ON sim_results(region, delay, universe)",
    "CREATE INDEX IF NOT EXISTS ix_hx_fields_scope ON fields(region, delay, type)",
    "CREATE INDEX IF NOT EXISTS ix_hx_datasets_scope ON datasets(region, delay, universe)",
]

_CHUNK = 500   # stay well under SQLite's bound-variable limit


def chunks(seq: Sequence, n: int = _CHUNK) -> Iterator[Sequence]:
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


def marks(n: int) -> str:
    return ",".join("?" * n)


class Store:
    def __init__(self, path: str | Path) -> None:
        self.path = str(path)
        self._lock = threading.Lock()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        """One short-lived connection; commits on success, rolls back on error."""
        conn = sqlite3.connect(self.path, timeout=30, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout=30000")
        try:
            yield conn
            conn.commit()
        except BaseException:
            conn.rollback()
            raise
        finally:
            conn.close()

    def query(self, sql: str, params: Sequence[Any] = ()) -> list[sqlite3.Row]:
        with self.connect() as c:
            return c.execute(sql, params).fetchall()

    def execute(self, sql: str, params: Sequence[Any] = ()) -> int:
        with self.connect() as c:
            return c.execute(sql, params).rowcount

    def required_defaults(self, table: str) -> dict[str, Any]:
        """Columns that are NOT NULL with no default (Alpha Sentry's own `submitted` is one): a plain insert must give them a value. 0 for numbers, '' for text."""
        with self.connect() as c:
            rows = c.execute(f"PRAGMA table_info({table})").fetchall()
        out: dict[str, Any] = {}
        for r in rows:
            if r["notnull"] and r["dflt_value"] is None and not r["pk"]:
                out[r["name"]] = "" if any(t in (r["type"] or "").upper() for t in ("CHAR", "TEXT", "CLOB")) else 0
        return out

    def columns(self, table: str) -> set[str]:
        with self.connect() as c:
            return {r["name"] for r in c.execute(f"PRAGMA table_info({table})").fetchall()}


def day_epoch(day: str, end: bool = False) -> float | None:
    """'YYYY-MM-DD' -> unix time at the start (or the very end, end=True) of that day on this computer; None for anything else."""
    import time as _t
    try:
        t = _t.mktime(_t.strptime(str(day).strip()[:10], "%Y-%m-%d"))
    except (ValueError, OverflowError):
        return None
    return t + 86399.999 if end else t


def ensure_tables(store: Store) -> None:
    """Create the harness_* tables if missing, plus a few read indexes on Alpha Sentry's tables (IF NOT EXISTS; no data is changed)."""
    with store.connect() as c:
        for stmt in DDL:
            c.execute(stmt)
    for stmt in INDEXES:                                   # separate: those tables may not exist yet on a brand-new database
        try:
            with store.connect() as c:
                c.execute(stmt)
        except Exception:  # noqa: BLE001
            pass


def check_ace_schema(store: Store) -> list[str]:
    """Problems with the Alpha Sentry tables the harness depends on (empty list = fine)."""
    problems = []
    for table, cols in REQUIRED_ACE_COLUMNS.items():
        have = store.columns(table)
        if not have:
            problems.append(f"Alpha Sentry table '{table}' is missing")
        else:
            missing = [c for c in cols if c not in have]
            if missing:
                problems.append(f"Alpha Sentry table '{table}' lacks column(s): {', '.join(missing)}")
    return problems


_default: Store | None = None
_default_lock = threading.Lock()


def default_store() -> Store:
    """Alpha Sentry's database. Resolved lazily so importing the harness never needs Alpha Sentry's settings."""
    global _default
    with _default_lock:
        if _default is None:
            from app.core.config import get_settings
            _default = Store(get_settings().db_path)
        return _default


def set_default_store(store: Store | None) -> None:
    """Tests (and tooling) point the harness at another database file."""
    global _default
    with _default_lock:
        _default = store
