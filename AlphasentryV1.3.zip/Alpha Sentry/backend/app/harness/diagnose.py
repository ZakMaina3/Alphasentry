"""Why is an engine simulation missing from Results? Pure: turns one simulation record into a plain-English reason (no BRAIN, no database)."""
from __future__ import annotations

STALE_RUNNING_S = 90 * 60          # the engine gives up on a batch after this long (brain_port.MAX_WAIT)
STALE_QUEUED_S = 30 * 60

# code -> (label, what to do). `fixable` actions the UI offers: "score" | "requeue" | ""
REASONS = {
    "ok": ("In Results", ""),
    "queued": ("Waiting in the queue", ""),
    "queued_stale": ("Queued for a long time: the engine is probably stopped, or this region is not the one it is working on", ""),
    "running": ("Being simulated at BRAIN", ""),
    "running_stale": ("Sent to BRAIN a long time ago and never came back (the engine stops waiting after 90 minutes)", "requeue"),
    "done_unscored": ("BRAIN finished it; it is waiting to be scored into Results", "score"),
    "scoring_failed": ("BRAIN finished it but scoring into Results failed", "score"),
    "scored_missing": ("Marked scored, but the alpha is not in the Results table", "score"),
    "rejected": ("BRAIN rejected this simulation", "requeue"),
    "no_alpha": ("BRAIN returned no alpha for it", "requeue"),
    "timed_out": ("Timed out waiting for BRAIN", "requeue"),
    "stale": ("Its batch never finished (released by the engine)", "requeue"),
    "dropped": ("Dropped by you (Drop / region change / follow Autosentry)", "requeue"),
    "reset": ("Cancelled by an engine reset", "requeue"),
    "dryrun": ("Dry-run: it was never simulated", "requeue"),
    "external": ("Run by Autosentry; its result is stored by Autosentry", ""),
    "external_missing": ("Run by Autosentry but not found in Results", ""),
}


def reason_for(rec: dict, in_results: bool, now: float) -> dict:
    """rec: {status, alpha_id, error, updated}. Returns {code, label, action, ok}."""
    status = str(rec.get("status") or "")
    err = str(rec.get("error") or "")
    age = max(0.0, now - float(rec.get("updated") or now))
    low = err.lower()
    code = "queued"
    if status in ("done", "scored", "external") and rec.get("alpha_id"):
        if in_results:
            code = "ok"
        elif status == "done":
            code = "scoring_failed" if "scoring failed" in low else "done_unscored"
        elif status == "scored":
            code = "scored_missing"
        else:
            code = "external_missing"
        if status == "external" and in_results:
            code = "external"
    elif status == "queued":
        code = "queued_stale" if age > STALE_QUEUED_S else "queued"
    elif status == "running":
        code = "running_stale" if age > STALE_RUNNING_S else "running"
    elif status == "cancelled":
        code = "reset" if "reset" in low else "dropped"
    elif status == "dryrun":
        code = "dryrun"
    elif status == "error":
        if "stale" in low:
            code = "stale"
        elif "timed out" in low:
            code = "timed_out"
        elif "no alpha returned" in low or not err:
            code = "no_alpha"
        else:
            code = "rejected"
    elif status in ("done", "scored") and not rec.get("alpha_id"):
        code = "no_alpha"
    label, action = REASONS[code]
    if code in ("rejected", "scoring_failed") and err:
        label = f"{label}: {err[:200]}"
    return {"code": code, "label": label, "action": action, "ok": code in ("ok", "external")}


def summarize(items: list[dict]) -> dict:
    """{code: n} over diagnosed items, hiding the healthy ones."""
    out: dict[str, int] = {}
    for it in items:
        if not it.get("ok"):
            out[it["code"]] = out.get(it["code"], 0) + 1
    return out


def missing(store, *, q: str = "", code: str = "", limit: int = 200, now: float | None = None, offset: int = 0, region: str = "",
            date_from: str = "", date_to: str = "") -> dict:
    """Every engine simulation that is not in Results, each with one plain reason; plus counts per reason."""
    import json
    now = now or __import__("time").time()
    rows = store.query("SELECT id, task, status, alpha_id, error, payload, updated FROM harness_sim_record ORDER BY id DESC LIMIT 5000")
    have: set[str] = set()
    ids = [r["alpha_id"] for r in rows if r["alpha_id"]]
    if ids:
        from app.harness.store import chunks, marks
        for part in chunks(list(set(ids))):
            have |= {x["alpha_id"] for x in store.query(f"SELECT alpha_id FROM sim_results WHERE alpha_id IN ({marks(len(part))})", list(part))}
    items = []
    needle = q.strip().lower()
    from app.harness.store import day_epoch
    lo, hi = day_epoch(date_from), day_epoch(date_to, True)
    want_region = region.strip().upper()
    for r in rows:
        if (lo is not None and (r["updated"] or 0) < lo) or (hi is not None and (r["updated"] or 0) > hi):
            continue
        try:
            pl = json.loads(r["payload"])
            expr = str(pl.get("regular", ""))
            rg = str((pl.get("settings") or {}).get("region", "")).upper()
        except Exception:  # noqa: BLE001
            expr, rg = "", ""
        if want_region and rg != want_region:
            continue
        d = reason_for(dict(r), bool(r["alpha_id"]) and r["alpha_id"] in have, now)
        d.update(id=r["id"], task=r["task"], status=r["status"], alpha_id=r["alpha_id"] or "", expression=expr, error=r["error"] or "", updated=r["updated"], region=rg)
        items.append(d)
    counts = summarize(items)
    shown = [i for i in items if not i["ok"] and (not code or i["code"] == code)
             and (not needle or needle in i["alpha_id"].lower() or needle in i["expression"].lower())]
    return {"counts": counts, "total": len(shown), "items": shown[max(0, offset):max(0, offset) + limit], "labels": {k: REASONS[k][0] for k in counts}}
