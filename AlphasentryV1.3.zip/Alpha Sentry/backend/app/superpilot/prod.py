"""Which Supersentry alphas get a production-correlation check (pure: no BRAIN, no database)."""
from __future__ import annotations


def passes_metrics(r: dict, sharpe_min: float, fitness_min: float) -> bool:
    """The minimum Sharpe AND fitness (either sign: a negative one is flipped later)."""
    try:
        return abs(float(r.get("sharpe") or 0)) >= float(sharpe_min) and abs(float(r.get("fitness") or 0)) >= float(fitness_min)
    except (TypeError, ValueError):
        return False


def split_for_prod(rows: list[dict], thr: dict, stored: dict[str, dict]) -> tuple[list[dict], list[dict]]:
    """rows with an alpha id -> (to_check, reuse). Every alpha that clears the minimum Sharpe and fitness, or already passed the whole gate,
    is checked for prod UNLESS its production correlation is already stored (then the stored numbers are reused). Best first."""
    cand = [r for r in rows if r.get("alpha_id") and (r.get("passed") or passes_metrics(r, thr["sharpe"], thr["fitness"]))]
    cand.sort(key=lambda r: (not r.get("passed"), -(abs(r.get("fitness") or 0) + 0.3 * abs(r.get("sharpe") or 0))))
    have = [r for r in cand if (stored.get(r["alpha_id"]) or {}).get("prod_corr") is not None]
    todo = [r for r in cand if r not in have]
    return todo, have


def chk_from_stored(stored: dict, max_corr: float) -> dict:
    """The check dict the engine expects, rebuilt from numbers saved in Results."""
    self_c, prod_c, pool_c = stored.get("self_corr"), stored.get("prod_corr"), stored.get("powerpool_corr")
    failed = [lab for lab, v in (("SELF_CORR>=max", self_c), ("PROD_CORR>=max", prod_c), ("POWERPOOL_CORR>=max", pool_c))
              if v is not None and abs(v) >= max_corr]
    return {"ok": not failed, "failed": failed, "pending": False, "self_corr": self_c, "prod_corr": prod_c, "pool_corr": pool_c, "stored": True}
