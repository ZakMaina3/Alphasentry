import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { api } from "../../lib/api";
import { SupersentryMark } from "../../lib/Logo";
import { useResearch } from "../../lib/store";
import { useToast } from "../../lib/toast";
import { NumberInput } from "../../lib/NumberInput";
import { usePersistentState } from "../../lib/persist";
import { AutopilotLibrary } from "../autopilot/AutopilotLibrary";
import { ScopeFields } from "../common/ScopePicker";

// Supersentry — its own section. No hypotheses: every round the LLM suggests selection + combo
// expressions aimed at good performance and LOW correlation; each selection is verified to pick more
// than 10 of your alphas BEFORE anything is simulated.

const PHASE: Record<string, string> = {
  idle: "idle", starting: "starting…", suggesting: "suggesting expressions", verifying: "verifying selections",
  simulating: "simulating SuperAlphas", reviewing: "checking correlations", improving: "improving (low correlation)",
  cooldown: "next round…", waiting: "waiting", stopped: "stopped",
};
const SEC: CSSProperties = { fontSize: 11, color: "var(--mut)", textTransform: "uppercase", letterSpacing: ".5px", marginTop: 14 };
const num = (v: any) => (v == null ? "—" : Number(v).toFixed(2));

export function SuperPilot() {
  const R: any = useResearch();
  const { toast, toastErr } = useToast();
  const [regionIn, setRegionIn] = usePersistentState("sp:region", "");
  const [universe, setUniverse] = usePersistentState("sp:universe", "ILLIQUID_MINVOL1M");
  const [neuts, setNeuts] = usePersistentState("sp:neuts", "FAST");
  const [decay, setDecay] = usePersistentState<number>("sp:decay", 10);
  const [trunc, setTrunc] = usePersistentState<number>("sp:trunc", 0.08);
  const [selLimit, setSelLimit] = usePersistentState<number>("sp:sellimit", 1000);
  const [selHandling, setSelHandling] = usePersistentState("sp:selhandling", "POSITIVE");
  const [own, setOwn] = usePersistentState("sp:own", true);
  const [minComp, setMinComp] = usePersistentState<number>("sp:mincomp", 11);
  const [perRound, setPerRound] = usePersistentState<number>("sp:perround", 6);
  const [prodDelay, setProdDelay] = usePersistentState<number>("sp:proddelay", 60);
  const [nSel, setNSel] = usePersistentState<number>("sp:nsel", 6);
  const [nCombo, setNCombo] = usePersistentState<number>("sp:ncombo", 6);
  const [goal, setGoal] = usePersistentState("sp:goal", "");
  const [minSharpe, setMinSharpe] = usePersistentState<number>("sp:minsharpe", 0);
  const [minFit, setMinFit] = usePersistentState<number>("sp:minfit", 0);
  const [maxCorr, setMaxCorr] = usePersistentState<number>("sp:maxcorr", 0.7);
  const [maxTurn, setMaxTurn] = usePersistentState<number>("sp:maxturn", 0.7);
  const [maxRounds, setMaxRounds] = usePersistentState<number>("sp:maxrounds", 0);
  const [maxWinners, setMaxWinners] = usePersistentState<number>("sp:maxwinners", 0);
  const [useLib, setUseLib] = usePersistentState("sp:uselib", true);
  const [flip, setFlip] = usePersistentState("sp:flip", true);
  const [decorr, setDecorr] = usePersistentState("sp:decorr", true);
  const [tag] = useState(() => localStorage.getItem("ace2-tag") || "");
  const [winnerTag] = useState(() => localStorage.getItem("ace2-winnertag") || "");
  const [tab, setTab] = useState<"live" | "library" | "learning">("live");
  const [st, setSt] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [checkText, setCheckText] = useState("");
  const [checked, setChecked] = useState<any[]>([]);
  const logRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let alive = true;
    const tick = async () => { const s = await api.get<any>("/superpilot/status"); if (alive && !s.error) setSt(s); };
    tick();
    const t = setInterval(tick, 2000);
    return () => { alive = false; clearInterval(t); };
  }, []);
  useEffect(() => { if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight; }, [st?.events?.length]);

  const running = !!st?.running;
  const state = st?.state || { rounds: 0, simulated: 0, winners: [], history: [] };
  const neutList = useMemo(() => neuts.split(",").map((x) => x.trim().toUpperCase()).filter(Boolean), [neuts]);
  const region = (regionIn.trim().toUpperCase() || R.ctx.region);
  const base = { region, delay: R.ctx.delay, instrument: R.ctx.instrument, selection_limit: selLimit, selection_handling: selHandling };

  async function start() {
    if (!neutList.length) return toast("Enter at least one neutralization (e.g. FAST).", "warn");
    setBusy(true);
    const r = await api.post<any>("/superpilot/start", {
      ...base, universe, neutralizations: neutList, decay, truncation: trunc, own, min_components: minComp, per_round: perRound, prod_check_delay: prodDelay,
      n_selections: nSel, n_combos: nCombo, goal, tag, winner_tag: winnerTag,
      min_sharpe: minSharpe > 0 ? minSharpe : null, min_fitness: minFit > 0 ? minFit : null,
      max_turnover: maxTurn, max_corr: maxCorr, max_rounds: maxRounds, max_winners: maxWinners,
      use_library: useLib, flip, decorrelate: decorr,
    });
    setBusy(false);
    if (r.error) return toastErr(r.error);
    toast(r.already_running ? "Supersentry is already running." : "Supersentry started.", "ok");
  }
  async function stop() { await api.post("/superpilot/stop"); toast("Stopping after the current step…"); }
  async function reset() {
    if (!window.confirm("Clear the winners list and results history shown here? (Stored simulation results are untouched.)")) return;
    await api.post("/superpilot/reset"); toast("History cleared.");
  }
  async function verify() {
    const sels = checkText.split("\n").map((x) => x.trim()).filter(Boolean);
    if (!sels.length) return toast("Paste one or more selection expressions (one per line).", "warn");
    setBusy(true);
    toast("Counting the alphas each selection picks…");
    const r = await api.post<any>("/superpilot/verify", { ...base, selections: sels, min_components: minComp });
    setBusy(false);
    if (r.error) return toastErr(r.error);
    setChecked(r.results || []);
  }

  const Pill = ({ on, label, onClick, title }: { on: boolean; label: string; onClick: () => void; title?: string }) =>
    <span className={"pill" + (on ? " on" : "")} onClick={onClick} title={title}>{label}</span>;
  const CountRow = ({ x }: { x: any }) => (
    <tr><td>{x.ok ? <span style={{ color: "var(--ok)" }}>✓</span> : <span style={{ color: "var(--bad)" }}>✗</span>}</td>
      <td style={{ fontFamily: "monospace", fontSize: 11 }}>{x.selection}</td>
      <td>{x.count ?? "—"}</td><td className="mut" style={{ fontSize: 11 }}>{x.ok ? "" : x.note}</td></tr>);

  return (
    <div className="dx-split" style={{ flex: 1, minHeight: 0 }}>
      {/* controls */}
      <div className="panel" style={{ padding: 14 }}>
        <div className="dx-head"><SupersentryMark size={20} /><b>Supersentry</b>
          <span className="mut">{region} · D{R.ctx.delay} · {universe}</span>
          {running ? <span className="badge ok" style={{ marginLeft: "auto" }}>running</span> : null}</div>
        <div className="panel-scroll">
          <div className="mut" style={{ fontSize: 11, marginBottom: 8, lineHeight: 1.5 }}>
            No hypotheses here. Every round the LLM suggests <b>selection → combo</b> expressions aimed at <b>good performance and low correlation</b>.
            Each selection is first counted against your alphas — it must pick <b>more than 10</b> or it is never simulated.
            Every metric-passing SuperAlpha then gets BRAIN's full correlation check.
          </div>
          <label className="fld"><span>Goal (optional)</span>
            <textarea value={goal} onChange={(e) => setGoal(e.target.value)} style={{ minHeight: 50 }}
              placeholder="e.g. combine my fundamental alphas, avoid anything price-momentum" /></label>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8, marginTop: 8 }}>
            <ScopeFields region={region} delay={R.ctx.delay} universe={universe}
              onChange={(v) => { setRegionIn(v.region); R.setCtx({ delay: v.delay }); setUniverse(v.universe); }} />
            <label className="fld" title="Comma-separated, e.g. FAST or FAST, SLOW"><span>Neutralizations</span><input value={neuts} onChange={(e) => setNeuts(e.target.value)} /></label>
            <label className="fld"><span>Decay</span><NumberInput min={0} fallback={10} value={decay} onChange={setDecay} /></label>
            <label className="fld"><span>Truncation</span><NumberInput step="0.01" min={0} fallback={0.08} value={trunc} onChange={setTrunc} /></label>
            <label className="fld" title="A selection must pick at least this many of your alphas. 11 = more than 10."><span>Min alphas picked</span><NumberInput min={1} fallback={11} value={minComp} onChange={setMinComp} /></label>
            <label className="fld"><span>Selection limit</span><NumberInput min={1} fallback={1000} value={selLimit} onChange={setSelLimit} /></label>
            <label className="fld"><span>SuperAlphas / round</span><NumberInput min={2} max={30} fallback={6} value={perRound} onChange={setPerRound} /></label>
            <label className="fld"><span title="Every alpha that clears the minimum Sharpe and fitness is checked for production correlation (unless Results already has it), one at a time, waiting this many seconds before each. 0 = no wait (up to 4 at once).">Prod check delay (s)</span><NumberInput min={0} max={600} fallback={60} value={prodDelay} onChange={setProdDelay} /></label>
            <label className="fld"><span>Selections / round</span><NumberInput min={2} max={12} fallback={6} value={nSel} onChange={setNSel} /></label>
            <label className="fld"><span>Combos / round</span><NumberInput min={2} max={12} fallback={6} value={nCombo} onChange={setNCombo} /></label>
            <label className="fld"><span>|Sharpe| ≥ (0 = default)</span><NumberInput step="0.01" min={0} fallback={0} value={minSharpe} onChange={setMinSharpe} /></label>
            <label className="fld"><span>|Fitness| ≥ (0 = default)</span><NumberInput step="0.1" min={0} fallback={0} value={minFit} onChange={setMinFit} /></label>
            <label className="fld" title="Self / prod / power-pool correlation must stay below this. Lower = stricter."><span>Max correlation</span><NumberInput step="0.05" min={0.1} max={1} fallback={0.7} value={maxCorr} onChange={setMaxCorr} /></label>
            <label className="fld"><span>Max turnover</span><NumberInput step="0.05" min={0.05} max={1} fallback={0.7} value={maxTurn} onChange={setMaxTurn} /></label>
            <label className="fld"><span>Selection handling</span>
              <input value={selHandling} onChange={(e) => setSelHandling(e.target.value.trim().toUpperCase())} list="sp-selh" />
              <datalist id="sp-selh"><option value="POSITIVE" /><option value="NEGATIVE" /><option value="ABSOLUTE" /></datalist></label>
            <label className="fld" title="0 = run forever"><span>Stop after N rounds (0 = ∞)</span><NumberInput min={0} fallback={0} value={maxRounds} onChange={setMaxRounds} /></label>
            <label className="fld" title="0 = run forever"><span>Stop after N winners (0 = ∞)</span><NumberInput min={0} fallback={0} value={maxWinners} onChange={setMaxWinners} /></label>
          </div>
          <div className="dx-filters" style={{ marginTop: 8 }}>
            <Pill on={own} label={`Own alphas only: ${own ? "ON" : "OFF"}`} onClick={() => setOwn((v) => !v)}
              title="Every selection starts with `own &&` so only your own alphas are combined." />
            <Pill on={useLib} label={`Use library & lessons: ${useLib ? "ON" : "OFF"}`} onClick={() => setUseLib((v) => !v)}
              title="Feed your SuperAlphas / selections / combos / papers / notes and everything learned so far to the LLM, and keep learning." />
            <Pill on={flip} label={`Reverse negative results: ${flip ? "ON" : "OFF"}`} onClick={() => setFlip((v) => !v)}
              title="When a SuperAlpha has negative Sharpe/Fitness, retry it with the combo weight reversed." />
            <Pill on={decorr} label={`Cut correlation: ${decorr ? "ON" : "OFF"}`} onClick={() => setDecorr((v) => !v)}
              title="If it passes everything except correlation: rebuild with low-correlation selections, swap sister/brother operators in the combo, then try other neutralizations." />
          </div>

          <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
            {!running ? <button className="btn" onClick={start} disabled={busy}>{busy ? <span className="spin" /> : null} Start Supersentry</button>
              : <button className="btn danger" onClick={stop}>Stop</button>}
            <button className="btn ghost sm" onClick={reset} disabled={running}>Clear winners & history</button>
          </div>

          <div style={SEC}>Check selections (pick &gt; {minComp - 1} alphas?)</div>
          <textarea value={checkText} onChange={(e) => setCheckText(e.target.value)} style={{ width: "100%", minHeight: 60, fontFamily: "monospace", fontSize: 11, marginTop: 4 }}
            placeholder={"own && turnover < 0.7\nown && category == \"FUNDAMENTAL\" && prod_correlation < 0.5"} />
          <button className="btn ghost sm" style={{ marginTop: 4 }} onClick={verify} disabled={busy}>Count alphas</button>
          {checked.length ? <table style={{ marginTop: 6 }}><thead><tr><th></th><th>Selection</th><th>Alphas</th><th></th></tr></thead>
            <tbody>{checked.map((x, i) => <CountRow key={i} x={x} />)}</tbody></table> : null}

          <div className="mut" style={{ fontSize: 11, marginTop: 10 }}>
            Never submits anything to BRAIN. Session expiry → the biometrics link goes to Telegram (set it up in the regular Autosentry's panel).
            This and the regular Autosentry share BRAIN's simulation slots, so only one runs at a time.
          </div>
        </div>
      </div>

      {/* live */}
      <div className="panel" style={{ padding: 14 }}>
        <div className="dx-head">
          {(["live", "library", "learning"] as const).map((t) =>
            <span key={t} className={"pill" + (tab === t ? " on" : "")} style={{ marginRight: 6 }} onClick={() => setTab(t)}>
              {t === "live" ? "Live" : t === "library" ? "Library" : "Learning"}</span>)}
          <span className="badge" style={{ marginLeft: 8 }}>{PHASE[st?.phase || "idle"] || st?.phase}</span>
          {st?.round ? <span className="mut" style={{ marginLeft: 8 }}>round {st.round}</span> : null}
          <span className="mut" style={{ marginLeft: "auto" }}>{state.rounds} rounds · {state.simulated} simulated · {state.winners.length} winners</span></div>
        {tab !== "live" ? <AutopilotLibrary region={region} tab={tab} scope="super" /> : <div className="panel-scroll">
          {st?.wait ? <div className="empty" style={{ marginBottom: 8 }}>{st.wait}</div> : null}

          {st?.selections?.length ? <>
            <div style={{ ...SEC, marginTop: 0 }}>Selection check — must pick ≥ {minComp} alphas</div>
            <table><thead><tr><th></th><th>Selection</th><th>Alphas</th><th></th></tr></thead>
              <tbody>{st.selections.map((x: any, i: number) => <CountRow key={i} x={x} />)}</tbody></table></> : null}

          {st?.last_batch?.length ? <>
            <div style={SEC}>Latest results</div>
            <table><thead><tr><th></th><th>SuperAlpha</th><th>Sharpe</th><th>Fit</th><th>Turn</th><th>Self</th><th>Prod</th><th>Notes</th></tr></thead>
              <tbody>{st.last_batch.map((r: any, i: number) => (
                <tr key={i}>
                  <td>{r.passed ? <span style={{ color: "var(--ok)" }}>✓</span> : <span style={{ color: "var(--bad)" }}>✗</span>}</td>
                  <td style={{ maxWidth: 280 }}>{r.alpha_id ? <a href={`https://platform.worldquantbrain.com/alpha/${r.alpha_id}`} target="_blank" rel="noopener"><code>{r.alpha_id}</code></a> : "—"}
                    <div className="sub" style={{ fontFamily: "monospace", fontSize: 10, wordBreak: "break-word" }}>{r.expr}</div></td>
                  <td>{num(r.sharpe)}</td><td>{num(r.fitness)}</td><td>{r.turnover == null ? "—" : (r.turnover * 100).toFixed(0) + "%"}</td>
                  <td>{num(r.self_corr)}</td><td>{num(r.prod_corr)}</td>
                  <td className="mut" style={{ fontSize: 11 }}>{(r.reasons || []).join(", ")}</td>
                </tr>))}</tbody></table></> : (!st?.selections?.length ? <div className="empty">Nothing yet — press Start.</div> : null)}

          <div style={SEC}>Winners (passed everything, incl. correlation)</div>
          {!state.winners.length ? <div className="empty">None yet.</div> :
            <table><thead><tr><th>Alpha</th><th>Sharpe</th><th>Fit</th><th>Turn</th><th>Self / Prod corr</th></tr></thead>
              <tbody>{[...state.winners].reverse().map((w: any, i: number) => (
                <tr key={i}>
                  <td><a href={`https://platform.worldquantbrain.com/alpha/${w.alpha_id}`} target="_blank" rel="noopener"><code>{w.alpha_id}</code></a>
                    <div className="sub" style={{ fontFamily: "monospace", fontSize: 10, wordBreak: "break-word" }}>{w.expr}</div>
                    {w.via ? <div className="mut" style={{ fontSize: 11 }}>via <b>{w.via}</b></div> : null}</td>
                  <td>{num(w.sharpe)}</td><td>{num(w.fitness)}</td><td>{w.turnover == null ? "—" : (w.turnover * 100).toFixed(0) + "%"}</td>
                  <td className="mut">{num(w.self_corr)} / {num(w.prod_corr)}</td>
                </tr>))}</tbody></table>}

          <div style={SEC}>Event log</div>
          <div ref={logRef} style={{ maxHeight: 200, overflow: "auto", fontSize: 11, fontFamily: "monospace", background: "var(--bg2, rgba(0,0,0,.15))", borderRadius: 6, padding: "6px 8px" }}>
            {(st?.events || []).map((e: any, i: number) => <div key={i}>{new Date(e.t * 1000).toLocaleTimeString()} · {e.msg}</div>)}
          </div>
        </div>}
      </div>
    </div>
  );
}
