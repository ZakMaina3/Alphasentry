import { useEffect, useRef, useState } from "react";
import { api } from "../../lib/api";
import { SentryEngineMark } from "../../lib/Logo";
import { useToast } from "../../lib/toast";
import { ScopeFields, useScopes } from "../common/ScopePicker";
import { ResultsTab, SlotsPanel } from "./ResultsView";
import "./harness.css";

type Res = Record<string, any>;

// FastAPI errors come back as { detail }, Alpha Sentry's own modules as { error } — accept both.
async function call(method: "get" | "post" | "delete", path: string, body?: unknown): Promise<{ d: Res; err?: string }> {
  const d: Res = method === "get" ? await api.get<Res>(path) : method === "delete" ? await api.delete<Res>(path) : await api.post<Res>(path, body);
  const raw = d.error ?? d.detail;
  const err = raw == null ? undefined : typeof raw === "string" ? raw : JSON.stringify(raw);
  return { d, err };
}

const split = (s: string) => s.split(",").map((x) => x.trim()).filter(Boolean);
const FLAGS: { name: string; label: string; help: string }[] = [
  { name: "harness_engine", label: "SentryEngine + labs", help: "Batch engine and the Relocate / Repair / Harden / Harvest / Diversify / Pair labs." },
  { name: "harness_vault", label: "Returns vault + mixing", help: "Daily-returns store, correlation matrix, mix candidates and mix queueing." },
  { name: "harness_planning", label: "Planning (daily plan + skeleton ledger)", help: "Lets the Planning tab queue the daily plan, and makes labs skip alpha shapes this market has already answered." },
  { name: "harness_llm", label: "LLM labs (Invent)", help: "Labs that call YOUR LLM key from Settings. They spend your provider quota, within the daily caps set in the Invent tab." },
  { name: "harness_seed", label: "Merge shipped data on start", help: "On by default. When Alpha Sentry starts, your database gets any rows it lacks from the data file that ships with this version (dataset and field catalogue and operator reference; never anyone's alphas, results, vault or library). It only adds; it never changes or removes a row, and it runs once per data file." },
  { name: "autopilot_via_engine", label: "Autosentry via engine", help: "Autosentry shares the engine's simulation slots and crash journal, so the two never fight over slots and a crash cannot lose a running batch. Supersentry (which cannot be batched) shares the slots only. The manual SuperAlpha screen is never affected. Takes effect on the next run." },
];
const LABS = [
  { id: "relocate", label: "Relocate", help: "Run formulas that work in one market in the others (refuses markets missing a field)." },
  { id: "repair", label: "Repair", help: "One targeted fix for each near-miss alpha, based on the check it failed." },
  { id: "harden", label: "Harden", help: "Nudge a winner's windows and wrappers to see whether it is real." },
  { id: "harvest", label: "Harvest", help: "Plain sensible patterns over the best fields in each dataset." },
  { id: "diversify", label: "Diversify", help: "Fields only from datasets none of your alphas use." },
  { id: "pair", label: "Pair", help: "Cross-dataset field pairs in a few relational shapes." },
] as const;
type LabId = typeof LABS[number]["id"];

const fmt = (v: any): string => {
  if (v == null) return "—";
  if (typeof v === "number") return Number.isInteger(v) ? String(v) : v.toFixed(3);
  if (typeof v === "boolean") return v ? "yes" : "no";
  if (Array.isArray(v)) return v.map(fmt).join(", ");
  if (typeof v === "object") return JSON.stringify(v);
  return String(v);
};

function Section({ name, v, depth = 0 }: { name: string; v: any; depth?: number }) {
  if (Array.isArray(v) && v.length && typeof v[0] === "object" && !Array.isArray(v[0])) {
    const cols = Object.keys(v[0]).slice(0, 7);
    return (
      <div style={{ marginTop: 10 }}>
        <b style={{ fontSize: 12 }}>{name}</b> <span className="mut">({v.length}{v.length > 25 ? ", first 25" : ""})</span>
        <div className="panel-scroll" style={{ maxHeight: 280 }}>
          <table className="hx-table"><thead><tr>{cols.map((c) => <th key={c}>{c}</th>)}</tr></thead>
            <tbody>{v.slice(0, 25).map((r: any, i: number) => (
              <tr key={i}>{cols.map((c) => <td key={c} title={fmt(r[c])}>{fmt(r[c])}</td>)}</tr>))}</tbody></table>
        </div>
      </div>
    );
  }
  if (v && typeof v === "object" && !Array.isArray(v) && depth < 2) {
    return <div style={{ marginTop: 10 }}><b style={{ fontSize: 12 }}>{name}</b><ResultBody d={v} depth={depth + 1} /></div>;
  }
  return null;
}

function ResultBody({ d, depth = 0 }: { d: Res; depth?: number }) {
  const scalars = Object.entries(d).filter(([k, v]) => k !== "note" && (v == null || typeof v !== "object" || (Array.isArray(v) && (!v.length || typeof v[0] !== "object"))));
  const rest = Object.entries(d).filter(([k, v]) => k !== "note" && v && typeof v === "object" && !(Array.isArray(v) && (!v.length || typeof v[0] !== "object")));
  return (
    <>
      {d.note ? <div className="hx-note">{String(d.note)}</div> : null}
      <div className="hx-chips">{scalars.map(([k, v]) => <span key={k} className="chip">{k}: <b>{fmt(v)}</b></span>)}</div>
      {rest.map(([k, v]) => <Section key={k} name={k} v={v} depth={depth} />)}
    </>
  );
}

function ResultView({ d }: { d: Res | null }) {
  if (!d) return null;
  return (
    <div style={{ marginTop: 8 }}>
      <ResultBody d={d} />
      <details className="hx-raw" style={{ marginTop: 10 }}><summary className="mut" style={{ cursor: "pointer", fontSize: 12 }}>raw response</summary>
        <pre>{JSON.stringify(d, null, 2)}</pre></details>
    </div>
  );
}

interface ScopeState { region: string; delay: number; universe: string; target: number }

function ScopeForm({ s, set }: { s: ScopeState; set: (p: Partial<ScopeState>) => void }) {
  return (
    <div className="hx-row">
      <ScopeFields region={s.region} delay={s.delay} universe={s.universe} onChange={(v) => set(v)} />
      <label className="fld"><span>Max simulations</span><input type="number" min={1} value={s.target} onChange={(e) => set({ target: Math.max(1, +e.target.value || 1) })} /></label>
    </div>
  );
}

// ───────────────────────────── Control ─────────────────────────────
// ───────────────────────────── Queue by region ─────────────────────────────
// The engine's queue is shared by every region. Pick the market to work on and the others are parked (kept, not lost),
// or drop what is queued for a region you have left. Dropping never touches batches that are already running on BRAIN.
function QueueByRegion({ flagOn }: { flagOn: boolean }) {
  const { toast, toastErr } = useToast();
  const S = useScopes();
  const [q, setQ] = useState<Res | null>(null);
  const [pick, setPick] = useState({ region: "", delay: 1 });
  const [dropOthers, setDropOthers] = useState(true);
  const [follow, setFollow] = useState(true);
  const [busy, setBusy] = useState("");
  const load = async () => {
    const { d, err } = await call("get", "/harness_engine/queue"); if (!err) setQ(d);
    const f = await call("get", "/harness_engine/focus"); if (!f.err && typeof f.d.follow === "boolean") setFollow(f.d.follow);
  };
  async function setFollowing(on: boolean) {
    setFollow(on);
    const { err } = await call("post", "/harness_engine/focus/follow_setting", { on });
    if (err) return toastErr(err);
    toast(on ? "SentryEngine now follows the region chosen in Autosentry and drops other regions' queued simulations." : "Follow is off: other regions are only parked.", "ok");
    load();
  }
  useEffect(() => { load(); const t = setInterval(load, 4000); return () => clearInterval(t); }, []);
  useEffect(() => { if (q?.focus?.region) setPick({ region: q.focus.region, delay: q.focus.delay ?? 1 }); }, [q?.focus?.region, q?.focus?.delay]);
  const focus = q?.focus?.region ? `${q.focus.region}${q.focus.delay != null ? " D" + q.focus.delay : ""}` : "";
  const rows: Res[] = q?.by_region ?? [];

  async function setFocus(region: string, delay: number | null) {
    setBusy("focus");
    const { d, err } = await call("post", "/harness_engine/focus", { region, delay, drop_others: !!region && dropOthers, pause_others: !!region });
    setBusy("");
    if (err) return toastErr(err);
    toast(region ? `Working on ${region}${delay != null ? " D" + delay : ""} only. Dropped ${d.dropped} queued simulation(s) from other markets, paused ${d.paused_tasks} task(s).`
                 : "Focus cleared: every market runs.", "ok");
    load();
  }
  async function drop(r: Res, all = false) {
    const txt = all
      ? `Drop EVERYTHING in the engine's queue (${rows.reduce((n, x) => n + x.queued, 0)} queued, ${rows.reduce((n, x) => n + x.running, 0)} running)?`
      : `Drop ${r.region} D${r.delay}: ${r.queued} queued and ${r.running} running?`;
    if (!window.confirm(`${txt}\n\nQueued simulations are removed. Ones already sent to BRAIN are abandoned: the engine stops waiting for them, frees their slots and ignores their results (BRAIN finishes what it started). Search tasks for the market are paused so they cannot refill it. Nothing is submitted.`)) return;
    setBusy(all ? "dropall" : `drop${r.region}${r.delay}`);
    let dropped = 0, abandoned = 0, paused = 0;
    for (const x of all ? rows : [r]) {
      const { d, err } = await call("post", "/harness_engine/queue/drop", { region: x.region, delay: x.delay, pause_tasks: true, include_running: true });
      if (err) { setBusy(""); return toastErr(err); }
      dropped += d.dropped ?? 0; abandoned += d.abandoned_running ?? 0; paused += d.paused_tasks ?? 0;
    }
    setBusy("");
    toast(`Dropped ${dropped} simulation(s) (${abandoned} were already running at BRAIN), paused ${paused} task(s).`, "ok");
    load();
  }
  return (
    <>
      <div className="dx-head" style={{ marginTop: 18 }}><b>Queue by region</b>
        <span className="mut">{focus ? `working on ${focus}; other markets are parked` : "no focus: every market runs"}</span></div>
      <label className="fld" style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 6 }}
        title="On (default): the engine always works on the region chosen in Autosentry. When you change it, and whenever other work is queued, every other region's queued simulations are dropped immediately and their search tasks paused. Running batches finish.">
        <input type="checkbox" checked={follow} onChange={(e) => setFollowing(e.target.checked)} />
        <span><b>Always follow the region chosen in Autosentry</b>: other regions' queued simulations are dropped immediately</span></label>
      <div className="mut" style={{ fontSize: 12 }}>One batch can only hold one region, so a queue spread over several regions runs them one after another. Choose the region you are working on; the rest waits (or is dropped).</div>
      <div className="hx-row" style={{ marginTop: 6 }}>
        <ScopeFields region={pick.region || S.regions[0] || "USA"} delay={pick.delay} withUniverse={false}
          onChange={(v) => setPick({ region: v.region, delay: v.delay })} />
        <label className="fld" style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
          <input type="checkbox" checked={dropOthers} onChange={(e) => setDropOthers(e.target.checked)} />
          <span>Drop other regions' queued sims</span></label>
        <button className="btn sm" disabled={!!busy} onClick={() => setFocus(pick.region || S.regions[0] || "USA", pick.delay)}>Work on this region</button>
        <button className="btn ghost sm" disabled={!!busy || !focus} onClick={() => setFocus("", null)}>Clear focus</button>
        <button className="btn ghost sm" disabled={!flagOn || !!busy || !rows.length} onClick={() => drop(rows[0], true)}>Drop everything</button>
      </div>
      {!flagOn ? <div className="hx-warn">Dropping needs “SentryEngine + labs” on; focusing works either way.</div> : null}
      {rows.length ? (
        <table className="hx-table"><thead><tr><th>region</th><th>delay</th><th>queued</th><th>running</th><th></th></tr></thead>
          <tbody>{rows.map((r) => {
            const parked = !!focus && !(r.region === q?.focus.region && (q?.focus.delay == null || r.delay === q?.focus.delay));
            return (
              <tr key={`${r.region}${r.delay}`}><td><b>{r.region}</b></td><td>{r.delay}</td><td>{r.queued}{parked && r.queued ? <span className="mut"> (parked)</span> : null}</td><td>{r.running}</td>
                <td><button className="btn ghost sm" disabled={!flagOn || !(r.queued || r.running) || !!busy} onClick={() => drop(r)}>Drop</button></td></tr>);
          })}</tbody></table>
      ) : <div className="mut" style={{ fontSize: 12, marginTop: 6 }}>Nothing is queued or running.</div>}
      {!focus && rows.length > 1 ? <div className="hx-note">{rows.length} markets are queued. Pick one above to stop the engine bouncing between them.</div> : null}
    </>
  );
}

function Control() {
  const { toast, toastErr } = useToast();
  const [st, setSt] = useState<Res | null>(null);
  const [yl, setYl] = useState<Res | null>(null);
  const [busy, setBusy] = useState("");
  const load = async () => {
    const { d, err } = await call("get", "/harness_engine/status");
    if (!err) setSt(d);
    const y = await call("get", "/harness_engine/plan/yields");
    if (!y.err) setYl(y.d);
  };
  useEffect(() => { load(); const t = setInterval(load, 4000); return () => clearInterval(t); }, []);

  async function act(path: string, body?: unknown, okMsg?: string) {
    setBusy(path);
    const { d, err } = await call("post", path, body);
    setBusy("");
    if (err) return toastErr(err);
    if (okMsg) toast(okMsg, "ok");
    load();
    return d;
  }
  const flags: Record<string, boolean> = st?.flags ?? {};
  const eng: Res | undefined = st?.engine;
  const lease = eng?.lease;

  return (
    <div className="panel" style={{ padding: 14 }}>
      <div className="dx-head"><b>Feature flags</b><span className="mut">all off by default</span></div>
      {FLAGS.map((f) => (
        <div key={f.name} className="hx-flag">
          <div><b style={{ fontSize: 13 }}>{f.label}</b><div className="mut" style={{ fontSize: 12 }}>{f.help}</div></div>
          <button className={"btn sm" + (flags[f.name] ? "" : " ghost")} disabled={busy === "/harness_engine/flags"}
            onClick={() => act("/harness_engine/flags", { name: f.name, value: !flags[f.name] }, `${f.label}: ${!flags[f.name] ? "on" : "off"}`)}>
            {flags[f.name] ? "On" : "Off"}</button>
        </div>
      ))}

      <div className="dx-head" style={{ marginTop: 18 }}><b>Batch engine</b>
        <span className="mut">{eng?.running ? "running" : "stopped"}{eng?.dry_run ? " · dry-run" : ""}</span>
        <button className="btn ghost sm" style={{ marginLeft: "auto" }} onClick={load}>Refresh</button></div>
      {!flags.harness_engine ? <div className="hx-warn">Turn on “SentryEngine + labs” above before starting the engine or queueing from a lab.</div> : null}
      <div className="hx-row" style={{ marginTop: 6 }}>
        <button className="btn sm" disabled={!flags.harness_engine || !!eng?.running || !!busy}
          onClick={() => { if (window.confirm("Start the engine? It will run everything in the queue and uses your BRAIN simulation quota. Use dry-run first if unsure.")) act("/harness_engine/start", undefined, "Engine started."); }}>Start</button>
        <button className="btn ghost sm" disabled={!eng?.running} onClick={() => act("/harness_engine/stop", undefined, "Stopping…")}>Stop</button>
        <button className="btn ghost sm" onClick={() => act("/harness_engine/dry_run", { on: !eng?.dry_run }, eng?.dry_run ? "Dry-run off." : "Dry-run on: nothing will be simulated.")}>
          {eng?.dry_run ? "Dry-run: on" : "Dry-run: off"}</button>
        <button className="btn ghost sm" disabled={!flags.harness_engine} onClick={async () => { const r: any = await act("/harness_engine/score"); if (r) (r.failed ? toastErr : (m: string) => toast(m, "ok"))(`Scored ${r.scored ?? 0}, failed ${r.failed ?? 0}.${(r.errors ?? []).slice(0, 3).map((e: any) => ` ${e.alpha_id}: ${e.error}`).join(" |")}`); }}>Score finished now</button>
        <button className="btn ghost sm" disabled={!flags.harness_engine || !!busy} title="Clean slate: cancels everything queued or running in the engine, stops its search tasks, clears its focus and crash journal, and starts a fresh engine. Your results, vault, library and Autosentry are not touched."
          onClick={async () => {
            if (!window.confirm("Reset the engine?\n\nThis cancels EVERYTHING queued or running in SentryEngine, stops all its search tasks, clears its region focus and crash journal, and starts a fresh engine.\n\nNot touched: your results, the vault, your library, and Autosentry's own running batches. Nothing is submitted. Simulations already sent to BRAIN are abandoned (BRAIN finishes them on its own).")) return;
            const d = await act("/harness_engine/reset", { restart: true });
            if (d) toast(`Engine reset: ${d.cancelled} simulation(s) cancelled (${d.abandoned_running} were running), ${d.tasks_stopped} task(s) stopped, ${d.slots_released} slot(s) freed. ${d.restarted ? "A fresh engine is running." : ""}`, "ok");
          }}>Reset engine</button>
      </div>
      {eng ? (
        <>
          <div className="hx-chips">
            {Object.entries(eng.counts ?? {}).map(([k, v]) => <span key={k} className="chip">{k}: <b>{String(v)}</b></span>)}
            {lease ? <span className="chip">slots: <b>{lease.used}/{lease.total}</b></span> : null}
          </div>
          {(eng.log ?? []).length ? <div className="hx-log">{(eng.log as string[]).join("\n")}</div> : null}
        </>
      ) : <div className="mut" style={{ fontSize: 12, marginTop: 8 }}>Engine not started yet in this session.</div>}

      <SlotsPanel />
      <QueueByRegion flagOn={!!flags.harness_engine} />

      <div className="dx-head" style={{ marginTop: 18 }}><b>Yield by lab</b><span className="mut">last {yl?.days ?? 14} days · target {((yl?.targetYield ?? 0.001) * 100).toFixed(1)}%</span></div>
      {yl?.plainly ? <div className="hx-note">{String(yl.plainly)}</div> : null}
      {(yl?.labs ?? []).length ? (
        <table className="hx-table"><thead><tr><th>lab</th><th>finished</th><th>passing</th><th>yield</th><th>best |Sharpe|</th><th></th></tr></thead>
          <tbody>{(yl!.labs as Res[]).map((l) => (
            <tr key={l.lab}><td>{l.lab}</td><td>{l.finished}</td><td>{l.passing}</td><td>{(l.yieldRate * 100).toFixed(2)}%</td>
              <td>{fmt(l.bestSharpe)}</td><td className="mut">{l.confident ? "" : "too few to judge"}</td></tr>))}</tbody></table>
      ) : null}
      <div className="mut" style={{ fontSize: 11.5, marginTop: 6 }}>Passing = passed Alpha Sentry's own gate. Autosentry and Supersentry simulations appear as “autopilot” / “superpilot” in the slot list once routed through the engine.</div>
      <SpeedPanel />
      <SeedPanel />
      <WinnerPanel />
    </div>
  );
}

// Autosentry speed (G1): only used while “Autosentry via engine” is on.
function SpeedPanel() {
  const { toast, toastErr } = useToast();
  const [st, setSt] = useState<Res | null>(null);
  const [d, setD] = useState({ parallel: "6", slow: "25" });
  const load = async () => {
    const r = await call("get", "/harness_engine/speed");
    if (r.err) return;
    setSt(r.d);
    setD({ parallel: String(r.d.settings.parallel), slow: String(Math.round(r.d.settings.straggler_s / 60)) });
  };
  useEffect(() => { load(); }, []);
  async function save() {
    const { err } = await call("post", "/harness_engine/speed", { parallel: Math.round(+d.parallel || 0), straggler_s: Math.max(0, Math.round((+d.slow || 0) * 60)) });
    if (err) return toastErr(err);
    toast("Speed settings saved. They apply the next time Autosentry starts a run.", "ok");
    load();
  }
  return (
    <>
      <div className="dx-head" style={{ marginTop: 18 }}><b>Autosentry speed</b><span className="mut">{st ? (st.routing ? "active (Autosentry via engine is on)" : "not active: turn on “Autosentry via engine”") : ""}</span></div>
      <div className="mut" style={{ fontSize: 12 }}>
        Alpha Sentry runs 3 batches of 10 side by side; BRAIN has 8 slots. With the switch on, each Autosentry round can run more batches at once (all slots are shared with the engine, so the total never goes over 8).
        If BRAIN refuses a batch, the number is lowered by itself for 20 minutes and then tried again. A batch still running long after the others finished no longer holds up the round: it keeps running on BRAIN and is scored by the harness when done.
        More batches per round also means more alphas per round, so the AI reads results less often.
      </div>
      <div className="hx-row" style={{ marginTop: 6 }}>
        <label className="fld"><span>Batches side by side (1–8; Alpha Sentry's own is 3)</span><input type="number" min={1} max={8} value={d.parallel} onChange={(e) => setD({ ...d, parallel: e.target.value })} /></label>
        <label className="fld"><span>Move on after a slow batch, minutes (0 = never)</span><input type="number" min={0} value={d.slow} onChange={(e) => setD({ ...d, slow: e.target.value })} /></label>
        <button className="btn sm" onClick={save}>Save</button>
      </div>
      {st?.learnedCeiling ? <div className="hx-warn">BRAIN refused a batch recently: limited to {st.learnedCeiling} at once for about {Math.ceil(st.ceilingSecondsLeft / 60)} more minute(s).</div> : null}
    </>
  );
}

// Shipped data (G2): the seed file that comes with each version, merged insert-only.
function SeedPanel() {
  const { toast, toastErr } = useToast();
  const [st, setSt] = useState<Res | null>(null);
  const [busy, setBusy] = useState("");
  const [out, setOut] = useState<Res | null>(null);
  const load = async () => {
    const r = await call("get", "/harness_engine/seed");
    if (!r.err) setSt(r.d);
  };
  useEffect(() => { load(); }, []);
  async function run(dry: boolean, force: boolean) {
    if (!dry && force && !window.confirm("Add back everything from the shipped data file that is missing from your database, including rows you deleted? Nothing existing is changed.")) return;
    setBusy(dry ? "dry" : force ? "force" : "merge");
    const { d, err } = await call("post", "/harness_engine/seed/merge", { dry_run: dry, force });
    setBusy("");
    if (err) return toastErr(err);
    setOut(d);
    if (!dry) toast(d.skipped ?? `Added ${Object.values(d.added ?? {}).reduce((a: number, b: any) => a + Number(b), 0)} row(s).`, "ok");
    load();
  }
  const tables = Object.entries((st?.tables ?? {}) as Record<string, Res>);
  return (
    <>
      <div className="dx-head" style={{ marginTop: 18 }}><b>Shipped data</b><span className="mut">{!st ? "" : !st.present ? "no data file in this version" : st.applied ? "merged" : "not merged yet"}{st && !st.enabled ? " · automatic merge is off" : ""}</span></div>
      <div className="mut" style={{ fontSize: 12 }}>
        Every version carries a copy of your knowledge data (catalogue and operator reference; never anyone's alphas, results, vault or library). On start, rows your database lacks are added; nothing is ever changed or removed, and this runs once per data file,
        so rows you delete stay deleted. A backup of your database is saved in the data folder’s “backups” first. It never contains anyone's own work.
      </div>
      {st?.present ? (
        <>
          <table className="hx-table"><thead><tr><th>table</th><th>in data file</th><th>in your database</th></tr></thead>
            <tbody>{tables.map(([t, v]) => <tr key={t}><td>{t}</td><td>{v.inSeed}</td><td>{v.live ?? "—"}</td></tr>)}</tbody></table>
          <div className="hx-row" style={{ marginTop: 6 }}>
            <button className="btn ghost sm" disabled={!!busy} onClick={() => run(true, false)}>{busy === "dry" ? <span className="spin" /> : "Count what is missing"}</button>
            <button className="btn sm" disabled={!!busy} onClick={() => run(false, false)}>{busy === "merge" ? <span className="spin" /> : "Merge now"}</button>
            <button className="btn ghost sm" disabled={!!busy} onClick={() => run(false, true)} title="Also restores rows you deleted">{busy === "force" ? <span className="spin" /> : "Merge again (restore deleted)"}</button>
          </div>
          {out ? <div className="hx-note">{out.skipped ?? `${out.dryRun ? "Would add" : "Added"}: ${Object.entries(out.added ?? {}).filter(([, n]) => Number(n) > 0).map(([t, n]) => `${t} ${n}`).join(", ") || "nothing, you already have everything"}`}
            {out.problems && Object.keys(out.problems).length ? <div className="hx-warn">{Object.entries(out.problems).map(([t, m]) => `${t}: ${m}`).join("; ")}</div> : null}</div> : null}
        </>
      ) : null}
    </>
  );
}

// Winner tag + colour for lab results (E2): the same rule Alpha Sentry's own runs use, from one default because lab runs have no per-run form.
function WinnerPanel() {
  const { toast, toastErr } = useToast();
  const [colors, setColors] = useState<string[]>([]);
  const [w, setW] = useState({ tag: "", color: "GREEN", above: "1" });
  const load = async () => {
    const r = await call("get", "/harness_engine/winner");
    if (r.err) return;
    setColors(r.d.colors ?? []);
    setW({ tag: String(r.d.settings.winner_tag ?? ""), color: String(r.d.settings.winner_color ?? "GREEN"), above: String(r.d.settings.tag_winners_above ?? 1) });
  };
  useEffect(() => { load(); }, []);
  async function save() {
    const { err } = await call("post", "/harness_engine/winner", { winner_tag: w.tag.trim(), winner_color: w.color, tag_winners_above: Math.max(0, +w.above || 0) });
    if (err) return toastErr(err);
    toast(w.tag.trim() ? "Winner tag saved." : "Winner tagging is off.", "ok");
    load();
  }
  return (
    <>
      <div className="dx-head" style={{ marginTop: 18 }}><b>Winner tag for lab results</b><span className="mut">{w.tag.trim() ? "on" : "off (blank tag)"}</span></div>
      <div className="mut" style={{ fontSize: 12 }}>
        When a lab's alpha is scored and PASSES your gate with |Fitness| at or above the threshold, it is labelled in BRAIN with this tag and colour, as your own runs do.
        Everything else keeps the plain “harness” tag. Blank tag = off. It only labels; it never submits.
      </div>
      <div className="hx-row" style={{ marginTop: 6 }}>
        <label className="fld"><span>Winner tag</span><input value={w.tag} maxLength={40} onChange={(e) => setW({ ...w, tag: e.target.value })} placeholder="e.g. harness-winner" /></label>
        <label className="fld"><span>Colour</span><select value={w.color} onChange={(e) => setW({ ...w, color: e.target.value })}>{colors.map((c) => <option key={c} value={c}>{c}</option>)}</select></label>
        <label className="fld"><span>Tag when |Fitness| ≥</span><input type="number" min={0} step="0.1" value={w.above} onChange={(e) => setW({ ...w, above: e.target.value })} /></label>
        <button className="btn sm" onClick={save}>Save</button>
      </div>
    </>
  );
}

// ───────────────────────────── Labs ─────────────────────────────
function Labs() {
  const { toast, toastErr } = useToast();
  const [lab, setLab] = useState<LabId>("relocate");
  const [sc, setSc] = useState<ScopeState>({ region: "USA", delay: 1, universe: "TOP3000", target: 300 });
  const [o, setO] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState("");
  const [out, setOut] = useState<Res | null>(null);
  const opt = (k: string, d: string) => o[k] ?? d;
  const setOpt = (k: string) => (e: { target: { value: string } }) => setO({ ...o, [k]: e.target.value });

  function body(): Res {
    const b: Res = { ...sc };
    if (lab === "relocate") Object.assign(b, { min_sharpe: +opt("min_sharpe", "1"), limit: +opt("limit", "20"), neutralizations: split(opt("neuts", "SUBINDUSTRY")) });
    if (lab === "repair") Object.assign(b, { seeds: +opt("seeds", "40"), checks: split(opt("checks", "")) });
    if (lab === "harden") Object.assign(b, { min_sharpe: +opt("min_sharpe", "1.25"), limit: +opt("limit", "10") });
    if (lab === "harvest" || lab === "diversify") Object.assign(b, { group: opt("group", "industry"), neutralization: opt("neut", "SUBINDUSTRY"), per_dataset: +opt("per_dataset", "1"), fields: split(opt("fields", "")), patterns: split(opt("patterns", "")) });
    if (lab === "pair") Object.assign(b, { group: opt("group", "subindustry"), neutralization: opt("neut", "SUBINDUSTRY"), decay: +opt("decay", "4"), per_dataset: +opt("per_dataset", "1") });
    return b;
  }
  async function go(kind: "preview" | "run") {
    setBusy(kind);
    const { d, err } = await call("post", `/harness_engine/${lab}/${kind}`, body());
    setBusy("");
    if (err) { setOut(null); return toastErr(err); }
    setOut(d);
    if (kind === "run") toast(`Queued ${d.queued ?? 0} (${d.duplicates ?? 0} already known). Nothing runs until the engine is started.`, "ok");
  }
  const meta = LABS.find((l) => l.id === lab)!;

  return (
    <div className="panel" style={{ padding: 14 }}>
      <div className="seg" style={{ marginBottom: 10 }}>
        {LABS.map((l) => <button key={l.id} className={"seg-btn" + (lab === l.id ? " on" : "")} onClick={() => { setLab(l.id); setOut(null); }}>{l.label}</button>)}
      </div>
      <div className="mut" style={{ fontSize: 12.5, marginBottom: 8 }}>{meta.help}</div>
      <ScopeForm s={sc} set={(p) => setSc({ ...sc, ...p })} />
      <div className="hx-row" style={{ marginTop: 8 }}>
        {lab === "relocate" ? <>
          <label className="fld"><span>Min |Sharpe| of source alphas</span><input type="number" step="0.1" value={opt("min_sharpe", "1")} onChange={setOpt("min_sharpe")} /></label>
          <label className="fld"><span>How many source alphas</span><input type="number" value={opt("limit", "20")} onChange={setOpt("limit")} /></label>
          <label className="fld"><span>Neutralizations (comma)</span><input value={opt("neuts", "SUBINDUSTRY")} onChange={setOpt("neuts")} /></label></> : null}
        {lab === "repair" ? <>
          <label className="fld"><span>Near-miss alphas to repair</span><input type="number" value={opt("seeds", "40")} onChange={setOpt("seeds")} /></label>
          <label className="fld"><span>Only these checks (comma, optional)</span><input value={opt("checks", "")} onChange={setOpt("checks")} placeholder="HIGH_TURNOVER, LOW_FITNESS" /></label></> : null}
        {lab === "harden" ? <>
          <label className="fld"><span>Min |Sharpe|</span><input type="number" step="0.1" value={opt("min_sharpe", "1.25")} onChange={setOpt("min_sharpe")} /></label>
          <label className="fld"><span>How many alphas</span><input type="number" value={opt("limit", "10")} onChange={setOpt("limit")} /></label></> : null}
        {lab === "harvest" || lab === "diversify" ? <>
          <label className="fld"><span>Group</span><input value={opt("group", "industry")} onChange={setOpt("group")} /></label>
          <label className="fld"><span>Neutralization</span><input value={opt("neut", "SUBINDUSTRY")} onChange={setOpt("neut")} /></label>
          <label className="fld"><span>Fields per dataset</span><input type="number" value={opt("per_dataset", "1")} onChange={setOpt("per_dataset")} /></label>
          <label className="fld"><span>Patterns (comma, optional)</span><input value={opt("patterns", "")} onChange={setOpt("patterns")} /></label>
          {lab === "harvest" ? <label className="fld"><span>Specific fields (comma, optional)</span><input value={opt("fields", "")} onChange={setOpt("fields")} /></label> : null}</> : null}
        {lab === "pair" ? <>
          <label className="fld"><span>Group</span><input value={opt("group", "subindustry")} onChange={setOpt("group")} /></label>
          <label className="fld"><span>Neutralization</span><input value={opt("neut", "SUBINDUSTRY")} onChange={setOpt("neut")} /></label>
          <label className="fld"><span>Decay</span><input type="number" value={opt("decay", "4")} onChange={setOpt("decay")} /></label>
          <label className="fld"><span>Fields per dataset</span><input type="number" value={opt("per_dataset", "1")} onChange={setOpt("per_dataset")} /></label></> : null}
      </div>
      <div className="hx-row" style={{ marginTop: 10 }}>
        <button className="btn sm" onClick={() => go("preview")} disabled={!!busy}>{busy === "preview" ? <span className="spin" /> : "Preview (free)"}</button>
        <button className="btn ghost sm" onClick={() => go("run")} disabled={!!busy}>{busy === "run" ? <span className="spin" /> : "Queue for the engine"}</button>
        <span className="mut" style={{ fontSize: 12 }}>Preview never simulates or spends quota. Queue only adds to the engine's list; nothing is submitted by any lab.</span>
      </div>
      <ResultView d={out} />
    </div>
  );
}

// ───────────────────────────── Mixing ─────────────────────────────
function Mixing() {
  const { toast, toastErr } = useToast();
  const [sc, setSc] = useState<ScopeState>({ region: "USA", delay: 1, universe: "TOP3000", target: 300 });
  const [neut, setNeut] = useState("");
  const [minSharpe, setMinSharpe] = useState("0.7");
  const [sizes, setSizes] = useState<number[]>([2]);
  const [maxCorr, setMaxCorr] = useState("0.5");
  const [busy, setBusy] = useState("");
  const [mix, setMix] = useState<Res | null>(null);
  const [matrix, setMatrix] = useState<Res | null>(null);
  const [picked, setPicked] = useState<Record<number, boolean>>({});
  const [preview, setPreview] = useState<Res | null>(null);
  const [queued, setQueued] = useState<Res | null>(null);
  const jobRef = useRef("");

  const base = () => ({ region: sc.region, delay: sc.delay, universe: sc.universe, neutralization: neut || null, min_sharpe: +minSharpe });

  async function run(kind: string, path: string, body: unknown, after: (d: Res) => void) {
    setBusy(kind);
    const { d, err } = await call("post", path, body);
    setBusy("");
    if (err) return toastErr(err);
    after(d);
  }
  const groups: Res[] = mix?.groups ?? [];
  const chosen = groups.filter((_, i) => picked[i]);

  return (
    <div className="panel" style={{ padding: 14 }}>
      <div className="mut" style={{ fontSize: 12.5, marginBottom: 8 }}>
        Needs the “Returns vault + mixing” flag. Backfill fetches each alpha's daily returns from BRAIN (reads only, no simulation quota); everything after that is computed locally.
      </div>
      <ScopeForm s={sc} set={(p) => setSc({ ...sc, ...p })} />
      <div className="hx-row" style={{ marginTop: 8 }}>
        <label className="fld"><span>Neutralization (optional)</span><input value={neut} onChange={(e) => setNeut(e.target.value.toUpperCase())} placeholder="any" /></label>
        <label className="fld"><span>Min |Sharpe|</span><input type="number" step="0.1" value={minSharpe} onChange={(e) => setMinSharpe(e.target.value)} /></label>
        <label className="fld"><span>Max correlation inside a mix</span><input type="number" step="0.05" value={maxCorr} onChange={(e) => setMaxCorr(e.target.value)} /></label>
        <div className="fld"><span>Mix sizes</span>
          <div className="hx-row" style={{ gap: 12, alignItems: "center" }}>
            {[2, 3, 4].map((n) => <label key={n} style={{ fontSize: 13 }}><input type="checkbox" style={{ width: "auto", marginRight: 4 }} checked={sizes.includes(n)}
              onChange={(e) => setSizes(e.target.checked ? [...sizes, n].sort() : sizes.filter((x) => x !== n))} />{n}</label>)}
          </div></div>
      </div>
      <div className="hx-row" style={{ marginTop: 10 }}>
        <button className="btn ghost sm" disabled={!!busy} onClick={() => run("backfill", "/harness_vault/backfill", { ...base(), limit: 200 }, (d) => { jobRef.current = d.job_id; toast("Backfill started — watch the job tray.", "ok"); })}>
          {busy === "backfill" ? <span className="spin" /> : "Backfill returns"}</button>
        <button className="btn ghost sm" disabled={!!busy} onClick={() => run("matrix", "/harness_vault/matrix", { ...base(), limit: 60 }, (d) => setMatrix(d))}>
          {busy === "matrix" ? <span className="spin" /> : "Correlation matrix"}</button>
        <button className="btn sm" disabled={!!busy || !sizes.length} onClick={() => run("mix", "/harness_vault/mix/candidates", { ...base(), sizes, max_correlation: +maxCorr, min_uplift: 0 }, (d) => { setMix(d); setPicked({}); setPreview(null); setQueued(null); })}>
          {busy === "mix" ? <span className="spin" /> : "Find mixes"}</button>
      </div>

      {mix?.note ? <div className="hx-note">{String(mix.note)}</div> : null}
      {mix ? <div className="hx-chips"><span className="chip">alphas with returns: <b>{mix.population}</b></span><span className="chip">shared days: <b>{mix.overlap}</b></span><span className="chip">candidate mixes: <b>{groups.length}</b></span></div> : null}
      {groups.length ? (
        <div className="panel-scroll" style={{ maxHeight: 340 }}>
          <table className="hx-table"><thead><tr><th></th><th>members</th><th>combined Sharpe</th><th>best member</th><th>uplift</th><th>max corr</th><th>self-correlation</th></tr></thead>
            <tbody>{groups.map((g, i) => (
              <tr key={i}>
                <td><input type="checkbox" style={{ width: "auto" }} checked={!!picked[i]} onChange={(e) => setPicked({ ...picked, [i]: e.target.checked })} /></td>
                <td title={(g.expressions ?? []).join("\n")}>{(g.members ?? []).join(" + ")}</td>
                <td>{fmt(g.combinedSharpe)}</td><td>{fmt(g.bestMember)}</td><td>{fmt(g.uplift)}</td><td>{fmt(g.maxPairCorrelation)}</td>
                <td title={g.selfCorrelation?.reason}>{g.selfCorrelation ? (g.selfCorrelation.passes ? "✓ pass" : "✗ fail") : "—"}</td>
              </tr>))}</tbody></table>
        </div>
      ) : null}
      {chosen.length ? (
        <div className="hx-row" style={{ marginTop: 10 }}>
          <button className="btn ghost sm" disabled={!!busy} onClick={() => run("prev", "/harness_vault/mix/preview", { members: chosen[0].members }, (d) => setPreview(d))}>Preview first selected</button>
          <button className="btn ghost sm" disabled={!!busy} onClick={() => run("dry", "/harness_vault/mix/run", { groups: chosen.map((g) => g.members), dry_run: true }, (d) => setQueued(d))}>Check selected (dry run)</button>
          <button className="btn sm" disabled={!!busy} onClick={() => run("queue", "/harness_vault/mix/run", { groups: chosen.map((g) => g.members) }, (d) => { setQueued(d); toast(`Queued ${d.queued ?? 0} mix(es). Start the engine to simulate them.`, "ok"); })}>Queue {chosen.length} selected</button>
        </div>
      ) : null}
      <ResultView d={preview} />
      <ResultView d={queued} />
      {matrix ? <><div className="dx-head" style={{ marginTop: 14 }}><b>Correlation matrix</b></div><ResultView d={matrix} /></> : null}
    </div>
  );
}

// ───────────────────────────── Tasks ─────────────────────────────
const STARTER_TEMPLATE = `name: reversion on a ranked field
description: Rank a z-scored field and sweep the lookback and neutralization.
expr: rank(ts_zscore($field, $lookback))
vars:
  field:    {type: datafield, category: fundamental, max_alpha_count: 50, limit: 10}
  lookback: {type: int, grid: [5, 22, 63, 252]}
settings:
  neutralization: [SUBINDUSTRY, INDUSTRY]
  decay: 4
constraints:
  max_simulations: 200
`;

const STATUS_CLASS: Record<string, string> = { running: "ok", done: "ok", paused: "", stopped: "", error: "bad" };

// A constraint map is { CHECK: violation }; 0 = passed, > 0 = how far past the limit.
const feasible = (c: any): boolean => !c || Object.values(c as Record<string, number>).every((x) => !(x > 0));

function ProgressBar({ v }: { v: number }) {
  const pct = Math.max(0, Math.min(100, Math.round((v || 0) * 100)));
  return <span className="hx-bar" title={pct + "%"}><span style={{ width: pct + "%" }} /></span>;
}

function TrialTable({ title, rows, objs }: { title: string; rows: Res[]; objs: { key: string; label: string }[] }) {
  if (!rows.length) return null;
  return (
    <div style={{ marginTop: 10 }}>
      <b style={{ fontSize: 12 }}>{title}</b> <span className="mut">({rows.length})</span>
      <div className="panel-scroll" style={{ maxHeight: 300 }}>
        <table className="hx-table">
          <thead><tr><th>#</th><th>alpha</th>{objs.map((o) => <th key={o.key}>{o.label}</th>)}<th>gate</th><th>{rows.some((r) => r.params?.expr) ? "expression" : "params"}</th></tr></thead>
          <tbody>{rows.map((r) => (
            <tr key={r.number}>
              <td>{r.number}</td>
              <td title={r.alphaId ?? ""}>{r.alphaId ?? "—"}</td>
              {objs.map((o, i) => <td key={o.key}>{fmt((r.values ?? [])[i])}</td>)}
              <td title={(r.summary?.failedChecks ?? []).join(", ")}>{feasible(r.constraint) ? "✓ pass" : "✗ " + (r.summary?.failedChecks ?? []).length}</td>
              <td title={r.params?.expr ? `${r.params.expr}\n(gen ${r.params.gen}, ${r.params.how})` : JSON.stringify(r.params)}>{r.params?.expr ? `g${r.params.gen} ${r.params.expr}` : Object.entries(r.params ?? {}).map(([k, v]) => `${k}=${fmt(v)}`).join(" ")}</td>
            </tr>))}</tbody>
        </table>
      </div>
    </div>
  );
}

function TaskDetail({ id, onChanged, onGone }: { id: number; onChanged: () => void; onGone: () => void }) {
  const { toast, toastErr } = useToast();
  const [d, setD] = useState<Res | null>(null);
  const [busy, setBusy] = useState("");
  const [pp, setPp] = useState<Res | null>(null);
  const load = async () => {
    const r = await call("get", `/harness_engine/tasks/${id}`);
    if (r.err) { setD(null); return; }
    setD(r.d);
  };
  useEffect(() => { setD(null); setPp(null); load(); const t = setInterval(load, 4000); return () => clearInterval(t); }, [id]);
  async function loadPool() {
    setBusy("pool");
    const r = await call("get", `/harness_engine/tasks/${id}/power_pool`);
    setBusy("");
    if (r.err) return toastErr(r.err);
    setPp(r.d);
  }

  async function act(kind: "pause" | "resume" | "stop" | "remove") {
    if (kind === "stop" && !window.confirm("Stop this task? Queued points are dropped; simulations already running finish but are no longer followed.")) return;
    if (kind === "remove" && !window.confirm("Remove this task and its trial list? Alphas already in Results stay there.")) return;
    setBusy(kind);
    const r = kind === "remove" ? await call("delete", `/harness_engine/tasks/${id}`) : await call("post", `/harness_engine/tasks/${id}/${kind}`);
    setBusy("");
    if (r.err) return toastErr(r.err);
    toast(kind === "remove" ? "Task removed." : `Task ${kind === "pause" ? "paused" : kind === "resume" ? "resumed" : "stopped"}.`, "ok");
    onChanged();
    if (kind === "remove") onGone(); else load();
  }

  if (!d) return <div className="mut" style={{ fontSize: 12, marginTop: 10 }}>Loading task…</div>;
  const optKeys: string[] = d.objectives ?? [];
  const objs = optKeys.map((k, i) => ({ key: k, label: `${k} (${(d.directions ?? [])[i] === "minimize" ? "min" : "max"})` }));
  const st: string = d.status;
  const counts: Record<string, number> = d.counts ?? {};
  return (
    <div style={{ marginTop: 14, paddingTop: 12, borderTop: "1px solid var(--line)" }}>
      <div className="dx-head"><b>#{d.id} {d.name}</b>
        <span className={"chip " + (STATUS_CLASS[st] ?? "")}>{st}</span>
        <span className="mut">{d.sampler} · {optKeys.join(", ")} · {d.scope?.region} d{d.scope?.delay} {d.scope?.universe}</span>
        <span style={{ marginLeft: "auto" }} className="hx-row">
          <button className="btn ghost sm" disabled={st !== "running" || !!busy} onClick={() => act("pause")}>Pause</button>
          <button className="btn ghost sm" disabled={st !== "paused" || !!busy} onClick={() => act("resume")}>Resume</button>
          <button className="btn ghost sm" disabled={(st !== "running" && st !== "paused") || !!busy} onClick={() => act("stop")}>Stop</button>
          <button className="btn ghost sm" disabled={!!busy} onClick={() => act("remove")}>Remove</button>
        </span>
      </div>
      <div className="hx-row" style={{ alignItems: "center", margin: "6px 0" }}><ProgressBar v={d.progress} /><span className="mut" style={{ fontSize: 12 }}>{Math.round((d.progress ?? 0) * 100)}% of {d.budget}</span></div>
      <div className="hx-chips">{Object.entries(counts).map(([k, v]) => <span key={k} className="chip">{k}: <b>{String(v)}</b></span>)}</div>
      {d.error ? <div className="hx-warn">{String(d.error)}</div> : null}
      {(d.notes ?? []).map((n: string, i: number) => <div key={i} className="hx-note">{n}</div>)}
      {(d.generations ?? []).length ? (
        <div style={{ marginTop: 10 }}>
          <b style={{ fontSize: 12 }}>Generations</b> <span className="mut">(is it improving?)</span>
          <table className="hx-table"><thead><tr><th>generation</th><th>alphas</th><th>finished</th><th>best {optKeys[0]}</th></tr></thead>
            <tbody>{(d.generations as Res[]).map((g) => (
              <tr key={g.generation}><td>{g.generation}</td><td>{g.alphas}</td><td>{g.finished}</td><td>{fmt(g.best)}</td></tr>))}</tbody></table>
        </div>
      ) : null}
      {d.powerPool ? (
        <div style={{ marginTop: 10 }}>
          <div className="hx-row" style={{ alignItems: "center" }}>
            <b style={{ fontSize: 12 }}>Power Pool selection</b>
            <button className="btn ghost sm" disabled={!!busy} onClick={loadPool}>{busy === "pool" ? <span className="spin" /> : pp ? "Refresh" : "Show which alphas qualify"}</button>
          </div>
          {pp ? (
            <>
              <div className="hx-chips">
                <span className="chip">qualifying: <b>{(pp.qualifying ?? []).length}</b></span>
                <span className="chip">one reason short: <b>{(pp.almost ?? []).length}</b></span>
                <span className="chip">further away: <b>{pp.other}</b></span>
                <span className="chip" title="Verify these against BRAIN's current Power Pool rules">limits: ≤{pp.limits?.maxOperators} operators · ≤{pp.limits?.maxFields} fields · |Sharpe| ≥ {pp.limits?.minSharpe} · pool corr &lt; {pp.limits?.maxPoolCorrelation}</span>
              </div>
              {[...(pp.qualifying ?? []), ...(pp.almost ?? [])].length ? (
                <div className="panel-scroll" style={{ maxHeight: 260 }}>
                  <table className="hx-table"><thead><tr><th>alpha</th><th>expression</th><th>Sharpe</th><th>turnover</th><th>pool corr</th><th>what stops it</th></tr></thead>
                    <tbody>{[...(pp.qualifying ?? []), ...(pp.almost ?? [])].map((r: Res) => (
                      <tr key={r.alpha_id}><td>{r.alpha_id}</td><td title={r.expression}>{r.expression}</td><td>{fmt(r.sharpe)}</td><td>{fmt(r.turnover)}</td>
                        <td>{fmt(r.powerpool_corr)}</td><td>{(r.reasons ?? []).length ? (r.reasons as string[]).join("; ") : "✓ qualifies"}</td></tr>))}</tbody></table>
                </div>
              ) : <div className="mut" style={{ fontSize: 12 }}>Nothing is close yet.</div>}
            </>
          ) : null}
        </div>
      ) : null}
      <TrialTable title="Best trials" rows={d.best ?? []} objs={objs} />
      {optKeys.length > 1 ? <TrialTable title="Pareto front" rows={d.pareto ?? []} objs={objs} /> : null}
      <details className="hx-raw" style={{ marginTop: 10 }}><summary className="mut" style={{ cursor: "pointer", fontSize: 12 }}>search space and settings</summary>
        <pre>{JSON.stringify({ space: d.space, scope: d.scope, budget: d.budget, batch: d.batch, cores: d.cores }, null, 2)}</pre></details>
      <TrialTable title="Most recent trials" rows={[...(d.recent ?? [])].reverse().slice(0, 25)} objs={objs} />
    </div>
  );
}

function Tasks() {
  const { toast, toastErr } = useToast();
  const [tasks, setTasks] = useState<Res[]>([]);
  const [sel, setSel] = useState<number | null>(null);
  const [st, setSt] = useState<Res | null>(null);
  const [opt, setOpt] = useState<Res | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [sc, setSc] = useState({ region: "USA", delay: 1, universe: "TOP3000" });
  const [tpl, setTpl] = useState(STARTER_TEMPLATE);
  const [name, setName] = useState("");
  const [sampler, setSampler] = useState("");
  const [objs, setObjs] = useState<string[] | null>(null);
  const [num, setNum] = useState({ budget: "50", batch: "10", cores: "2", seed: "" });
  const [busy, setBusy] = useState("");
  const [pv, setPv] = useState<Res | null>(null);
  const [presets, setPresets] = useState<Res[]>([]);
  const [presetId, setPresetId] = useState("");
  const [lab, setLab] = useState("search");
  const [rec, setRec] = useState<Res | null>(null);
  const [saved, setSaved] = useState<Res[]>([]);
  const [savedId, setSavedId] = useState("");

  const loadSaved = async () => { const r = await call("get", "/harness_engine/saved"); if (!r.err) setSaved(r.d.saved ?? []); };
  useEffect(() => { loadSaved(); }, []);

  const load = async () => {
    const t = await call("get", "/harness_engine/tasks");
    if (!t.err) setTasks(t.d.tasks ?? []);
    const s = await call("get", "/harness_engine/status");
    if (!s.err) setSt(s.d);
  };
  useEffect(() => { load(); const t = setInterval(load, 4000); return () => clearInterval(t); }, []);
  useEffect(() => { call("get", "/harness_engine/optimizers").then((r) => { if (!r.err) setOpt(r.d); }); }, []);
  useEffect(() => { call("get", "/harness_engine/templates/presets").then((r) => { if (!r.err) setPresets(r.d.presets ?? []); }); }, []);

  function applyPreset(id: string) {
    setPresetId(id);
    const p = presets.find((x) => x.id === id);
    if (!p) return;
    setTpl(String(p.template));
    setSampler(p.sampler ?? "");
    setObjs(p.objectives ?? null);
    setNum((n) => ({ ...n, budget: String(p.budget ?? n.budget) }));
    setLab(String(p.lab ?? "search"));
    setPv(null);
    setRec(null);
  }

  function applySaved(id: string) {
    setSavedId(id);
    const x = saved.find((r) => String(r.id) === id);
    if (!x) return;
    setTpl(String(x.template));
    setSampler(x.sampler ?? "");
    setObjs((x.objectives ?? []).length ? x.objectives : null);
    setNum({ budget: String(x.budget), batch: String(x.batch), cores: String(x.cores), seed: x.seed == null ? "" : String(x.seed) });
    if (x.scope?.region) setSc({ region: x.scope.region, delay: x.scope.delay ?? 1, universe: x.scope.universe ?? "TOP3000" });
    setName(String(x.name));
    setLab("search");
    setPresetId("");
    setPv(null);
    setRec(null);
  }
  async function saveSearch() {
    const nm = window.prompt("Name for this saved search?", name.trim() || "");
    if (!nm || !nm.trim()) return;
    const r = await call("post", "/harness_engine/saved", {
      name: nm.trim(), template: tpl, sampler: curSampler, objectives: curObjs, budget: Math.max(1, +num.budget || 1), batch: Math.max(1, +num.batch || 1),
      cores: Math.max(1, +num.cores || 1), seed: num.seed.trim() === "" ? null : Math.trunc(+num.seed), ...scopeBody(),
    });
    if (r.err) return toastErr(r.err);
    toast(`Saved “${r.d.name}”.`, "ok");
    loadSaved();
    setSavedId(String(r.d.id));
  }
  async function deleteSaved() {
    if (!savedId || !window.confirm("Delete this saved search?")) return;
    const r = await call("delete", `/harness_engine/saved/${savedId}`);
    if (r.err) return toastErr(r.err);
    setSavedId("");
    loadSaved();
  }

  const samplers: Res[] = opt?.samplers ?? [];
  const objectives: Res[] = opt?.objectives ?? [];
  const curSampler = sampler || (samplers.find((s) => s.name === "nsga2") ? "nsga2" : samplers[0]?.name ?? "nsga2");
  const curObjs = objs ?? (opt?.defaultObjectives ?? ["fitness"]);
  const sm = samplers.find((s) => s.name === curSampler);
  const flags: Record<string, boolean> = st?.flags ?? {};
  const eng: Res | undefined = st?.engine;

  const scopeBody = () => ({ region: sc.region, delay: sc.delay, universe: sc.universe });

  async function preview() {
    setBusy("preview");
    const path = lab === "template" ? "/harness_engine/template/preview" : "/harness_engine/templates/preview";
    const { d, err } = await call("post", path, { template: tpl, ...scopeBody(), ...(lab === "template" ? { budget: Math.max(1, +num.budget || 1), batch: Math.max(1, +num.batch || 1) } : {}) });
    if (err) { setBusy(""); setPv(null); setRec(null); return toastErr(err); }
    setPv(d);
    const r = await call("post", "/harness_engine/templates/recommend", { template: tpl, ...scopeBody(), objectives: curObjs, budget: Math.max(1, +num.budget || 1) });
    setBusy("");
    setRec(r.err ? null : r.d);
  }
  async function create() {
    if (!curObjs.length) return toastErr("Pick at least one objective.");
    setBusy("create");
    const common = {
      template: tpl, ...scopeBody(), name: name.trim(), objectives: curObjs,
      budget: Math.max(1, +num.budget || 1), batch: Math.max(1, +num.batch || 1), cores: Math.max(1, +num.cores || 1),
      seed: num.seed.trim() === "" ? null : Math.trunc(+num.seed),
    };
    const { d, err } = lab === "template"
      ? await call("post", "/harness_engine/template/run", common)          // grid sweep: every combination once; the budget is only a cap
      : await call("post", "/harness_engine/tasks", { ...common, lab, sampler: curSampler });
    setBusy("");
    if (err) return toastErr(err);
    toast(`Task #${d.id} created (budget ${d.budget}). It advances only while the engine is running.`, "ok");
    setShowForm(false);
    setSel(d.id);
    load();
  }

  const multi = curObjs.length > 1;
  const sizeHint = pv && pv.gridSize != null && +num.budget > pv.gridSize
    ? `The grid has only ${pv.gridSize} points, so the task will finish after trying them all.` : "";

  return (
    <div className="panel" style={{ padding: 14 }}>
      <div className="mut" style={{ fontSize: 12.5, marginBottom: 8 }}>
        A task searches a template: the sampler proposes points, the engine simulates them, results land in Results (tag “harness”) and feed back to the sampler.
        Nothing is ever submitted.
      </div>
      {!flags.harness_engine ? <div className="hx-warn">Turn on “SentryEngine + labs” in the Control tab before creating tasks.</div> : null}
      {flags.harness_engine && !eng?.running ? <div className="hx-note">The engine is stopped, so tasks wait. Start it in the Control tab (use dry-run first if unsure; dry-run does not advance tasks).</div> : null}
      {eng?.running && eng?.dry_run ? <div className="hx-note">Dry-run is on: nothing is simulated and tasks do not advance.</div> : null}

      <div className="dx-head"><b>Tasks</b><span className="mut">{tasks.length}</span>
        <button className="btn sm" style={{ marginLeft: "auto" }} onClick={() => setShowForm(!showForm)}>{showForm ? "Close form" : "New task"}</button>
        <button className="btn ghost sm" onClick={load}>Refresh</button></div>

      {showForm ? (
        <div className="hx-form">
          {presets.length ? (
            <div className="hx-row" style={{ marginBottom: 8 }}>
              <label className="fld"><span>Start from a preset</span>
                <select value={presetId} onChange={(e) => applyPreset(e.target.value)}>
                  <option value="">Choose…</option>
                  {presets.map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}</select></label>
              <span className="mut" style={{ fontSize: 12, flex: 2 }}>{presets.find((p) => p.id === presetId)?.description ?? "Loads a template with a suggested sampler, objectives and budget. Edit anything afterwards."}</span>
            </div>
          ) : null}
          <div className="hx-row" style={{ marginBottom: 8 }}>
            <label className="fld"><span>Saved searches</span>
              <select value={savedId} onChange={(e) => applySaved(e.target.value)}>
                <option value="">{saved.length ? "Load…" : "None saved yet"}</option>
                {saved.map((x) => <option key={x.id} value={String(x.id)}>{x.name}</option>)}</select></label>
            <button className="btn ghost sm" onClick={saveSearch}>Save this search</button>
            <button className="btn ghost sm" disabled={!savedId} onClick={deleteSaved}>Delete saved</button>
            <label className="fld"><span>Kind of task</span>
              <select value={lab} onChange={(e) => { setLab(e.target.value); setPv(null); }}>
                <option value="search">Search (sampler explores)</option>
                <option value="template">Template sweep (every combination once)</option>
                <option value="power">Power Pool (limits + pool constraints)</option></select></label>
          </div>
          {lab === "power" ? <div className="hx-note">Power Pool task: alphas over 8 operators or 3 data fields are dropped before queueing (set <code>power_pool: true</code> under constraints), and results are judged against the Power Pool numbers instead of the ordinary gate.</div> : null}
          <label className="fld"><span>Template (YAML or JSON)</span>
            <textarea className="hx-ta" spellCheck={false} rows={14} value={tpl} onChange={(e) => setTpl(e.target.value)} /></label>
          <div className="hx-row">
            <button className="btn ghost sm" onClick={() => { setTpl(STARTER_TEMPLATE); setPresetId(""); setLab("search"); setPv(null); setRec(null); }}>Reset to starter template</button>
          </div>
          <div className="hx-row" style={{ marginTop: 8 }}>
            <ScopeFields region={sc.region} delay={sc.delay} universe={sc.universe} onChange={(v) => setSc({ ...sc, ...v })} />
            <label className="fld"><span>Task name (optional)</span><input value={name} onChange={(e) => setName(e.target.value)} placeholder="template name" /></label>
          </div>
          <div className="hx-row" style={{ marginTop: 8 }}>
            <label className="fld"><span>Sampler</span>
              <select value={curSampler} onChange={(e) => setSampler(e.target.value)}>
                {samplers.map((s) => <option key={s.name} value={s.name}>{s.label ?? s.name}{s.recommended ? " (recommended)" : ""}</option>)}
                {!samplers.length ? <option value="nsga2">NSGA-II</option> : null}</select></label>
            <label className="fld"><span>Budget (simulations)</span><input type="number" min={1} value={num.budget} onChange={(e) => setNum({ ...num, budget: e.target.value })} /></label>
            <label className="fld"><span>Batch size</span><input type="number" min={1} value={num.batch} onChange={(e) => setNum({ ...num, batch: e.target.value })} /></label>
            <label className="fld"><span>Cores (batches in flight)</span><input type="number" min={1} value={num.cores} onChange={(e) => setNum({ ...num, cores: e.target.value })} /></label>
            <label className="fld"><span>Seed (optional)</span><input type="number" value={num.seed} onChange={(e) => setNum({ ...num, seed: e.target.value })} placeholder="random" /></label>
          </div>
          {lab === "template" ? <div className="mut" style={{ fontSize: 12, marginTop: 4 }}>A sweep uses the exhaustive sampler; “Budget” is only the most you are willing to spend. Preview shows whether the whole grid fits.</div> : null}
          {sm?.summary && lab !== "template" ? <div className="mut" style={{ fontSize: 12, marginTop: 4 }}>{String(sm.summary)}</div> : null}
          {rec && lab !== "template" ? (
            <div className="hx-note">Suggested sampler: <b>{String(samplers.find((x) => x.name === rec.sampler)?.label ?? rec.sampler)}</b> — {String(rec.why)}
              {rec.sampler !== curSampler ? <> <button className="btn ghost sm" onClick={() => setSampler(String(rec.sampler))}>Use it</button></> : null}
              {(rec.alternatives ?? []).length ? <details style={{ marginTop: 4 }}><summary className="mut" style={{ cursor: "pointer", fontSize: 12 }}>other options</summary>
                {(rec.alternatives as Res[]).map((a) => <div key={a.sampler} style={{ fontSize: 12 }}><b>{String(samplers.find((x) => x.name === a.sampler)?.label ?? a.sampler)}</b>: {String(a.why)}</div>)}</details> : null}
            </div>
          ) : null}
          {sm && !sm.multiObjective && multi ? <div className="hx-warn">{sm.label ?? sm.name} supports a single objective; with several selected the server may fall back to another sampler.</div> : null}
          <div className="fld" style={{ marginTop: 8 }}><span>Objectives {opt?.backend ? <span className="mut">· optimizer backend: {opt.backend}{opt.optunaInstalled ? "" : " (Optuna not installed)"}</span> : null}</span>
            <div className="hx-row" style={{ gap: 14, alignItems: "center" }}>
              {objectives.map((o) => (
                <label key={o.key} style={{ fontSize: 13 }} title={o.summary}>
                  <input type="checkbox" style={{ width: "auto", marginRight: 4 }} checked={curObjs.includes(o.key)}
                    onChange={(e) => setObjs(e.target.checked ? [...curObjs, o.key] : curObjs.filter((x: string) => x !== o.key))} />
                  {o.label}{o.direction === "minimize" ? " ↓" : " ↑"}</label>))}
              {!objectives.length ? <span className="mut" style={{ fontSize: 12 }}>Loading objectives…</span> : null}
            </div></div>

          <div className="hx-row" style={{ marginTop: 10 }}>
            <button className="btn sm" onClick={preview} disabled={!!busy}>{busy === "preview" ? <span className="spin" /> : "Preview template (free)"}</button>
            <button className="btn ghost sm" onClick={create} disabled={!!busy || !flags.harness_engine}>{busy === "create" ? <span className="spin" /> : lab === "template" ? "Create sweep" : "Create task"}</button>
            <span className="mut" style={{ fontSize: 12 }}>Preview parses the template and shows its size and sample alphas. It never simulates.</span>
          </div>

          {pv ? (
            <div style={{ marginTop: 8 }}>
              <div className="hx-chips">
                <span className="chip">grid size: <b>{pv.continuous ? "continuous" : fmt(pv.gridSize)}</b></span>
                <span className="chip">max simulations: <b>{fmt(pv.maxSimulations)}</b></span>
                {Object.entries(pv.fields ?? {}).map(([k, v]) => <span key={k} className="chip">${k} fields: <b>{fmt(v)}</b></span>)}
                {Object.entries(pv.dimensions ?? {}).map(([k, v]) => <span key={k} className="chip" title={JSON.stringify(v)}>{k}: <b>{fmt(Array.isArray(v) ? v[1] : v)}</b></span>)}
              </div>
              {sizeHint && lab !== "template" ? <div className="hx-note">{sizeHint}</div> : null}
              {lab === "template" && pv.sweepError ? <div className="hx-warn">{String(pv.sweepError)}</div> : null}
              {lab === "template" && pv.sweep ? (
                <>
                  <div className="hx-chips">
                    <span className="chip">combinations: <b>{fmt(pv.sweep.gridSize)}</b></span>
                    <span className="chip">will simulate: <b>{fmt(pv.sweep.budget)}</b></span>
                    <span className="chip">batches of {num.batch}: <b>{fmt(pv.sweep.batches)}</b></span>
                    <span className={"chip " + (pv.sweep.fits ? "ok" : "bad")}>{pv.sweep.fits ? "whole grid fits" : `${fmt(pv.sweep.untried)} never tried`}</span>
                  </div>
                  {(pv.sweep.warnings ?? []).map((w: string, i: number) => <div key={i} className="hx-warn">{w}</div>)}
                </>
              ) : null}
              {(pv.problems ?? []).map((p: string, i: number) => <div key={i} className="hx-warn">{p}</div>)}
              {(pv.notes ?? []).map((p: string, i: number) => <div key={i} className="hx-note">{p}</div>)}
              {(pv.sample ?? []).length ? (
                <table className="hx-table"><thead><tr><th>sample alpha</th><th>settings</th><th>problems</th></tr></thead>
                  <tbody>{(pv.sample as Res[]).map((s, i) => (
                    <tr key={i}><td title={s.expression}>{s.expression}</td><td title={JSON.stringify(s.settings)}>{fmt(s.settings)}</td>
                      <td>{(s.breaks ?? []).length ? (s.breaks as string[]).join("; ") : "—"}</td></tr>))}</tbody></table>
              ) : null}
            </div>
          ) : null}
        </div>
      ) : null}

      {tasks.length ? (
        <table className="hx-table" style={{ marginTop: 8 }}>
          <thead><tr><th>#</th><th>name</th><th>lab</th><th>status</th><th>progress</th><th>sampler</th><th>objectives</th><th>counts</th></tr></thead>
          <tbody>{tasks.map((t) => (
            <tr key={t.id} className={"hx-click" + (sel === t.id ? " on" : "")} onClick={() => setSel(sel === t.id ? null : t.id)}>
              <td>{t.id}</td><td title={t.name}>{t.name}</td><td>{t.lab}</td>
              <td><span className={"chip " + (STATUS_CLASS[t.status] ?? "")}>{t.status}</span></td>
              <td><ProgressBar v={t.progress} /> <span className="mut">{Math.round((t.progress ?? 0) * 100)}%</span></td>
              <td>{t.sampler}</td><td>{(t.objectives ?? []).join(", ")}</td>
              <td>{Object.entries(t.counts ?? {}).map(([k, v]) => `${k} ${v}`).join(" · ") || "—"}</td>
            </tr>))}</tbody>
        </table>
      ) : <div className="mut" style={{ fontSize: 12, marginTop: 8 }}>No tasks yet. Use “New task” to start from the starter template.</div>}
      {sel != null ? <TaskDetail id={sel} onChanged={load} onGone={() => setSel(null)} /> : null}
    </div>
  );
}

// ───────────────────────────── Deepen ─────────────────────────────
function ScopeRow({ sc, setSc }: { sc: { region: string; delay: number; universe: string }; setSc: (v: { region: string; delay: number; universe: string }) => void }) {
  return (
    <>
      <ScopeFields region={sc.region} delay={sc.delay} universe={sc.universe} onChange={(v) => setSc({ ...sc, ...v })} />
    </>
  );
}

function Deepen() {
  const { toast, toastErr } = useToast();
  const [sc, setSc] = useState({ region: "USA", delay: 1, universe: "TOP3000" });
  const [alphaId, setAlphaId] = useState("");
  const [expr, setExpr] = useState("");
  const [o, setO] = useState({ radius: "2", windows: true, operators: true, wrapper: true, varyDecay: false, varyNeut: false, max: "200", decay: "0", neut: "" });
  const [obj, setObj] = useState("sharpe");
  const [pv, setPv] = useState<Res | null>(null);
  const [busy, setBusy] = useState("");

  const body = () => ({
    ...sc, alpha_id: alphaId.trim(), expression: expr.trim(), radius: Math.max(1, +o.radius || 2), windows: o.windows, operators: o.operators,
    wrapper: o.wrapper, vary_decay: o.varyDecay, vary_neutralization: o.varyNeut, max_simulations: Math.max(1, +o.max || 200), decay: Math.trunc(+o.decay || 0),
    neutralization: o.neut.trim().toUpperCase(), objectives: [obj],
  });
  async function preview() {
    setBusy("preview");
    const { d, err } = await call("post", "/harness_engine/deepen/preview", body());
    setBusy("");
    if (err) { setPv(null); return toastErr(err); }
    setPv(d);
  }
  async function run() {
    setBusy("run");
    const { d, err } = await call("post", "/harness_engine/deepen/run", body());
    setBusy("");
    if (err) return toastErr(err);
    toast(`Deepen task #${d.id} created (${d.size} alphas). Watch it in the Tasks tab; it advances while the engine is running.`, "ok");
  }
  const chk = (k: "windows" | "operators" | "wrapper" | "varyDecay" | "varyNeut", label: string) => (
    <label style={{ fontSize: 13 }}><input type="checkbox" style={{ width: "auto", marginRight: 4 }} checked={o[k]} onChange={(e) => setO({ ...o, [k]: e.target.checked })} />{label}</label>
  );
  return (
    <div className="panel" style={{ padding: 14 }}>
      <div className="mut" style={{ fontSize: 12.5, marginBottom: 8 }}>
        Deepen takes an alpha that worked and tries its neighbours: nearby windows, close-relative operators, an optional outer rank / zscore / scale. The original is always one of the points.
        Preview is free; creating queues a task. Nothing is ever submitted.
      </div>
      <div className="hx-row">
        <ScopeRow sc={sc} setSc={setSc} />
        <label className="fld"><span>Alpha id (from Results)</span><input value={alphaId} onChange={(e) => setAlphaId(e.target.value)} placeholder="e.g. a1B2c3" /></label>
      </div>
      <label className="fld" style={{ marginTop: 8 }}><span>…or paste an expression (wins over the id)</span>
        <textarea className="hx-ta" rows={3} spellCheck={false} value={expr} onChange={(e) => setExpr(e.target.value)} /></label>
      <div className="hx-row" style={{ gap: 14, alignItems: "center", marginTop: 8 }}>
        {chk("windows", "Windows")}{chk("operators", "Operator swaps")}{chk("wrapper", "Outer wrapper")}{chk("varyDecay", "Decay")}{chk("varyNeut", "Neutralization")}
      </div>
      <div className="hx-row" style={{ marginTop: 8 }}>
        <label className="fld"><span>Window steps each way</span><input type="number" min={1} max={4} value={o.radius} onChange={(e) => setO({ ...o, radius: e.target.value })} /></label>
        <label className="fld"><span>Most alphas to simulate</span><input type="number" min={1} value={o.max} onChange={(e) => setO({ ...o, max: e.target.value })} /></label>
        <label className="fld"><span>Current decay</span><input type="number" min={0} value={o.decay} onChange={(e) => setO({ ...o, decay: e.target.value })} /></label>
        <label className="fld"><span>Neutralization (blank = alpha's own)</span><input value={o.neut} onChange={(e) => setO({ ...o, neut: e.target.value })} placeholder="SUBINDUSTRY" /></label>
        <label className="fld"><span>Rank by</span>
          <select value={obj} onChange={(e) => setObj(e.target.value)}>{["sharpe", "fitness", "returns", "margin"].map((k) => <option key={k} value={k}>{k}</option>)}</select></label>
      </div>
      <div className="hx-row" style={{ marginTop: 10 }}>
        <button className="btn sm" onClick={preview} disabled={!!busy}>{busy === "preview" ? <span className="spin" /> : "Preview neighbourhood (free)"}</button>
        <button className="btn ghost sm" onClick={run} disabled={!!busy || !pv}>{busy === "run" ? <span className="spin" /> : "Create task"}</button>
        <span className="mut" style={{ fontSize: 12 }}>Preview first; creating is enabled once you have seen the neighbourhood.</span>
      </div>
      {pv ? (
        <div style={{ marginTop: 8 }}>
          <div className="hx-chips">
            <span className="chip">alphas: <b>{fmt(pv.size)}</b></span>
            <span className="chip" title={pv.originExpression}>original: <b>{String(pv.originExpression).slice(0, 60)}</b></span>
          </div>
          {(pv.notes ?? []).map((n: string, i: number) => <div key={i} className="hx-note">{n}</div>)}
          {(pv.sample ?? []).length ? (
            <table className="hx-table"><thead><tr><th>sample neighbour</th><th>settings</th></tr></thead>
              <tbody>{(pv.sample as Res[]).map((r, i) => <tr key={i}><td title={r.expression}>{r.expression}</td><td title={JSON.stringify(r.settings)}>{r.settings?.neutralization} · decay {r.settings?.decay}</td></tr>)}</tbody></table>
          ) : null}
          <details className="hx-raw" style={{ marginTop: 8 }}><summary className="mut" style={{ cursor: "pointer", fontSize: 12 }}>generated template</summary><pre>{String(pv.yaml)}</pre></details>
        </div>
      ) : null}
    </div>
  );
}

// ───────────────────────────── Evolution ─────────────────────────────
function Evolution() {
  const { toast, toastErr } = useToast();
  const [sc, setSc] = useState({ region: "USA", delay: 1, universe: "TOP3000" });
  const [exprs, setExprs] = useState("");
  const [ids, setIds] = useState("");
  const [opt, setOpt] = useState<Res | null>(null);
  const [objs, setObjs] = useState<string[]>(["fitness"]);
  const [num, setNum] = useState({ minSharpe: "1.0", limit: "8", budget: "100", population: "20", offspring: "10", crossover: "0.4", seed: "", decay: "0" });
  const [neut, setNeut] = useState("SUBINDUSTRY");
  const [pool, setPool] = useState(false);
  const [name, setName] = useState("");
  const [pv, setPv] = useState<Res | null>(null);
  const [busy, setBusy] = useState("");
  useEffect(() => { call("get", "/harness_engine/optimizers").then((r) => { if (!r.err) setOpt(r.d); }); }, []);

  const body = () => ({
    ...sc, expressions: exprs.split("\n").map((x) => x.trim()).filter(Boolean), alpha_ids: split(ids), min_sharpe: +num.minSharpe || 0,
    limit: Math.max(1, +num.limit || 8), name: name.trim(), objectives: objs, budget: Math.max(1, +num.budget || 1),
    population: Math.max(2, +num.population || 20), offspring: Math.max(1, +num.offspring || 10), power_pool: pool,
    crossover_rate: Math.min(1, Math.max(0, +num.crossover || 0)), seed: num.seed.trim() === "" ? null : Math.trunc(+num.seed),
    neutralization: neut.trim().toUpperCase() || "SUBINDUSTRY", decay: Math.trunc(+num.decay || 0),
  });
  async function preview() {
    setBusy("preview");
    const { d, err } = await call("post", "/harness_engine/evolution/preview", body());
    setBusy("");
    if (err) { setPv(null); return toastErr(err); }
    setPv(d);
  }
  async function run() {
    if (!objs.length) return toastErr("Pick at least one objective.");
    setBusy("run");
    const { d, err } = await call("post", "/harness_engine/evolution/run", body());
    setBusy("");
    if (err) return toastErr(err);
    toast(`Evolution task #${d.id} created (${d.seeds} starting alphas, budget ${d.budget}). Watch the generations in the Tasks tab.`, "ok");
  }
  const objectives: Res[] = opt?.objectives ?? [];
  const n = (k: keyof typeof num, label: string, step?: string) => (
    <label className="fld"><span>{label}</span><input type="number" step={step} value={num[k]} onChange={(e) => setNum({ ...num, [k]: e.target.value })} /></label>
  );
  return (
    <div className="panel" style={{ padding: 14 }}>
      <div className="mut" style={{ fontSize: 12.5, marginBottom: 8 }}>
        Evolution breeds new alphas from good ones: it changes a window, swaps an operator or field, wraps / unwraps, or mixes two parents. Each generation is simulated before the next is bred;
        the best alphas found so far (parents and children together) survive. Every offspring is checked against operator and field limits before it is queued. Nothing is ever submitted.
      </div>
      <div className="hx-row"><ScopeRow sc={sc} setSc={setSc} /><label className="fld"><span>Task name (optional)</span><input value={name} onChange={(e) => setName(e.target.value)} /></label></div>
      <label className="fld" style={{ marginTop: 8 }}><span>Starting expressions, one per line (blank = use your strongest alphas in this market)</span>
        <textarea className="hx-ta" rows={4} spellCheck={false} value={exprs} onChange={(e) => setExprs(e.target.value)} /></label>
      <div className="hx-row" style={{ marginTop: 8 }}>
        <label className="fld"><span>…and/or alpha ids (comma separated)</span><input value={ids} onChange={(e) => setIds(e.target.value)} /></label>
        {n("minSharpe", "Strongest alphas: min |Sharpe|", "0.1")}{n("limit", "…how many")}
      </div>
      <div className="hx-row" style={{ marginTop: 8 }}>
        {n("budget", "Budget (simulations)")}{n("population", "Population kept")}{n("offspring", "Offspring per generation")}{n("crossover", "Crossover rate (0–1)", "0.1")}{n("seed", "Seed (optional)")}
      </div>
      <div className="hx-row" style={{ marginTop: 8 }}>
        <label className="fld"><span>Neutralization</span><input value={neut} onChange={(e) => setNeut(e.target.value)} /></label>
        {n("decay", "Decay")}
        <label style={{ fontSize: 13, alignSelf: "center" }}><input type="checkbox" style={{ width: "auto", marginRight: 4 }} checked={pool} onChange={(e) => setPool(e.target.checked)} />Power Pool limits (≤8 operators, ≤3 fields) and judging</label>
      </div>
      <div className="fld" style={{ marginTop: 8 }}><span>Objectives</span>
        <div className="hx-row" style={{ gap: 14, alignItems: "center" }}>
          {objectives.map((o) => (
            <label key={o.key} style={{ fontSize: 13 }} title={o.summary}>
              <input type="checkbox" style={{ width: "auto", marginRight: 4 }} checked={objs.includes(o.key)}
                onChange={(e) => setObjs(e.target.checked ? [...objs, o.key] : objs.filter((x) => x !== o.key))} />{o.label}{o.direction === "minimize" ? " ↓" : " ↑"}</label>))}
        </div></div>
      <div className="hx-row" style={{ marginTop: 10 }}>
        <button className="btn sm" onClick={preview} disabled={!!busy}>{busy === "preview" ? <span className="spin" /> : "Preview (free)"}</button>
        <button className="btn ghost sm" onClick={run} disabled={!!busy || !pv || !(pv.seeds ?? []).length}>{busy === "run" ? <span className="spin" /> : "Create task"}</button>
        <span className="mut" style={{ fontSize: 12 }}>Preview shows the starting alphas and a sample of first offspring; creating is enabled after a preview with usable starting alphas.</span>
      </div>
      {pv ? (
        <div style={{ marginTop: 8 }}>
          <div className="hx-chips">
            <span className="chip">starting alphas: <b>{(pv.seeds ?? []).length}</b></span>
            <span className="chip">fields mutations can pick: <b>{fmt(pv.fields)}</b></span>
            {pv.generations ? <span className="chip">≈ generations: <b>{fmt(pv.generations)}</b></span> : null}
          </div>
          {pv.operatorsKnown === false ? <div className="hx-note">Your operator list is not loaded, so offspring are not filtered against it; BRAIN rejects any operator it does not offer.</div> : null}
          {(pv.notes ?? []).map((x: string, i: number) => <div key={i} className="hx-note">{x}</div>)}
          {(pv.seeds ?? []).length ? (
            <table className="hx-table"><thead><tr><th>starting alpha</th></tr></thead><tbody>{(pv.seeds as string[]).map((x, i) => <tr key={i}><td title={x}>{x}</td></tr>)}</tbody></table>
          ) : null}
          {(pv.offspring ?? []).length ? (
            <table className="hx-table" style={{ marginTop: 8 }}><thead><tr><th>sample offspring</th><th>how</th></tr></thead>
              <tbody>{(pv.offspring as Res[]).map((r, i) => <tr key={i}><td title={r.expression}>{r.expression}</td><td>{r.how}</td></tr>)}</tbody></table>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

// ───────────────────────────── Invent (LLM) ─────────────────────────────
function Invent() {
  const { toast, toastErr } = useToast();
  const [sc, setSc] = useState({ region: "USA", delay: 1, universe: "TOP3000" });
  const [st, setSt] = useState<Res | null>(null);
  const [fl, setFl] = useState<Record<string, boolean>>({});
  const [caps, setCaps] = useState({ calls: "", tokens: "", price: "", usd: "" });
  const [goal, setGoal] = useState("");
  const [n, setN] = useState("6");
  const [pool, setPool] = useState(false);
  const [maxSims, setMaxSims] = useState("100");
  const [out, setOut] = useState<Res | null>(null);
  const [texts, setTexts] = useState<string[]>([]);
  const [run, setRun] = useState({ sampler: "nsga2", objective: "fitness", budget: "60" });
  const [busy, setBusy] = useState("");

  const loadStatus = async () => {
    const r = await call("get", "/harness_engine/llm/status");
    if (r.err) return;
    setSt(r.d);
    const c = r.d.budget?.config ?? {};
    setCaps({ calls: String(c.max_calls_per_day ?? ""), tokens: String(c.max_tokens_per_day ?? ""), price: String(c.usd_per_million_tokens ?? ""), usd: String(c.max_usd_per_day ?? "") });
    const f = await call("get", "/harness_engine/status");
    if (!f.err) setFl(f.d.flags ?? {});
  };
  useEffect(() => { loadStatus(); }, []);

  async function saveCaps() {
    const num = (x: string) => (x.trim() === "" ? null : +x);
    const r = await call("post", "/harness_engine/llm/budget", { max_calls_per_day: num(caps.calls), max_tokens_per_day: num(caps.tokens), usd_per_million_tokens: num(caps.price), max_usd_per_day: num(caps.usd) });
    if (r.err) return toastErr(r.err);
    toast("Daily caps saved.", "ok");
    loadStatus();
  }
  const body = () => ({ ...sc, goal: goal.trim(), n: Math.max(1, Math.min(12, +n || 6)), power_pool: pool, max_simulations: Math.max(1, +maxSims || 100) });
  async function propose() {
    setBusy("propose");
    const { d, err } = await call("post", "/harness_engine/invent/propose", body());
    setBusy("");
    loadStatus();
    if (err) { return toastErr(err); }
    setOut(d);
    setTexts((d.accepted ?? []).map((a: Res) => String(a.yaml)));
  }
  async function create(i: number) {
    setBusy("run" + i);
    const { d, err } = await call("post", "/harness_engine/invent/run", {
      ...body(), template: texts[i], name: String(out?.accepted?.[i]?.name ?? ""), sampler: run.sampler, objectives: [run.objective], budget: Math.max(1, +run.budget || 1),
    });
    setBusy("");
    if (err) return toastErr(err);
    toast(`Task #${d.id} created. Watch it in the Tasks tab; it advances while the engine is running.`, "ok");
  }
  const b = st?.budget;
  const cfg = b?.config ?? {};
  const field = (k: keyof typeof caps, label: string) => (
    <label className="fld"><span>{label}</span><input type="number" min={0} value={caps[k]} onChange={(e) => setCaps({ ...caps, [k]: e.target.value })} /></label>
  );
  return (
    <div className="panel" style={{ padding: 14 }}>
      <div className="mut" style={{ fontSize: 12.5, marginBottom: 8 }}>
        Invent asks your LLM (the provider and key you set up in Settings) for new search templates. Every proposal is checked before you see it as usable: real data fields only,
        operators your market offers, Power Pool limits when asked, a small search space. Proposing costs LLM quota; running a template is a normal task. Nothing is ever submitted.
      </div>
      {!fl.harness_llm ? <div className="hx-warn">Turn on “LLM labs (Invent)” in the Control tab to let this tab call your LLM.</div> : null}
      {st && !(st.used ?? []).length ? <div className="hx-warn">No LLM provider is set up{st.error ? ` (${st.error})` : ""}. Add an API key in Settings.</div> : null}
      <div className="dx-head"><b>LLM use today</b>
        <span className="mut">{(st?.used ?? []).length ? `providers: ${((st?.used ?? []) as string[]).join(" → ")}` : "no provider"} · estimates only (characters ÷ 4)</span></div>
      <div className="hx-chips">
        <span className="chip">calls: <b>{b?.today?.calls ?? 0}</b>{cfg.max_calls_per_day ? ` / ${cfg.max_calls_per_day}` : " (no cap)"}</span>
        <span className="chip">≈ tokens: <b>{b?.today?.tokens ?? 0}</b>{cfg.max_tokens_per_day ? ` / ${cfg.max_tokens_per_day}` : " (no cap)"}</span>
        {cfg.usd_per_million_tokens ? <span className="chip">≈ cost: <b>${fmt(b?.today?.usd ?? 0)}</b>{cfg.max_usd_per_day ? ` / $${cfg.max_usd_per_day}` : ""}</span> : null}
      </div>
      <div className="hx-row">
        {field("calls", "Max calls per day (0 = no cap)")}{field("tokens", "Max est. tokens per day")}{field("price", "Price per 1M tokens, $ (optional)")}{field("usd", "Max est. $ per day")}
        <button className="btn ghost sm" onClick={saveCaps}>Save caps</button>
      </div>

      <div className="dx-head" style={{ marginTop: 14 }}><b>Propose templates</b></div>
      <div className="hx-row"><ScopeRow sc={sc} setSc={setSc} />
        <label className="fld"><span>How many (1–12)</span><input type="number" min={1} max={12} value={n} onChange={(e) => setN(e.target.value)} /></label>
        <label className="fld"><span>Largest search space</span><input type="number" min={1} value={maxSims} onChange={(e) => setMaxSims(e.target.value)} /></label></div>
      <label className="fld" style={{ marginTop: 8 }}><span>Theme or idea to explore (optional)</span>
        <textarea className="hx-ta" rows={2} value={goal} onChange={(e) => setGoal(e.target.value)} placeholder="e.g. balance-sheet quality vs. price momentum" /></label>
      <div className="hx-row" style={{ marginTop: 8, alignItems: "center" }}>
        <label style={{ fontSize: 13 }}><input type="checkbox" style={{ width: "auto", marginRight: 4 }} checked={pool} onChange={(e) => setPool(e.target.checked)} />Power Pool limits (≤8 operators, ≤3 fields)</label>
        <button className="btn sm" onClick={propose} disabled={!!busy || !fl.harness_llm || !fl.harness_engine}>{busy === "propose" ? <span className="spin" /> : "Propose (uses your LLM key)"}</button>
      </div>

      {out ? (
        <div style={{ marginTop: 10 }}>
          <div className="hx-chips">
            <span className="chip">asked: <b>{out.asked}</b></span><span className="chip ok">usable: <b>{(out.accepted ?? []).length}</b></span>
            <span className={"chip " + ((out.rejected ?? []).length ? "bad" : "")}>rejected: <b>{(out.rejected ?? []).length}</b></span>
            <span className="chip">{out.provider} {out.model}</span>
          </div>
          <div className="hx-row" style={{ margin: "6px 0" }}>
            <label className="fld"><span>Sampler for tasks</span><select value={run.sampler} onChange={(e) => setRun({ ...run, sampler: e.target.value })}>
              {["nsga2", "tpe", "random", "qmc", "brute"].map((x) => <option key={x} value={x}>{x}</option>)}</select></label>
            <label className="fld"><span>Rank by</span><select value={run.objective} onChange={(e) => setRun({ ...run, objective: e.target.value })}>
              {["fitness", "sharpe", "returns", "margin"].map((x) => <option key={x} value={x}>{x}</option>)}</select></label>
            <label className="fld"><span>Budget per task</span><input type="number" min={1} value={run.budget} onChange={(e) => setRun({ ...run, budget: e.target.value })} /></label>
          </div>
          {(out.accepted ?? []).map((a: Res, i: number) => (
            <div key={i} className="hx-form" style={{ margin: "6px 0" }}>
              <div className="dx-head"><b>{a.name}</b><span className="mut">{a.template?.description}</span>
                <span className="chip" style={{ marginLeft: "auto" }}>{a.size == null ? "continuous" : `${a.size} combinations`}</span>
                <button className="btn sm" disabled={!!busy || !fl.harness_engine} onClick={() => create(i)}>{busy === "run" + i ? <span className="spin" /> : "Create task"}</button></div>
              {(a.notes ?? []).map((x: string, j: number) => <div key={j} className="hx-note">{x}</div>)}
              <details><summary className="mut" style={{ cursor: "pointer", fontSize: 12 }}>template (editable; checked again when you create the task)</summary>
                <textarea className="hx-ta" rows={10} spellCheck={false} value={texts[i] ?? ""} onChange={(e) => setTexts(texts.map((t, k) => (k === i ? e.target.value : t)))} /></details>
            </div>))}
          {(out.rejected ?? []).length ? (
            <details style={{ marginTop: 8 }}><summary className="mut" style={{ cursor: "pointer", fontSize: 12 }}>{(out.rejected ?? []).length} rejected proposal(s) and why</summary>
              {(out.rejected as Res[]).map((r, i) => <div key={i} className="hx-warn"><b>{r.name}</b>: {(r.problems ?? []).join("; ")}</div>)}</details>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

// ───────────────────────────── Planning ─────────────────────────────
const TAB_OF: Record<string, "control" | "tasks" | "planning" | "labs" | "evolution" | "mixing"> = {
  control: "control", tasks: "tasks", planning: "planning", labs: "labs", evolution: "evolution", mixing: "mixing",
};

function YieldTrend({ days, target }: { days: Res[]; target: number }) {
  const W = 560, H = 110, pad = 18;
  const max = Math.max(1, ...days.map((d) => d.finished));
  const bw = (W - pad * 2) / Math.max(1, days.length);
  const total = days.reduce((a, d) => a + d.finished, 0);
  if (!total) return <div className="mut" style={{ fontSize: 12 }}>Nothing has finished in the last {days.length} days, so there is no trend yet.</div>;
  return (
    <svg viewBox={`0 0 ${W} ${H + 16}`} style={{ width: "100%", maxWidth: 640 }} role="img" aria-label="Simulations finished and passing per day">
      {days.map((d, i) => {
        const x = pad + i * bw + 2, hf = (d.finished / max) * (H - 10), hp = (d.passing / max) * (H - 10);
        return (
          <g key={d.day}>
            <title>{`${d.day}: ${d.finished} finished, ${d.passing} passing (${(d.yieldRate * 100).toFixed(2)}%; target ${(target * 100).toFixed(1)}%)`}</title>
            <rect x={x} y={H - hf} width={Math.max(2, bw - 4)} height={hf} fill="var(--surface-2)" stroke="var(--line)" />
            {d.passing ? <rect x={x} y={H - hp} width={Math.max(2, bw - 4)} height={Math.max(2, hp)} fill="var(--acc)" /> : null}
            {i % 2 === 0 || days.length <= 8 ? <text x={x + bw / 2 - 2} y={H + 12} fontSize="9" textAnchor="middle" fill="currentColor" opacity="0.6">{String(d.day).slice(5)}</text> : null}
          </g>
        );
      })}
    </svg>
  );
}

function Planning({ go }: { go: (t: "control" | "tasks" | "planning" | "labs" | "evolution" | "mixing") => void }) {
  const { toast, toastErr } = useToast();
  const [sc, setSc] = useState({ region: "USA", delay: 1, universe: "TOP3000" });
  const [ov, setOv] = useState<Res | null>(null);
  const [labInfo, setLabInfo] = useState<Record<string, string>>({});
  const [draft, setDraft] = useState({ budget: "", explore: "", chunk: "", labs: [] as string[] });
  const [pm, setPm] = useState<Res | null>(null);
  const [nar, setNar] = useState<Res | null>(null);
  const [ran, setRan] = useState<Res | null>(null);
  const [ledger, setLedger] = useState<Res | null>(null);
  const [shapeQ, setShapeQ] = useState("");
  const [onlyAnswered, setOnlyAnswered] = useState(false);
  const [busy, setBusy] = useState("");

  const loadSeq = useRef(0);                      // only the latest region's answer may be shown (an older, slower one must not overwrite it)
  async function load() {
    const mine = ++loadSeq.current;
    setBusy("load");
    const { d, err } = await call("post", "/harness_engine/plan/overview", sc);
    if (mine !== loadSeq.current) return;
    setBusy("");
    if (err) return toastErr(err);
    setOv(d);
    setDraft({ budget: String(d.settings.daily_budget), explore: String(Math.round(d.settings.explore_fraction * 100)), chunk: String(d.settings.min_chunk), labs: d.settings.labs });
  }
  useEffect(() => { call("get", "/harness_engine/plan/settings").then((r) => { if (!r.err) setLabInfo(r.d.labs ?? {}); }); }, []);
  useEffect(() => { setPm(null); setNar(null); setRan(null); setLedger(null); load(); }, [sc.region, sc.delay, sc.universe]);

  async function saveSettings() {
    const { err } = await call("post", "/harness_engine/plan/settings", {
      daily_budget: Math.max(0, +draft.budget || 0), explore_fraction: Math.min(1, Math.max(0, (+draft.explore || 0) / 100)), min_chunk: Math.max(1, +draft.chunk || 1), labs: draft.labs,
    });
    if (err) return toastErr(err);
    toast("Plan settings saved.", "ok");
    setPm(null);
    load();
  }
  async function explain() {
    setBusy("nar");
    const { d, err } = await call("post", "/harness_engine/plan/advice", { ...sc, narrate: true });
    setBusy("");
    if (err) return toastErr(err);
    setNar(d.narration);
  }
  async function askPm() {
    setBusy("pm");
    const { d, err } = await call("post", "/harness_engine/plan/pm", { ...sc, use_llm: true });
    setBusy("");
    if (err) return toastErr(err);
    setPm(d);
  }
  async function queue(labs: string[]) {
    const n = labs.length ? labs.length : (ov?.plan?.allocations ?? []).length;
    if (!window.confirm(`Queue today's plan across ${n} lab(s)? This only adds simulations to the engine's queue (duplicates are skipped); they run when the engine runs, and nothing is submitted.`)) return;
    setBusy("queue");
    const { d, err } = await call("post", "/harness_engine/plan/run", { ...sc, labs });
    setBusy("");
    if (err) return toastErr(err);
    setRan(d);
    toast(`Queued ${d.queued} simulation(s).`, "ok");
    load();
  }
  async function loadLedger() {
    setBusy("ledger");
    const { d, err } = await call("post", "/harness_engine/plan/skeletons", { ...sc, days: 30 });
    setBusy("");
    if (err) return toastErr(err);
    setLedger(d);
  }

  const plan = ov?.plan, spent = ov?.spent, fl = ov?.flags ?? {};
  const used = plan ? Math.min(100, Math.round(((plan.budget - plan.remaining) / Math.max(1, plan.budget)) * 100)) : 0;
  const blockers = Object.entries(ov?.readiness?.blockers ?? {}) as [string, string[]][];
  const allocTable = (rows: Res[], pmView = false) => (
    <table className="hx-table"><thead><tr><th>lab</th><th>simulations</th><th>share</th><th>yield</th><th>{pmView ? "why (PM)" : "why"}</th></tr></thead>
      <tbody>{rows.map((a) => (
        <tr key={a.lab}><td><b>{a.lab}</b></td><td>{a.sims}</td>
          <td><span className="hx-bar"><span style={{ width: `${Math.round(a.share * 100)}%` }} /></span> {Math.round(a.share * 100)}%</td>
          <td>{a.finished ? `${(a.passing / a.finished * 100).toFixed(2)}% (${a.passing}/${a.finished})` : "no history"}</td>
          <td title={a.why} style={{ whiteSpace: "normal", maxWidth: 420 }}>{a.why}{a.capped ? " (capped)" : ""}</td></tr>))}</tbody></table>
  );
  return (
    <div className="panel" style={{ padding: 14 }}>
      <div className="mut" style={{ fontSize: 12.5, marginBottom: 8 }}>
        Planning shares each day's simulation budget between the labs by how well each has converted into alphas that pass your gate, and tells you what to do next.
        Everything on this page is read-only until you press <b>Queue</b>; queueing only adds work to the engine's queue and never submits an alpha.
      </div>
      <div className="hx-row"><ScopeRow sc={sc} setSc={setSc} /><button className="btn ghost sm" onClick={load} disabled={busy === "load"}>{busy === "load" ? <span className="spin" /> : "Refresh"}</button></div>

      {ov ? (
        <>
          {/* budget + settings */}
          <div className="dx-head" style={{ marginTop: 12 }}><b>Today's budget</b><span className="mut">UTC day · {ov.scope}</span></div>
          <div className="hx-chips">
            <span className="chip">budget: <b>{plan.budget}</b></span>
            <span className="chip" title={`${spent.records} queued/finished today + ${spent.committed} promised by running tasks`}>used or committed: <b>{spent.total}</b></span>
            <span className="chip ok">left: <b>{plan.remaining}</b></span>
            <span className="hx-bar" style={{ alignSelf: "center" }}><span style={{ width: `${used}%` }} /></span>
          </div>
          <details>
            <summary className="mut" style={{ cursor: "pointer", fontSize: 12 }}>Plan settings</summary>
            <div className="hx-row" style={{ marginTop: 6 }}>
              <label className="fld"><span>Daily simulations</span><input type="number" min={0} value={draft.budget} onChange={(e) => setDraft({ ...draft, budget: e.target.value })} /></label>
              <label className="fld"><span>Exploration share, %</span><input type="number" min={0} max={100} value={draft.explore} onChange={(e) => setDraft({ ...draft, explore: e.target.value })} /></label>
              <label className="fld"><span>Smallest run worth making</span><input type="number" min={1} value={draft.chunk} onChange={(e) => setDraft({ ...draft, chunk: e.target.value })} /></label>
              <button className="btn sm" onClick={saveSettings}>Save</button>
            </div>
            <div className="hx-row" style={{ gap: 14, marginTop: 6 }}>
              {Object.keys(labInfo).map((l) => (
                <label key={l} style={{ fontSize: 13 }} title={labInfo[l]}>
                  <input type="checkbox" style={{ width: "auto", marginRight: 4 }} checked={draft.labs.includes(l)}
                    onChange={(e) => setDraft({ ...draft, labs: e.target.checked ? [...draft.labs, l] : draft.labs.filter((x) => x !== l) })} />{l}</label>))}
            </div>
          </details>

          {/* advice */}
          <div className="dx-head" style={{ marginTop: 14 }}><b>What to do next</b>
            <button className="btn ghost sm" style={{ marginLeft: "auto" }} onClick={explain} disabled={!!busy || !fl.llm}
              title={fl.llm ? "Your LLM rewrites the top items as a short paragraph (counts against the daily caps)" : "Turn on “LLM labs” in Control to enable"}>
              {busy === "nar" ? <span className="spin" /> : "Explain in words (uses your LLM)"}</button></div>
          {nar ? <div className="hx-note">{nar.text}{nar.error ? <div className="mut" style={{ fontSize: 11.5 }}>(Plain text shown: {nar.error})</div> : null}</div> : null}
          {(ov.advice ?? []).length ? (ov.advice as Res[]).map((a) => (
            <div key={a.id} className="hx-flag">
              <div><b>{a.title}</b><div className="mut" style={{ fontSize: 12 }}>{a.why}</div></div>
              {a.tab && TAB_OF[a.tab] && a.tab !== "planning" ? <button className="btn ghost sm" onClick={() => go(TAB_OF[a.tab])}>Open {a.tab}</button> : null}
            </div>)) : <div className="mut" style={{ fontSize: 12 }}>Nothing needs attention right now.</div>}

          {/* today's plan */}
          <div className="dx-head" style={{ marginTop: 14 }}><b>Today's plan</b><span className="mut">{plan.planned} of {plan.remaining} remaining simulations allocated</span></div>
          {(plan.notes ?? []).map((n: string, i: number) => <div key={i} className="hx-note">{n}</div>)}
          {blockers.length ? <div className="hx-warn"><b>Closed today:</b> {blockers.map(([l, why]) => `${l} (${why.join("; ")})`).join(" · ")}</div> : null}
          {(plan.allocations ?? []).length ? allocTable(plan.allocations) : null}
          <div className="hx-row" style={{ marginTop: 8, alignItems: "center" }}>
            <button className="btn sm" onClick={() => queue([])} disabled={!!busy || !fl.engine || !fl.planning || !(plan.allocations ?? []).length}
              title={!fl.planning ? "Turn on “Planning” in Control first" : ""}>{busy === "queue" ? <span className="spin" /> : "Queue today's plan"}</button>
            <button className="btn ghost sm" onClick={askPm} disabled={!!busy}>{busy === "pm" ? <span className="spin" /> : fl.llm ? "Ask the PM (uses your LLM)" : "Show the PM's briefing (rules only)"}</button>
            {!fl.planning ? <span className="hx-warn" style={{ margin: 0 }}>Queueing needs the “Planning” switch in Control.</span> : null}
          </div>

          {pm ? (
            <div className="hx-form">
              <div className="dx-head"><b>{pm.fromPM ? "The PM's plan" : "Ordinary plan"}</b><span className="mut">{pm.usedLLM ? "chosen by your LLM, numbers by the plan arithmetic" : "rule-written briefing"}</span></div>
              <div className="hx-note">{pm.briefing}</div>
              {pm.error ? <div className="hx-warn">{pm.error}</div> : null}
              {(pm.allocations ?? []).length ? allocTable(pm.allocations, true) : null}
              {(pm.rejected ?? []).length ? <div className="mut" style={{ fontSize: 12 }}>Ignored from the model: {(pm.rejected as Res[]).map((r) => `${r.lab} (${r.reason})`).join("; ")}</div> : null}
              {(pm.dropped ?? []).length ? <div className="mut" style={{ fontSize: 12 }}>Too small to run: {(pm.dropped as Res[]).map((r) => r.lab).join(", ")}</div> : null}
              {pm.changes ? <div className="mut" style={{ fontSize: 12 }}>Compared with the ordinary plan: added {fmt(pm.changes.added)}; removed {fmt(pm.changes.removed)}.</div> : null}
              {pm.fromPM && (pm.allocations ?? []).length ? (
                <div style={{ marginTop: 8 }}><button className="btn sm" disabled={!!busy || !fl.engine || !fl.planning} onClick={() => queue((pm.allocations as Res[]).map((a) => a.lab))}>Queue the PM's plan</button></div>) : null}
            </div>
          ) : null}

          {ran ? (
            <div className="hx-form">
              <div className="dx-head"><b>Queued just now</b><span className="chip ok">{ran.queued} simulation(s)</span><span className="mut">{ran.rounds} round(s) · {ran.leftover} of today's budget not used</span></div>
              <table className="hx-table"><thead><tr><th>round</th><th>lab</th><th>asked</th><th>queued</th><th>already known</th><th>note</th></tr></thead>
                <tbody>{(ran.results as Res[]).map((r, i) => (
                  <tr key={i}><td>{r.round}</td><td>{r.lab}</td><td>{r.asked}</td><td>{r.queued}</td><td>{r.duplicates}</td><td title={r.error ?? r.note ?? ""}>{r.error ?? r.note ?? (r.task ? `task #${r.task}` : "")}</td></tr>))}</tbody></table>
              {(ran.notes ?? []).map((n: string, i: number) => <div key={i} className="hx-note">{n}</div>)}
              <div className="mut" style={{ fontSize: 12 }}>Start the engine in Control for these to run. Task-style labs (evolution, deepen) appear in the Tasks tab.</div>
            </div>
          ) : null}

          {/* yield */}
          <div className="dx-head" style={{ marginTop: 14 }}><b>Yield</b><span className="mut">passing alphas per finished simulation · target {(ov.yields.targetYield * 100).toFixed(1)}% · last {ov.yields.days} days</span></div>
          <div className={"hx-note"}>{ov.yields.plainly}</div>
          {(ov.yields.labs ?? []).length ? (
            <table className="hx-table"><thead><tr><th>lab</th><th>simulated</th><th>finished</th><th>passing</th><th>yield</th><th>best |Sharpe|</th><th></th></tr></thead>
              <tbody>{(ov.yields.labs as Res[]).map((l) => (
                <tr key={l.lab}><td><b>{l.lab}</b></td><td>{l.simulated}</td><td>{l.finished}</td><td>{l.passing}</td><td>{(l.yieldRate * 100).toFixed(2)}%</td><td>{fmt(l.bestSharpe)}</td>
                  <td>{l.meetsTarget ? <span className="chip ok">meets target</span> : l.confident ? <span className="chip bad">below target</span> : <span className="chip">too early</span>}</td></tr>))}</tbody></table>
          ) : null}
          <div style={{ marginTop: 8 }}>
            <YieldTrend days={ov.trend.days} target={ov.trend.targetYield} />
            <div className="mut" style={{ fontSize: 11.5 }}>Grey bars: simulations finished each day. Coloured: how many of those alphas pass the gate. Hover a day for the numbers.</div>
          </div>

          {/* ledger */}
          <div className="dx-head" style={{ marginTop: 14 }}><b>Shapes already tried (ledger)</b>
            <button className="btn ghost sm" style={{ marginLeft: "auto" }} onClick={loadLedger} disabled={!!busy}>{busy === "ledger" ? <span className="spin" /> : ledger ? "Reload" : "Load ledger"}</button></div>
          {ledger ? (
            <>
              <div className="mut" style={{ fontSize: 12 }}>
                A shape is an alpha with its fields and numbers blanked (F = field, N = number). A shape is “answered” when it passed enough times to start repeating itself, or was tried many times with nothing passing.
                {ledger.enabled ? " Labs are skipping answered shapes." : " Labs are NOT skipping them yet: turn on “Planning” in Control."}
              </div>
              <div className="hx-chips"><span className="chip">shapes: <b>{(ledger.shapes ?? []).length}</b></span><span className="chip bad">answered: <b>{(ledger.saturated ?? []).length}</b></span>
                <input style={{ maxWidth: 220 }} placeholder="Filter shapes, e.g. ts_rank" value={shapeQ} onChange={(e) => setShapeQ(e.target.value)} />
                <label style={{ fontSize: 12.5 }}><input type="checkbox" style={{ width: "auto", marginRight: 4 }} checked={onlyAnswered} onChange={(e) => setOnlyAnswered(e.target.checked)} />answered only</label></div>
              {(ledger.shapes ?? []).length ? (
                <div className="panel-scroll" style={{ maxHeight: 280 }}>
                  <table className="hx-table"><thead><tr><th>shape</th><th>tried</th><th>passed</th><th>status</th><th>why</th></tr></thead>
                    <tbody>{[...(ledger.saturated ?? []), ...(ledger.shapes ?? []).filter((r: Res) => !r.saturated)]
                      .filter((r: Res) => (!onlyAnswered || r.saturated) && r.shape.toLowerCase().includes(shapeQ.trim().toLowerCase())).slice(0, 120).map((r: Res) => (
                      <tr key={r.shape}><td style={{ fontFamily: "var(--mono)" }} title={r.shape}>{r.shape}</td><td>{r.tried}</td><td>{r.submittable}</td>
                        <td>{r.saturated ? <span className="chip bad">answered</span> : <span className="chip ok">open</span>}</td><td title={r.why}>{r.saturated ? r.why : ""}</td></tr>))}</tbody></table>
                </div>) : <div className="mut" style={{ fontSize: 12 }}>No results in this market in the last 30 days.</div>}
            </>
          ) : null}

          {/* history */}
          <div className="dx-head" style={{ marginTop: 14 }}><b>Recent plan runs</b></div>
          {(ov.history ?? []).length ? (
            <table className="hx-table"><thead><tr><th>when (UTC)</th><th>market</th><th>planned</th><th>queued</th><th>by lab</th></tr></thead>
              <tbody>{(ov.history as Res[]).map((h) => (
                <tr key={h.id}><td>{new Date(h.created * 1000).toISOString().replace("T", " ").slice(0, 16)}</td><td>{h.scope}</td><td>{h.planned}</td><td>{h.queued}</td>
                  <td title={JSON.stringify(h.results)}>{(h.results as Res[]).map((r) => `${r.lab} ${r.queued}${r.error ? "✗" : ""}`).join(" · ")}</td></tr>))}</tbody></table>
          ) : <div className="mut" style={{ fontSize: 12 }}>The plan has not been queued yet.</div>}
        </>
      ) : <div className="mut" style={{ marginTop: 10 }}>{busy === "load" ? "Reading…" : "No data yet."}</div>}
    </div>
  );
}


// ───────────────────────────── Guide ─────────────────────────────
const GUIDE: { id: string; title: string; tab: string; what: string; when: string; needs: string; output: string }[] = [
  { id: "search", title: "Search / Template / Power Pool", tab: "Tasks", what: "Write one template with $variables; a sampler (random, grid, Sobol, NSGA-II/III, TPE, CMA-ES) chooses which combinations to simulate, learning from results. Power Pool mode keeps every alpha within 8 operators and 3 data fields.",
    when: "You have an idea with open choices (windows, fields, decay) and want the best setting without simulating them all.", needs: "“SentryEngine + labs”. Preview first: it shows the size of the space, sample alphas and any problems.", output: "Finished simulations are scored into Results with the tag “harness”." },
  { id: "deepen", title: "Deepen", tab: "Deepen", what: "Takes one winning alpha and builds a template that explores around it (neighbouring windows and wrappers), then queues it as a task.",
    when: "An alpha passed and you want to know whether it is real or a lucky setting, or to find a stronger neighbour.", needs: "“SentryEngine + labs”.", output: "A normal task in the Tasks tab; preview shows the template before anything is queued." },
  { id: "evolution", title: "Evolution", tab: "Evolution", what: "A genetic search over expressions: starts from your winners, swaps operators and fields, changes windows, wraps and unwraps, crosses two alphas, and keeps the best by the objectives and limits you set.",
    when: "You have at least a few passing alphas and want new relatives of them, not just tuned copies.", needs: "“SentryEngine + labs”. Fewer than 3 passing alphas in a market keeps this lab closed in the plan.", output: "Generations run as tasks; every offspring is checked against the limits before it is queued." },
  { id: "invent", title: "Invent", tab: "Invent", what: "Your LLM proposes new templates or ideas. Every proposal is parsed and checked against the template rules and limits before anything is queued.",
    when: "You want fresh shapes rather than variations on what you already have.", needs: "“LLM labs (Invent)” and a key in Settings. It spends your provider quota, within the daily caps set in the tab.", output: "Valid proposals are shown for you to queue; invalid ones are listed with the reason." },
  { id: "relocate", title: "Relocate", tab: "Labs", what: "Runs formulas that work in one market in the others. It refuses markets that lack a field the formula needs.", when: "A winner exists in one market and you want to test it elsewhere.", needs: "“SentryEngine + labs”.", output: "Queued simulations, scored into Results." },
  { id: "repair", title: "Repair", tab: "Labs", what: "Makes one targeted fix for each near-miss alpha, chosen from the check it failed (e.g. high turnover).", when: "Many alphas almost pass.", needs: "“SentryEngine + labs”. Closed in the plan when there are no near-misses.", output: "Queued simulations, scored into Results." },
  { id: "harden", title: "Harden", tab: "Labs", what: "Nudges a winner's windows and wrappers a little to see whether it holds up.", when: "Before trusting a winner.", needs: "“SentryEngine + labs”. Closed in the plan when there are no strong alphas.", output: "Queued simulations, scored into Results." },
  { id: "harvest", title: "Harvest", tab: "Labs", what: "Plain sensible patterns over the best fields in each dataset.", when: "Broad, cheap exploration of data you have not mined.", needs: "“SentryEngine + labs”.", output: "Queued simulations, scored into Results." },
  { id: "diversify", title: "Diversify", tab: "Labs", what: "Uses only fields from datasets none of your alphas use yet.", when: "Your alphas are too alike to submit together.", needs: "“SentryEngine + labs”.", output: "Queued simulations, scored into Results." },
  { id: "pair", title: "Pair", tab: "Labs", what: "Cross-dataset field pairs in a few relational shapes.", when: "You want combinations of signals from different datasets.", needs: "“SentryEngine + labs”.", output: "Queued simulations, scored into Results." },
  { id: "mixing", title: "Mixing", tab: "Mixing", what: "Finds alphas that combine well, using stored daily returns and their correlations, and can queue the mixes as simulations.",
    when: "You have several passing alphas and want a portfolio-level improvement.", needs: "“Returns vault + mixing”.", output: "Mix candidates; queueing only adds them to the engine." },
  { id: "speed", title: "Autosentry speed", tab: "Control", what: "With “Autosentry via engine” on, each Autosentry round can run more batches side by side than Alpha Sentry's own 3 (up to BRAIN's 8 slots, shared with the engine), lowers itself when BRAIN refuses, and no longer waits for a batch that is stuck.",
    when: "Autosentry rounds feel slow because each one waits for its slowest batch.", needs: "“Autosentry via engine”. Settings are in Control, under Autosentry speed, and apply to the next run.", output: "Same Autosentry results, sooner. Batches released as slow are scored by the harness when they finish." },
  { id: "seed", title: "Shipped data", tab: "Control", what: "Each version carries a copy of your knowledge data (dataset and field catalogue and operator reference; never anyone's alphas, results, vault or library). On start your database gets the rows it lacks; nothing is changed or removed.",
    when: "After installing a new version, or restoring from a fresh data folder.", needs: "“Merge shipped data on start” (on by default).", output: "A backup in the data folder, then the missing catalogue rows." },
  { id: "planning", title: "Planning", tab: "Planning", what: "Splits each day's simulation budget between the labs by how well each has produced passing alphas, with a share kept for exploration; the PM and the advisor explain it in words. The ledger lists alpha shapes already answered so labs can skip them.",
    when: "You run several labs and want the budget spent where it pays.", needs: "Queueing needs “Planning” (and the engine). Skipping answered shapes needs the same switch. The PM and explanations need “LLM labs”.", output: "Queued simulations by lab, recorded under Recent plan runs." },
];

function Guide({ go }: { go: (t: "control" | "tasks" | "planning" | "deepen" | "evolution" | "invent" | "labs" | "mixing") => void }) {
  const [q, setQ] = useState("");
  const TAB: Record<string, "control" | "tasks" | "planning" | "deepen" | "evolution" | "invent" | "labs" | "mixing"> = {
    Control: "control", Tasks: "tasks", Planning: "planning", Deepen: "deepen", Evolution: "evolution", Invent: "invent", Labs: "labs", Mixing: "mixing" };
  const rows = GUIDE.filter((g) => (g.title + g.what + g.when).toLowerCase().includes(q.trim().toLowerCase()));
  return (
    <div className="panel" style={{ padding: 14 }}>
      <div className="mut" style={{ fontSize: 12.5, marginBottom: 8 }}>
        What each lab does and when to use it. Every lab is preview-first and only adds simulations to the engine's queue; no lab can submit an alpha.
        The switches mentioned below are in the Control tab, and all of them start off.
      </div>
      <input style={{ maxWidth: 260 }} placeholder="Filter, e.g. turnover or LLM" value={q} onChange={(e) => setQ(e.target.value)} />
      {rows.map((g) => (
        <details key={g.id} className="hx-form" style={{ marginTop: 8 }}>
          <summary style={{ cursor: "pointer" }}><b>{g.title}</b> <span className="mut" style={{ fontSize: 12 }}>· {g.tab} tab</span></summary>
          <div style={{ fontSize: 13, marginTop: 6 }}>{g.what}</div>
          <div className="mut" style={{ fontSize: 12.5, marginTop: 4 }}><b>Use it when:</b> {g.when}</div>
          <div className="mut" style={{ fontSize: 12.5 }}><b>Needs:</b> {g.needs}</div>
          <div className="mut" style={{ fontSize: 12.5 }}><b>Result:</b> {g.output}</div>
          <button className="btn ghost sm" style={{ marginTop: 6 }} onClick={() => go(TAB[g.tab])}>Open {g.tab}</button>
        </details>))}
      {rows.length ? null : <div className="mut" style={{ marginTop: 10 }}>Nothing matches that.</div>}
    </div>
  );
}

// ───────────────────────────── Screen ─────────────────────────────
export function Harness() {
  const [tab, setTab] = useState<"control" | "tasks" | "planning" | "deepen" | "evolution" | "invent" | "labs" | "mixing" | "results" | "guide">("control");
  return (
    <div className="hx">
      <div className="dx-head" style={{ marginBottom: 8 }}><SentryEngineMark size={22} /><b>SentryEngine</b><span className="mut">batch engine · labs · planning</span></div>
      <div className="seg">
        <button className={"seg-btn" + (tab === "control" ? " on" : "")} onClick={() => setTab("control")}>Control</button>
        <button className={"seg-btn" + (tab === "tasks" ? " on" : "")} onClick={() => setTab("tasks")}>Tasks</button>
        <button className={"seg-btn" + (tab === "planning" ? " on" : "")} onClick={() => setTab("planning")}>Planning</button>
        <button className={"seg-btn" + (tab === "deepen" ? " on" : "")} onClick={() => setTab("deepen")}>Deepen</button>
        <button className={"seg-btn" + (tab === "evolution" ? " on" : "")} onClick={() => setTab("evolution")}>Evolution</button>
        <button className={"seg-btn" + (tab === "invent" ? " on" : "")} onClick={() => setTab("invent")}>Invent</button>
        <button className={"seg-btn" + (tab === "labs" ? " on" : "")} onClick={() => setTab("labs")}>Labs</button>
        <button className={"seg-btn" + (tab === "mixing" ? " on" : "")} onClick={() => setTab("mixing")}>Mixing</button>
        <button className={"seg-btn" + (tab === "results" ? " on" : "")} onClick={() => setTab("results")}>Results</button>
        <button className={"seg-btn" + (tab === "guide" ? " on" : "")} onClick={() => setTab("guide")}>Guide</button>
      </div>
      <div className="panel-scroll" style={{ flex: 1, minHeight: 0 }}>
        {tab === "control" ? <Control /> : tab === "tasks" ? <Tasks /> : tab === "planning" ? <Planning go={setTab} /> : tab === "deepen" ? <Deepen /> : tab === "evolution" ? <Evolution /> : tab === "invent" ? <Invent /> : tab === "labs" ? <Labs /> : tab === "mixing" ? <Mixing /> : tab === "results" ? <ResultsTab /> : <Guide go={setTab} />}
      </div>
    </div>
  );
}
