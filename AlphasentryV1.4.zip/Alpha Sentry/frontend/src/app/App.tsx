import { useEffect, useState, type ComponentType } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import { ErrorBoundary } from "./ErrorBoundary";
import { Sidebar } from "./layout/Sidebar";
import { Header } from "./layout/Header";
import { CommandCenter } from "../features/command/CommandCenter";
import { DataExplorer } from "../features/data/DataExplorer";
import { Generation } from "../features/generate/Generation";
import { Simulation } from "../features/simulate/Simulation";
import { ResultsAnalytics } from "../features/results/ResultsAnalytics";
import { Portfolio } from "../features/portfolio/Portfolio";
import { PromptLibrary } from "../features/prompts/PromptLibrary";
import { SuperAlpha } from "../features/super/SuperAlpha";
import { OperatorAtlas } from "../features/operators/OperatorAtlas";
import { Settings } from "../features/settings/Settings";
import { StrategyLab } from "../features/strategy/StrategyLab";
import { RegionAtlas } from "../features/regions/RegionAtlas";
import { SuccessDonation } from "../features/tier/SuccessDonation";
import { TemplateStudio } from "../features/templates/TemplateStudio";
import { AlphaVault } from "../features/vault/AlphaVault";
import { Autopilot } from "../features/autopilot/Autopilot";
import { Osmosis } from "../features/osmosis/Osmosis";
import { Catalog } from "../features/catalog/Catalog";
import { PyAlpha } from "../features/pyalpha/PyAlpha";
import { BrainPrompts } from "../features/brainprompts/BrainPrompts";
import { SuperPilot } from "../features/superpilot/SuperPilot";
import { Harness } from "../features/harness/Harness";
import { Whip } from "../features/whip/Whip";
import { useTheme } from "../lib/useTheme";
import { Placeholder } from "../features/common/Placeholder";
import { useAutoScale } from "../lib/useAutoScale";
import { ResearchProvider } from "../lib/store";
import { EngineFollow } from "../features/harness/EngineFollow";
import { ToastProvider } from "../lib/toast";
import { SessionProvider, useSession } from "../lib/session";
import { LoginGate } from "./LoginGate";
import { DailyQuote } from "./DailyQuote";
import { api } from "../lib/api";
import type { NavGroup } from "./types";
import "./shell.css";

const SCREENS: Record<string, ComponentType> = {
  "/": CommandCenter,
  "/data": DataExplorer,
  "/generate": Generation,
  "/simulate": Simulation,
  "/results": ResultsAnalytics,
  "/portfolio": Portfolio,
  "/prompts": PromptLibrary,
  "/super": SuperAlpha,
  "/operators": OperatorAtlas,
  "/settings": Settings,
  "/strategies": StrategyLab,
  "/regions": RegionAtlas,
  "/tier": SuccessDonation,
  "/templates": TemplateStudio,
  "/vault": AlphaVault,
  "/autopilot": Autopilot,
  "/pyalpha": PyAlpha,
  "/brain-prompts": BrainPrompts,
  "/super-autopilot": SuperPilot,
  "/harness": Harness,
  "/osmosis": Osmosis,
  "/catalog": Catalog,
  "/whip": Whip,
};

export function App() {
  useAutoScale();
  useTheme();   // apply the remembered light/dark theme on load
  const [navRaw, setNav] = useState<NavGroup[]>([]);
  const { pathname } = useLocation();
  useEffect(() => { api.get<{ nav: NavGroup[] }>("/meta/nav").then((d) => setNav(d.nav ?? [])); }, []);
  // Defensive: only ever show nav items whose route still exists in this build. If a stale backend
  // (e.g. an older running instance) serves a removed screen like /research or /knowledge, it is
  // dropped here rather than rendering a dead link.
  const nav = navRaw
    .map((g) => ({ ...g, items: g.items.filter((it) => it.path in SCREENS) }))
    .filter((g) => g.items.length);
  const items = nav.flatMap((g) => g.items);

  return (
    <ToastProvider>
      <ResearchProvider>
        <EngineFollow />
        <SessionProvider>
        <div className="shell">
          <Sidebar nav={nav} />
          <div className="shell-main">
            <Header nav={nav} />
            <DailyQuote />
            <LoginGate />
            <main className="shell-content">
              <ErrorBoundary key={pathname}>
                <Routes>
                  {items.map((it) => {
                    const Screen = SCREENS[it.path];
                    return (
                      <Route key={it.id} path={it.path}
                        element={Screen ? <Screen /> : <Placeholder title={it.label} ready={it.ready} />} />
                    );
                  })}
                  <Route path="/" element={<CommandCenter />} />
                  {/* Off the sidebar but still reachable (Settings via the header gear; Success by link). */}
                  <Route path="/settings" element={<Settings />} />
                  <Route path="/tier" element={<SuccessDonation />} />
                  <Route path="*" element={<Placeholder title="Not found" ready={false} />} />
                </Routes>
              </ErrorBoundary>
            </main>
            <ShellFooter />
          </div>
        </div>
        </SessionProvider>
      </ResearchProvider>
    </ToastProvider>
  );
}

// Footer is hidden while the "no session" login banner is up, so the yellow prompt owns the
// bottom of the shell and nothing competes with it. It returns once a session exists.
function ShellFooter() {
  const { s, loading } = useSession();
  if (!loading && !s.ok) return null;
  return (
    <footer className="shell-foot">
      <span>Alpha Sentry</span><span className="sep">·</span>
      <span>Local Alpha Research Studio</span>
      <span className="right">Happy Research ✦ · Let's Shine Together!</span>
    </footer>
  );
}
