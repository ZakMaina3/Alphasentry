import { useEffect, useRef, useState } from "react";
import { api } from "../../lib/api";
import { usePersistentState } from "../../lib/persist";
import "../data/data.css";
import "./whip.css";

const CLICKS_PER_CLEAN = 60;
const MAX_LINES = 1500;

const bytes = (n: number) => n < 1024 ? `${n} B` : n < 1048576 ? `${(n / 1024).toFixed(1)} KB` : n < 1073741824 ? `${(n / 1048576).toFixed(1)} MB` : `${(n / 1073741824).toFixed(2)} GB`;
const GROUP_NAMES: Record<string, string> = { logs: "logs", install_logs: "install logs", pycache: "Python cache", tmp: "temp files", updater_tmp: "updater temp" };

// A log pane that follows new lines, unless you scrolled up to read.
function useFollow(dep: unknown) {
  const ref = useRef<HTMLDivElement>(null);
  const stick = useRef(true);
  useEffect(() => { const el = ref.current; if (el && stick.current) el.scrollTop = el.scrollHeight; }, [dep]);
  const onScroll = () => { const el = ref.current; if (el) stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 40; };
  return { ref, onScroll };
}

export function Whip() {
  const [clicks, setClicks] = usePersistentState<number>("whip:clicks", 0);
  const [lines, setLines] = useState<any[]>([]);
  const seq = useRef(0);
  const [st, setSt] = useState<any>(null);          // Autosentry live status
  const [rep, setRep] = useState<any>(null);        // what a clean-up would remove
  const [msg, setMsg] = useState<string>("");
  const [busy, setBusy] = useState(false);
  const [crack, setCrack] = useState(0);
  const [big, setBig] = useState(false);
  const [shake, setShake] = useState(false);
  const left = useFollow(lines.length);
  const right = useFollow(st?.events?.length);

  // backend output: always polling while the tab is open, only the new lines each time
  useEffect(() => {
    let alive = true;
    const tick = async () => {
      const r = await api.get<any>(`/whip/logs?since=${seq.current}`);
      if (!alive || r.error) return;
      if (r.seq < seq.current) { seq.current = 0; setLines([]); return; }       // backend restarted
      seq.current = r.seq;
      if (r.lines?.length) setLines((p) => [...p, ...r.lines].slice(-MAX_LINES));
    };
    tick();
    const t = setInterval(tick, 1500);
    return () => { alive = false; clearInterval(t); };
  }, []);

  // Autosentry's live status and event log
  useEffect(() => {
    let alive = true;
    const tick = async () => { const s = await api.get<any>("/autopilot/status"); if (alive && !s.error) setSt(s); };
    tick();
    const t = setInterval(tick, 2000);
    return () => { alive = false; clearInterval(t); };
  }, []);

  const loadReport = async () => { const r = await api.get<any>("/whip/report"); if (!r.error) setRep(r); };
  useEffect(() => { loadReport(); const t = setInterval(loadReport, 30000); return () => clearInterval(t); }, []);

  async function whip() {
    if (busy) return;
    const n = clicks + 1;
    const real = n >= CLICKS_PER_CLEAN;
    setBig(real); setCrack((c) => c + 1);
    window.setTimeout(() => setShake(true), 300); window.setTimeout(() => setShake(false), 700);
    if (!real) { setClicks(n); return; }
    setBusy(true);
    const r = await api.post<any>("/whip/clean");
    setBusy(false);
    if (r.error) { setMsg(`Clean-up failed: ${r.error}`); setClicks(CLICKS_PER_CLEAN); return; }
    setMsg(r.message || "");
    setClicks(r.reason === "busy" ? CLICKS_PER_CLEAN : 0);     // busy: stay at 60 and clean on the first click after the run stops
    loadReport();
  }

  const running = !!st?.running;
  const pct = Math.min(100, Math.round((clicks / CLICKS_PER_CLEAN) * 100));
  const last = rep?.last;

  return (
    <div style={{ display: "flex", flexDirection: "column", flex: 1, minHeight: 0 }}>
      <div className="panel" style={{ padding: 12, marginBottom: 10 }}>
        <div className="whip-bar">
          <button className="btn whip-btn" onClick={whip} disabled={busy}
            title={`Every click cracks the whip. Click ${CLICKS_PER_CLEAN} times and it also clears temporary files (never your results, library, learning or anything that costs LLM tokens). Skipped while Autosentry, Supersentry or SentryEngine run.`}>
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 20l5-5M9 15c6 1 11-4 10-11M19 4l1.5 2.2M19 4l-2.4.4" /></svg>
            Whip</button>
          <span className="whip-count">{Math.min(clicks, CLICKS_PER_CLEAN)}/{CLICKS_PER_CLEAN}</span>
          <span className="whip-meter"><i style={{ width: `${pct}%` }} /></span>
          {clicks >= CLICKS_PER_CLEAN ? <span className="whip-note">Ready: the next click cleans{rep?.busy?.length ? ` (waiting: ${rep.busy.join(", ")} running)` : ""}.</span> : null}
          <span className="whip-note" style={{ marginLeft: "auto" }}>
            {rep ? <>Would free <b>{bytes(rep.bytes)}</b>{rep.groups?.length ? <> · {rep.groups.slice(0, 4).map((g: any) => `${GROUP_NAMES[g.group] || g.group} ${bytes(g.bytes)}`).join(" · ")}</> : null}</> : "Checking temporary files…"}
          </span>
        </div>
        <div className="whip-note">
          {msg ? <><b>{msg}</b> · </> : null}
          {last ? <>Last clean-up {new Date(last.at * 1000).toLocaleString()}: freed {bytes(last.freed)}.</> : "No clean-up yet."}
          {" "}Only temporary files are cleared: your results, vault, library, learning, LLM cache and session are never touched.
        </div>
      </div>

      <div className="dx-split" style={{ flex: 1, minHeight: 0 }}>
        <div className="panel whip-pane" style={{ padding: 12 }}>
          <div className="dx-head"><b>Backend</b><span className="mut">live output · {lines.length} lines</span></div>
          <div className="whip-term" ref={left.ref} onScroll={left.onScroll}>
            {lines.length ? lines.map((l) => <div key={l.seq} className={l.level}><span className="t">{new Date(l.t * 1000).toLocaleTimeString()}</span>{l.text}</div>)
              : <span className="mut">Waiting for backend output…</span>}
          </div>
        </div>

        <div className={"panel whip-pane" + (shake ? " shake" : "")} style={{ padding: 12 }}>
          <div className="dx-head"><b>Autosentry</b>
            <span className="mut">{st?.phase || "idle"}</span>
            {running ? <span className="badge ok" style={{ marginLeft: "auto" }}>running</span> : null}</div>
          <div className="whip-term" ref={right.ref} onScroll={right.onScroll}>
            {(st?.events || []).length ? (st.events as any[]).map((e, i) => <div key={i}><span className="t">{new Date(e.t * 1000).toLocaleTimeString()}</span>{e.msg}</div>)
              : <span className="mut">No Autosentry events yet. Start it on the Autosentry screen.</span>}
          </div>
          {crack ? (
            <div key={crack} className={"whip-overlay go" + (big ? " big" : "")} aria-hidden="true">
              <svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice">
                <g className="whip-whole">
                  <line className="whip-handle" x1="18" y1="26" x2="44" y2="52" />
                  <path className="whip-lash" d="M44 52 C 120 20, 150 150, 230 120 S 330 150, 330 162" />
                </g>
                <circle className="whip-flash" cx="330" cy="162" r="18" />
                <text className="whip-word" x="250" y="132">{big ? "CLEAN!" : "CRACK!"}</text>
              </svg>
            </div>) : null}
        </div>
      </div>
    </div>
  );
}
