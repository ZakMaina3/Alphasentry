import { useEffect, useMemo, useRef, useState } from "react";
import { api } from "../../lib/api";
import { AutosentryMark } from "../../lib/Logo";
import { useResearch } from "../../lib/store";
import { usePersistentState } from "../../lib/persist";
import { NumberInput } from "../../lib/NumberInput";
import { AlphaCell } from "../../lib/AlphaCell";
import { useToast } from "../../lib/toast";
import { AutopilotLibrary } from "./AutopilotLibrary";
import { TelegramSetup } from "./TelegramSetup";
import { ScopeFields } from "../common/ScopePicker";
import { FrameworkPanel, fwPayload, useFwSel } from "../frameworks/FrameworkPanel";

const num = (v: any, d = 2) => (v == null ? "—" : (+v).toFixed(d));
const PHASE: Record<string, string> = {
  idle: "idle", starting: "starting…", hypothesizing: "forming hypotheses", templating: "designing templates",
  simulating: "simulating batch", boosting: "boosting winners", flipping: "reversing negative signals", decorrelating: "reducing prod correlation", reviewing: "reviewing results", cooldown: "next hypothesis…",
  waiting: "waiting", stopped: "stopped",
};

// Autosentry — the autonomous engine. Pick datafields in Data Explorer, press Start. It forms
// hypotheses, designs templates, simulates batches of 10, reviews the results (full BRAIN check
// incl. correlations), refines the templates and repeats — until you press Stop. Winners are
// parked in the Alpha Vault; nothing is ever submitted automatically.
const DEFAULT_NEUTS = ["NONE", "MARKET", "SECTOR", "INDUSTRY", "SUBINDUSTRY", "COUNTRY", "CROWDING", "FAST", "SLOW",
  "SLOW_AND_FAST", "REVERSION_AND_MOMENTUM", "STATISTICAL"];

export function Autopilot() {
  const R = useResearch();
  const { toast, toastErr } = useToast();

  const [goal, setGoal] = usePersistentState("ap:goal", "");
  const [batch, setBatch] = usePersistentState("ap:batch", 10);
  const [rounds, setRounds] = usePersistentState("ap:rounds2", 4);
  const [tpl, setTpl] = usePersistentState("ap:tpl", 6);
  const [ops, setOps] = usePersistentState("ap:ops", 4);
  const [twoField, setTwoField] = usePersistentState("ap:two", true);
  const [neuts, setNeuts] = usePersistentState<string[]>("ap:neuts", ["INDUSTRY"]);
  const [decay, setDecay] = usePersistentState("ap:decay", 4);
  const [trunc, setTrunc] = usePersistentState("ap:trunc", 0.08);
  const [conc, setConc] = usePersistentState("ap:conc1", 1)
  const [prodDelay, setProdDelay] = usePersistentState("ap:proddelay", 60);
  const [stallMin, setStallMin] = usePersistentState("ap:stallmin", 30);
  const [rescueMax, setRescueMax] = usePersistentState("ap:rescuemax", 0.74);
  const [perHyp, setPerHyp] = usePersistentState("ap:perhyp", 1);
  const [maxCycles, setMaxCycles] = usePersistentState("ap:maxcycles", 0);
  const [maxWinners, setMaxWinners] = usePersistentState("ap:maxwinners", 0);
  const [minSharpe, setMinSharpe] = usePersistentState<number>("ap:minsharpe", 0);   // 0 = default by delay
  const [minFit, setMinFit] = usePersistentState<number>("ap:minfit", 0);
  const [tag] = useState(() => localStorage.getItem("ace2-tag") || "");
  const [winnerTag] = useState(() => localStorage.getItem("ace2-winnertag") || "");
  const [useLib, setUseLib] = usePersistentState("ap:uselib", true);
  const [seedRun, setSeedRun] = usePersistentState("ap:seedrun", true);
  const [boost, setBoost] = usePersistentState("ap:boost", true);
  const [trigger, setTrigger] = usePersistentState<number>("ap:trigger", 1.0);
  const [flip, setFlip] = usePersistentState("ap:flip", true);
  const [flipMin, setFlipMin] = usePersistentState<number>("ap:flipmin2", 1.0);
  const [method, setMethod] = usePersistentState<"explore" | "clone" | "framework">("ap:method", "explore");
  const [cloneSim, setCloneSim] = usePersistentState<number>("ap:clonesim", 0.5);
  const [cloneMin, setCloneMin] = usePersistentState<number>("ap:clonemin", 1.0);
  const [clonePer, setClonePer] = usePersistentState<number>("ap:cloneper", 10);
  const [cloneMax, setCloneMax] = usePersistentState<number>("ap:clonemax", 30);
  const [cloneSub, setCloneSub] = usePersistentState("ap:clonesub", true);
  const [cloneVault, setCloneVault] = usePersistentState("ap:clonevault", true);
  const [cloneIds, setCloneIds] = usePersistentState<string>("ap:cloneids", "");
  const [clonePaste, setClonePaste] = usePersistentState<string>("ap:clonepaste", "");
  const [pasteInfo, setPasteInfo] = useState<any>(null);
  const [starters, setStarters] = usePersistentState("ap:starters", true);
  const [triage, setTriage] = usePersistentState("ap:triage", true);
  const [triageSh, setTriageSh] = usePersistentState<number>("ap:triagesh", 0.5);
  const [nudge, setNudge] = usePersistentState("ap:nudge", true);
  const [boostWin, setBoostWin] = usePersistentState("ap:boostwin", false);
  const [nearMiss, setNearMiss] = usePersistentState<number>("ap:nearmiss", 0);
  const [decorr, setDecorr] = usePersistentState("ap:decorr", true);
  const [decorrRounds, setDecorrRounds] = usePersistentState<number>("ap:decorrrounds", 2);
  const [tab, setTab] = useState<"live" | "library" | "learning">("live");
  const [st, setSt] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const logRef = useRef<HTMLDivElement>(null);

  // Live list from BRAIN when loaded; otherwise the standard set, so the selector is NEVER empty/hidden.
  const liveNeuts = useMemo(() => {
    const recs = (R.options || []).filter((o) => o.instrument === R.ctx.instrument && o.region === R.ctx.region);
    return [...new Set(recs.flatMap((o) => o.neutralizations))];
  }, [R.options, R.ctx]);
  const neutOpts = useMemo(() => {
    const base = liveNeuts.length ? liveNeuts : DEFAULT_NEUTS;
    return [...new Set([...base, ...neuts.filter((n) => !liveNeuts.length || liveNeuts.includes(n))])];
  }, [liveNeuts, neuts]);
  useEffect(() => {
    if (!liveNeuts.length) return;      // only prune a stale choice (e.g. COUNTRY on USA) once the real list is known
    setNeuts((p) => { const k = p.filter((n) => liveNeuts.includes(n)); return k.length ? k : [liveNeuts.includes("INDUSTRY") ? "INDUSTRY" : liveNeuts[0]]; });
  }, [liveNeuts]);

  const selected = useMemo(() => R.fields.filter((f) => R.selFields.includes(f.id)), [R.fields, R.selFields]);
  const categories = useMemo(() => {
    const dsCat: Record<string, string> = {};
    R.datasets.forEach((d) => { dsCat[d.id] = d.category_name || d.category_id || ""; });
    const m: Record<string, string> = {};
    selected.forEach((f) => { if (f.dataset_id && dsCat[f.dataset_id]) m[f.id] = dsCat[f.dataset_id]; });
    return m;
  }, [R.datasets, selected]);

  // poll the engine's live state (always — so reopening the page re-attaches to a running engine)
  useEffect(() => {
    let alive = true;
    const tick = async () => { const s = await api.get<any>("/autopilot/status"); if (alive && !s.error) setSt(s); };
    tick();
    const t = setInterval(tick, 2000);
    return () => { alive = false; clearInterval(t); };
  }, []);
  useEffect(() => { if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight; }, [st?.events?.length]);

  const running = !!st?.running;

  // preview of the pasted alphas (what was recognised, which can be swapped), refreshed shortly after typing stops
  useEffect(() => {
    if (method !== "clone" || !clonePaste.trim()) { setPasteInfo(null); return; }
    let alive = true;
    const t = setTimeout(async () => {
      const r = await api.post<any>("/autopilot/clone/preview", { text: clonePaste, region: R.ctx.region, delay: R.ctx.delay });
      if (alive && !r.error) setPasteInfo(r);
    }, 400);
    return () => { alive = false; clearTimeout(t); };
  }, [method, clonePaste, R.ctx.region, R.ctx.delay]);

  const [fw, setFw] = useFwSel("autosentry");
  const fwOn = fw.ids.length > 0 || fw.cats.length > 0;
  const [lanes, setLanes] = usePersistentState<number>("ap:fwlanes", 1);
  async function start() {
    if (method === "framework" && !fwOn) return toast("Tick at least one saved framework (or paste one and save it) first.", "warn");
    if (method === "explore" && !selected.length) return toast("Select datafields in Data Explorer first — the engine builds hypotheses around them.", "warn");
    if (method === "clone" && !cloneSub && !cloneVault && !clonePaste.trim()) return toast("Pick at least one source: submitted alphas, the vault, or paste your own alphas.", "warn");
    if (!neuts.length) return toast("Pick at least one neutralization.", "warn");
    setBusy(true);
    const r = await api.post<any>("/autopilot/start", {
      region: R.ctx.region, delay: R.ctx.delay, instrument: R.ctx.instrument, universe: R.ctx.universe,
      neutralizations: neuts, decay, truncation: trunc, batch_size: batch, max_rounds: rounds,
      templates_per_round: tpl, max_operators: ops, allow_two_field: twoField, winners_per_hypothesis: perHyp,
      concurrency: conc, prod_check_delay: prodDelay, prod_rescue_max: rescueMax, stall_minutes: stallMin, goal, tag, winner_tag: winnerTag, max_cycles: maxCycles, max_winners: maxWinners,
      min_sharpe: minSharpe > 0 ? minSharpe : null, min_fitness: minFit > 0 ? minFit : null,
      ...(method === "framework" ? { ...fwPayload(fw), fw_lanes: fw.ids.length > 1 ? lanes : 1 } : {}),
      fields: selected.map((f) => ({ id: f.id, description: f.description || "", type: f.type || "MATRIX", dataset_id: f.dataset_id || "" })),
      categories, use_library: useLib, seed_run: seedRun, boost, booster_trigger: trigger, flip, flip_min_sharpe: flipMin, method, clone_sources: [...(cloneSub ? ["submitted"] : []), ...(cloneVault ? ["vault"] : [])], clone_similarity: cloneSim, clone_min_sharpe: cloneMin, clone_per_alpha: clonePer, clone_max_sources: cloneMax, clone_ids: cloneIds.split(/[\s,;]+/).filter(Boolean), clone_pasted: clonePaste, builtin_boosters: starters, triage, triage_sharpe: triageSh, nudge, boost_winners: boostWin, boost_near_miss: nearMiss, decorrelate: decorr, decorr_rounds: decorrRounds,
    });
    setBusy(false);
    if (r.error) return toastErr(r.error);
    toast(r.already_running ? "Autosentry is already running." : "Autosentry started.", "ok");
  }
  async function stop() { await api.post("/autopilot/stop"); toast("Stopping after the current step…"); }
  async function reset() {
    if (!window.confirm("Clear the winners list and hypothesis history shown here? (Stored simulation results are untouched.)")) return;
    await api.post("/autopilot/reset"); toast("History cleared.");
  }

  const Pill = ({ on, label, onClick, title }: { on: boolean; label: string; onClick: () => void; title?: string }) =>
    <span className={"pill" + (on ? " on" : "")} onClick={onClick} title={title}>{label}</span>;
  const state = st?.state || { cycles: 0, simulated: 0, winners: [], hypotheses: [] };
  const hyp = st?.hypothesis;

  return (
    <div className="dx-split" style={{ flex: 1, minHeight: 0 }}>
      {/* controls */}
      <div className="panel" style={{ padding: 14 }}>
        <div className="dx-head"><AutosentryMark size={20} /><b>Autosentry</b>
          <span className="mut">{R.ctx.region} · D{R.ctx.delay} · {R.ctx.universe} · {selected.length} fields</span>
          {running ? <span className="badge ok" style={{ marginLeft: "auto" }}>running</span> : null}</div>
        <div className="panel-scroll">
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8, marginBottom: 8 }}
            title="The market this run works in. Choices come from the data stored on this computer; it is the same market as the one in the top bar. A run that is already going keeps the market it started with.">
            <ScopeFields region={R.ctx.region} delay={R.ctx.delay} universe={R.ctx.universe}
              onChange={(v) => R.setCtx({ region: v.region, delay: v.delay, universe: v.universe })} />
          </div>
          <div className="dx-filters" style={{ marginBottom: 8 }}>
            <Pill on={method === "explore"} label="Explore ideas" onClick={() => setMethod("explore")}
              title="The LLM forms hypotheses from the datafields you picked in Data Explorer." />
            <Pill on={method === "clone"} label="Clone and swap" onClick={() => setMethod("clone")}
              title="Take your old alphas, swap in similar datafields from the Data Catalog, simulate in batches of 10, then run the full check incl. prod correlation." />
            <Pill on={method === "framework"} label="Frameworks" onClick={() => setMethod("framework")}
              title="Follow one or two saved research frameworks, each in its own region, with datafields from the Data Catalog and the pairing rules." />
          </div>
          {method === "clone" ? (
            <div className="panel" style={{ padding: 10, marginBottom: 8 }}>
              <div className="dx-filters">
                <Pill on={cloneSub} label={`Submitted alphas: ${cloneSub ? "ON" : "OFF"}`} onClick={() => setCloneSub((v) => !v)} />
                <Pill on={cloneVault} label={`Alpha Vault: ${cloneVault ? "ON" : "OFF"}`} onClick={() => setCloneVault((v) => !v)} />
              </div>
              <label className="fld" style={{ marginTop: 8 }} title="Paste alphas of your own that work. They are cloned first, whatever their Sharpe, and are used in every region and delay you run (the swaps come from the Data Catalog of the current context). One alpha per line; a blank line separates alphas; an alpha may span several lines while its brackets are open or lines end with ;">
                <span>My own working alphas (paste, one per line)</span>
                <textarea value={clonePaste} onChange={(e) => setClonePaste(e.target.value)} spellCheck={false}
                  style={{ minHeight: 84, fontFamily: "var(--mono, monospace)", fontSize: 12 }}
                  placeholder={"rank(ts_mean(oth143_buy_tier1_broker_rank1, 20))\n-zscore(anl4_eps_est)   # comments after # are ignored"} /></label>
              {clonePaste.trim() ? (
                <div className="mut" style={{ fontSize: 11, marginTop: 4 }}>
                  {pasteInfo ? <>
                    <b>{pasteInfo.usable}</b> of {pasteInfo.total} pasted alpha(s) can be swapped for {R.ctx.region} delay {R.ctx.delay}
                    {pasteInfo.catalog_fields === 0 ? " (the Data Catalog has no fields for this scope yet)" : ""}.
                    {pasteInfo.alphas.filter((a: any) => a.problem).slice(0, 4).map((a: any) =>
                      <div key={a.id}>⚠ {a.expr.length > 48 ? a.expr.slice(0, 48) + "…" : a.expr}: {a.problem}</div>)}
                  </> : "Checking…"}
                  <span className="pill" style={{ marginLeft: 8 }} onClick={() => setClonePaste("")}>Clear</span>
                </div>) : null}
              <label className="fld" style={{ marginTop: 8 }} title="0 = swap only in fields from the SAME dataset (closest idea, likely correlated with the original). 1 = only fields from OTHER datasets (more likely to pass prod correlation). In between favours one or the other.">
                <span>Similarity: same dataset ← {num(cloneSim, 2)} → other datasets</span>
                <input type="range" min={0} max={1} step={0.05} value={cloneSim} onChange={(e) => setCloneSim(+e.target.value)} /></label>
              <label className="fld"><span>Only clone alphas with Sharpe at least</span><NumberInput step="0.1" min={0} fallback={1} value={cloneMin} onChange={setCloneMin} /></label>
              <label className="fld"><span>Swaps per source alpha</span><NumberInput min={1} max={60} fallback={10} value={clonePer} onChange={setClonePer} /></label>
              <label className="fld"><span>Most source alphas (best Sharpe first)</span><NumberInput min={1} max={500} fallback={30} value={cloneMax} onChange={setCloneMax} /></label>
              <label className="fld"><span>Only these alpha ids (optional)</span>
                <input value={cloneIds} onChange={(e) => setCloneIds(e.target.value)} placeholder="leave empty to use every matching alpha" /></label>
              <div className="mut" style={{ fontSize: 11, marginTop: 6 }}>
                Uses the datafields in the <b>Data Catalog</b> for {R.ctx.region} delay {R.ctx.delay}; download them there first. Submitted and vault alphas are limited to this region and delay; alphas you paste are always used.
                Datafields picked in Data Explorer are not needed in this mode.</div>
            </div>
          ) : null}
          {method === "framework" ? (<>
            <div className="mut" style={{ fontSize: 12, marginBottom: 4 }}>Each framework runs in the region you saved it with; the market picker above is only used for a framework saved without one.</div>
            <FrameworkPanel sel={fw} setSel={setFw} region={R.ctx.region} delay={R.ctx.delay} who="Autosentry" />
            {fw.ids.length > 1 ? (
              <div className="dx-filters" style={{ marginBottom: 8 }} title="Two lanes work on two frameworks at the same time and share the simulation slots; one lane takes them in turn.">
                <b style={{ fontSize: 12 }}>Run</b>
                <Pill on={lanes <= 1} label="One at a time" onClick={() => setLanes(1)} title="Work through the ticked frameworks in turn." />
                <Pill on={lanes >= 2} label="Two at a time" onClick={() => setLanes(2)} title="Two frameworks side by side; each lane uses half of the parallel batches, so together they stay within the engine's slots. With more than two, each lane takes its share in turn." />
              </div>) : null}
          </>) : null}
          {method === "explore" && !selected.length ? <div className="empty" style={{ marginBottom: 8 }}>No datafields selected. Pick them in <b>Data Explorer</b> — the engine builds every hypothesis around your selection.</div> : null}
          <label className="fld"><span>Research Goal (Optional)</span>
            <textarea value={goal} onChange={(e) => setGoal(e.target.value)} style={{ minHeight: 56 }}
              placeholder="e.g. low-turnover fundamental alphas that diversify away from price momentum" /></label>

          <label style={{ fontSize: 11, color: "var(--mut)", marginTop: 8, display: "block" }}>Neutralizations
            {!liveNeuts.length ? <span title="BRAIN's option list isn't loaded (log in, then reload). Invalid ones are skipped automatically per region."> · standard list</span> : null}</label>
          <div className="dx-filters wrap">{neutOpts.map((n) =>
            <Pill key={n} on={neuts.includes(n)} label={n} onClick={() => setNeuts((p) => p.includes(n) ? p.filter((x) => x !== n) : [...p, n])} />)}</div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8, marginTop: 8 }}>
            <label className="fld"><span>Batch size (2–10)</span><NumberInput min={2} max={10} fallback={10} value={batch} onChange={setBatch} /></label>
            <label className="fld"><span>Max rounds / hypothesis</span><NumberInput min={1} fallback={4} value={rounds} onChange={setRounds} /></label>
            <label className="fld"><span>Templates / round</span><NumberInput min={2} max={12} fallback={6} value={tpl} onChange={setTpl} /></label>
            <label className="fld"><span>Max operators</span><NumberInput min={1} max={10} fallback={4} value={ops} onChange={setOps} /></label>
            <label className="fld"><span>Decay</span><NumberInput min={0} fallback={4} value={decay} onChange={setDecay} /></label>
            <label className="fld"><span>Truncation</span><NumberInput step="0.01" min={0} fallback={0.08} value={trunc} onChange={setTrunc} /></label>
            <label className="fld"><span title="1 = each round tests one batch of 10. Higher values run several batches of 10 side by side in the same round (BRAIN allows about 3 in parallel).">Batches per round (1 = 10 alphas)</span><NumberInput min={1} max={3} fallback={1} value={conc} onChange={setConc} /></label>
            <label className="fld"><span title="When an alpha passes everything except production correlation, Autosentry tries to fix it. It will not try when the correlation is above this number (it almost never works).">Skip prod rescue above</span><NumberInput step="0.01" min={0.5} max={1} fallback={0.74} value={rescueMax} onChange={setRescueMax} /></label>
            <label className="fld"><span title="If one step makes no progress for this long, Autosentry stops, abandons everything in flight and sends you the details on Telegram. 0 = off.">Stop if stuck for (min)</span><NumberInput min={0} max={240} fallback={30} value={stallMin} onChange={setStallMin} /></label>
            <label className="fld"><span title="Seconds to wait before each production-correlation check, one check at a time. 0 = no wait (up to 4 checks at once).">Prod check delay (s)</span><NumberInput min={0} max={600} fallback={60} value={prodDelay} onChange={setProdDelay} /></label>
            <label className="fld"><span>Winners / hypothesis</span><NumberInput min={1} fallback={1} value={perHyp} onChange={setPerHyp} /></label>
            <label className="fld"><span>|Sharpe| ≥ (0 = default)</span><NumberInput step="0.01" min={0} fallback={0} value={minSharpe} onChange={setMinSharpe} /></label>
            <label className="fld"><span>|Fitness| ≥ (0 = default)</span><NumberInput step="0.1" min={0} fallback={0} value={minFit} onChange={setMinFit} /></label>
            <label className="fld" title="0 = run forever"><span>Stop after N hypotheses (0 = ∞)</span><NumberInput min={0} fallback={0} value={maxCycles} onChange={setMaxCycles} /></label>
            <label className="fld" title="0 = run forever"><span>Stop after N winners (0 = ∞)</span><NumberInput min={0} fallback={0} value={maxWinners} onChange={setMaxWinners} /></label>
          </div>
          <div className="dx-filters" style={{ marginTop: 8 }}>
            <Pill on={twoField} label={`Two-field templates: ${twoField ? "ON" : "OFF"}`} onClick={() => setTwoField((v) => !v)}
              title="Let the LLM combine two datafields ({field} + {field2}) in some templates." />
            <Pill on={useLib} label={`Use library & lessons: ${useLib ? "ON" : "OFF"}`} onClick={() => setUseLib((v) => !v)}
              title="Feed your uploaded alphas / templates / papers / notes and everything learned so far to the LLM, and keep learning." />
            <Pill on={seedRun} label={`Simulate library alphas first: ${seedRun ? "ON" : "OFF"}`} onClick={() => setSeedRun((v) => !v)}
              title="Before new research, simulate your working alphas under this run's settings." />
            <Pill on={flip} label={`Reverse negative signals: ${flip ? "ON" : "OFF"}`} onClick={() => setFlip((v) => !v)}
              title="When an alpha has Sharpe below the limit below (default −1), it is reversed. The reversed version runs in the next batch of 10, together with new alphas." />
            <Pill on={decorr} label={`Cut prod correlation: ${decorr ? "ON" : "OFF"}`} onClick={() => setDecorr((v) => !v)}
              title="If an alpha passes everything except PROD correlation: re-simulate under other neutralizations, re-check, then swap in sister/brother operators." />
            <Pill on={boost} label={`Boosters: ${boost ? "ON" : "OFF"}`} onClick={() => setBoost((v) => !v)}
              title="Every alpha with Sharpe above the limit below (default 1) that does not yet pass everything is boosted. Boosted versions run in the next batch of 10, together with new alphas." />
            <Pill on={starters} label={`Built-in starter boosters: ${starters ? "ON" : "OFF"}`} onClick={() => setStarters((v) => !v)}
              title="Used only when your Library has no booster for this region (neutralize, decay, rank, liquid-days wrappers). Your own boosters replace them as soon as you add any." />
            <Pill on={nudge} label={`Window nudges: ${nudge ? "ON" : "OFF"}`} onClick={() => setNudge((v) => !v)}
              title="For promising alphas, also try a shorter and a longer first window." />
            <Pill on={triage} label={`Test many ideas: ${triage ? "ON" : "OFF"}`} onClick={() => setTriage((v) => !v)}
              title="Each idea gets one batch of 10. If nothing reaches the Sharpe below, it is dropped and the next idea starts. Promising ideas keep going." />
            <Pill on={boostWin} label={`Boost passing alphas too: ${boostWin ? "ON" : "OFF"}`} onClick={() => setBoostWin((v) => !v)}
              title="Also try boosters on alphas that already pass everything. Off by default: boosted copies are highly correlated with the original." />
          </div>
          {boost && st?.boost_info && st.boost_info.count === 0 ? <div style={{ color: "var(--bad)", fontSize: 12, marginTop: 6 }}>
            No booster is available for this region, so nothing can be boosted. Add boosters in Library or turn on the built-in starters.</div> : null}
          {boost && st?.boost_info && st.boost_info.count > 0 ? <div className="mut" style={{ fontSize: 11, marginTop: 6 }}>
            Boosters in use: {st.boost_info.count} from {st.boost_info.source}.</div> : null}
          {triage ? <label className="fld" style={{ marginTop: 8 }} title="Drop an idea after its first batch when its best alpha has a smaller |Sharpe| than this (strongly negative alphas count, they can be reversed).">
            <span>Move on if best |Sharpe| after the first batch is below</span><NumberInput step="0.1" min={0} fallback={0.5} value={triageSh} onChange={setTriageSh} /></label> : null}
          {boost ? <label className="fld" style={{ marginTop: 8 }} title="Also boost alphas up to this much BELOW the limit (0 = off).">
            <span>Also boost near-misses within</span><NumberInput step="0.1" min={0} fallback={0} value={nearMiss} onChange={setNearMiss} /></label> : null}
          {decorr ? <label className="fld" style={{ marginTop: 8 }} title="How many rounds of sister/brother operator swaps to try after cross-neutralization fails.">
            <span>Operator-swap rounds</span><NumberInput min={1} max={5} fallback={2} value={decorrRounds} onChange={setDecorrRounds} /></label> : null}
          {flip ? <label className="fld" style={{ marginTop: 8 }} title="Negative alphas closer to zero than this are treated as noise and not flipped.">
            <span>Reverse when Sharpe is below −</span><NumberInput step="0.1" min={0} fallback={1} value={flipMin} onChange={setFlipMin} /></label> : null}
          {boost ? <label className="fld" style={{ marginTop: 8 }} title="Alphas above this Sharpe get boosted. This is the one threshold; a booster's own limit is ignored.">
            <span>Boost alphas with Sharpe above</span><NumberInput step="0.1" min={0} fallback={1} value={trigger} onChange={setTrigger} /></label> : null}
          <div className="mut" style={{ fontSize: 11, marginTop: 8 }}>
            {st?.run ? <>This run: {st.run.hyps} idea(s) tested ({st.run.abandoned} dropped early) · boosts helped {st.run.boost_helped}/{st.run.boosts} · reversals promising {st.run.flip_helped}/{st.run.flips} · nudges helped {st.run.nudge_helped}/{st.run.nudges}.<br /></> : null}
            Every gate-passing alpha gets BRAIN's full submission check (self / prod / power-pool correlation + every IS test).
            An alpha only counts as a winner when <b>everything</b> passes. Winners are tagged{winnerTag ? <> “{winnerTag}”</> : null} and parked in the Alpha Vault — <b>never auto-submitted</b>.
          </div>

          <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
            <button className="btn" style={{ flex: 1 }} onClick={start} disabled={running || busy}>
              {running ? <><span className="spin" /> Running…</> : "▶ Start Autosentry"}</button>
            {running ? <button className="btn ghost" onClick={stop}>Stop</button> : null}
          </div>
          <button className="btn ghost sm" style={{ marginTop: 8 }} onClick={reset} disabled={running}>Clear winners & history</button>
          <TelegramSetup />
        </div>
      </div>

      {/* live view */}
      <div className="panel" style={{ padding: 14 }}>
        <div className="dx-head">
          {(["live", "library", "learning"] as const).map((t) =>
            <span key={t} className={"pill" + (tab === t ? " on" : "")} style={{ marginRight: 6 }} onClick={() => setTab(t)}>
              {t === "live" ? "Live" : t === "library" ? "Library" : "Learning"}</span>)}
          <span className="badge" style={{ marginLeft: 8 }}>{PHASE[st?.phase || "idle"] || st?.phase}</span>
          <span className="mut" style={{ marginLeft: "auto" }}>{state.cycles} hypotheses · {state.simulated} simulated · <b style={{ color: "var(--ok)" }}>{state.winners.length} winners</b></span></div>
        {tab !== "live" ? <AutopilotLibrary region={R.ctx.region} tab={tab} /> : <div className="panel-scroll">
          {st?.wait ? <div style={{ fontSize: 12, color: "var(--warn)", marginBottom: 8 }}>{st.wait}</div> : null}

          {hyp ? <div style={{ marginBottom: 10 }}>
            <div className="section" style={{ fontSize: 11, color: "var(--mut)", textTransform: "uppercase", letterSpacing: ".5px" }}>
              Hypothesis #{st.cycle} · round {st.round}/{st.max_rounds}</div>
            <div style={{ fontWeight: 600, marginTop: 2 }}>{hyp.idea}</div>
            <div className="mut" style={{ fontSize: 12 }}>{hyp.mechanism}</div>
            <div className="mut" style={{ fontSize: 11, marginTop: 2 }}>fields: {(hyp.fields || []).map((f: string) => <code key={f} style={{ marginRight: 6 }}>{f}</code>)}</div>
            {st.templates?.length ? <div style={{ marginTop: 6 }}>{st.templates.map((t: string, i: number) =>
              <div key={i} className="sub"><AlphaCell expr={t} max={90} /></div>)}</div> : null}
          </div> : <div className="empty">{running ? "Working…" : "Press Start. The engine will propose hypotheses from your selected datafields, simulate batches, review, refine and repeat."}</div>}

          {st?.last_batch?.length ? <>
            <div className="section" style={{ fontSize: 11, color: "var(--mut)", textTransform: "uppercase", letterSpacing: ".5px" }}>Last batch</div>
            <table><thead><tr><th></th><th>Alpha</th><th>Sharpe</th><th>Fit</th><th>Turn</th><th>Why not</th></tr></thead>
              <tbody>{st.last_batch.map((r: any, i: number) => (
                <tr key={i}>
                  <td>{r.passed ? <span style={{ color: "var(--ok)" }}>✓</span> : <span style={{ color: "var(--bad)" }}>✗</span>}</td>
                  <td>{r.alpha_id ? <a href={`https://platform.worldquantbrain.com/alpha/${r.alpha_id}`} target="_blank" rel="noopener"><code>{r.alpha_id}</code></a> : "—"}
                    <div className="sub" style={{ marginTop: 2 }}><AlphaCell expr={r.expr} max={44} /></div></td>
                  <td>{num(r.sharpe)}</td><td>{num(r.fitness)}</td><td>{r.turnover == null ? "—" : (r.turnover * 100).toFixed(0) + "%"}</td>
                  <td className="mut" style={{ fontSize: 11 }}>{(r.reasons || []).join(", ")}</td>
                </tr>))}</tbody></table></> : null}

          <div className="section" style={{ fontSize: 11, color: "var(--mut)", textTransform: "uppercase", letterSpacing: ".5px", marginTop: 14 }}>Winners (passed everything)</div>
          {!state.winners.length ? <div className="empty">None yet.</div> :
            <table><thead><tr><th>Alpha</th><th>Sharpe</th><th>Fit</th><th>Turn</th><th>Self / Prod corr</th></tr></thead>
              <tbody>{[...state.winners].reverse().map((w: any, i: number) => (
                <tr key={i}>
                  <td><a href={`https://platform.worldquantbrain.com/alpha/${w.alpha_id}`} target="_blank" rel="noopener"><code>{w.alpha_id}</code></a>
                    <div className="sub" style={{ marginTop: 2 }}><AlphaCell expr={w.expr} max={44} /></div>
                    <div className="mut" style={{ fontSize: 11 }}>{w.hypothesis}{w.via ? <> · <b>{w.via}</b></> : null}</div></td>
                  <td>{num(w.sharpe)}</td><td>{num(w.fitness)}</td><td>{w.turnover == null ? "—" : (w.turnover * 100).toFixed(0) + "%"}</td>
                  <td className="mut">{num(w.self_corr)} / {num(w.prod_corr)}</td>
                </tr>))}</tbody></table>}

          <div className="section" style={{ fontSize: 11, color: "var(--mut)", textTransform: "uppercase", letterSpacing: ".5px", marginTop: 14 }}>Hypothesis history</div>
          {!state.hypotheses.length ? <div className="empty">Nothing explored yet.</div> :
            <table><thead><tr><th>Hypothesis</th><th>Result</th><th>Rounds</th><th>Best |fit|</th></tr></thead>
              <tbody>{[...state.hypotheses].reverse().map((h: any, i: number) => (
                <tr key={i}><td style={{ fontSize: 12 }}>{h.idea}</td>
                  <td style={{ color: h.status === "won" ? "var(--ok)" : "var(--mut)" }}>{h.status}</td>
                  <td className="mut">{h.rounds}</td><td className="mut">{num(h.best_fitness)}</td></tr>))}</tbody></table>}

          <div className="section" style={{ fontSize: 11, color: "var(--mut)", textTransform: "uppercase", letterSpacing: ".5px", marginTop: 14 }}>Event log</div>
          <div ref={logRef} style={{ maxHeight: 180, overflow: "auto", fontSize: 11, fontFamily: "monospace", background: "var(--bg2, rgba(0,0,0,.15))", borderRadius: 6, padding: "6px 8px" }}>
            {(st?.events || []).map((e: any, i: number) => <div key={i}>{new Date(e.t * 1000).toLocaleTimeString()} · {e.msg}</div>)}
          </div>
        </div>}
      </div>
    </div>
  );
}
