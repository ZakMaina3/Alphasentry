import { useEffect, useMemo, useRef, useState, type ChangeEvent, type CSSProperties } from "react";
import { api } from "../../lib/api";
import { useResearch } from "../../lib/store";
import { AlphaCell } from "../../lib/AlphaCell";
import { useToast } from "../../lib/toast";

type Kind = "alpha" | "template" | "booster" | "paper" | "note" | "opgroup" | "superalpha" | "selection" | "combo";

const ALL_KINDS: { id: Kind; label: string; hint: string; ph: string }[] = [
  { id: "alpha", label: "Working alphas", hint: "Concrete, proven expressions. The engine studies them, mutates them, simulates them once at the start of a run, and boosts them. One per line (optional “name :: expression”).",
    ph: "group_neutralize(-1 * ts_rank(close - vwap, 10), industry)" },
  { id: "template", label: "Templates", hint: "Abstract expressions with {field} (and optionally {field2}). They are added to round 1 of every hypothesis and the LLM modifies them. One per line.",
    ph: "group_neutralize(ts_rank({field}, 60), industry)" },
  { id: "booster", label: "Boosters", hint: "Wrappers around {alpha}. Applied to any alpha whose Sharpe clears the trigger but that doesn’t pass everything yet. One per line.",
    ph: "ts_decay_linear({alpha}, 8)" },
  { id: "superalpha", label: "SuperAlphas", hint: "Proven SuperAlphas as `selection -> combo`, one per line. In SuperAlpha mode the engine re-simulates them first, studies them, and varies them (flip / boost / operator swaps / other neutralizations).",
    ph: "own && turnover < 0.7 -> s = generate_stats(alpha); ts_ir(s.returns, 250)" },
  { id: "selection", label: "Selections", hint: "Selection expressions (a filter over alpha attributes) that work for you. Used in round 1 of every SuperAlpha hypothesis and extended by the LLM. One per line.",
    ph: "own && turnover < 0.7 && long_count > 100" },
  { id: "combo", label: "Combos", hint: "Combo expressions (how selected alphas are weighted). Used in round 1 of every SuperAlpha hypothesis and extended by the LLM. One per line.",
    ph: "s = generate_stats(alpha); ts_ir(s.returns, 250)" },
  { id: "opgroup", label: "Sister/brother operators", hint: "Groups of interchangeable operators, comma-separated, one group per line. When an alpha passes everything except PROD correlation (and cross-neutralization didn’t fix it), the Autosentry swaps one operator at a time for a group-mate and re-checks prod. If you add none, built-in groups are used (e.g. ts_rank, ts_zscore, ts_scale).",
    ph: "ts_rank, ts_zscore, ts_scale" },
  { id: "paper", label: "Papers", hint: "Upload a PDF / .txt / .md, or paste text. The text is stored and distilled into tradeable ideas that feed every future run.", ph: "Paste paper text or notes…" },
  { id: "note", label: "Notes", hint: "Free-form guidance (e.g. “avoid analyst fields in ASI”, “I care about low turnover”). Fed to the LLM every run.", ph: "Your note…" },
];

const SECTION: CSSProperties = { fontSize: 11, color: "var(--mut)", textTransform: "uppercase", letterSpacing: ".5px", marginTop: 14 };

// Alphas and boosters can be switched on or off per region. No regions stored on an item = every region (how all older items behave).
const REGION_KINDS: Kind[] = ["alpha", "booster"];
const FALLBACK_REGIONS = ["USA", "EUR", "ASI", "GLB", "CHN", "JPN", "KOR", "IND", "HKG", "TWN", "AMR", "DEU", "GBR"];
const regsOf = (a: any): string[] | null => (Array.isArray(a?.meta?.regions) ? (a.meta.regions as string[]) : null);
const ticked = (a: any, r: string): boolean => { const x = regsOf(a); return x === null ? true : x.includes(r); };

const REGULAR_KINDS: Kind[] = ["alpha", "template", "booster", "opgroup", "paper", "note"];
const SUPER_KINDS: Kind[] = ["superalpha", "selection", "combo", "opgroup", "paper", "note"];

// scope="super": the Supersentry's library (SuperAlphas / selections / combos) and its own lessons memory
export function AutopilotLibrary({ region: baseRegionProp, tab, scope = "regular" }: { region: string; tab: "library" | "learning"; scope?: "regular" | "super" }) {
  const baseRegion = baseRegionProp;
  const region = scope === "super" ? `${baseRegion}:super` : baseRegion;
  const KINDS = ALL_KINDS.filter((k) => (scope === "super" ? SUPER_KINDS : REGULAR_KINDS).includes(k.id))
    .sort((a, b) => (scope === "super" ? SUPER_KINDS : REGULAR_KINDS).indexOf(a.id) - (scope === "super" ? SUPER_KINDS : REGULAR_KINDS).indexOf(b.id));
  const { toast, toastErr } = useToast();
  const R = useResearch();
  const [kind, setKind] = useState<Kind>(scope === "super" ? "superalpha" : "alpha");
  const [addRegions, setAddRegions] = useState<string[] | null>(null);     // null = every region
  const [onlyRegion, setOnlyRegion] = useState(false);
  const [items, setItems] = useState<any[]>([]);
  const [lessons, setLessons] = useState<any[]>([]);
  const [summary, setSummary] = useState<any>({});
  const [body, setBody] = useState("");
  const [name, setName] = useState("");
  const [minSharpe, setMinSharpe] = useState(1.0);
  const [busy, setBusy] = useState(false);
  const [lesson, setLesson] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  async function load() {
    const [a, l] = await Promise.all([api.get<any>(`/autopilot/library?engine=${scope === "super" ? "super" : "auto"}`), api.get<any>(`/autopilot/lessons?region=${region}`)]);
    if (!a.error) { setItems(a.items || []); setSummary(a.summary || {}); }
    if (!l.error) setLessons(l.items || []);
  }
  useEffect(() => { load(); }, [region, tab]);

  const K = KINDS.find((k) => k.id === kind)!;
  const regional = REGION_KINDS.includes(kind);
  const known = useMemo(() => {
    const fromApp = R.regions("EQUITY");
    const used = items.flatMap((i) => regsOf(i) ?? []);
    const base = fromApp.length ? fromApp : FALLBACK_REGIONS;
    return [...new Set([...base, ...used, baseRegion])].filter(Boolean).sort();
  }, [R, items, baseRegion]);
  const list = items.filter((i) => i.kind === kind && (!(regional && onlyRegion) || ticked(i, baseRegion)));

  async function add() {
    if (!body.trim()) return toast("Nothing to add.", "warn");
    setBusy(true);
    const r = await api.post<any>("/autopilot/library", {
      kind, body, name, bulk: ["alpha", "template", "booster", "opgroup", "superalpha", "selection", "combo"].includes(kind),
      meta: {
        engine: scope === "super" ? "super" : "auto",
        ...(kind === "booster" ? { min_sharpe: minSharpe } : {}),
        ...(regional && addRegions && !known.every((k) => addRegions.includes(k)) ? { regions: addRegions } : {}),
      },
    });
    setBusy(false);
    if (r.error) return toastErr(r.error);
    const rej = r.rejected?.length ? ` · rejected ${r.rejected.length}: ${r.rejected[0]}` : "";
    toast(r.added != null ? `Added ${r.added}${r.duplicates ? `, ${r.duplicates} duplicate(s)` : ""}${rej}` : r.duplicate ? "Already in your library." : "Added.", r.rejected?.length ? "warn" : "ok");
    setBody(""); setName(""); load();
  }

  async function pickFile(e: ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0]; e.target.value = "";
    if (!f) return;
    if (kind === "paper") {
      setBusy(true);
      toast("Uploading and distilling the paper…");
      const fd = new FormData(); fd.append("file", f); if (name) fd.append("name", name);
      const r = await api.upload<any>("/autopilot/library/paper", fd);
      setBusy(false);
      if (r.error) return toastErr(r.error);
      toast(r.duplicate ? "That paper is already stored." : r.digest ? "Paper stored and distilled." : "Paper stored (no digest — add an LLM key, then press “Re-digest”).", "ok");
      setName(""); load();
    } else {
      setBody(await f.text());   // .txt/.csv/.json with one expression per line
      toast(`Loaded ${f.name} — review it, then press Add.`);
    }
  }

  // Shared items (older papers / notes / operator groups) are read by both engines; this pins one to this engine only.
  async function pinHere(a: any) {
    const res = await api.patch<any>(`/autopilot/library/${a.id}`, { meta: { ...(a.meta || {}), engine: scope === "super" ? "super" : "auto" } });
    if (res?.error) return toastErr(res.error);
    toast(`Now used by the ${scope === "super" ? "Supersentry" : "Autosentry"} only.`, "ok"); load();
  }
  async function toggle(a: any) { await api.patch(`/autopilot/library/${a.id}`, { enabled: !a.enabled }); load(); }
  async function del(a: any) { if (window.confirm(`Delete “${a.name}”?`)) { await api.delete(`/autopilot/library/${a.id}`); load(); } }
  async function redigest(a: any) {
    toast("Re-reading the paper…");
    const r = await api.post<any>(`/autopilot/library/${a.id}/digest`);
    r.error ? toastErr(r.error) : toast("Digest updated.", "ok"); load();
  }
  async function tick(a: any, r: string) {
    const cur = new Set<string>(regsOf(a) ?? known);
    if (cur.has(r)) cur.delete(r); else cur.add(r);
    const meta: Record<string, any> = { ...(a.meta || {}) };
    if (known.every((k) => cur.has(k))) delete meta.regions; else meta.regions = [...cur].sort();
    const res = await api.patch<any>(`/autopilot/library/${a.id}`, { meta });
    if (res?.error) return toastErr(res.error);
    load();
  }
  async function tickAll(r: string, on: boolean) {
    const res = await api.post<any>("/autopilot/library/regions", { kind, region: r, on, known });
    if (res?.error) return toastErr(res.error);
    toast(`${on ? "Ticked" : "Unticked"} ${r} for ${res.changed ?? 0} ${K.label.toLowerCase()}.`, "ok");
    load();
  }
  function toggleAdd(r: string) {
    const cur = new Set<string>(addRegions ?? known);
    if (cur.has(r)) cur.delete(r); else cur.add(r);
    setAddRegions(known.every((k) => cur.has(k)) ? null : [...cur].sort());
  }
  async function setTrigger(a: any, v: number) { await api.patch(`/autopilot/library/${a.id}`, { meta: { ...(a.meta || {}), min_sharpe: v } }); load(); }

  async function addLesson() {
    if (!lesson.trim()) return;
    const r = await api.post<any>("/autopilot/lessons", { text: lesson, kind: "insight", region, pinned: true });
    if (r.error) return toastErr(r.error);
    setLesson(""); load();
  }
  async function pin(l: any) { await api.post(`/autopilot/lessons/${l.id}/pin?pinned=${!l.pinned}`); load(); }
  async function delLesson(l: any) { await api.delete(`/autopilot/lessons/${l.id}`); load(); }

  if (tab === "learning") {
    const color: Record<string, string> = { success: "var(--ok)", failure: "var(--bad)", booster: "var(--warn)", insight: "var(--mut)" };
    return (
      <div className="panel-scroll">
        <div className="mut" style={{ fontSize: 12 }}>
          Everything the engine learns is stored here and fed back into the next hypothesis and template prompts: what passed, what kept failing and why,
          which boosters helped. Pinned lessons are always included. Winners are also added to your library as new working alphas.
        </div>
        <div className="mut" style={{ fontSize: 11, marginTop: 6 }}>
          {lessons.length} lessons · {summary.autopilot_saved || 0} alphas saved by Autosentry · {summary.assets?.alpha || 0} alphas · {summary.assets?.template || 0} templates · {summary.assets?.paper || 0} papers · {summary.assets?.booster || 0} boosters
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
          <input value={lesson} onChange={(e) => setLesson(e.target.value)} placeholder="Teach it something (pinned automatically)…" style={{ flex: 1 }}
            onKeyDown={(e) => { if (e.key === "Enter") addLesson(); }} />
          <button className="btn sm" onClick={addLesson}>Add lesson</button>
        </div>
        <div style={SECTION}>Lessons</div>
        {!lessons.length ? <div className="empty">Nothing learned yet. Run the Autosentry — lessons appear after the first batch.</div> :
          <table><thead><tr><th></th><th>Lesson</th><th>×</th><th></th></tr></thead>
            <tbody>{lessons.map((l) => (
              <tr key={l.id}>
                <td style={{ color: color[l.kind], fontSize: 11, whiteSpace: "nowrap" }}>{l.kind}</td>
                <td style={{ fontSize: 12 }}>{l.text}</td>
                <td className="mut">{l.weight}</td>
                <td style={{ whiteSpace: "nowrap" }}>
                  <span className="pill" onClick={() => pin(l)} title="Always include">{l.pinned ? "📌" : "pin"}</span>{" "}
                  <span className="pill" onClick={() => delLesson(l)}>✕</span></td>
              </tr>))}</tbody></table>}
      </div>
    );
  }

  return (
    <div className="panel-scroll">
      <div className="dx-filters wrap">{KINDS.map((k) =>
        <span key={k.id} className={"pill" + (kind === k.id ? " on" : "")} onClick={() => setKind(k.id)}>
          {k.label} ({summary.assets?.[k.id] || 0})</span>)}</div>
      <div className="mut" style={{ fontSize: 12, marginTop: 8 }}>{K.hint}</div>

      <div style={{ marginTop: 8 }}>
        {kind === "paper" ? <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Paper title (optional)" style={{ width: "100%", marginBottom: 6 }} /> : null}
        <textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder={K.ph} style={{ width: "100%", minHeight: 90, fontFamily: kind === "paper" || kind === "note" ? undefined : "monospace" }} />
        <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 6, flexWrap: "wrap" }}>
          {kind === "booster" ? <label className="fld" style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
            <span>Apply when Sharpe ≥</span>
            <input type="number" step="0.1" min={0} value={minSharpe} onChange={(e) => setMinSharpe(+e.target.value)} style={{ width: 70 }} /></label> : null}
          <button className="btn sm" onClick={add} disabled={busy}>{busy ? <span className="spin" /> : null} Add{kind === "paper" ? " pasted text" : ""}</button>
          <button className="btn ghost sm" onClick={() => fileRef.current?.click()} disabled={busy}>
            {kind === "paper" ? "Upload PDF / txt" : "Load from file"}</button>
          <input ref={fileRef} type="file" hidden onChange={pickFile}
            accept={kind === "paper" ? ".pdf,.txt,.md" : ".txt,.csv,.json,.md"} />
        </div>
      </div>

      {regional ? (
        <div style={{ marginTop: 8 }}>
          <div className="mut" style={{ fontSize: 11 }}>New {K.label.toLowerCase()} apply to (untick to leave a region out):</div>
          <div className="dx-filters wrap">{known.map((r) => (
            <span key={r} className={"pill" + ((addRegions ?? known).includes(r) ? " on" : "")} onClick={() => toggleAdd(r)}>{r}</span>))}</div>
        </div>) : null}

      <div style={SECTION}>{K.label} in your library</div>
      {regional && items.some((i) => i.kind === kind) ? (
        <div style={{ marginBottom: 6 }}>
          <div className="mut" style={{ fontSize: 11 }}>
            Every {kind} is used in every region unless you untick it. Click a region to tick or untick it for ALL {K.label.toLowerCase()} at once, or use the ticks on each row.
          </div>
          <div className="dx-filters wrap">{known.map((r) => {
            const all = items.filter((i) => i.kind === kind);
            const n = all.filter((i) => ticked(i, r)).length;
            return <span key={r} className={"pill" + (n === all.length ? " on" : "")} style={n > 0 && n < all.length ? { borderStyle: "dashed" } : undefined}
              title={n === all.length ? `Untick ${r} for all` : `Tick ${r} for all`} onClick={() => tickAll(r, n !== all.length)}>{r} {n}/{all.length}</span>;
          })}</div>
          <label style={{ fontSize: 12 }}><input type="checkbox" style={{ width: "auto", marginRight: 4 }} checked={onlyRegion} onChange={(e) => setOnlyRegion(e.target.checked)} />
            Show only those used in {baseRegion}</label>
        </div>) : null}
      {!list.length ? <div className="empty">Nothing here yet.</div> :
        <table><thead><tr><th>On</th><th>{kind === "paper" ? "Paper" : "Expression"}</th>{regional ? <th>Regions</th> : null}<th>Used / won</th><th></th></tr></thead>
          <tbody>{list.map((a) => (
            <tr key={a.id} style={{ opacity: a.enabled ? 1 : 0.5 }}>
              <td><input type="checkbox" checked={a.enabled} onChange={() => toggle(a)} /></td>
              <td>
                {kind === "paper" ? <>
                  <b style={{ fontSize: 12 }}>{a.name}</b> <span className="mut" style={{ fontSize: 11 }}>{Math.round(a.chars / 1000)}k chars</span>
                  <div className="mut" style={{ fontSize: 11, whiteSpace: "pre-wrap", maxHeight: 90, overflow: "auto" }}>{a.digest || "No digest yet."}</div>
                  <span className="pill" onClick={() => redigest(a)}>{a.digest ? "Re-digest" : "Digest now"}</span>
                </> : kind === "note" ? <span style={{ fontSize: 12 }}>{a.body}</span> : <>
                  {a.name && a.name !== a.body.slice(0, 48) ? <div className="mut" style={{ fontSize: 11 }}>{a.name}{a.source === "autopilot" ? " · saved by Autosentry" : ""}</div> : a.source === "autopilot" ? <div className="mut" style={{ fontSize: 11 }}>saved by Autosentry</div> : null}
                  <AlphaCell expr={a.body} max={70} />
                  {kind === "booster" ? <div className="mut" style={{ fontSize: 11, marginTop: 2 }}>apply when Sharpe ≥{" "}
                    <input type="number" step="0.1" min={0} defaultValue={a.meta?.min_sharpe ?? 1} style={{ width: 60 }}
                      onBlur={(e) => setTrigger(a, +e.target.value)} /></div> : null}
                </>}
              </td>
              {regional ? (
                <td style={{ minWidth: 150 }}>
                  <div className="dx-filters wrap">{known.map((r) => (
                    <span key={r} className={"pill" + (ticked(a, r) ? " on" : "")} style={{ fontSize: 10.5, padding: "1px 6px" }} onClick={() => tick(a, r)}>{r}</span>))}</div>
                  <div className="mut" style={{ fontSize: 10.5 }}>{regsOf(a) === null ? "all regions" : regsOf(a)!.length ? `${regsOf(a)!.length} region(s)` : "none (parked)"}{a.meta?.found_in ? ` · found in ${a.meta.found_in}` : ""}</div>
                </td>) : null}
              <td className="mut">{a.uses} / {a.wins}</td>
              <td>{a.engine === "both" ? <span className="pill" title="Read by both the Autosentry and the Supersentry. Click to keep it for this engine only." onClick={() => pinHere(a)}>shared → only here</span> : null} <span className="pill" onClick={() => del(a)}>✕</span></td>
            </tr>))}</tbody></table>}
    </div>
  );
}
