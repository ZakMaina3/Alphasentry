import { useEffect, useMemo, useRef, useState } from "react";
import { api } from "../../lib/api";
import { usePersistentState } from "../../lib/persist";
import { NumberInput } from "../../lib/NumberInput";
import { useToast } from "../../lib/toast";

type Res = Record<string, any>;
export type FwSel = { ids: number[]; cats: string[]; pairs: string[][]; lo: number; hi: number };
const EMPTY: FwSel = { ids: [], cats: [], pairs: [], lo: 0, hi: 0 };
export const useFwSel = (key: string) => usePersistentState<FwSel>(`fw:${key}`, EMPTY);

/** The fields every Start request carries for frameworks. */
export function fwPayload(s: FwSel, withCount = true) {
  return {
    framework_ids: s.ids, fw_categories: s.cats, fw_pairs: s.pairs,
    ...(withCount ? { min_field_alphas: s.lo > 0 ? s.lo : null, max_field_alphas: s.hi > 0 ? s.hi : null } : {}),
  };
}
const pk = (a: string, b: string) => [a, b].sort().join("|");
const BADGE: Record<string, [string, string]> = { tier1: ["strong", "#22c55e"], tier2: ["use with discipline", "#eab308"], free: ["allowed", "#9ca3af"], reject: ["blocked", "#a855f7"] };

/** Frameworks, data categories and combinations (with Fred M's pairing rules), and the alpha-count range, for Autosentry and Supersentry. */
export function FrameworkPanel({ sel, setSel, region, delay, showCount = true, who }: { sel: FwSel; setSel: (f: (p: FwSel) => FwSel) => void; region: string; delay: number; showCount?: boolean; who: string }) {
  const { toast, toastErr } = useToast();
  const [fws, setFws] = useState<Res[]>([]);
  const [rules, setRules] = useState<Res>({ categories: [], pairs: [] });
  const [counts, setCounts] = useState<Res[]>([]);
  const [paste, setPaste] = useState("");
  const [review, setReview] = useState<Res[] | null>(null);
  const [warn, setWarn] = useState<string[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);
  const [setups, setSetups] = useState<Res[]>([]);
  const loadSetups = async () => { const d = await api.get<Res>("/frameworks/setups"); if (!d.error) setSetups(d.items ?? []); };
  useEffect(() => { loadSetups(); }, []);
  async function saveSetup() {
    const name = window.prompt("Name this setup (same name overwrites):"); if (!name) return;
    const d = await api.post<Res>("/frameworks/setups", { name, sel });
    if (d.error) return toastErr(d.error);
    toast(`Saved setup “${name}”.`, "ok"); loadSetups();
  }
  const useSetup = (s: Res) => { setSel(() => ({ ids: (s.ids ?? []).filter((i: number) => fws.some((f) => f.id === i)), cats: s.cats ?? [], pairs: s.pairs ?? [], lo: s.lo ?? 0, hi: s.hi ?? 0 })); toast(`Loaded setup “${s.name}”.`, "ok"); };
  async function delSetup(s: Res) { if (window.confirm(`Delete setup “${s.name}”?`)) { await api.delete(`/frameworks/${s.id}`); loadSetups(); } }
  async function rename(f: Res) {
    const name = window.prompt("Rename framework:", f.name); if (!name || name === f.name) return;
    const r = await api.patch<Res>(`/autopilot/library/${f.id}`, { name }); if (r?.error) return toastErr(r.error); load();
  }
  const load = async () => { const d = await api.get<Res>("/frameworks"); if (!d.error) setFws(d.items ?? []); };
  useEffect(() => { load(); api.get<Res>("/frameworks/rules").then((d) => { if (!d.error) setRules(d); }); }, []);
  // category counts follow the first ticked framework's own market
  const first = fws.find((f) => f.id === sel.ids[0]);
  const regionEff: string = first?.region || region;
  const delayEff: number = first ? Number(first.delay ?? delay) : delay;
  useEffect(() => {
    if (!showCount) return;
    const t = setTimeout(async () => { const d = await api.get<Res>(`/frameworks/categories?region=${regionEff}&delay=${delayEff}&min_alphas=${sel.lo}&max_alphas=${sel.hi}`); if (!d.error) setCounts(d.items ?? []); }, 300);
    return () => clearTimeout(t);
  }, [regionEff, delayEff, sel.lo, sel.hi, showCount]);

  const verdict = useMemo(() => { const m: Record<string, Res> = {}; (rules.pairs ?? []).forEach((p: Res) => { m[pk(p.a, p.b)] = p; }); return m; }, [rules]);
  const count = (k: string) => counts.find((c) => c.key === k);
  const blockedBy = (k: string) => sel.cats.map((c) => verdict[pk(c, k)]).find((v) => v && v.verdict === "reject");
  const chosenPairs = useMemo(() => { const out: Res[] = []; for (let i = 0; i < sel.cats.length; i++) for (let j = i + 1; j < sel.cats.length; j++) { const v = verdict[pk(sel.cats[i], sel.cats[j])]; if (v) out.push(v); } return out; }, [sel.cats, verdict]);
  const label = (k: string) => (rules.categories ?? []).find((c: Res) => c.key === k)?.label ?? k;

  const toggleId = (id: number) => setSel((p) => ({ ...p, ids: p.ids.includes(id) ? p.ids.filter((x) => x !== id) : [...p.ids, id] }));
  const toggleCat = (k: string) => setSel((p) => {
    const on = p.cats.includes(k);
    return { ...p, cats: on ? p.cats.filter((c) => c !== k) : [...p.cats, k], pairs: on ? p.pairs.filter((q) => !q.includes(k)) : p.pairs };
  });
  const togglePair = (a: string, b: string) => setSel((p) => {
    const has = p.pairs.some((q) => pk(q[0], q[1]) === pk(a, b));
    return { ...p, pairs: has ? p.pairs.filter((q) => pk(q[0], q[1]) !== pk(a, b)) : [...p.pairs, [a, b]] };
  });

  async function readText(text: string, source: string) {
    const d = await api.post<Res>("/frameworks/parse", { text, source });
    if (d.error) return toastErr(d.error);
    setReview(d.frameworks ?? []); setWarn(d.warnings ?? []); advise(d.frameworks ?? []);
    if (!(d.frameworks ?? []).length) toast("No frameworks found in that text.", "warn");
  }
  async function readFile(f: File) {
    const fd = new FormData(); fd.append("file", f);
    const d = await api.upload<Res>("/frameworks/upload", fd);
    if (d.error) return toastErr(typeof d.error === "string" ? d.error : JSON.stringify(d.error));
    setReview(d.frameworks ?? []); setWarn(d.warnings ?? []); advise(d.frameworks ?? []);
    if (!(d.frameworks ?? []).length) toast("No frameworks found in that file.", "warn");
  }
  // After reading a framework, the LLM suggests the best category pair for each one (rules decide when no LLM is set up).
  const [adv, setAdv] = useState<Record<number, Res>>({});
  const [advBusy, setAdvBusy] = useState(false);
  async function advise(list: Res[]) {
    setAdv({}); if (!list.length) return;
    setAdvBusy(true);
    const out: Record<number, Res> = {};
    for (let i = 0; i < list.length; i++) {
      const d = await api.post<Res>("/frameworks/suggest", { framework: list[i] });
      if (!d.error) out[i] = d;
    }
    setAdv(out); setAdvBusy(false);
  }
  const [autoApply, setAutoApply] = usePersistentState<boolean>("fw:autoapply", true);
  const edit = (i: number, patch: Res) => setReview((r) => (r ?? []).map((x, j) => (j === i ? { ...x, ...patch } : x)));
  const editSlot = (i: number, si: number, cat: string) => setReview((r) => (r ?? []).map((x, j) => j !== i ? x : { ...x, slots: x.slots.map((s: Res, k: number) => k === si ? { ...s, categories: cat ? [cat] : [] } : s), categories: x.slots.map((s: Res, k: number) => (k === si ? cat : s.categories?.[0])).filter(Boolean) }));
  async function saveReview() {
    const d = await api.post<Res>("/frameworks/save", { frameworks: review });
    if (d.error) return toastErr(d.error);
    toast(`Saved ${d.saved} framework(s).`, "ok");
    // continue from the suggestion: tick the new frameworks and their best pair
    if (autoApply) {
      const best = (Object.values(adv) as Res[]).map((a) => a?.best).filter(Boolean);
      const cats = [...new Set(best.flatMap((b: Res) => b.cats as string[]))];
      const okCats = cats.filter((c, _i, all) => !all.some((o) => o !== c && verdict[pk(o, c)]?.verdict === "reject"));
      setSel((p) => ({ ...p, ids: [...new Set([...p.ids, ...((d.ids ?? []) as number[])])],
        cats: [...new Set([...p.cats, ...okCats])],
        pairs: [...p.pairs, ...best.map((b: Res) => b.cats as string[]).filter((q: string[]) => q.every((c) => okCats.includes(c)) && !p.pairs.some((x) => pk(x[0], x[1]) === pk(q[0], q[1])))] }));
      if (best.length) toast("Ticked the new framework(s) and the suggested pair. Adjust below, then Start.", "ok");
    }
    setReview(null); setAdv({}); setPaste(""); load();
  }
  async function del(id: number) {
    if (!window.confirm("Delete this framework?")) return;
    await api.delete(`/frameworks/${id}`); setSel((p) => ({ ...p, ids: p.ids.filter((x) => x !== id) })); load();
  }

  const summary = sel.ids.length > 1 ? `${who} will cycle through ${sel.ids.length} frameworks, each in its own region.`
    : sel.ids.length === 1 ? `${who} will follow the chosen framework in its own region.` : sel.cats.length ? `${who} will draw only from the chosen categories.` : "Off: nothing chosen, so the normal behaviour applies.";

  return (
    <details style={{ margin: "10px 0", border: "1px solid var(--line, #8884)", borderRadius: 8, padding: "6px 10px" }} open={sel.ids.length > 0 || sel.cats.length > 0}>
      <summary style={{ cursor: "pointer", fontWeight: 600 }}>Frameworks, categories and pairing rules <span className="mut" style={{ fontWeight: 400, fontSize: 12 }}>· {summary}</span></summary>

      <div className="dx-filters wrap" style={{ marginTop: 6 }}>
        <b style={{ fontSize: 12 }}>Saved setups</b>
        {setups.length === 0 ? <span className="mut">None yet. Tick frameworks, categories and pairs below, then save the whole choice to reuse it.</span> : setups.map((s) => (
          <span key={s.id} style={{ display: "inline-flex", gap: 2, marginRight: 6 }}>
            <button className="btn sm" title={`${(s.ids ?? []).length} framework(s), ${(s.cats ?? []).length} categories`} onClick={() => useSetup(s)}>{s.name}</button>
            <button className="btn ghost sm" title="Delete setup" onClick={() => delSetup(s)}>✕</button></span>))}
        <button className="btn ghost sm" disabled={!sel.ids.length && !sel.cats.length} onClick={saveSetup}>Save current choice…</button>
      </div>
      <div className="mut" style={{ fontSize: 12, marginTop: 6 }}>1. Frameworks. Each carries its own region, delay and universe; with several, {who} works through them in turn.</div>
      <div className="dx-filters wrap" style={{ marginTop: 4 }}>
        {fws.length === 0 ? <span className="mut">None saved yet. Upload or paste one below.</span> : fws.map((f) => (
          <span key={f.id} style={{ display: "inline-flex", alignItems: "center", gap: 4, marginRight: 8 }}>
            <label style={{ display: "inline-flex", gap: 4, alignItems: "center" }} title={f.expression}>
              <input type="checkbox" checked={sel.ids.includes(f.id)} onChange={() => toggleId(f.id)} />
              <b>{f.name}</b> <span className="mut">{f.region || "any region"} · {(f.categories ?? []).map(label).join(" + ")}</span></label>
            <button className="btn ghost sm" title="Rename" onClick={() => rename(f)}>✎</button>
            <button className="btn ghost sm" title="Delete" onClick={() => del(f.id)}>✕</button>
          </span>))}
        {fws.length > 1 ? <>
          <button className="btn ghost sm" onClick={() => setSel((p) => ({ ...p, ids: fws.map((f) => f.id) }))}>All</button>
          <button className="btn ghost sm" onClick={() => setSel((p) => ({ ...p, ids: [] }))}>None</button></> : null}
      </div>
      <div className="hx-row" style={{ marginTop: 6 }}>
        <input ref={fileRef} type="file" accept=".txt,.md,.pdf" onChange={(e) => { const f = e.target.files?.[0]; if (f) readFile(f); if (fileRef.current) fileRef.current.value = ""; }} />
        <button className="btn ghost sm" disabled={!paste.trim()} onClick={() => readText(paste, "pasted")}>Read pasted text</button>
      </div>
      <textarea value={paste} onChange={(e) => setPaste(e.target.value)} placeholder="…or paste a framework here (Framework 1: … with Field_X / Field_Y, Field Definitions, Mechanism)" style={{ width: "100%", minHeight: 48, marginTop: 4 }} />
      {review ? (
        <div style={{ border: "1px dashed #8886", borderRadius: 8, padding: 8, marginTop: 6 }}>
          <b>Review before saving</b> <span className="mut">(fix anything the reader got wrong)</span>
          {warn.map((w, i) => <div key={i} className="mut" style={{ color: "#eab308" }}>{w}</div>)}
          {review.map((f, i) => (
            <div key={i} style={{ marginTop: 6, paddingBottom: 6, borderBottom: "1px solid #8883" }}>
              <div className="hx-row">
                <input value={f.name} onChange={(e) => edit(i, { name: e.target.value })} style={{ minWidth: 260 }} />
                <input value={f.region} placeholder="Region" onChange={(e) => edit(i, { region: e.target.value.toUpperCase() })} style={{ width: 70 }} />
                <label className="fld"><span>Delay</span><input type="number" min={0} max={1} value={f.delay} onChange={(e) => edit(i, { delay: Number(e.target.value) })} style={{ width: 50 }} /></label>
                <input value={f.universe} placeholder="Universe (auto)" onChange={(e) => edit(i, { universe: e.target.value.toUpperCase() })} style={{ width: 130 }} />
                <button className="btn ghost sm" onClick={() => setReview((r) => (r ?? []).filter((_, j) => j !== i))}>Drop</button>
              </div>
              <div className="mut" style={{ fontSize: 12 }}><code>{f.expression || "(no expression)"}</code></div>
              {(f.slots ?? []).map((s: Res, si: number) => (
                <div key={si} className="hx-row" style={{ fontSize: 12 }}>
                  <code>{s.name}</code><span className="mut" style={{ flex: 1 }}>{s.definition}</span>
                  <select value={s.categories?.[0] ?? ""} onChange={(e) => editSlot(i, si, e.target.value)}>
                    <option value="">category?</option>{(rules.categories ?? []).map((c: Res) => <option key={c.key} value={c.key}>{c.label}</option>)}</select>
                </div>))}
              {advBusy && !adv[i] ? <div className="mut" style={{ fontSize: 12 }}>The LLM is choosing the best pair…</div> : null}
              {adv[i]?.suggestions?.length ? (
                <div style={{ fontSize: 12, marginTop: 4 }}>
                  <b>Suggested pair:</b> {adv[i].suggestions.map((s: Res, k: number) => (
                    <span key={k} title={s.why} style={{ marginLeft: 8, opacity: k === 0 ? 1 : 0.7 }}>
                      {k === 0 ? "★ " : ""}{s.cats.map(label).join(" + ")} <span className="mut">({s.verdict === "tier1" ? "strong" : s.verdict === "tier2" ? "with discipline" : "allowed"}{s.source === "rules" ? ", by rules" : ""})</span>
                      {k > 0 ? <button className="btn ghost sm" onClick={() => setAdv((p) => ({ ...p, [i]: { ...p[i], best: s } }))}>use</button> : null}
                    </span>))}
                  <div className="mut">{adv[i].best?.why}{adv[i].note ? ` — ${adv[i].note}` : ""}</div>
                </div>) : null}
              {(f.warnings ?? []).map((w: string, k: number) => <div key={k} className="mut" style={{ color: "#a855f7", fontSize: 12 }}>{w}</div>)}
            </div>))}
          <div className="hx-row" style={{ marginTop: 6 }}>
            <button className="btn sm" disabled={!review.length || review.some((f) => !String(f.region || "").trim())} title={review.some((f) => !String(f.region || "").trim()) ? "Type the region each framework runs in (e.g. GBR) before saving." : ""} onClick={saveReview}>Save {review.length} framework(s)</button>
            {review.some((f) => !String(f.region || "").trim()) ? <span style={{ color: "#eab308", fontSize: 12 }}>Type the region for each framework, then Save.</span> : null}
            <label className="fld" title="After saving, tick the framework and its suggested pair so you can press Start straight away."><input type="checkbox" checked={autoApply} onChange={(e) => setAutoApply(e.target.checked)} /><span>Then tick the suggested pair</span></label>
            <button className="btn ghost sm" onClick={() => { setReview(null); setAdv({}); }}>Cancel</button></div>
        </div>) : null}

      <div className="mut" style={{ fontSize: 12, marginTop: 10 }}>2. Data categories. {showCount ? `Datafields come from your Data Catalog for ${regionEff} delay ${delayEff}.` : "Selections are built around alphas that use these categories."} A category that would form a rejected pair with one already ticked is blocked.</div>
      <div className="dx-filters wrap" style={{ marginTop: 4 }}>
        {(rules.categories ?? []).map((c: Res) => {
          const on = sel.cats.includes(c.key); const bad = !on && blockedBy(c.key); const n = count(c.key);
          return <button key={c.key} className={"btn sm" + (on ? "" : " ghost")} disabled={!!bad}
            title={bad ? `Blocked with ${label(bad.a === c.key ? bad.b : bad.a)}: ${bad.reason}` : n ? `${n.fields} datafields in the catalog` : showCount ? "none in the catalog for this market" : ""}
            onClick={() => toggleCat(c.key)}>{c.label}{showCount && n ? ` (${n.in_range}/${n.fields})` : ""}</button>;
        })}
      </div>
      {showCount ? <div className="mut" style={{ fontSize: 11 }}>(fields in your alpha-count range / all fields)</div> : null}

      {chosenPairs.length ? (<>
        <div className="mut" style={{ fontSize: 12, marginTop: 10 }}>3. Combinations. Tick the pairs you want. If you tick none, any pair the rules allow is used.</div>
        {chosenPairs.map((v) => {
          const [bl, col] = BADGE[v.verdict] ?? BADGE.free; const on = sel.pairs.some((q) => pk(q[0], q[1]) === pk(v.a, v.b));
          return (
            <div key={pk(v.a, v.b)} className="hx-row" style={{ fontSize: 12, alignItems: "baseline" }}>
              <input type="checkbox" disabled={v.verdict === "reject"} checked={on} onChange={() => togglePair(v.a, v.b)} />
              <b>{label(v.a)} + {label(v.b)}</b>
              <span style={{ background: col, color: "#fff", borderRadius: 8, padding: "0 6px" }}>{bl}</span>
              <span className="mut">{v.verdict === "reject" ? v.reason : [v.roles ? Object.entries(v.roles).map(([k, r]) => `${label(k)} = ${r}`).join(", ") : "", v.build ? `build: ${v.build}` : "", v.watch ? `watch: ${v.watch}` : ""].filter(Boolean).join(" · ") || v.reason}</span>
            </div>);
        })}</>) : null}

      <div className="hx-row" style={{ marginTop: 10 }}>
        {showCount ? <>
          <label className="fld" title="Only datafields that BRAIN says are used by at least this many alphas. 0 = no minimum."><span>Min alphas per datafield</span>
            <NumberInput min={0} fallback={0} value={sel.lo} onChange={(n) => setSel((p) => ({ ...p, lo: n }))} style={{ width: 90 }} /></label>
          <label className="fld" title="Only datafields used by at most this many alphas (less crowded). 0 = no maximum."><span>Max alphas per datafield</span>
            <NumberInput min={0} fallback={0} value={sel.hi} onChange={(n) => setSel((p) => ({ ...p, hi: n }))} style={{ width: 90 }} /></label></>
          : <span className="mut" style={{ fontSize: 12 }}>The alpha-count range applies to datafields, so it only works in Autosentry (SuperAlphas pick alphas, not datafields).</span>}
      </div>
    </details>
  );
}
