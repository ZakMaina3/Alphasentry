# SentryEngine -> Alpha Sentry port: STATUS (resume from here)

Blueprint: Alpha_Harness_to_ACE_Studio_Blueprint.docx. Rules: additive only (new modules + harness_* tables),
existing Alpha Sentry functions unchanged, new labs have NO submit path, AH data catalog excluded.
AH source: alpha-harness-main.zip (backend/src/alpha_harness). To resume: read this file, continue at "NEXT".
Run `python tests/run_all.py` (works offline, no pytest needed; pytest also works).

## Architecture (current)
- Everything lives in backend/app/harness/ + two modules: app/modules/harness_engine, app/modules/harness_vault
  (both registered in modules/__init__.py ENABLED). Flags (all default OFF, data/harness/flags.json): harness_engine,
  harness_vault, harness_planning, autopilot_via_engine.
- DB: NO SQLAlchemy in the harness. `harness/store.py` is a plain sqlite3 gateway to Alpha Sentry's own DB file (settings.db_path).
  It creates 3 tables (harness_sim_record, harness_alpha_info, harness_alpha_pnl), reads Alpha Sentry's sim_results/datasets/fields,
  and the scorer INSERTs into sim_results (only columns that exist). `check_ace_schema()` logs a warning at startup if
  Alpha Sentry's tables/columns the harness reads are missing. Alpha Sentry's own SQLAlchemy code is untouched.
- ONE payload builder: harness/payload.py (Scope + make_settings/make_payload) used by every lab (NaN handling ON etc).
- ONE alpha query: labs/ace_sources.scoped_alphas() (winners, repair rows, strong rows, vault series all use it).
- Shared API bits: harness/api_common.py (ScopeBase request, need_flag).
- brain_port.py is the only place ace_lib is touched (lazy imports).

## Done
- [x] Removed Kenya geo gate and support/log forwarding (backend, frontend modal+button, support-worker, config, scripts).
- [x] Engine: packer + dedup (ported as-is), shared SlotLease, crash-safe Tracker (fsync journal, orphan adoption),
      BatchEngine (dry-run, scorer side thread). Endpoints /api/harness_engine: status, flags, start, stop, dry_run, enqueue, cancel_task, score.
- [x] Labs (each: free /preview + queue-only /run): Relocate, Repair (reads failed checks from BRAIN GET /alphas/{id}, cached),
      Harden, Harvest/Sweep, Diversify, Pair. Field checks are per region+delay and coverage is per DATASET (Alpha Sentry has no
      per-field coverage / per-universe fields) - weaker than AH's catalog.
- [x] Returns vault + mixing (harness_vault): backfill job, correlation matrix, mix candidates (pairs + greedy 3-4,
      offline self-correlation prediction), combine, mix preview/run (same scope + neutralization enforced).
      Repair uses vault partners for self-correlation fixes when harness_vault is on.
- [x] Scorer (scoring.py): finished engine sims -> BRAIN stats/checks -> Alpha Sentry sim_results (tag "harness", Alpha Sentry gate rules);
      records go done -> scored (dedup treats scored as live).
- [x] Skeleton ledger (plan/skeletons.py), applied to Repair/Harvest/Pair/Diversify only when harness_planning is on.
- [x] Frontend: features/harness/Harness.tsx (+harness.css), route /harness, sidebar entry 'SentryEngine' (meta NAV, Run group). Tabs: Control (flags, engine start/stop/dry-run/score, live counts+log), Labs (6 labs, preview/queue, generic result tables), Mixing (backfill, matrix, find/preview/queue mixes). Type-checked against stub React types only (sandbox has no node_modules). HARNESS_TESTING.md = test script for the user.
- [x] Autosentry routing (flag `autopilot_via_engine`, default OFF): harness/autopilot_route.py. ONLY the batch-execution block of
      simulation/service.run_simulation is swapped (hook = 9 added lines; original ThreadPool path kept verbatim as the fallback and
      used whenever the flag is off or setup fails); autopilot/service._simulate wraps its call in `engine_routing()` (2 added lines,
      thread-local, so Simulation screen / other callers are unaffected). Verified with `diff -w` against the original upload: nothing
      removed or changed in Alpha Sentry's files. Routed batches: take slots from the shared SlotLease (waiting workers register so the
      engine leaves them a slot), are journalled before polling (records task='autopilot', status running -> 'external'; a crash
      is rescued by the engine's orphan adoption and scored into Results), keep fast Stop (abandon at once; slots free when BRAIN
      really finishes), keep BATCH ERROR / error-row collection, Alpha Sentry's own BRAIN tag "ace_tag". Everything after the batch step
      (stats, gating, tagging, credit hooks, sign-reversal / cross-neutralisation retries, Telegram refresh, prod-corr checks) is
      untouched Alpha Sentry code. Supersentry (type SUPER, no multi-sim) is routed on the lease only: see E1 below.
- [x] Learning hooks: scoring.score_pending now calls Alpha Sentry's own `_credit_usage` / `_credit_template_stat` for each NEW lab result
      (same credit run_simulation gives its own results); never double-credits an alpha already in sim_results; a failing hook never
      loses the stored row. Shared row matcher engine/match.py (used by engine + Autosentry route); routed Autosentry records now keep
      their alpha ids (status 'external').
- [x] Yield book (plan/yields.py, GET /api/harness_engine/plan/yields, table in Control tab): per-lab passing/finished, target 0.1%,
      'confident' only at 200+ finished; only finished sims count. Autosentry shows as lab "autopilot".
- [x] Optimizer layer (harness/optimize/): ONE interface (ask / tell(handle, values, constraint=, state=) / replay via tell(None, params=) /
      from_history) with two interchangeable backends, so the Optuna-dependent labs are testable without Optuna:
      builtin.py = pure Python (random, brute, qmc=Halton, nsga2 [constraint-dominance, crowding, SBX, poly mutation], tpe [joint product-kernel
      Parzen + constant liar]; nsga3 and cmaes fall back to nsga2 with a stated note); optuna_backend.py = thin adapter following AH's own
      plumbing, auto-used when Optuna is installed (env ACE_HARNESS_OPTIMIZER=builtin|optuna overrides); space.py = declarative spaces.
      tests/test_optimize.py runs the same contract against every available backend (Optuna is exercised automatically wherever installed).
- [x] Task layer (NEW this session, all unit-tested with a fake engine, 75 tests): harness/templates/{spec,realise}.py (template language: parse with
      plain-language errors, build_space/split_params/realise, power-pool + operator/field limits checked BEFORE queueing, summary),
      harness/optimize/objectives.py (objectives incl. K-Ratio, constraints derived from Alpha Sentry's gate numbers), harness/tasks.py (TaskRunner:
      ask -> enqueue -> harvest -> tell; restart-safe; pause/resume/stop/remove; Pareto/ranking; whole-batch top-ups; pruned points never
      spend budget), tables harness_task/harness_trial, labs/ace_sources.template_fields (datafield filters -> Alpha Sentry fields), engine side-threads
      (scoring + task ticking; both skipped in dry-run), endpoints GET /optimizers, POST /templates/preview, POST/GET /tasks, GET /tasks/{id},
      POST /tasks/{id}/pause|resume|stop, DELETE /tasks/{id}. Endpoints are compile-checked only (fragment A2 closes that in a real env). UI: Tasks tab (fragment A1, done).
      Real bugs the tests caught and that are fixed: delay 0 treated as falsy (wrong gate thresholds), pinned single-match datafield NameError,
      repeated proposals when the budget equals the grid, straight-line K-Ratio blow-up, ObjectiveError leaking from create.
- [x] A1 Tasks tab (Harness.tsx, new tab between Control and Labs): task list (status/progress chips, counts, auto-refresh 4 s), New-task form
      (starter YAML template textarea, sampler select + summary from GET /optimizers, objective checkboxes, budget/batch/cores/seed, region/delay/universe),
      "Preview template" (POST /templates/preview: grid size, per-variable field counts, notes, problems, 3 sample alphas), Create (POST /tasks, lab "search"),
      task detail (progress, counts, notes/error, best trials, Pareto front when 2+ objectives, recent trials, search space) with Pause/Resume/Stop/Remove.
      Warns when the harness_engine flag is off, the engine is stopped, or dry-run is on (dry-run does not advance tasks). Stub-type `tsc` clean; 75 tests green.
      No backend change. Not yet exercised against real FastAPI (A2).
- [~] A2 (partly): sandbox has no FastAPI/pydantic and no network, so the endpoints were still NOT run here. Added `tests/a2_http_check.py`
      (python tests/a2_http_check.py: throwaway data dir, harness router only, FastAPI TestClient, no BRAIN, ~25 checks incl. 404/409/422 and a scheduler pass).
      Also fixed a real race found by reading: TaskRunner.stop/set_status/remove now take the scheduler lock (a tick could re-enqueue for a task being
      stopped), and the lazy engine/runner init is locked. Still to do in the real env: run that script, then ONE tiny real task (budget 10, random, dry-run first).
- [x] A3: HARNESS_TESTING.md step 1 count -> 75 + a2_http_check, new step 11 (Tasks: create/preview, dry-run, small real run, pause/resume/stop/remove, restart mid-run, bad inputs).
- [x] A4 presets: harness/templates/presets.py (reversion, momentum, grouped rank, power-pool 3-field, grid sweep; each with suggested sampler/objectives/budget), GET /templates/presets, preset picker in the Tasks form. tests/test_templates.py parses + realises every preset (power-pool limits, no leftover `$`, brute grid fits its budget). 76 tests. Written from scratch: AH's templates/library.py was not in the uploads. Presets use `category: fundamental`; edit if a market lacks it.
- [x] Cleanup done: catalog_port + db.py removed; payload/query/request/flag duplication merged.

- [x] **Fragment B (all of B1–B5)**, written from scratch (AH's labs/*.py were not in the uploads), all queue-only, no submit path:
      B1 `labs/sweep.py` (grid plan: size, fits-budget, never-tried warning) + `POST /template/preview|run` (lab "template", exhaustive sampler).
      B2 `labs/powerpool.py` + `constraints_from_row(row, power_pool=True)` (Sharpe >= 1.0, pool corr < 0.5; constants in optimize/objectives.py,
      VERIFY against BRAIN's current rules) + `TaskRunner.power_pool_view` + `GET /tasks/{id}/power_pool`; tasks with `constraints.power_pool` are judged this way.
      B3 `labs/exprtree.py` (FASTEXPR tokenizer/parser/printer, round-trips) + `labs/deepen.py` (windows on the ladder, operator families, optional outer
      rank/zscore/scale, optional decay/neutralization; ORIGINAL is always one point; auto-shrinks to the cap) + `templates/realise.render` (an empty `$wrap(...)`
      choice means no wrapper) + `POST /deepen/preview|run`.
      B4a `labs/ga.py` (mutations: window/operator/field/wrap/unwrap/negate; crossover like-for-like; `check()` limits incl. Power Pool; deterministic).
      B4b `harness/evolution.py`: Evolution is a `harness_task` (lab "evolution", sampler "ga"): synchronous generations, mu+lambda survivors by the usual ranking,
      tournament parents, per-generation seeded RNG (restart-safe and reproducible), generation summary in task detail; endpoints `POST /evolution/preview|run`.
      B4c UI: Deepen and Evolution tabs. B5: `templates/advice.py` (+ `POST /templates/recommend`), `saved.py` (+ table harness_saved_search, `/saved` CRUD),
      Tasks tab: lab chooser, sweep box, suggested sampler, saved searches, Power Pool view, Generations table, expression column. Presets now carry a `lab`.
      Tests: tests/test_ga.py, test_labs_b.py, test_endpoints.py (runs the endpoint functions with stand-in FastAPI/pydantic when the real ones are absent),
      a2_http_check.py extended with ~20 route checks for the real env. Stub-type `tsc` clean. Limits: evolution keeps one generation in flight; seeds all use one
      neutralization/decay; field pool = seeds' fields + best 5 per dataset; Deepen does not swap fields (Evolution does).

- [x] **Fragment C (all of C1–C3)**: LLM-dependent, built on Alpha Sentry's OWN llm layer (nothing from AH's llm/ was ported).
      C1 `harness/llm.py`: `LLM.complete / complete_list` over `llm_providers.MultiLLM(default_chain(keymgr.get_preferred()))` (that layer only offers
      `generate_list(prompt)` -> strings, no token counts); JSON extraction tolerant of fences/chatter; typed errors (LLMUnavailable, LLMError, BudgetExceeded);
      provider injected so everything is tested with a fake. C2 `harness/llm_budget.py`: per-day caps on calls / ESTIMATED tokens (chars/4) / optional estimated $,
      config in data/harness/llm_budget.json (0 = no cap, safe defaults 40 calls, 300k tokens), ledger table `harness_llm_usage` (failures recorded too),
      check happens BEFORE the call. New flag `harness_llm` (default OFF) gates anything that calls an LLM.
      C3a `labs/invent.py` (pure): prompt (fields in a delimited <data> block, winners as style examples, Power Pool rule), parse (JSON/YAML/fences), and
      `validate`: real fields only, operators in the market's list (including operators smuggled in via a choice variable), filter variables must match,
      Power Pool limits forced on and satisfiable, max_simulations clamped, dedup within a batch, expansion sanity check. C3b endpoints: GET /llm/status,
      POST /llm/budget, GET /llm/usage, POST /invent/propose (flag-gated, 429 over cap / 409 no provider / 502 model error), POST /invent/run (re-validates,
      creates a task with lab "invent"); UI: Invent tab (usage + caps, propose, editable cards, rejected list), flag toggle in Control.
      Bug found by the tests and fixed in the shared parser: a template whose `vars` is not a mapping crashed `templates.spec.parse`.
      Tests: test_llm.py, test_invent.py, endpoint test extended, a2_http_check extended (never calls an LLM).
      Limits: spend numbers are estimates; Invent proposes TEMPLATES only (no free-form alphas); no automatic repair round for rejected proposals;
      Alpha Sentry has no per-field coverage, so field choice leans on dataset coverage.

- [x] **Fragment D1 + D2 (planning core; D3-D5 NOT started, by request)**, written from scratch (AH's plan/*.py were not in the uploads):
      D1 `plan/day.py`: `make_plan` shares today's remaining budget between labs by yield. Yield is smoothed toward the 0.1% target
      (`(passing + 200*target)/(finished + 200)`), so a lab with little history is not judged on a handful of results; 30% (setting) of the budget is
      an exploration pool shared by every lab (double weight for labs under 200 finished) so no lab is starved; per-lab capacity is a hard ceiling
      and spill goes to the others; allocations under `min_chunk` are folded into the rest. `spent_today` = today's non-dry-run records + the
      not-yet-queued part of every running/paused task's budget (UTC day, same as the LLM caps). `PlanSettings` (data/harness/plan.json, validated):
      daily_budget 300, explore_fraction 0.3, min_chunk 10, labs (repair, harden, relocate, harvest, diversify, pair, evolution, deepen).
      D2 `plan/dispatch.py`: `dispatch(cfg, book, spent, runners)` calls one caller-supplied runner per funded lab as `runner(target, extra)`;
      a lab that returns fewer NEW items than asked (or errors, or has no runner) is marked exhausted and its shortfall is re-planned over the
      others (max 3 rounds); one lab failing never costs the rest. `record_run`/`history` write table `harness_plan_run`. Queue-only: runners are
      meant to be the labs' own /run functions, so nothing simulates or submits.
      NOT done yet: the HTTP endpoints, the runners that wrap the lab /run functions, and any UI (that is D5), plus D3 advisor and D4 PM summary.
      8 new tests in tests/test_plan.py (123 total).

- [x] **D3** `plan/advisor.py`: `advise(snapshot)` -> prioritised plain-language next steps (engine off / dry-run on / stopped engine with work queued, unscored
      results, errored tasks, unused daily budget, no results yet -> Harvest, near-misses -> Repair, strong alphas -> Harden/Deepen, 3+ passing -> Evolution / mixing,
      passing-but-unsubmitted -> review, best lab by yield, labs with 400+ finished and 0 passing, saturated shapes); each item has id, priority, title, why, tab.
      `narrate(items, complete)` optionally rewrites the top items as a paragraph with YOUR LLM and falls back to the rule text on any failure; it never suggests
      submitting. Pure module: the snapshot gatherer + `/plan/advice` endpoint + UI belong to D5. 2 tests (125 total).

- [x] **D4** `plan/pm.py` (pure; ported from AH `plan/pm.py`, which was available in this session): the PM. `allocate(cfg, book, spent, summary=, blockers=, capacity=, complete=)`
      builds `brief` (every desk: ready/blockedBy/record + the fund overall), shows an LLM the desks it may fund + the ORDINARY PLAN (D1's `make_plan`), and asks it to CHOOSE DESKS
      and say why. The model never supplies numbers: chosen desks are validated (real, ready, distinct, at most 4; invented/closed/repeated ones are reported in `rejected`),
      then the day's simulations are divided by `make_plan` restricted to those desks (yield-weighted, exploration share, capacity limits, minimum run size; a chosen desk
      that ends up too small is reported in `dropped`). Result keeps both reasons (`pmWhy` the model's, `numbersWhy` the arithmetic's) and a `changes` diff against the
      ordinary plan. The floor is the ordinary plan with a rule-written briefing: no model / provider or budget error / non-JSON / wrong shape / nothing usable all return it with
      `error` set; the model is NOT called when there is nothing to decide (no ready desk, or today's budget used). Briefing sentences about submitting are removed (nothing here
      submits). Differences from AH on purpose: AH split CORES evenly; here the scarce resource is the day's simulation budget and the split is by yield. Prompt contains only fixed
      lab ids/descriptions and computed numbers (no user text). 11 tests in tests/test_pm.py (136 total). NOT done (D5): data readers for `blockers`/`capacity`/`summary`, the
      `/plan/pm` endpoint, the `harness_llm` gate + model adapter wiring, UI.

- [x] **D5 (planning endpoints + readers + runners + Planning tab)**: `plan/readers.py` (cheap SQL only, no BRAIN): `results_counts`, `readiness` (blockers per lab with
      plain reasons; probes for fresh datasets / un-deepened alphas that can never close a lab by failing), `deepened_expressions`, `trend` (per-UTC-day finished / passing,
      all labs and per lab, gap-free, alphas counted once a day), `snapshot` (advisor input). Endpoints in modules/harness_engine: GET/POST `/plan/settings`,
      POST `/plan/overview` (everything the tab shows, reads only), GET `/plan/trend`, GET `/plan/history`, POST `/plan/advice` (optional LLM narration),
      POST `/plan/pm` (D4 `allocate`; LLM only if flag `harness_llm`; proposes, queues nothing), POST `/plan/run` (flags `harness_engine` AND `harness_planning`; closed labs are
      left out; `labs` restricts to e.g. the PM's choice; records `harness_plan_run`). Runners (`_plan_runners`): repair/harden/relocate/harvest/diversify/pair call the lab's OWN
      `*_run` with `target`; evolution creates an Evolution task with budget `extra`; deepen picks the strongest alpha without a deepen task. UI: Planning tab (budget + settings,
      advice with jump buttons, today's plan, closed labs, PM briefing, queue with confirm + per-lab result table, yield table + 14-day chart, ledger view, run history);
      `harness_planning` is now labelled "Planning (daily plan + skeleton ledger)". Tests: test_plan_d5.py (5), endpoint test for the whole planning flow (stand-in FastAPI),
      a2_http_check +9 route checks. Stub-type tsc clean. Limits: near-miss count is a proxy; no capacity numbers are read up front (a lab that has fewer candidates than its share
      reports it when it runs and the shortfall is re-planned); `/plan/run` is synchronous (Repair may take seconds); one market per plan run; PM/advice narration cost 1 LLM call each.

- [x] **E1 Supersentry on the shared slot lease (lease only)**: `harness/super_route.py` `routed(sim_one, abandon)` returns the original `_sim_one` unless
      `engine_routing()` is active on the calling thread (flag `autopilot_via_engine`); otherwise each SuperAlpha simulation holds ONE shared slot (owner `superpilot`),
      tells the engine a worker is waiting, releases in `finally`, and gives up at once on Fast Stop. No batching, no journal (SUPER cannot be multi-simulated; a crash mid-sim is
      not re-attached). Alpha Sentry files touched (2 small hooks): `super/service.py` (+~9 lines in `run_simulation`: abandon event, `routed`, `abandon.set()` before `pool.terminate()`) and
      `superpilot/service.py` (`_simulate` wraps `SU.run_simulation` in `engine_routing()`). The manual SuperAlpha screen (`modules/super`) is NOT routed (tested).
- [x] **E2 winner tag/colour for lab results**: `harness/winner.py` (settings in data/harness/winner.json; blank tag = off, default; tag charset/length and colour validated),
      `scoring.score_pending(winner=, tagger=)`: a PASSING alpha with |Fitness| >= threshold is labelled in BRAIN (`brain_port.tag_alpha`) and the stored row's `tagged` is the winner tag;
      anything else, or a BRAIN refusal, keeps `harness`. Endpoints GET/POST `/winner`; UI panel at the bottom of Control. Existing results are not re-tagged. Autosentry-routed results are
      still scored by Autosentry's own pipeline with ITS tags. Tests: tests/test_e.py (10) + endpoint test; a2_http_check +3.

- [~] **E4 real `npm run build`: NOT possible in the sandbox (no network; no vite / @types/react / react-router-dom installed). Done instead, offline**:
      (1) esbuild (Vite's transformer) bundled the WHOLE app (48 files, main.tsx): no syntax errors, every relative import and CSS/asset resolves;
      (2) `tsc` with the project's REAL tsconfig (strict, noUnusedLocals ...) and the REAL src/lib files, stubbing only external packages: **Harness.tsx = 0 errors**;
      found and FIXED one genuine build-breaker: `app/layout/Header.tsx` left `useEffect` and `api` imported but unused after the support/update removal (TS6133 would fail
      `tsc -b`). Remaining stub-only noise is in files this port did not touch. Script: tests/frontend_offline/check.sh. Still required in a real env: `npm ci && npm run build` (HARNESS_TESTING step 17).

## Tests: 190 pass, 1 skipped here (needs SQLAlchemy), 0 skipped (python tests/run_all.py)
Pure logic (packer, dedup, lease, all labs, mixing, ledger, scoring gate) AND the sqlite3 layer against a throwaway DB
shaped like Alpha Sentry's tables (tests/ace_db.py mirrors Alpha Sentry's DDL by hand): tracker dedup/journal/orphans, engine run + dry-run +
orphan adoption, schema check, every ace_sources query, repair rows, scorer (incl. older Alpha Sentry layout), vault end-to-end.
NOT verified (need real deps/network): FastAPI/pydantic module endpoints (compile only), real ace_lib/BRAIN calls,
the header change in the frontend build, anything against a real Alpha Sentry database file.

- [x] **E5 samplers + frontend polish**: `optimize/sobol.py` (Joe-Kuo direction numbers for 14 dimensions + random digital shift; test proves each polynomial is primitive, m-values valid, every
      dimension stratified, textbook first points; extra dimensions fall back to random with a stated note), `optimize/niching.py` (Das-Dennis reference points, normalisation, niche ordering) used by the
      built-in `nsga3`, `optimize/cma.py` (separable CMA-ES; state recomputed from finished trials in trial order, so it is restart-safe and identical after replay; categoricals keep the best trial's value 70%).
      The fallback "nsga3/cmaes -> nsga2" and the Halton qmc are gone; `templates/advice.py` no longer gates nsga3/cmaes on Optuna (tests updated accordingly). The optimizer still draws
      the old per-dimension rng values so seeded runs of random/nsga2/tpe reproduce exactly as before. 157 tests. The skeleton-ledger view already existed in Planning (D5); added a filter box +
      "answered only" tick there, and a **Guide** tab (one entry per lab: what / when / needs / result, with jump buttons). Offline esbuild + tsc check clean.
- [x] **G1 Autosentry speed** (`harness/speed.py`, hooks in `autopilot_route.py` and one flag-gated line in `autopilot/service.py`; only with `autopilot_via_engine` on). Measured from the user's own database
      (ace_studio_v2.db, 20 Autosentry batches): batches ran 3 at a time (Alpha Sentry caps `parallel` at 3 although BRAIN has 8 slots), a batch of 10 took 20 s to 15 min regardless of its size (once 94 min), each
      round waited for its slowest batch, and fetching stats took only ~3-12 s per round (so it was NOT worth overlapping). Changes: (1) a round runs `parallel` batches side by side, default 6, max 8, set in Control
      (`data/harness/speed.json`); an Autosentry concurrency below 3 is respected as a deliberate gentle setting; (2) the ceiling is learned: BRAIN's 429 while we hold k slots lowers it to k-1 (never below 2)
      for 20 min, then BRAIN is probed again; (3) slow-batch release: once at least one batch of the round is done and every remaining batch has run longer than the limit (default 25 min, 0 = never)
      the round continues without them. They keep their slot until BRAIN finishes, and are then marked `done` so the harness scorer puts them in Results (not `external`). Never released when no batch has
      finished (an outage is not a slow batch). Alpha Sentry's original path is untouched with the flag off. 8 tests in tests/test_speed.py. Trade-off: bigger rounds mean the AI reads results less often.
- [x] **G2 Shipped data** (`harness/seed.py`, `tools/make_seed.py`, `seed/ace_studio_v2.seed.db`, startup hook in `main.py`, flag `harness_seed` = ON by default, the one flag that is, because it was asked for). The
      user's ace_studio_v2.db is shipped in every version as a compact KNOWLEDGE-ONLY seed (datasets, fields, operator_ref, autopilot_lessons/assets, sim_results, vault_alphas, template_stats, usage,
      hypothesis_log, harness_alpha_info; never simulation records, tasks, flags or keys; scanned: no secrets or e-mail addresses). It is merged INSERT-ONLY (a row is added only when its natural key is absent;
      existing rows, including user-edited operator rows, are never changed; ids are the live database's own; vault links re-pointed to live sim_results ids), ONCE per seed file (SHA-256 in `harness_seed_log`,
      so deleted rows stay deleted), after a one-time backup in `data/backups/`. The seed deliberately is NOT a copy of the live .db: unzipping a version over an install must never overwrite its data.
      Autosentry skips expressions already in sim_results, so merged history also saves repeat simulations. Rehearsed on a copy of the real file: removed 100 fields, 50 results and 10 lessons, merge restored
      exactly those, integrity check ok, simulation records untouched. 8 tests in tests/test_seed.py. To refresh: `python tools/make_seed.py [path/to/ace_studio_v2.db]` before zipping a version.
      Packaging: `package.py` copies `seed/` into every signed release (so it is in the manifest and replaced by updates) and `build_pyinstaller.py` adds it as data; both edits are untested here (they need npm / signing keys). Endpoints: GET/POST /speed, GET /seed, POST /seed/merge {dry_run, force}. UI: Control tab panels *Autosentry speed* and *Shipped data*, Guide entries. 172 tests.
- [x] **H1 Library: regions for alphas and boosters** (Autosentry > Library). Each alpha and booster has a row of region ticks; a bar above the list ticks/unticks a region for ALL items of the kind
      (shows n/total, dashed = some); "Show only those used in <region>"; new items can be added for chosen regions only. Stored in the item's existing `meta.regions` (no schema change): no key = every region
      (all older items behave as before), a list = only those, an empty list = parked everywhere; "all ticked" is stored as no key so regions BRAIN adds later still count. Enforced where Autosentry reads the
      library: `build_context` (prompt examples and the round-1 seed alphas) and `active_boosters(region)` (called with cfg region from `_boost`); Supersentry's ":super" suffix is ignored. Alphas saved by
      Autosentry get `meta.found_in` (information only; they are NOT restricted). New: `autopilot/regions.py` (pure), `POST /api/autopilot/library/regions`, `library.toggle_region`, 6 tests in
      tests/test_library_regions.py; the database-backed test (boosters/context filtered by region, bulk toggle) needs SQLAlchemy, so it was SKIPPED in the build sandbox and runs in your environment.
- [x] **I1 One-click Alpha Translation** (`pyalpha/guidelines.py`, `pyalpha/service.py`, `PyAlpha.tsx`). Your translation guidelines are built in, so "Translate to Python" works at once (no placeholders to fill; a saved custom guideline still overrides them, and "Restore built-in" removes the override). Each translation also gets deterministic facts computed from the expression itself (fields by type MATRIX / VECTOR / group, operators outside the mapping table, cold-start days = sum of ts_ windows) and the model must answer with the code plus a short checklist; both the checks and the checklist show under the code. Tests: tests/test_pyalpha_guidelines.py (5).
- [x] **I2 Rebrand: Alpha Sentry** (ACE Studio -> **Alpha Sentry**, Autopilot -> **Autosentry**, Super Autopilot -> **Supersentry**, Alpha Harness / Harness Labs -> **SentryEngine**). Every user-visible name, title, launcher, shortcut, message, doc and window title changed; new logo family (shield + rising signal, loop, double chevron, hexagon engine) drawn by `tools/make_logos.py` into `frontend/public/*.svg|png` and `build/alpha-sentry.ico`, used in the sidebar, favicon, nav icons and screen headers. Launchers: `Alpha Sentry.vbs`, `Stop Alpha Sentry.vbs`. Deliberately NOT renamed (renaming would break your data, links or flags): the database file `ace_studio_v2.db`, `seed/ace_studio_v2.seed.db`, API paths (`/api/autopilot`, `/api/harness`...), route `/super-autopilot`, feature-flag names (`harness_*`, `autopilot_via_engine`), the BRAIN tag `harness`, the update repo URL and `ace-studio-updater` user-agent, the signing key folder `~/.ace_studio_keys`. After unzipping over an old copy, delete the old `ACE Studio.vbs` / `Stop ACE Studio.vbs` and run `Install Desktop Icon.bat` again for the new shortcuts and icon.
- [x] **J1 Telegram remote controls SentryEngine** (`notify/engine_remote.py`, hooks in `notify/remote.py`). New commands: `/engine` (status: switch, running, slots, queue, running tasks), `/engine on|off` (the "SentryEngine + labs" switch), `/engine start|stop`, `/engine score`, `/tasks`, `/task pause|resume|stop <id>`; `/menu` gets "SentryEngine" and "Engine tasks" buttons; `/status` gains a SentryEngine line; `/help` lists them. Same chat-id check as before; start needs the switch ON; there is no submit command. 5 tests in tests/test_engine_remote.py (a fake API; the real wiring through `remote.py` needs your environment, so try `/engine` once in Telegram).
- [x] **L1 Final fixes after your test of I4** (this build = checkpoint_I4 + the three changes below; the sealed-release experiment (K1) was NOT carried over). (1) Translator guidelines now include your pasted BRAIN article EXACTLY as given (`pyalpha/guideline_article.py`, compared byte for byte with `tests/data/translation_article.txt` by a test), appended to the built-in guideline under "Reference article". (2) SentryEngine is in the Telegram remote (J1 re-applied). (3) The shipped seed no longer contains any Library data: the `autopilot_assets` (alphas, boosters) and `autopilot_lessons` tables are removed from `seed/ace_studio_v2.seed.db` and from `harness/seed.py` TABLES, so a new user starts with an empty Library and lessons; the seed still carries the dataset/field catalogue, operator reference, past results, vault alphas and usage statistics. Rows an earlier build already merged into someone's own database stay there (delete them in Library if wanted).
- [x] **L2 Nothing of the author's own work ships** (follow-up to L1 item 3). The shipped seed (`seed/ace_studio_v2.seed.db`, now 2.2 MB) holds ONLY the public catalogue: `datasets`, `fields`, `operator_ref` (`seed.SHIPPED`). Removed from it: past simulation results (1,968), vault alphas (25), usage statistics, alpha info, template stats, hypothesis log, plus the Library tables removed in L1. `tools/make_seed.py` now writes the catalogue only (`--with-history` is for private use). The merge code still supports history tables; tests/test_seed.py now builds a seed with INVENTED history rows (`tests/data/history_schema.sql`) so that path stays tested. 190 tests pass. IMPORTANT: this only changes what NEW installs receive. A database that already merged an earlier seed keeps those rows; to empty one, stop the app and delete or rename `data/ace_studio_v2.db` (it is recreated empty, then fills with the catalogue from BRAIN), or delete the rows in the app.

## NEXT  — the remaining work is FRAGMENTED in FRAGMENTS.md (pick one fragment id per session; full handoff + prompt: HANDOFF.md)
- [ ] First thing in the real environment: run the tests, start the app, confirm startup logs no "harness:" schema warnings.
- [x] Search / Template / Evolution / Power Pool / Deepen labs (fragment B). Optuna remains optional.
- [x] Planning layer D1–D5 complete.
- [x] Frontend polish (ledger filter, Guide tab). Real build (`npm run build`) still to be run in your environment.
- [ ] Autosentry routing is built but P2: editable suggested points + "Implement on BRAIN" (`osmosis/apply.py`, service.implement/undo; PATCHes `osmosisPoints` only, validates every scope is exactly 100,000 over 10+ alphas and 3+ scopes, canary write read back before the rest, journal + undo, post-write verification; 227 tests pass). Standing rule updated: the app still never SUBMITS alphas; it may write Osmosis points when the user presses Implement. UNTESTED against real BRAIN: test with a tiny Autosentry run (see HARNESS_TESTING.md step 9).
- [x] Supersentry routed onto the shared lease only (E1).
- [ ] (done) learning hooks. Still skipped: Alpha Sentry's user-chosen winner tag/colour (it is per-run config, not available to the scorer).

- [x] M1: Autosentry follow-ups (reverse only Sharpe < -1, boost all > 1, ride in the next batch of 10; `autopilot/followups.py`, `tests/test_followups.py`). Windows install fix: long-path relocation, `logs/pip.log`, `logs/setup_error.txt`. 198 tests pass. UNTESTED on Windows/real BRAIN.

- [x] N1: Autosentry hypothesis step tolerant + diagnostic; repeated ideas are now allowed as an IMPROVEMENT pass (new operator mix, extra unused fields, prior result in the brief). UNTESTED against a live LLM.

- [x] P1: Osmosis Planner. `osmosis/{planner,extract,service}.py`, module `/api/osmosis`, screen `Osmosis.tsx`, `tests/test_osmosis.py` (218 tests pass). Reads submitted alphas (GET only), >=10 qualifying alphas per scope, exactly 100,000 points, caps, gradual moves. UNTESTED against real BRAIN: field names for investability-constrained Sharpe and current Osmosis points are guesses (both optional).

- [x] R1: Autosentry boosting rebuild: `autopilot/boosting.py` (built-in starters when the library has none, one Sharpe threshold, ranked booster choice with exploration and retirement, window nudges, queue trim, adaptive new-idea reserve, triage of weak ideas after 1 batch, run summary), follow-ups extended, hypotheses per call 8, max rounds 4, Telegram alert after 3 failed cycles, Osmosis gap hint in the idea prompt. 241 tests pass. UNTESTED against real BRAIN / the SQLAlchemy service flow (pure logic is tested).

- [x] S1: Data Catalog (`catalog/{pure,service}.py`, `/api/catalog`, `Catalog.tsx`): one-time, resumable download of datasets+datafields by region/delay/category into the shared `datasets`/`fields` tables (read by Autosentry and the SentryEngine labs), browse, CSV/Excel export (stdlib xlsx writer). Clone and swap (`autopilot/clone.py`, `_clone_run`, method switch in Autopilot.tsx): old alphas from submitted + vault, similar datafields (TF-IDF over id+description, same type, similarity slider), batches of 10, follow-ups, full check, lineage in the vault note. 258 tests pass (pure logic, pull loop with fakes, export round-trip). UNTESTED here: the SQLAlchemy parts of catalog/service.py and `_clone_run` against a real database/BRAIN.

## Notes
- AH uses Python 3.14 syntax (`except A, B:`) -> rewrite as `except (A, B):` when porting more.
- Build sandbox is Python 3.12 with no SQLAlchemy/FastAPI/pydantic/optuna and no network.
- [x] M1: Clone and swap, "My own working alphas": paste box in the Clone panel (`clone.parse_pasted` / `describe_pasted`, `clone_pasted` setting, `POST /api/autopilot/clone/preview`, live "N of M can be swapped" line). Pasted alphas are cloned first, ignore the Sharpe / region / id filters and the source cap, and can be the only source. 4 new tests (262 pass). UNTESTED here: `_clone_sources` against the real database and the live UI (type-checked with stubs only).
- [x] T1: Region switching in SentryEngine. Causes found: global queue (old region kept running, tasks kept refilling it), no timeout on BRAIN polling (a never-finishing batch held a slot for ever), per-keystroke heavy unindexed reads while typing a region, stale responses overwriting newer ones. Fixes: engine focus (`engine/focus.py`, parks other markets), `Tracker.region_counts/drop_queued/reap_stale`, `TaskRunner.pause_other_markets`, endpoints `GET /queue`, `POST /queue/drop`, `GET|POST /focus`, `max_wait` (90 min) in `ace_lib.simulation_progress/multisimulation_progress` via `brain_port.MAX_WAIT`, read indexes on sim_results/fields/datasets, latest-response-wins in Planning. UI: "Queue by region" panel in Control.
- [x] T2: Region / Delay / Universe dropdowns (`features/common/ScopePicker.tsx`, `GET /api/catalog/local_scopes` from stored data merged with BRAIN options) in Autosentry, Supersentry and all SentryEngine screens.
- [x] T3: Clone and swap "Nothing to swap": `plan_swaps(stats=)` + `why_empty` give the exact reason, one automatic widening retry (3x swaps per alpha, no similarity floor), case-insensitive field matching. 14 new tests (276 pass). UNTESTED here: live BRAIN behaviour, the UI against a real database.
- [x] U1: Autosentry pace: default one batch of 10 per round (concurrency 1) and a 60 s wait before each prod-correlation check, one at a time (`autopilot/pacing.py`, `prod_check_delay`, UI "Prod check delay (s)"; also used by the prod rescue re-checks). 4 new tests. UNTESTED here: `_checks_parallel` against live BRAIN.
- [x] V1: SentryEngine Drop now works on running simulations too. Cause: Drop only removed queued rows; the rest were already 'running' (sent or retrying after BRAIN's 'busy'), and a busy retry re-queued them, so they reappeared. Now: `drop_queued(include_running=)` marks them cancelled (final: `requeue/mark/complete/fail` never overwrite 'cancelled'), engine pollers stop waiting via `cancel` hook in `ace_lib` and free the slot, a batch dropped before sending never starts, Autosentry's rows are excluded. UI: Drop / Drop everything. 4 new tests (284 pass). UNTESTED here: against live BRAIN.
- [x] W1: Reset engine button (Control): `POST /api/harness_engine/reset` = stop loop, `Tracker.reset_all` (cancel queued + engine-owned running, prune trials, close engine journal entries; Autosentry rows and results untouched), `TaskRunner.stop_all`, `BatchEngine.reset` (epoch: old threads no longer release slots), clear focus + learned ceiling, discard and rebuild the engine. 3 new tests (287 pass). The endpoint itself is UNTESTED here (no FastAPI in the sandbox); compiled and type-checked only.
- [x] X1: Engine follows the region chosen in Autosentry (default ON, switch in Control → Queue by region). `Focus.follow()/set_follow()`, `POST /harness_engine/focus/follow` (called by `EngineFollow` on every region change and at start-up), `BatchEngine.tick` drops other regions' queued sims instead of parking them (`Tracker.cancel_queued`), `on_foreign` pauses their tasks. Region only: both delays of it are kept; running batches finish. 5 new tests (291 pass). The new endpoints are UNTESTED here (no FastAPI); compiled and type-checked only.
- [x] Y1: Autosentry winners always saved + notified. Bugs: Telegram alert was gated by `notify_winners` (default OFF), sent silent, and `.2f` on a None Sharpe raised and was swallowed; vault save was skipped when the result row was missing; failures were silent. Now `_bank_winner` records the winner first, runs tag / vault (fallback `add_manual`) / library / notify as independent logged steps; notification is always sent when token+chat are saved (`winners.winner_text`). Prod rescue skipped above `prod_rescue_max` (0.74, `winners.worth_rescuing`). 2 new tests. `_bank_winner` itself is UNTESTED here (needs SQLAlchemy/BRAIN).
- [x] Z1: Clone and swap ignores Python alphas (`clone.is_python_alpha`, `language` from `osmosis.extract.normalise`). SentryEngine: Slots panel (`GET /slots`, `POST /slots/abandon`, `Tracker.running_batches/abandon_batch`), Results tab with Missing results (`harness/diagnose.py`, `GET /missing`, `POST /missing/fix`, per-simulation BRAIN rejection via `match.match_errors`, scoring errors stored on the record) and Alpha stats (`harness/alphas.py`, `GET /alphas`, one-by-one prod checks `POST /alphas/check` with delay + Stop, red rows for alphas missing from Results). UI `features/harness/ResultsView.tsx`. 12 new tests (302 pass). UNTESTED here: all endpoints (no FastAPI), live BRAIN `check_submission`, the UI against a real database (type-checked with stubs only).
- [x] Z2: Session expiry: Autosentry pauses and sends ONE biometrics link, no reminders, and resumes only after you verify. Cause of 'stuck after verifying': every reminder called `begin_login` again, which replaced the pending login, so the link you had verified was no longer the one being confirmed. A fresh link is sent only if the pending login is lost. UNTESTED here (needs live BRAIN + Telegram); compiled only.
- [x] Z3: Session end = full stop + automatic restart: `_ensure_session`/heads-up watchdog call `_session_halt` (abandons the run via `_abandon_everything`, `jobs.force_end` for a stuck thread, cancels Autosentry's running engine records, frees its slots), one link, `_resume_after_login` restarts with the saved start settings after verification (Stop cancels the restart). Stall watchdog: `stall_minutes` (default 30, UI "Stop if stuck for (min)"), `_BEAT` updated by every event/phase change/deliberate wait, `supervisor.stalled/stall_message`, Telegram details, no auto-restart. 3 new tests (305 pass). UNTESTED here (needs live BRAIN + Telegram + SQLAlchemy): `_session_halt`, `_resume_after_login`, `_stall_halt`; a thread stuck inside a BRAIN call is left to end on its own (the job is marked finished and told to cancel).
- [x] Z4: Autosentry and Supersentry use the Operator Atlas: `operators/listing.atlas_listing` (pure) + `operators.service.atlas_block`; Autosentry's template prompt gets all REGULAR atlas operators (setting `use_atlas`, default on), Supersentry's selection prompt gets the SELECTION atlas (combo already did). 2 new tests (307 pass). UNTESTED here: against a seeded atlas / live LLM.
- [x] Z5: Osmosis allocator: best N (default 10) per scope in `planner.select` (`top_n`), uncompensated rule (`consultant_start`, USA alphas with `date_submitted` before it get verdict drop; points they hold are released in one step, not gradually; `is_uncompensated`), UI fields in Osmosis.tsx. 3 new tests (310 pass). The consultant start date is not known to the app: you must set it. UNTESTED here: against a real BRAIN snapshot (relies on `dateSubmitted` being in the stored alphas).
- [x] Z6: More LLM providers: `vendor/provider_presets.py` (25 ready-made OpenAI-compatible entries incl. free tiers, 9Router and local servers, per-provider base-URL override), custom providers (`keys.custom_*`, `llm_providers.custom_provider`), Settings endpoints `GET /provider_catalog`, `POST /providers/{p}/base_url`, `POST /custom`, `POST /custom/{name}/delete`, UI in Settings.tsx. 6 new tests (316 pass). Base URLs, default models and free-tier notes are from memory and UNVERIFIED against each vendor; endpoints UNTESTED here (no FastAPI) and no provider was called live.
- [x] Z7: SentryEngine results: stats are pulled the moment a batch finishes (`_Side.kick` after `_apply`), everything except prod (`brain_port.alpha_stats` default: stats + BRAIN IS tests + self corr, `check_submission` table built for scoring). FOUND AND FIXED: scoring read a `check_submission` key the vendor never returned, so prod/self correlation were never stored for engine alphas. Gate split Ready / Passed incl. prod / Did not pass (`alphas.counts`, `gate=` filter, tabs in Results), prod failure moves an alpha to failed with its reason, winner tag deferred until prod passes (`alphas.winner_after_check`), engine and Autosentry results separated by source (engine default). 4 new tests (320 pass). UNTESTED here: live BRAIN (`get_self_corr` shape, `get_check_submission`), endpoints.
- [x] Z8: Supersentry prod check parity with Autosentry: every alpha that clears the minimum Sharpe and fitness (gate passers first, either sign) is checked for production correlation with the same `A._checks_parallel` (sequential, `prod_check_delay` default 60 s; 0 = 4 at once). Alphas whose prod correlation is already in Results are reused, not checked again (`superpilot/prod.py`: `passes_metrics`, `split_for_prod`, `chk_from_stored`). Near-miss rescue via `prod_rescue_max` 0.74 as in Autosentry. UI field 'Prod check delay (s)'. 4 new tests (324 pass). UNTESTED here: `_review`/`_stored_corr` (need SQLAlchemy + live BRAIN).
- [x] Z9: Results restructure: colour code per alpha (`alphas.color_state`): grey no stats yet, yellow passed the gate but prod not checked, green passed everything incl. prod, purple failed (gate or prod); no red. Rows coloured with a legend, new All tab (default), batch picker with per-batch colour counts (`alphas.batches`, `/alphas/batches`, `batch=` filter), unscored alphas show grey. Score buttons (Control and Results) now show the real failure reason (`score_pending(errors_out=)`, endpoints return `errors`), manual score cap 40 -> 5000. Automatic scoring when a batch finishes unchanged (`_Side.kick`). 3 new tests (327 pass). UNTESTED here: UI rendering, live BRAIN.
- [x] Z10: Missing results: 'Pull stats now' button pulls stats of the shown missing alphas from BRAIN one by one (stats + BRAIN IS tests, no correlations: `alpha_stats(corr=False)`), with a terminal-style log (per alpha Sharpe/Fitness, colour, failure reason, timing), progress and Stop. `alphas.PullRun`, `/missing/pull` (POST, GET state, stop), `score_pending(only_ids=)`. Records without an alpha id are logged and skipped (use Requeue). 1 new test (328 pass). UNTESTED here: live BRAIN, UI rendering.
- [x] Z11: FIXED a real bug found by the user's Pull-stats log: Alpha Sentry's `sim_results.submitted` is NOT NULL with no default, and scoring never set it, so EVERY engine scoring insert failed (IntegrityError) on the real database; our test table had a default so tests missed it. `Store.required_defaults` + `score_pending` now fill any NOT NULL column without a default (0 / ''). New test uses a table shaped like the real one (329 pass).
- [x] Z12: Prod check log: the Results > Alpha stats prod check now keeps a timestamped log (`CheckRun._log`, in the polled state) shown in a terminal window: run start, wait before each alpha, the BRAIN call, prod/self/pool values with GREEN/PURPLE and failed checks, errors and pending with reasons, done/stopped. 1 new test (330 pass). UNTESTED here: live BRAIN, UI rendering.
- [x] Z13: Results filters + paging + bigger pull: region and From/To date filters on Alpha stats (created date) and on the Missing list (region from the simulation settings, last-updated date); Previous/Next pager (200 per page, first/last, 'x-y of N') appears only when results exceed a page, on both lists; 'Pull stats now' pulls everything matching the filters, up to 2000 at once (`PULL_MAX`), not just the visible page. `store.day_epoch`, `diagnose.missing(offset, region, date_from, date_to)`, `alphas.list_alphas(date_from, date_to)`. 1 new test (331 pass). UNTESTED here: UI rendering, live BRAIN.
- [x] Z14: User guide: 6 diagrams (app map, setup flow, Autosentry loop, alpha lifecycle with the colour code, simulation slots, annotated Results screen; drawings, not screenshots, in `docs/img`) and a new section 14 'How to' with step-by-step recipes (AI key, BRAIN login, Autosentry, Supersentry, SentryEngine task, read Results and check prod, filters and pages, recover missing results, Operator Atlas, session-expired alert). Quick reference is now section 15. PDF rebuilt (18 pages).
- [x] Z15: Frameworks, category pairing and alpha-count range for Autosentry AND Supersentry (flags default off: nothing happens until you tick a framework or category). NEW `app/frameworks/` (rules.py = Fred M's pairing guide: roles, Tier 1/2 with build recipes and watch-outs, rejected pairs blocked, unlisted pairs free; parse.py = reads a pasted/uploaded framework (txt/md/pdf) into frameworks with region, slots + category guess, operators, neutralization, mechanism, reviewable before saving; plan.py = eligible fields by category and min/max alpha count (either side optional), stages per framework with the framework's own region/delay/universe, guidance text, hypothesis and selection checks, stage cycling; store.py = saved as library assets of kind 'framework'), `modules/frameworks` (parse, upload, save, list, delete, rules, check, categories). Autosentry: `framework_ids / fw_categories / fw_pairs / min_field_alphas / max_field_alphas / fw_hypotheses`; several frameworks are cycled (N hypotheses each, own region), hypotheses that mix rejected / unchosen / out-of-category pairs are dropped, the framework text goes into hypothesis and template prompts; frameworks that cannot run (no fields in range, rejected pair) are skipped and logged. Supersentry: same choosers (`fw_rounds` rounds per framework), selections that put rejected category pairs together via datacategories are dropped, framework text in the prompts. LIMIT: the alpha-count range is for datafields so it applies to Autosentry only (SuperAlphas choose alphas, not fields). UI: `FrameworkPanel` (upload / paste / review / save, framework picker, category pills with counts and blocked pairs, combination list with tier badges, min/max alphas) on both screens. 9 new tests (340 pass). UNTESTED here (no SQLAlchemy / live BRAIN / LLM): `_fw_plan`, `_run_stages`, `_new_hypotheses` block, Supersentry `_fw_turn`, catalog loading and the endpoints, UI rendering.
- [x] V1: Whip tab (Tools → Whip): backend output (in-memory recorder of logging + stdout/stderr, `whip/recorder.py`) and Autosentry's event log side by side; Whip button with a whip animation, a persistent 60-click counter, and a safe temp-file clean-up on the 60th click (`whip/cleanup.py`: allowlist plan + last-gate `is_safe`; `modules/whip`: `/logs`, `/report`, `/clean`). Skipped while Autosentry / Supersentry / SentryEngine run (counter stays at 60), at most once per 5 minutes. Never touches the database, LLM cache/budget, Osmosis, session, keys, licence, settings or `data/backups`. 6 new tests (337 pass). UNTESTED here: live backend (no FastAPI), UI rendering and animation (type-checked with stubs only), Windows locked-log behaviour.

## Z16 - Separate libraries for Autosentry and Supersentry (checkpoint AM)
- Library items carry `meta.engine` (auto / super / both). Items saved earlier: alphas, templates, boosters -> Autosentry; SuperAlphas, selections, combos -> Supersentry; papers, notes, operator groups, frameworks stay shared until pinned ("shared -> only here" button).
- `build_context`, `active_boosters`, `active_opgroups` and `GET /autopilot/library?engine=` filter by engine. New items and winners are tagged to the screen/engine that made them. Duplicate check is per engine.
- Whip (V1.3) kept intact: Tools -> Whip and tests/test_whip.py. Suite: 349 passed, 0 failed, 1 skipped.
- Not testable in the sandbox: UI rendering, endpoints, live BRAIN/LLM, framework stage cycling.

## Z17 - Saved framework setups (checkpoint AN)
- Frameworks were already saved in the library once uploaded; now also: rename (pencil) on a saved framework, and named **setups** (library kind `fwsetup`) that remember the whole choice: ticked frameworks, categories, pairs, min/max alphas. Same name overwrites. Endpoints: GET/POST `/api/frameworks/setups`, delete via `DELETE /api/frameworks/{id}`.
- Setups are shared by Autosentry and Supersentry panels. Suite: 350 passed, 0 failed, 1 skipped. UI and endpoints untested in the sandbox.

## Z18 - LLM suggests the best pair for a pasted framework (checkpoint AO)
- After Read pasted text / upload, `POST /api/frameworks/suggest` asks the LLM which two data categories best fit each framework (prompt carries the framework and Fred M's pairing guide). Answers are checked with `frameworks/advise.py`: blocked/unknown/duplicate pairs dropped; if the LLM is missing or answers badly the rules choose (tier 1 pairs among the framework's categories first). Up to 3 suggestions, the top one starred, "use" to switch.
- On Save, with "Then tick the suggested pair" on (default), the new frameworks, the best pair's categories and the pair are ticked so Start can be pressed straight away.
- Suite: 351 passed, 0 failed, 1 skipped. Endpoint, LLM call and UI untested in the sandbox.

## Z19 - Frameworks as their own method, two lanes, region at save (checkpoint AP)
- Autosentry now has three methods: Explore ideas, Clone and swap, **Frameworks**. The Frameworks panel moved out of Explore ideas (Supersentry keeps its panel). A saved framework needs its region (Save is disabled until typed); a run uses each framework's own region/delay/universe, and the category counts follow the first ticked framework's market.
- **Two at a time** (`fw_lanes` = 2, shown when 2+ frameworks are ticked): `autopilot/lanes.py` (`assign`, `PerLane`, `enter`) + `_run_lanes` in `autopilot/service.py`. Each lane is a thread with its own settings copy and its own follow-up / hypothesis-failure / prod-flag lists (thread-local proxies); parallel batches per lane = parallel // 2 so both stay within one run's slot use (engine routing's slot lease still arbitrates). Shared: winners target, state file (now behind `_STATE_LOCK`), BRAIN session, one watchdog. Log lines carry `[lane A]` / `[lane B]`; with more than 2 frameworks each lane cycles through its share.
- Known limits: the live panel shows whichever lane wrote last; Telegram remote edits to the running settings do not reach the lanes; first lane alone runs the library seed run. Untested here: real parallel runs (no BRAIN), UI. Suite 352 passed, 0 failed, 1 skipped; type-check clean for the touched screens.

## Z20 - Mark submitted / used alphas in Results (checkpoint AQ)
- New table `harness_alpha_mark` (created if missing; nothing else changes). `alphas.set_marks/mark_counts`, `POST /api/harness/alphas/mark {ids, mark: submitted|used|""}`, `mark=` filter on the list (none / any / submitted / used), `mark` on every row and `marks` counts in the response. Marking "submitted" also sets Alpha Sentry's own `submitted` flag (+ `submitted_at`) so Planning's "unsubmitted" counts agree; clearing resets it. Nothing is ever sent to BRAIN.
- UI (Results): Mark column with a badge (click to clear), "all marks / not marked / any / submitted (n) / used (n)" filter, and Mark submitted / Mark used / Clear mark buttons for the selected rows. Suite 353 passed, 0 failed, 1 skipped; type-check clean.
