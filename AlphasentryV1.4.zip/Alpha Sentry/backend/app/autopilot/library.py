"""Autosentry Library & Learning memory.

Stores what the user uploads (working alphas, templates, papers, boosters, notes) and what the
engine learns (lessons from successes and failures), and turns both into compact prompt
context for the hypothesis / template stages. Everything is persisted in the local SQLite DB,
so it keeps compounding across runs and restarts.
"""

from __future__ import annotations

import json
import re
import time
from collections import Counter

from sqlalchemy import select

from app.autopilot import regions as RG
from app.db import models as M
from app.db.base import SessionLocal

KINDS = ("alpha", "template", "paper", "booster", "note", "opgroup", "superalpha", "selection", "combo", "framework", "fwsetup")
SUPER_SEP = " -> "
LESSON_KINDS = ("success", "failure", "insight", "booster")


def _norm(e: str) -> str:
    return re.sub(r"\s+", "", str(e)).lower()


def _fp_text(t: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(t).lower()).strip()[:140]


def _balanced(expr: str) -> bool:
    d = 0
    for ch in expr:
        d += (ch == "(") - (ch == ")")
        if d < 0:
            return False
    return d == 0


def _asset_dict(a: M.AutopilotAsset, full: bool = False) -> dict:
    try:
        meta = json.loads(a.meta_json or "{}")
    except Exception:
        meta = {}
    body = a.body if (full or a.kind != "paper") else a.body[:400]
    return {"id": a.id, "kind": a.kind, "name": a.name, "body": body, "digest": a.digest,
            "chars": len(a.body or ""), "meta": meta, "source": a.source, "enabled": a.enabled,
            "uses": a.uses, "wins": a.wins, "created_at": a.created_at}


# ── assets ───────────────────────────────────────────────────────────────────────────

def validate(kind: str, body: str, meta: dict) -> str | None:
    """Return an error string, or None when the asset is acceptable."""
    body = (body or "").strip()
    if kind not in KINDS:
        return f"unknown kind {kind!r}"
    if not body:
        return "empty"
    if kind in ("alpha", "template", "booster") and not _balanced(body):
        return "unbalanced parentheses"
    if kind == "fwsetup":
        return None if isinstance((meta or {}).get("sel"), dict) else "a setup needs its selection"
    if kind == "framework":
        return None if (meta or {}).get("slots") is not None or (meta or {}).get("categories") else "a framework needs its slots or categories"
    if kind == "booster" and "{alpha}" not in body:
        return "a booster must contain the {alpha} placeholder, e.g. group_neutralize({alpha}, industry)"
    if kind == "opgroup":
        names = [x.strip() for x in body.split(",") if x.strip()]
        if len(names) < 2 or not all(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", n) for n in names):
            return "an operator group is 2+ operator names separated by commas, e.g. ts_rank, ts_zscore, ts_scale"
        return None
    if kind == "superalpha":
        if SUPER_SEP not in body:
            return "a SuperAlpha is `selection -> combo`, e.g.  own && turnover < 0.7 -> 1"
        sel, combo = [x.strip() for x in body.split(SUPER_SEP, 1)]
        if not sel or not combo or not _balanced(sel) or not _balanced(combo):
            return "selection or combo is empty / has unbalanced parentheses"
        return None
    if kind in ("selection", "combo") and not _balanced(body):
        return "unbalanced parentheses"
    if kind == "template" and "{field}" not in body:
        return "a template must contain the {field} placeholder"
    return None


# ── engine scope: which engine (Autosentry "auto" / Supersentry "super") an item belongs to ──
ENGINES = ("auto", "super", "both")
_LEGACY_ENGINE = {"alpha": "auto", "template": "auto", "booster": "auto",
                  "superalpha": "super", "selection": "super", "combo": "super"}   # others: shared ("both")


def engine_of(kind: str, meta: dict | None) -> str:
    """Effective engine of an item. Items stored before libraries were split have no tag and
    fall back by kind; papers, notes, operator groups and frameworks stay shared until assigned."""
    e = (meta or {}).get("engine")
    return e if e in ENGINES else _LEGACY_ENGINE.get(kind, "both")


def for_engine(kind: str, meta: dict | None, engine: str | None) -> bool:
    if engine not in ("auto", "super"):
        return True
    return engine_of(kind, meta) in (engine, "both")


def _meta_clean(meta: dict | None) -> dict:
    """Keep `regions` well-formed (see autopilot/regions.py); everything else passes through."""
    m = dict(meta or {})
    if "engine" in m and m["engine"] not in ENGINES:
        m.pop("engine")
    if "regions" in m:
        r = RG.clean(m["regions"])
        if r is None:
            m.pop("regions")
        else:
            m["regions"] = r
    return m


def add_asset(kind: str, body: str, name: str = "", meta: dict | None = None,
              source: str = "user", digest: str = "") -> dict:
    meta = _meta_clean(meta)
    err = validate(kind, body, meta)
    if err:
        return {"error": err}
    body = body.strip()
    fp = _norm(body)[:200] if kind != "paper" else _fp_text(name or body[:80])
    with SessionLocal() as db:
        eng = engine_of(kind, meta)
        ex = next((x for x in db.scalars(select(M.AutopilotAsset).where(
            M.AutopilotAsset.kind == kind, M.AutopilotAsset.fingerprint == fp)).all()
            if engine_of(kind, _meta_of(x)) == eng), None)
        if ex:
            return {**_asset_dict(ex), "duplicate": True}
        a = M.AutopilotAsset(kind=kind, name=(name or body[:48]).strip()[:120], body=body,
                             digest=digest, meta_json=json.dumps(meta), source=source, fingerprint=fp)
        db.add(a)
        db.commit()
        return _asset_dict(a)


def bulk_add(kind: str, text: str, meta: dict | None = None, source: str = "user") -> dict:
    """One asset per non-empty line (lines starting with # are skipped). A line may be
    `name :: expression`."""
    added, dup, bad = 0, 0, []
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        name = ""
        if "::" in line:
            name, line = [p.strip() for p in line.split("::", 1)]
        r = add_asset(kind, line, name=name, meta=meta, source=source)
        if r.get("error"):
            bad.append(f"{line[:60]} — {r['error']}")
        elif r.get("duplicate"):
            dup += 1
        else:
            added += 1
    return {"added": added, "duplicates": dup, "rejected": bad}


def list_assets(kind: str | None = None, full: bool = False, engine: str | None = None) -> list:
    with SessionLocal() as db:
        q = select(M.AutopilotAsset).order_by(M.AutopilotAsset.created_at.desc())
        if kind:
            q = q.where(M.AutopilotAsset.kind == kind)
        out = []
        for a in db.scalars(q).all():
            if not for_engine(a.kind, _meta_of(a), engine):
                continue
            d = _asset_dict(a, full)
            d["engine"] = engine_of(a.kind, d["meta"])
            out.append(d)
        return out


def get_asset(aid: int) -> M.AutopilotAsset | None:
    with SessionLocal() as db:
        return db.get(M.AutopilotAsset, aid)


def update_asset(aid: int, patch: dict) -> dict:
    with SessionLocal() as db:
        a = db.get(M.AutopilotAsset, aid)
        if not a:
            return {"error": "not found"}
        for k in ("name", "enabled"):
            if k in patch and patch[k] is not None:
                setattr(a, k, patch[k])
        if patch.get("body") is not None:
            err = validate(a.kind, patch["body"], {})
            if err:
                return {"error": err}
            a.body = patch["body"].strip()
            a.fingerprint = _norm(a.body)[:200] if a.kind != "paper" else a.fingerprint
        if patch.get("meta") is not None:
            a.meta_json = json.dumps(_meta_clean(patch["meta"]))
        if patch.get("digest") is not None:
            a.digest = patch["digest"]
        a.updated_at = time.time()
        db.commit()
        return _asset_dict(a)


def toggle_region(kind: str, region: str, on: bool, known: list[str], ids: list[int] | None = None) -> dict:
    """Tick or untick one region for every item of `kind` (or just `ids`). `known` = the regions on offer, so that "all ticked" is stored as
    "no restriction". Nothing else in an item's meta changes."""
    try:
        RG.toggled({}, region, on, known)                    # validates the code
    except ValueError as e:
        return {"error": str(e)}
    n = 0
    with SessionLocal() as db:
        q = select(M.AutopilotAsset).where(M.AutopilotAsset.kind == kind)
        if ids:
            q = q.where(M.AutopilotAsset.id.in_(ids))
        for a in db.scalars(q).all():
            try:
                meta = json.loads(a.meta_json or "{}")
            except Exception:
                meta = {}
            new = RG.toggled(meta, region, on, known)
            if new != meta:
                a.meta_json = json.dumps(new)
                a.updated_at = time.time()
                n += 1
        db.commit()
    return {"changed": n}


def delete_asset(aid: int) -> dict:
    with SessionLocal() as db:
        a = db.get(M.AutopilotAsset, aid)
        if a:
            db.delete(a)
            db.commit()
    return {"ok": True}


def record_outcome(ids: list[int], won: bool) -> None:
    if not ids:
        return
    with SessionLocal() as db:
        for a in db.scalars(select(M.AutopilotAsset).where(M.AutopilotAsset.id.in_(ids))).all():
            a.uses += 1
            a.wins += 1 if won else 0
            a.last_used_at = time.time()
        db.commit()


# ── lessons ──────────────────────────────────────────────────────────────────────────

def add_lesson(text: str, kind: str = "insight", region: str = "", source: str = "autopilot",
               pinned: bool = False) -> dict:
    text = (text or "").strip()
    if not text:
        return {"error": "empty"}
    kind = kind if kind in LESSON_KINDS else "insight"
    fp = _fp_text(text)
    with SessionLocal() as db:
        ex = db.scalar(select(M.AutopilotLesson).where(
            M.AutopilotLesson.fingerprint == fp, M.AutopilotLesson.region == region))
        if ex:
            ex.weight += 1
            ex.last_at = time.time()
            ex.pinned = ex.pinned or pinned
            db.commit()
            return {"id": ex.id, "reinforced": True}
        row = M.AutopilotLesson(kind=kind, region=region, text=text[:600], fingerprint=fp,
                                source=source, pinned=pinned)
        db.add(row)
        db.commit()
        return {"id": row.id}


def list_lessons(region: str = "", limit: int = 200) -> list:
    with SessionLocal() as db:
        q = select(M.AutopilotLesson).order_by(M.AutopilotLesson.last_at.desc()).limit(limit)
        if region:
            q = q.where(M.AutopilotLesson.region.in_([region, ""]))
        return [{"id": r.id, "kind": r.kind, "region": r.region, "text": r.text, "weight": r.weight,
                 "source": r.source, "pinned": r.pinned, "last_at": r.last_at}
                for r in db.scalars(q).all()]


def delete_lesson(lid: int) -> dict:
    with SessionLocal() as db:
        r = db.get(M.AutopilotLesson, lid)
        if r:
            db.delete(r)
            db.commit()
    return {"ok": True}


def set_pinned(lid: int, pinned: bool) -> dict:
    with SessionLocal() as db:
        r = db.get(M.AutopilotLesson, lid)
        if r:
            r.pinned = pinned
            db.commit()
    return {"ok": True}


# ── context for the prompts ──────────────────────────────────────────────────────────

def _rank_assets(rows: list, k: int) -> list:
    """Favour assets that have won, then ones used least recently (so everything gets a turn)."""
    return sorted(rows, key=lambda a: (-(a.wins * 2 - a.uses * 0.25), a.last_used_at))[:k]


def _meta_of(a: M.AutopilotAsset) -> dict:
    try:
        return json.loads(a.meta_json or "{}")
    except Exception:
        return {}


def build_context(region: str, mode: str = "regular") -> dict:
    """{'text': {...prompt blocks...}, 'ids': [asset ids used], 'seed_templates': [str]}.
    mode="super": the user's SuperAlphas / selections / combos replace alphas / templates, and lessons
    come from the separate "<region>:super" memory (so regular and super research never mix)."""
    if mode == "super":
        region = region + ":super"
    with SessionLocal() as db:
        assets = db.scalars(select(M.AutopilotAsset).where(M.AutopilotAsset.enabled.is_(True))).all()
        lessons = db.scalars(select(M.AutopilotLesson).where(
            M.AutopilotLesson.region.in_([region, ""]))).all()
    eng = "super" if mode == "super" else "auto"
    assets = [a for a in assets if for_engine(a.kind, _meta_of(a), eng)]     # each engine reads only its own library
    assets = [a for a in assets if RG.applies(_meta_of(a), region)]          # items ticked off for this region stay out of its prompts
    by = {k: [a for a in assets if a.kind == k] for k in KINDS}
    ids: list[int] = []
    blocks = {"alphas": "", "templates": "", "papers": "", "notes": "", "lessons": "",
              "selections": "", "combos": ""}
    if mode == "super":
        sa = _rank_assets(by["superalpha"], 6)
        if sa:
            ids += [a.id for a in sa]
            blocks["alphas"] = (
                "=== USER'S WORKING SUPERALPHAS (selection -> combo; proven starting points) ===\n"
                "Do NOT copy them: study WHY they work and vary the selection logic / weighting idea.\n"
                + "\n".join(f"- {a.body}" for a in sa) + "\n")
        sl = _rank_assets(by["selection"], 6)
        if sl:
            ids += [a.id for a in sl]
            blocks["selections"] = ("=== USER'S SELECTION EXPRESSIONS (modify and extend these) ===\n"
                                    + "\n".join(f"- {a.body}" for a in sl) + "\n")
        cl = _rank_assets(by["combo"], 6)
        if cl:
            ids += [a.id for a in cl]
            blocks["combos"] = ("=== USER'S COMBO EXPRESSIONS (modify and extend these) ===\n"
                                + "\n".join(f"- {a.body}" for a in cl) + "\n")

    al = _rank_assets(by["alpha"], 6) if mode != "super" else []
    if al:
        ids += [a.id for a in al]
        blocks["alphas"] = (
            "=== USER'S WORKING ALPHAS (proven starting points) ===\n"
            "These already work for the user. Do NOT copy them: study WHY they work and build "
            "templates that vary the idea (other fields, other windows, other operators, "
            "different normalisation) while keeping the winning structure.\n"
            + "\n".join(f"- {a.body}" for a in al) + "\n")

    tl = _rank_assets(by["template"], 6) if mode != "super" else []
    if tl:
        ids += [a.id for a in tl]
        blocks["templates"] = (
            "=== USER'S TEMPLATES (modify and extend these) ===\n"
            + "\n".join(f"- {a.body}" for a in tl) + "\n")

    pl = _rank_assets(by["paper"], 3)
    if pl:
        ids += [a.id for a in pl]
        parts = []
        for a in pl:
            txt = (a.digest or a.body[:2500]).strip()
            parts.append(f"[{a.name}]\n{txt[:2500]}")
        blocks["papers"] = ("=== USER'S RESEARCH PAPERS (ideas to exploit — map them onto the "
                            "datafields provided, never invent fields) ===\n" + "\n\n".join(parts) + "\n")

    nl = by["note"][:5]
    if nl:
        blocks["notes"] = "=== USER NOTES ===\n" + "\n".join(f"- {a.body[:400]}" for a in nl) + "\n"

    if lessons:
        top = sorted(lessons, key=lambda r: (not r.pinned, -(r.weight + (2 if r.kind == "success" else 0)),
                                             -r.last_at))[:14]
        tag = {"success": "WORKED", "failure": "FAILED", "insight": "NOTE", "booster": "BOOSTER"}
        blocks["lessons"] = ("=== LESSONS FROM PREVIOUS RUNS (repeat what worked, avoid what failed) ===\n"
                             + "\n".join(f"- [{tag.get(r.kind, 'NOTE')}{' x' + str(r.weight) if r.weight > 1 else ''}] {r.text}"
                                         for r in top) + "\n")
    if mode == "super":
        return {"text": blocks, "ids": ids, "seed_templates": [],
                "seed_alphas": [a.body for a in by["superalpha"]],
                "seed_selections": [a.body for a in by["selection"]],
                "seed_combos": [a.body for a in by["combo"]]}
    return {"text": blocks, "ids": ids, "seed_templates": [a.body for a in tl],
            "seed_alphas": [a.body for a in by["alpha"]]}


def context_text(ctx: dict, *keys: str) -> str:
    return "".join(ctx["text"].get(k, "") for k in keys)


# ── sister / brother operator groups (used to cut prod correlation) ───────────────────

DEFAULT_OPGROUPS = [
    ["ts_rank", "ts_zscore", "ts_scale"],
    ["ts_mean", "ts_median", "ts_decay_linear", "ts_sum"],
    ["ts_delta", "ts_av_diff"],
    ["ts_std_dev", "ts_max", "ts_min"],
    ["ts_corr", "ts_covariance"],
    ["rank", "zscore", "scale"],
    ["group_rank", "group_zscore", "group_neutralize", "group_scale"],
]


def active_opgroups(engine: str | None = None) -> list:
    """Operator groups whose members are interchangeable drop-ins. The user's enabled groups win;
    the built-in defaults are used only when the user has defined none."""
    with SessionLocal() as db:
        rows = db.scalars(select(M.AutopilotAsset).where(
            M.AutopilotAsset.kind == "opgroup", M.AutopilotAsset.enabled.is_(True))).all()
    mine = [[x.strip() for x in a.body.split(",") if x.strip()] for a in rows
            if for_engine("opgroup", _meta_of(a), engine)]
    return mine or [list(g) for g in DEFAULT_OPGROUPS]


# ── boosters ─────────────────────────────────────────────────────────────────────────

def active_boosters(region: str = "", engine: str | None = "auto") -> list:
    """Enabled boosters; with a region, only those ticked for it (no region = all, as before)."""
    with SessionLocal() as db:
        rows = db.scalars(select(M.AutopilotAsset).where(
            M.AutopilotAsset.kind == "booster", M.AutopilotAsset.enabled.is_(True))).all()
    out = []
    for a in rows:
        meta = _meta_of(a)
        if not RG.applies(meta, region) or not for_engine("booster", meta, engine):
            continue
        out.append({"id": a.id, "name": a.name, "body": a.body,
                    "min_sharpe": float(meta.get("min_sharpe") or 1.0),
                    "max_turnover": meta.get("max_turnover")})
    return out


def apply_booster(expr: str, booster: dict) -> str:
    return booster["body"].replace("{alpha}", f"({expr.strip()})")


def eligible(row: dict, booster: dict, default_trigger: float) -> bool:
    sh = row.get("sharpe")
    if sh is None:
        return False
    trig = booster.get("min_sharpe") or default_trigger
    if sh < trig:
        return False
    mt = booster.get("max_turnover")
    tu = row.get("turnover")
    return not (mt and tu is not None and tu > float(mt))


# ── deterministic learning from a batch ──────────────────────────────────────────────

def learn_from_batch(region: str, hyp: dict, rows: list, skeleton_fn) -> None:
    """Cheap, LLM-free lessons: dominant failure reasons, sign inversion, passing structures."""
    if not rows:
        return
    reasons = Counter()
    for r in rows:
        for x in set(r.get("reasons") or []):
            reasons[str(x)[:70]] += 1
    n = len(rows)
    for why, c in reasons.most_common(2):
        if c >= max(3, n // 2):
            add_lesson(f"{c}/{n} alphas for \"{hyp['idea'][:80]}\" failed with: {why}. "
                       "Design templates that address this up front.", "failure", region)
    neg = [r for r in rows if (r.get("sharpe") or 0) < -0.8]
    if len(neg) >= max(3, n // 2):
        add_lesson(f"For \"{hyp['idea'][:80]}\" the signal sign was inverted (strongly negative Sharpe) — "
                   "this mechanism needs the opposite direction.", "insight", region)
    for r in rows:
        if r.get("passed"):
            try:
                sk = skeleton_fn(r["expr"])
            except Exception:
                sk = r["expr"]
            add_lesson(f"Structure that passed everything: {sk[:180]} "
                       f"(Sharpe {r.get('sharpe') and round(r['sharpe'], 2)}, "
                       f"turnover {r.get('turnover') and round(r['turnover'], 2)}).", "success", region)


def learn_booster(region: str, booster: dict, base: float, boosted: float) -> None:
    d = boosted - base
    if d >= 0.15:
        add_lesson(f"Booster `{booster['name']}` raised Sharpe by ~{d:.2f} on an alpha with base Sharpe {base:.2f}.",
                   "booster", region)
    elif d <= -0.15:
        add_lesson(f"Booster `{booster['name']}` HURT Sharpe by ~{abs(d):.2f} (base {base:.2f}).",
                   "booster", region)


def summary(region: str = "") -> dict:
    with SessionLocal() as db:
        assets = db.scalars(select(M.AutopilotAsset)).all()
        n_les = len(db.scalars(select(M.AutopilotLesson.id)).all())
    c = Counter(a.kind for a in assets)
    return {"assets": dict(c), "lessons": n_les,
            "autopilot_saved": sum(1 for a in assets if a.source == "autopilot")}
