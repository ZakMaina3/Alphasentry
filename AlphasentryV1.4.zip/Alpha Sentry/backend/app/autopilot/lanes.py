"""Framework lanes: two frameworks worked on side by side inside one Autosentry run.
The loop keeps a few module-level work lists (follow-ups waiting, why-hypotheses-failed, prod-correlation candidates);
`PerLane` makes each lane (a thread that called `enter`) see its own copy, while every other thread sees the shared one."""
from __future__ import annotations

import threading

_TLS = threading.local()


def enter(label: str) -> None:
    """Call at the start of a lane thread: from now on this thread has its own PerLane contents and log prefix."""
    _TLS.own = {}
    _TLS.lane = label


def label() -> str:
    return getattr(_TLS, "lane", "")


class PerLane:
    def __init__(self, factory):
        self._f = factory
        self._base = factory()

    def _o(self):
        own = getattr(_TLS, "own", None)
        if own is None:
            return self._base
        if id(self) not in own:
            own[id(self)] = self._f()
        return own[id(self)]

    def __getattr__(self, n):
        return getattr(self._o(), n)

    def __iter__(self): return iter(self._o())
    def __len__(self): return len(self._o())
    def __bool__(self): return bool(self._o())
    def __getitem__(self, k): return self._o()[k]
    def __setitem__(self, k, v): self._o()[k] = v
    def __delitem__(self, k): del self._o()[k]
    def __contains__(self, k): return k in self._o()
    def __repr__(self): return repr(self._o())


def assign(stages: list[dict], lanes: int) -> list[list[dict]]:
    """Split the runnable frameworks between `lanes` lanes (round robin); a framework that cannot run is left out.
    Never more lanes than runnable frameworks. [] when nothing can run."""
    ok = [s for s in stages if not s.get("error")]
    n = max(1, min(int(lanes or 1), len(ok)))
    return [ok[k::n] for k in range(n)] if ok else []
