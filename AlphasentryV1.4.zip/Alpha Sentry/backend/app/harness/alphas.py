"""Alpha stats table and one-by-one production-correlation checks (plain sqlite3 through the harness Store; BRAIN is reached only through a
function you pass in, so everything here is testable without a network)."""
from __future__ import annotations

import time
from typing import Any, Callable

from app.harness.scoring import MAX_CORR, _corr, _num

COLS = ["alpha_id", "expression", "region", "delay", "universe", "neutralization", "sharpe", "fitness", "turnover", "returns", "margin",
        "drawdown", "self_corr", "prod_corr", "powerpool_corr", "tests_failed", "passed_gate", "gate_reasons", "tagged", "submitted", "created_at"]
SORTABLE = {"sharpe", "fitness", "turnover", "returns", "margin", "drawdown", "self_corr", "prod_corr", "powerpool_corr", "created_at", "tests_failed"}
RESCUE_LIMIT = 0.74


def prod_state(prod, checked_at=None) -> str:
    """'unchecked' | 'ok' (< 0.70) | 'high' (0.70-0.74: worth fixing) | 'too_high' (> 0.74)."""
    if prod is None:
        return "unchecked"
    v = abs(float(prod))
    return "ok" if v < MAX_CORR else ("high" if v <= RESCUE_LIMIT else "too_high")


def color_state(row: dict) -> str:
    """Colour of a row: 'grey' no stats yet, 'yellow' passed the gate but prod not checked, 'green' passed everything incl. prod,
    'purple' failed (missed the gate, or failed on prod)."""
    if row.get("sharpe") is None and row.get("fitness") is None:
        return "grey"
    prod = row.get("prod_corr")
    if prod is not None and abs(float(prod)) >= MAX_CORR:
        return "purple"
    if not row.get("passed_gate"):
        return "purple"
    return "yellow" if prod is None else "green"


def batches(store, source: str = "engine", limit: int = 15) -> list[dict]:
    """The latest batches with how many of their alphas are in each colour (newest first)."""
    cond = {"engine": "AND task != 'autopilot'", "autosentry": "AND task = 'autopilot'"}.get(source, "")
    recs = store.query(f"SELECT batch_id, MAX(updated) AS t, COUNT(*) AS n, MAX(task) AS task FROM harness_sim_record "
                       f"WHERE batch_id != '' {cond} GROUP BY batch_id ORDER BY t DESC LIMIT ?", (int(limit),))
    out = []
    for b in recs:
        rows = store.query("SELECT r.sharpe, r.fitness, r.prod_corr, r.passed_gate FROM harness_sim_record h JOIN sim_results r ON r.alpha_id = h.alpha_id "
                           "WHERE h.batch_id=? AND h.alpha_id != ''", (b["batch_id"],))
        c = {"grey": int(b["n"]) - len(rows), "yellow": 0, "green": 0, "purple": 0}
        for r in rows:
            c[color_state({k: r[k] for k in r.keys()})] += 1
        out.append({"batch_id": b["batch_id"], "task": b["task"], "updated": b["t"], "size": int(b["n"]), **c})
    return out


def counts(store, source: str = "engine") -> dict:
    """How many alphas are in each group (for the tabs): ready for a prod check, cleared, failed."""
    src = {"engine": "alpha_id IN (SELECT alpha_id FROM harness_sim_record WHERE alpha_id != '' AND task != 'autopilot')",
           "autosentry": "(alpha_id IN (SELECT alpha_id FROM harness_sim_record WHERE task='autopilot') OR tagged LIKE '%autopilot%')"}.get(source, "1=1")
    r = store.query(f"SELECT SUM(CASE WHEN COALESCE(passed_gate,0)=1 AND prod_corr IS NULL THEN 1 ELSE 0 END) AS ready, "
                    f"SUM(CASE WHEN COALESCE(passed_gate,0)=1 AND prod_corr IS NOT NULL THEN 1 ELSE 0 END) AS cleared, "
                    f"SUM(CASE WHEN COALESCE(passed_gate,0)=0 THEN 1 ELSE 0 END) AS failed FROM sim_results WHERE alpha_id != '' AND {src}")[0]
    return {k: int(r[k] or 0) for k in ("ready", "cleared", "failed")}


# ── your own marks: which alphas you submitted or used (nothing here ever submits anything) ──
MARKS = ("submitted", "used")
_MARK_DDL = ("CREATE TABLE IF NOT EXISTS harness_alpha_mark (alpha_id TEXT PRIMARY KEY, mark TEXT NOT NULL, "
             "note TEXT NOT NULL DEFAULT '', at REAL NOT NULL)")


def set_marks(store, ids: list[str], mark: str | None, note: str = "") -> dict:
    """Mark alphas as 'submitted' or 'used' (None clears the mark). Marking 'submitted' also sets Alpha Sentry's own submitted flag so the
    Planning counts agree; clearing resets it. Only marks you give are stored; nothing is sent to BRAIN."""
    ids = [str(i).strip() for i in ids or [] if str(i).strip()]
    if mark not in (None, *MARKS):
        return {"error": f"mark must be one of {', '.join(MARKS)} or empty"}
    store.execute(_MARK_DDL)
    have = store.columns("sim_results")
    now = time.time()
    for a in ids:
        was = store.query("SELECT mark FROM harness_alpha_mark WHERE alpha_id=?", (a,))
        if mark is None:
            store.execute("DELETE FROM harness_alpha_mark WHERE alpha_id=?", (a,))
        else:
            store.execute("INSERT INTO harness_alpha_mark (alpha_id, mark, note, at) VALUES (?,?,?,?) "
                          "ON CONFLICT(alpha_id) DO UPDATE SET mark=excluded.mark, note=excluded.note, at=excluded.at", (a, mark, note[:300], now))
        if "submitted" in have and (mark == "submitted" or (was and was[0]["mark"] == "submitted")):
            sub = 1 if mark == "submitted" else 0
            if "submitted_at" in have:
                store.execute("UPDATE sim_results SET submitted=?, submitted_at=? WHERE alpha_id=?", (sub, now if sub else None, a))
            else:
                store.execute("UPDATE sim_results SET submitted=? WHERE alpha_id=?", (sub, a))
    return {"marked": len(ids), "mark": mark}


def mark_counts(store) -> dict:
    store.execute(_MARK_DDL)
    r = store.query("SELECT mark, COUNT(*) AS n FROM harness_alpha_mark GROUP BY mark")
    return {m: int(next((x["n"] for x in r if x["mark"] == m), 0)) for m in MARKS}


def list_alphas(store, *, q: str = "", region: str = "", passed: str = "", prod: str = "", source: str = "", sort: str = "created_at",
                desc: bool = True, limit: int = 100, offset: int = 0, gate: str = "", batch: str = "", date_from: str = "", date_to: str = "", mark: str = "") -> dict:
    """One page of alpha stats from Results, each row with its source (the engine task, or the tag) and a prod state."""
    have = store.columns("sim_results")
    cols = [c for c in COLS if c in have]
    where, p = ["alpha_id != ''"], []
    if q.strip():
        where.append("(alpha_id LIKE ? OR expression LIKE ?)")
        p += [f"%{q.strip()}%"] * 2
    if region.strip():
        where.append("region=?")
        p.append(region.strip().upper())
    if passed == "yes":
        where.append("COALESCE(passed_gate,0)=1")
    elif passed == "no":
        where.append("COALESCE(passed_gate,0)=0")
    if gate == "ready":            # passed everything except prod, prod not checked yet: these are the ones to check
        where.append("COALESCE(passed_gate,0)=1 AND prod_corr IS NULL")
    elif gate == "cleared":        # passed everything including prod
        where.append("COALESCE(passed_gate,0)=1 AND prod_corr IS NOT NULL")
    elif gate == "failed":         # failed the gate, or failed on a correlation once checked
        where.append("COALESCE(passed_gate,0)=0")
    if prod == "unchecked":
        where.append("prod_corr IS NULL")
    elif prod == "checked":
        where.append("prod_corr IS NOT NULL")
    elif prod == "high":
        where.append("ABS(prod_corr) >= ?")
        p.append(MAX_CORR)
    elif prod == "ok":
        where.append("ABS(prod_corr) < ?")
        p.append(MAX_CORR)
    if mark:
        store.execute(_MARK_DDL)
        if mark == "none":
            where.append("alpha_id NOT IN (SELECT alpha_id FROM harness_alpha_mark)")
        elif mark == "any":
            where.append("alpha_id IN (SELECT alpha_id FROM harness_alpha_mark)")
        elif mark in MARKS:
            where.append("alpha_id IN (SELECT alpha_id FROM harness_alpha_mark WHERE mark=?)")
            p.append(mark)
    from app.harness.store import day_epoch
    lo, hi = day_epoch(date_from), day_epoch(date_to, True)
    if lo is not None and "created_at" in have:
        where.append("created_at >= ?")
        p.append(lo)
    if hi is not None and "created_at" in have:
        where.append("created_at <= ?")
        p.append(hi)
    if batch.strip():
        where.append("alpha_id IN (SELECT alpha_id FROM harness_sim_record WHERE alpha_id != '' AND batch_id=?)")
        p.append(batch.strip())
    if source == "engine":
        where.append("alpha_id IN (SELECT alpha_id FROM harness_sim_record WHERE alpha_id != '' AND task != 'autopilot')")
    elif source == "autosentry":
        where.append("(alpha_id IN (SELECT alpha_id FROM harness_sim_record WHERE task='autopilot') OR tagged LIKE '%autopilot%')")
    key = sort if sort in SORTABLE and sort in have else ("created_at" if "created_at" in have else "alpha_id")
    order = f"{'ABS(' + key + ')' if key in ('sharpe', 'fitness', 'prod_corr', 'self_corr') else key} {'DESC' if desc else 'ASC'}"
    sql_where = " AND ".join(where)
    total = store.query(f"SELECT COUNT(*) AS n FROM sim_results WHERE {sql_where}", p)[0]["n"]
    rows = store.query(f"SELECT {', '.join(cols)} FROM sim_results WHERE {sql_where} ORDER BY {order} LIMIT ? OFFSET ?",
                       [*p, int(limit), int(offset)])
    ids = [r["alpha_id"] for r in rows]
    src: dict[str, str] = {}
    bat: dict[str, str] = {}
    if ids:
        from app.harness.store import chunks, marks
        for part in chunks(ids):
            for r in store.query(f"SELECT alpha_id, task, batch_id FROM harness_sim_record WHERE alpha_id IN ({marks(len(part))})", list(part)):
                src[r["alpha_id"]] = r["task"]
                bat[r["alpha_id"]] = r["batch_id"]
    mk: dict[str, str] = {}
    if ids:
        store.execute(_MARK_DDL)
        from app.harness.store import chunks as _ch, marks as _mk
        for part in _ch(ids):
            for r in store.query(f"SELECT alpha_id, mark FROM harness_alpha_mark WHERE alpha_id IN ({_mk(len(part))})", list(part)):
                mk[r["alpha_id"]] = r["mark"]
    out = []
    for r in rows:
        d = {k: r[k] for k in r.keys()}
        d["mark"] = mk.get(d["alpha_id"], "")
        d["source"] = src.get(d["alpha_id"]) or (d.get("tagged") or "Alpha Sentry")
        d["prod_state"] = prod_state(d.get("prod_corr"))
        d["state"] = color_state(d)
        d["batch"] = bat.get(d["alpha_id"], "")
        out.append(d)
    return {"total": int(total), "rows": out}


def check_result(df) -> dict:
    """BRAIN's submission-check table -> {self, prod, pool, failed: [names], pending}. `pending` = BRAIN has not finished the correlation yet."""
    out: dict[str, Any] = {"self": None, "prod": None, "pool": None, "failed": [], "pending": False}
    if df is None or getattr(df, "empty", True) or "name" not in getattr(df, "columns", []):
        out["pending"] = True
        return out
    out["self"], out["prod"] = _corr(df, "self"), _corr(df, "prod")
    out["pool"] = _corr(df, "pool") or _corr(df, "power")
    if "result" in df.columns:
        for _, row in df.iterrows():
            res = str(row.get("result", "")).upper()
            nm = str(row.get("name", ""))
            if res == "FAIL":
                out["failed"].append(nm)
            elif res == "PENDING" and ("corr" in nm.lower()):
                out["pending"] = True
    if out["prod"] is None and any("prod" in str(n).lower() for n in df["name"]):
        out["pending"] = True
    return out


def save_corr(store, alpha_id: str, res: dict) -> bool:
    """Write the checked correlations into Results (and mark a passing alpha as failing when a correlation is >= 0.70; never the other way)."""
    sets, p = [], []
    for col, key in (("self_corr", "self"), ("prod_corr", "prod"), ("powerpool_corr", "pool")):
        if res.get(key) is not None and col in store.columns("sim_results"):
            sets.append(f"{col}=?")
            p.append(res[key])
    if not sets:
        return False
    bad = [(lab, res[k]) for lab, k in (("self", "self"), ("prod", "prod"), ("powerpool", "pool")) if res.get(k) is not None and abs(res[k]) >= MAX_CORR]
    if bad:
        import json
        row = store.query("SELECT gate_reasons FROM sim_results WHERE alpha_id=?", [alpha_id])
        try:
            reasons = json.loads(row[0]["gate_reasons"]) if row else []
        except Exception:  # noqa: BLE001
            reasons = []
        reasons += [f"{lab}-corr {abs(v):.2f}≥{MAX_CORR}" for lab, v in bad if not any(str(r).startswith(f"{lab}-corr") for r in reasons)]
        sets += ["passed_gate=0", "gate_reasons=?"]
        p.append(json.dumps(reasons))
    store.execute(f"UPDATE sim_results SET {', '.join(sets)} WHERE alpha_id=?", [*p, alpha_id])
    return True


def winner_after_check(store, alpha_id: str, tagger=None, wcfg: dict | None = None) -> str:
    """An alpha that passed everything INCLUDING prod now gets the winner tag/colour (the engine does not tag before prod is known). Never raises."""
    try:
        from app.harness import winner as W
        r = store.query("SELECT * FROM sim_results WHERE alpha_id=?", [alpha_id])
        if not r:
            return ""
        row = {k: r[0][k] for k in r[0].keys()}
        if not row.get("passed_gate") or row.get("prod_corr") is None or abs(row["prod_corr"]) >= MAX_CORR:
            return ""
        if tagger is None:
            from app.harness import brain_port
            tagger = brain_port.tag_alpha
        tag = W.apply({**row, "passed_gate": True}, W.current() if wcfg is None else wcfg, tagger, row.get("tagged") or "harness")
        if tag and tag != row.get("tagged"):
            store.execute("UPDATE sim_results SET tagged=? WHERE alpha_id=?", [tag, alpha_id])
        return tag
    except Exception:  # noqa: BLE001
        return ""


def check_one(store, alpha_id: str, fetch: Callable[[str], Any], after_pass: Callable[[str], Any] | None = None) -> dict:
    """Check ONE alpha's production / self correlation through `fetch(alpha_id) -> DataFrame` and store it. Never raises."""
    t0 = time.time()
    try:
        res = check_result(fetch(alpha_id))
    except Exception as e:  # noqa: BLE001
        return {"alpha_id": alpha_id, "state": "error", "message": f"{type(e).__name__}: {str(e)[:200]}", "seconds": round(time.time() - t0, 1)}
    if res["pending"] or res["prod"] is None:
        return {"alpha_id": alpha_id, "state": "pending", "message": "BRAIN has not finished the correlation yet; try again in a minute.",
                "seconds": round(time.time() - t0, 1)}
    save_corr(store, alpha_id, res)
    if after_pass is not None:
        after_pass(alpha_id)
    return {"alpha_id": alpha_id, "state": prod_state(res["prod"]), "prod": res["prod"], "self": res["self"], "pool": res["pool"],
            "failed": res["failed"], "seconds": round(time.time() - t0, 1)}


class CheckRun:
    """One-after-another prod checks with a wait before each (default 60 s) and a Stop. State is plain data the UI polls. `sleep` / `check` are injectable."""

    def __init__(self) -> None:
        self.stop_flag = False
        self.state: dict[str, Any] = {"running": False, "total": 0, "done": 0, "current": "", "waiting": 0, "results": [], "message": "", "log": []}

    def stop(self) -> None:
        self.stop_flag = True

    def _log(self, line: str) -> None:
        self.state.setdefault("log", []).append(f"{time.strftime('%H:%M:%S')}  {line}")
        del self.state["log"][:-500]

    def run(self, store, ids: list[str], *, delay: float, recheck: bool, fetch, sleep=time.sleep, after_pass=None) -> dict:
        todo = list(dict.fromkeys(ids))
        if not recheck and todo:
            from app.harness.store import chunks, marks
            seen: set[str] = set()
            for part in chunks(todo):
                seen |= {r["alpha_id"] for r in store.query(f"SELECT alpha_id FROM sim_results WHERE prod_corr IS NOT NULL AND alpha_id IN ({marks(len(part))})", list(part))}
            skipped = [a for a in todo if a in seen]
            todo = [a for a in todo if a not in seen]
        else:
            skipped = []
        self.stop_flag = False
        self.state = {"running": True, "total": len(todo), "done": 0, "current": "", "waiting": 0, "skipped": len(skipped), "results": [], "message": "", "log": []}
        self._log(f"prod check for {len(todo)} alpha(s), one at a time, {max(0, int(delay))} s wait before each"
                  + (f"; {len(skipped)} already checked, skipped" if skipped else "") + " (nothing is submitted, no simulations)")
        for i, aid in enumerate(todo):
            wait = max(0, int(delay))
            if wait and not self.stop_flag:
                self._log(f"[{i + 1}/{len(todo)}] {aid}: waiting {wait} s before asking BRAIN")
            for left in range(wait, 0, -1):                 # the wait comes BEFORE every check, so BRAIN is never hit back to back
                if self.stop_flag:
                    break
                self.state["waiting"], self.state["current"] = left, aid
                sleep(1)
            if self.stop_flag:
                break
            self.state.update(waiting=0, current=aid)
            self._log(f"[{i + 1}/{len(todo)}] {aid}: asking BRAIN for the correlation check ...")
            r = check_one(store, aid, fetch, after_pass)
            self.state["results"].append(r)
            f3 = lambda v: "-" if v is None else f"{float(v):.3f}"
            if r["state"] in ("error", "pending"):
                self._log(f"[{i + 1}/{len(todo)}] {aid}: {r['state'].upper()} in {r['seconds']}s: {r['message']}")
            else:
                self._log(f"[{i + 1}/{len(todo)}] {aid}: prod {f3(r.get('prod'))} self {f3(r.get('self'))} pool {f3(r.get('pool'))} -> "
                          f"{'GREEN (passed)' if r['state'] == 'ok' else 'PURPLE (' + r['state'].replace('_', ' ') + ')'}"
                          + (f" failed: {', '.join(map(str, r.get('failed') or []))}" if r.get("failed") else "") + f" in {r['seconds']}s")
            self.state["done"] += 1
        self._log("stopped" if self.stop_flag else f"done: {self.state['done']} checked")
        self.state.update(running=False, waiting=0, current="",
                          message="stopped" if self.stop_flag else f"checked {self.state['done']}, skipped {len(skipped)} already checked")
        return self.state


class PullRun:
    """Pull the stats of missing results from BRAIN one by one (stats and BRAIN's tests only, no correlations), keeping a plain log the UI shows like a terminal.
    `score` / `sleep` are injectable."""

    def __init__(self) -> None:
        self.stop_flag = False
        self.state: dict[str, Any] = {"running": False, "total": 0, "done": 0, "ok": 0, "failed": 0, "current": "", "log": []}

    def stop(self) -> None:
        self.stop_flag = True

    def _log(self, line: str) -> None:
        self.state["log"].append(f"{time.strftime('%H:%M:%S')}  {line}")
        del self.state["log"][:-500]

    def run(self, store, rec_ids: list[int], *, score, delay: float = 1.0, sleep=time.sleep) -> dict:
        ids = list(dict.fromkeys(int(i) for i in rec_ids))
        self.stop_flag = False
        self.state = {"running": True, "total": len(ids), "done": 0, "ok": 0, "failed": 0, "current": "", "log": []}
        self._log(f"pulling stats for {len(ids)} alpha(s) from BRAIN, one at a time (no correlations, no simulations)")
        for n, rid in enumerate(ids, 1):
            if self.stop_flag:
                self._log("stopped")
                break
            rec = store.query("SELECT alpha_id, status FROM harness_sim_record WHERE id=?", (rid,))
            aid = rec[0]["alpha_id"] if rec else ""
            if not aid:
                self._log(f"[{n}/{len(ids)}] record {rid}: no alpha id, nothing to pull (use Requeue)")
                self.state["failed"] += 1
                self.state["done"] = n
                continue
            self.state["current"] = aid
            self._log(f"[{n}/{len(ids)}] {aid}: asking BRAIN for stats ...")
            store.execute("UPDATE harness_sim_record SET status='done', error='' WHERE id=?", (rid,))
            errs: list = []
            t0 = time.time()
            try:
                score(1, errs, [rid])
            except Exception as e:  # noqa: BLE001
                errs.append({"alpha_id": aid, "error": f"{type(e).__name__}: {str(e)[:200]}"})
            row = store.query("SELECT sharpe, fitness, prod_corr, passed_gate, gate_reasons FROM sim_results WHERE alpha_id=? LIMIT 1", (aid,))
            took = f"{time.time() - t0:.1f}s"
            if errs or not row:
                self.state["failed"] += 1
                self._log(f"[{n}/{len(ids)}] {aid}: FAILED in {took}: {errs[0]['error'] if errs else 'BRAIN returned no stats'}")
            else:
                r = {k: row[0][k] for k in row[0].keys()}
                col = color_state(r)
                self.state["ok"] += 1
                fmt = lambda v: "-" if v is None else f"{float(v):.2f}"
                try:
                    import json
                    rs = "; ".join(json.loads(r.get("gate_reasons") or "[]"))
                except Exception:  # noqa: BLE001
                    rs = str(r.get("gate_reasons") or "")
                why = f" ({rs})" if col == "purple" and rs else ""
                self._log(f"[{n}/{len(ids)}] {aid}: Sharpe {fmt(r['sharpe'])} Fitness {fmt(r['fitness'])} -> {col.upper()}{why} in {took}")
            self.state["done"] = n
            if n < len(ids) and delay > 0 and not self.stop_flag:
                sleep(delay)
        self._log(f"done: {self.state['ok']} pulled, {self.state['failed']} failed")
        self.state.update(running=False, current="")
        return self.state


def missing_rows(store, winners: list[dict] | None = None, q: str = "", source: str = "") -> list[dict]:
    """Alphas we know about but Results does not have (engine records with an alpha id, Autosentry/Supersentry winners): shown red in the table."""
    known: dict[str, dict] = {}
    for r in store.query("SELECT alpha_id, task, payload FROM harness_sim_record WHERE alpha_id != '' ORDER BY id DESC LIMIT 3000"):
        if (source == "engine" and r["task"] == "autopilot") or (source == "autosentry" and r["task"] != "autopilot"):
            continue
        try:
            import json
            expr = str(json.loads(r["payload"]).get("regular", ""))
        except Exception:  # noqa: BLE001
            expr = ""
        known.setdefault(r["alpha_id"], {"alpha_id": r["alpha_id"], "expression": expr,
                                         "source": {"autopilot": "Autosentry", "superpilot": "Supersentry"}.get(r["task"], f"Engine: {r['task']}")})
    for w in (winners or []) if source != "engine" else []:
        aid = w.get("alpha_id")
        if aid:
            known.setdefault(aid, {"alpha_id": aid, "expression": w.get("expr", ""), "source": "Autosentry winner"})
            known[aid].update({k: w.get(k) for k in ("sharpe", "fitness", "turnover", "self_corr", "prod_corr", "neutralization") if w.get(k) is not None})
    if not known:
        return []
    from app.harness.store import chunks, marks
    have: set[str] = set()
    for part in chunks(list(known)):
        have |= {x["alpha_id"] for x in store.query(f"SELECT alpha_id FROM sim_results WHERE alpha_id IN ({marks(len(part))})", list(part))}
    needle = q.strip().lower()
    out = []
    for aid, d in known.items():
        if aid in have or (needle and needle not in aid.lower() and needle not in d["expression"].lower()):
            continue
        d.update(missing=True, state="grey", prod_state=prod_state(d.get("prod_corr")))
        out.append(d)
    return out
