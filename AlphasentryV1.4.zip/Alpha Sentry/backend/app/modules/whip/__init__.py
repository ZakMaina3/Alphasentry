"""Whip tab: live backend output + a safe temp-file clean-up (skipped while Autosentry, Supersentry or the engine run)."""
from __future__ import annotations

import json
import tempfile
import threading
import time
from pathlib import Path

from fastapi import APIRouter

from app.core.config import get_settings
from app.whip import cleanup as C, recorder as R

PREFIX = "/api/whip"
router = APIRouter()
R.install()                                    # starts recording as soon as the module is mounted

MIN_GAP_S = 300                                # at most one real clean-up per 5 minutes
_LOCK = threading.Lock()


def _paths():
    s = get_settings()
    root = Path(s.data_dir).resolve().parent
    return root, Path(s.data_dir), Path(tempfile.gettempdir())


def _state_file() -> Path:
    return Path(get_settings().data_dir) / "whip_state.json"


def _load() -> dict:
    try:
        return json.loads(_state_file().read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def _save(d: dict) -> None:
    try:
        f = _state_file(); tmp = f.with_suffix(".json.part")
        tmp.write_text(json.dumps(d), encoding="utf-8"); tmp.replace(f)
    except Exception:  # noqa: BLE001
        pass


def busy() -> list:
    """Which long runs are active right now. A clean-up never runs while any of them is."""
    out = []
    try:
        from app.autopilot import service as A
        if A.live_cfg() is not None or A._HALT.get("resuming"):
            out.append("Autosentry")
    except Exception:  # noqa: BLE001
        pass
    try:
        from app.superpilot import service as SP
        if SP.is_running():
            out.append("Supersentry")
    except Exception:  # noqa: BLE001
        pass
    try:
        from app.modules import harness_engine as HE
        eng = getattr(HE, "_engine", None)
        if eng is not None and getattr(eng, "running", False):
            out.append("SentryEngine")
    except Exception:  # noqa: BLE001
        pass
    return out


@router.get("/logs")
def logs(since: int = 0, limit: int = 400):
    return R.lines(since, max(1, min(2000, limit)))


@router.get("/report")
def report():
    root, data_dir, tmp = _paths()
    items = C.build_plan(root, data_dir, tmp)
    return {**C.summarize(items), "busy": busy(), "last": _load().get("last")}


@router.post("/clean")
def clean():
    with _LOCK:
        b = busy()
        if b:
            return {"ok": False, "skipped": True, "reason": "busy", "message": f"Skipped: {', '.join(b)} running. Stop it and click again."}
        st = _load()
        last = (st.get("last") or {}).get("at") or 0
        if time.time() - last < MIN_GAP_S:
            return {"ok": False, "skipped": True, "reason": "recent",
                    "message": f"Skipped: cleaned {int(time.time() - last)} s ago (at most once per {MIN_GAP_S // 60} min)."}
        root, data_dir, tmp = _paths()
        res = C.run_plan(C.build_plan(root, data_dir, tmp), root, data_dir, tmp)
        res["at"] = time.time()
        res["message"] = (f"Freed {C.human(res['freed'])} ({res['cleaned']} item(s))" if res["cleaned"] else "Nothing to clean.") \
            + (f" · {len(res['skipped'])} skipped (in use)" if res["skipped"] else "")
        st["last"] = res
        _save(st)
        R._add("Whip: " + res["message"], "INFO")
        return {"ok": True, "skipped": False, **res}
