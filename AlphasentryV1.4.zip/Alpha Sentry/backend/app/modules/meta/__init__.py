"""Meta module — app-wide metadata the frontend shell needs at boot: the navigation
map (so the sidebar/header render from one source of truth) and build info.

The navigation map lives on the backend deliberately: as modules come online they can
contribute or gate screens, and the tier/entitlement system can later hide or unlock
routes without a frontend change.
"""

from __future__ import annotations

from fastapi import APIRouter

from app.core.config import get_settings

router = APIRouter()

# groups the sidebar renders, in order. `ready=False` screens show a "coming soon"
# placeholder until their module lands in a later phase.
NAV = [
    {"group": "Overview", "items": [
        {"id": "command", "path": "/", "label": "Command Center", "icon": "grid", "ready": True},
    ]},
    {"group": "Research", "items": [
        {"id": "data", "path": "/data", "label": "Data Explorer", "icon": "database", "ready": True},
        # Strategy Lab absorbs the old Knowledge Graph + Strategy Atlas: semantic + AI per-field
        # hypotheses/operators, composed straight into Alpha Lab.
        {"id": "strategies", "path": "/strategies", "label": "Strategy Lab", "icon": "share", "ready": True},
        {"id": "prompts", "path": "/prompts", "label": "Prompt Library", "icon": "bookmark", "ready": True},
    ]},
    {"group": "Build", "items": [
        {"id": "templates", "path": "/templates", "label": "Template Studio", "icon": "layout", "ready": True},
        # Research Lab merged into this unified workspace: hypotheses/papers -> composed instruction
        # -> validated alphas, all in one screen.
        {"id": "generate", "path": "/generate", "label": "Alpha Lab", "icon": "flask", "ready": True},
        # Autonomous engine: hypotheses -> templates -> simulate batches of 10 -> review -> refine, forever.
        {"id": "autopilot", "path": "/autopilot", "label": "Autosentry", "icon": "sentry-auto", "ready": True},
        {"id": "superpilot", "path": "/super-autopilot", "label": "Supersentry", "icon": "sentry-super", "ready": True},
        # Fast Expression -> Python Alpha (follows the editable translation guideline) + simulation.
        {"id": "pyalpha", "path": "/pyalpha", "label": "Alpha Translation", "icon": "code", "ready": True},
        # BRAIN LLM-prompt submissions: build the prompt, check the sample output, keep the form fields.
        {"id": "brainprompts", "path": "/brain-prompts", "label": "BRAIN Prompts", "icon": "bookmark", "ready": True},
    ]},
    {"group": "Run", "items": [
        {"id": "simulate", "path": "/simulate", "label": "Simulation", "icon": "play", "ready": True},
        {"id": "super", "path": "/super", "label": "SuperAlpha", "icon": "star", "ready": True},
        # SentryEngine labs: Relocate / Repair / Harden / Harvest / Diversify / Pair, batch engine, returns vault + mixing.
        {"id": "harness", "path": "/harness", "label": "SentryEngine", "icon": "sentry-engine", "ready": True},
    ]},
    {"group": "Analyse", "items": [
        {"id": "results", "path": "/results", "label": "Results & Analytics", "icon": "chart", "ready": True},
        {"id": "vault", "path": "/vault", "label": "Alpha Vault", "icon": "bookmark", "ready": True},
        # Osmosis Planner: reads every submitted alpha (read-only) and proposes the 100,000-point allocation per scope.
        # Data Catalog: one-time download of datasets/datafields by region and category; browse and export (shared by all engines).
        {"id": "catalog", "path": "/catalog", "label": "Data Catalog", "icon": "database", "ready": True},
        {"id": "osmosis", "path": "/osmosis", "label": "Osmosis Planner", "icon": "grid2", "ready": True},
        {"id": "portfolio", "path": "/portfolio", "label": "Correlation & Portfolio", "icon": "grid2", "ready": True},
        {"id": "operators", "path": "/operators", "label": "Operator Atlas", "icon": "list", "ready": True},
        {"id": "regions", "path": "/regions", "label": "R & U Atlas", "icon": "globe", "ready": True},
    ]},
    {"group": "Tools", "items": [
        {"id": "whip", "path": "/whip", "label": "Whip", "icon": "whip", "ready": True},
    ]},
    # Settings lives on the header (gear icon) and Success is reached from there — neither clutters
    # the sidebar. Their routes still exist; they are just not sidebar entries.
]


@router.get("/nav")
def nav():
    return {"nav": NAV}


@router.get("/info")
def info():
    s = get_settings()
    return {"app": s.app_name, "version": s.version}


@router.get("/jobs")
def jobs_list(limit: int = 40):
    """All recent background jobs (running first) for the global job tray."""
    from app.core.jobs import jobs
    return {"jobs": jobs.list_recent(limit)}
