"""Autosentry module — start/stop/inspect the autonomous alpha engine."""

from __future__ import annotations

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from pydantic import BaseModel

from app.autopilot import library as K
from app.autopilot import service
from app.core.jobs import jobs

PREFIX = "/api/autopilot"
router = APIRouter()


class StartReq(BaseModel):
    region: str = "USA"
    delay: int = 1
    instrument: str = "EQUITY"
    universe: str = "TOP3000"
    neutralizations: list[str] = ["INDUSTRY"]
    decay: int = 4
    truncation: float = 0.08
    batch_size: int = 10
    max_rounds: int = 4
    templates_per_round: int = 6
    max_operators: int = 4
    allow_two_field: bool = True
    winners_per_hypothesis: int = 1
    concurrency: int = 1
    prod_rescue_max: float = 0.74     # do not try to lower prod correlation above this
    stall_minutes: int = 30           # stop and notify when a step makes no progress for this long (0 = off)
    prod_check_delay: int = 60        # seconds to wait before each production-correlation check (0 = none)
    goal: str = ""
    tag: str = ""
    winner_tag: str = ""
    min_sharpe: float | None = None
    min_fitness: float | None = None
    max_turnover: float = 0.70
    max_corr: float = 0.70
    max_cycles: int = 0          # 0 = run forever
    max_winners: int = 0         # 0 = run forever
    pause_between_cycles: int = 5
    fields: list[dict] = []
    categories: dict[str, str] = {}
    use_library: bool = True        # feed uploaded alphas/templates/papers/notes + lessons to the LLM
    seed_run: bool = True           # simulate library alphas once before new research starts
    boost: bool = True              # boost every alpha with Sharpe above the trigger (runs in the next standard batch)
    booster_trigger: float = 1.0    # default Sharpe trigger (a booster's own min_sharpe wins)
    flip: bool = True               # reverse an alpha only when its Sharpe is below -flip_min_sharpe (runs in the next standard batch)
    flip_min_sharpe: float = 1.0    # reverse only when Sharpe < -this
    builtin_boosters: bool = True   # built-in starter boosters, only when your library has none for the region
    booster_own_limit: bool = False  # False: one Sharpe threshold; True: a booster's own limit also applies
    boost_top: int = 3              # boosters tried per alpha (plus one exploratory)
    boost_near_miss: float = 0.0    # also boost alphas this far below the trigger (0 = off)
    boost_winners: bool = False     # also try boosting alphas that already pass everything
    nudge: bool = True              # window nudges on promising alphas
    queue_cap: int = 30             # most follow-ups waiting at once
    triage: bool = True             # drop an idea after its first batch if nothing reaches triage_sharpe
    triage_rounds: int = 1
    triage_sharpe: float = 0.5
    hypotheses_per_call: int = 8
    method: str = "explore"          # "explore" = LLM ideas, "clone" = swap similar datafields into old alphas
    clone_sources: list[str] = ["submitted", "vault"]
    clone_min_sharpe: float = 1.0
    clone_similarity: float = 0.5    # 0 = same dataset only, 1 = other datasets only
    clone_per_alpha: int = 10
    clone_max_sources: int = 30
    clone_ids: list[str] = []        # optional: only these alpha ids
    clone_pasted: str = ""           # your own working alphas, pasted as text (one per line)
    decorrelate: bool = True        # prod-corr rescue: cross-neutralization, then sister/brother operators
    decorr_rounds: int = 2          # operator-swap rounds
    decorr_max_neuts: int = 6       # cross-neutralization options to try
    framework_ids: list[int] = []   # uploaded frameworks to follow; several = cycle through them (each with its own region)
    fw_categories: list[str] = []   # data categories to draw datafields from (besides the frameworks' own)
    fw_pairs: list[list[str]] = []  # category combinations you chose; empty = any pair the pairing rules allow
    min_field_alphas: int | None = None   # only datafields used by at least / at most this many alphas
    max_field_alphas: int | None = None
    fw_lanes: int = 1               # Framework method: 1 or 2 frameworks at a time (sharing the engine slots)
    fw_hypotheses: int = 3          # with several frameworks: hypotheses on one framework before the next


@router.post("/start")
def start(req: StartReq):
    try:
        return service.start(req.model_dump())
    except RuntimeError as e:
        raise HTTPException(400, str(e))


class ClonePreviewReq(BaseModel):
    text: str = ""
    region: str = "USA"
    delay: int = 1


@router.post("/clone/preview")
def clone_preview(req: ClonePreviewReq):
    """What the pasted alphas look like to Clone and swap: how many were recognised and how many can be swapped."""
    from app.autopilot import clone as CL
    try:
        catalog = service._catalog_rows({"region": req.region, "delay": req.delay})
    except Exception:  # noqa: BLE001
        catalog = []
    d = CL.describe_pasted(req.text, catalog)
    d["catalog_fields"] = len(catalog)
    return d


@router.post("/stop")
def stop():
    return {"cancelled": service.stop()}


@router.get("/status")
def status():
    return service.status()


@router.post("/reset")
def reset():
    """Clear the winners/hypothesis history (does not touch stored simulation results)."""
    return service.reset_state()


# ── Library: working alphas, templates, papers, boosters, notes ──────────────────────

class AssetReq(BaseModel):
    kind: str
    body: str
    name: str = ""
    meta: dict = {}
    bulk: bool = False          # one asset per line


class AssetPatch(BaseModel):
    name: str | None = None
    body: str | None = None
    enabled: bool | None = None
    meta: dict | None = None


@router.get("/library")
def library(kind: str = "", engine: str = ""):
    """engine="auto" | "super": only that engine's library (plus shared items); empty = everything."""
    return {"items": K.list_assets(kind or None, engine=engine or None), "summary": K.summary()}


@router.post("/library")
def library_add(req: AssetReq):
    if req.bulk:
        r = K.bulk_add(req.kind, req.body, req.meta)
        if not r["added"] and not r["duplicates"]:
            raise HTTPException(400, "; ".join(r["rejected"][:3]) or "nothing to add")
        return r
    r = K.add_asset(req.kind, req.body, req.name, req.meta)
    if r.get("error"):
        raise HTTPException(400, r["error"])
    return r


@router.patch("/library/{aid}")
def library_patch(aid: int, req: AssetPatch):
    r = K.update_asset(aid, req.model_dump())
    if r.get("error"):
        raise HTTPException(400, r["error"])
    return r


class RegionToggle(BaseModel):
    kind: str
    region: str
    on: bool
    known: list[str] = []          # the regions on offer, so that "all ticked" is stored as "no restriction"
    ids: list[int] = []


@router.post("/library/regions")
def library_regions(req: RegionToggle):
    """Tick or untick one region for every item of a kind (or just `ids`)."""
    if req.kind not in ("alpha", "booster"):
        raise HTTPException(400, "Regions can be set for alphas and boosters.")
    r = K.toggle_region(req.kind, req.region, req.on, req.known, req.ids or None)
    if r.get("error"):
        raise HTTPException(400, r["error"])
    return r


@router.delete("/library/{aid}")
def library_delete(aid: int):
    return K.delete_asset(aid)


@router.post("/library/paper")
async def library_paper(file: UploadFile = File(...), pages: str = Form(""), name: str = Form("")):
    """Upload a paper (PDF, or .txt/.md). Its text is stored and an LLM digest of the tradeable
    ideas is created (best effort) so the engine can use it in every future run."""
    data = await file.read()
    fname = file.filename or "paper"
    try:
        if fname.lower().endswith(".pdf"):
            from app.research import service as RS
            text = RS.extract_pdf_text(data, pages)
        else:
            text = data.decode("utf-8", errors="ignore")
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, f"Could not read that file ({e}).")
    text = (text or "").strip()
    if not text:
        raise HTTPException(400, "No selectable text found (is it a scan?).")
    r = K.add_asset("paper", text[:120000], name=(name or fname)[:120])
    if r.get("duplicate"):
        return r
    r["digest_ok"] = _make_digest(r["id"], text, r["name"])
    return K.list_assets("paper")[0] if r["digest_ok"] else r


def _make_digest(aid: int, text: str, name: str) -> bool:
    try:
        res = service._llm(
            "Distil this research paper for a WorldQuant BRAIN alpha researcher. Return ONLY a JSON array "
            "of 5-8 strings; each string is ONE tradeable idea in this form: signal idea — mechanism — "
            "which kinds of datafields express it — expected sign — practical notes (windows, "
            f"normalisation, turnover).\n=== PAPER: {name} ===\n{text[:30000]}", 8)
        items = [str(x).strip() for x in res.expressions if str(x).strip()]
        if items:
            K.update_asset(aid, {"digest": "\n".join(f"- {x}" for x in items)})
            return True
    except Exception:
        pass
    return False


@router.post("/library/{aid}/digest")
def library_redigest(aid: int):
    a = K.get_asset(aid)
    if not a or a.kind != "paper":
        raise HTTPException(404, "no such paper")
    if not _make_digest(aid, a.body, a.name):
        raise HTTPException(400, "Could not create a digest (is an LLM key set up in Settings?).")
    return {"ok": True}


# ── Learning memory ──────────────────────────────────────────────────────────────────

class LessonReq(BaseModel):
    text: str
    kind: str = "insight"
    region: str = ""
    pinned: bool = True


@router.get("/lessons")
def lessons(region: str = ""):
    return {"items": K.list_lessons(region), "summary": K.summary()}


@router.post("/lessons")
def lessons_add(req: LessonReq):
    r = K.add_lesson(req.text, req.kind, req.region, source="user", pinned=req.pinned)
    if r.get("error"):
        raise HTTPException(400, r["error"])
    return r


@router.post("/lessons/{lid}/pin")
def lessons_pin(lid: int, pinned: bool = True):
    return K.set_pinned(lid, pinned)


@router.delete("/lessons/{lid}")
def lessons_delete(lid: int):
    return K.delete_lesson(lid)
