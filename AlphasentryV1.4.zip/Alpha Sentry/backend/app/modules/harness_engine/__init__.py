"""SentryEngine module: flags, batch engine control, queue. Gated by the `harness_engine` flag
(default OFF). Existing Alpha Sentry simulation/Autosentry are untouched. NOTE: no submit route lives here."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

import logging
import threading
import time

from app.core.jobs import jobs
from app.harness import flags
from app.harness.api_common import ScopeBase, need_flag
from app.harness.store import check_ace_schema, default_store, ensure_tables

PREFIX = "/api/harness_engine"
router = APIRouter()

_engine = None
_job_id: str | None = None


def on_startup() -> None:
    ensure_tables(default_store())
    for problem in check_ace_schema(default_store()):
        logging.getLogger(__name__).warning("harness: %s", problem)


def _tracker():
    from pathlib import Path
    from app.core.config import get_settings
    from app.harness.engine.tracker import Tracker
    return Tracker(default_store(), Path(get_settings().data_dir) / "harness" / "inflight.jsonl")


_runner_inst = None
_init_lock = threading.Lock()


def _focus():
    from pathlib import Path
    from app.core.config import get_settings
    from app.harness.engine.focus import Focus
    return Focus(Path(get_settings().data_dir) / "harness" / "engine_focus.json")


def _get_engine():
    global _engine, _runner_inst
    with _init_lock:                                  # sync endpoints run in a thread pool: two first calls must not build two runners
        if _engine is None:
            from app.harness.engine.batch import BatchEngine
            from app.harness.scoring import score_pending
            from app.harness.tasks import TaskRunner
            tracker = _tracker()
            _runner_inst = TaskRunner(default_store(), tracker)
            _engine = BatchEngine(tracker, scorer=score_pending, ticker=_runner_inst.tick, focus=_focus(),
                                 on_foreign=lambda region: _runner_inst.pause_other_markets(keep_region=region))   # tasks advance while the engine runs
    return _engine


def _get_runner():
    _get_engine()
    return _runner_inst


class FlagReq(BaseModel):
    name: str
    value: bool


class EnqueueReq(BaseModel):
    task: str = "manual"
    payloads: list[dict]


class DryReq(BaseModel):
    on: bool


@router.get("/status")
def status():
    out = {"flags": flags.get_all()}
    if _engine is not None:
        out["engine"] = _engine.status()
    return out


@router.post("/flags")
def set_flag(req: FlagReq):
    try:
        return {"flags": flags.set_flag(req.name, req.value)}
    except KeyError:
        raise HTTPException(404, f"unknown flag {req.name!r}")


@router.post("/start")
def start():
    global _job_id
    need_flag("harness_engine")
    eng = _get_engine()
    if eng.running:
        return {"started": False, "message": "already running", "job_id": _job_id}
    _job_id = jobs.submit("harness_engine", lambda progress, cancelled: eng.run(progress, cancelled))
    return {"started": True, "job_id": _job_id}


@router.post("/stop")
def stop():
    if _engine is not None:
        _engine.stop()
    if _job_id:
        jobs.cancel(_job_id)
    return {"stopped": True}


@router.post("/dry_run")
def dry_run(req: DryReq):
    _get_engine().dry_run = bool(req.on)
    return {"dry_run": _get_engine().dry_run}


@router.post("/enqueue")
def enqueue(req: EnqueueReq):
    """Queue simulations (deduplicated). Free: nothing is spent until the engine runs them."""
    need_flag("harness_engine")
    return _get_engine().tracker.enqueue_many(req.task, req.payloads)


@router.post("/cancel_task")
def cancel_task(task: str):
    need_flag("harness_engine")
    return {"cancelled": _get_engine().tracker.cancel_task(task)}


class ResetReq(BaseModel):
    restart: bool = True              # start a fresh engine straight away (it has nothing queued, so nothing is simulated until you queue work)


@router.post("/reset")
def reset(req: ResetReq):
    """Clean slate: stop the engine, cancel everything it has queued or running, stop its search tasks, forget its crash journal and its
    focus / learned slot limit, discard the engine object and (by default) start a new one. Never touches results, the vault, your library
    or Autosentry's own running batches, and never submits anything."""
    global _engine, _runner_inst, _job_id
    need_flag("harness_engine")
    import time as _time
    runner = _get_runner()
    eng = _engine
    out: dict = {}
    eng.stop()
    if _job_id:
        jobs.cancel(_job_id)
    out["tasks_stopped"] = runner.stop_all()
    out.update(runner.tracker.reset_all())            # cancels the records first, so batches still waiting on BRAIN stop waiting
    out.update(eng.reset())
    for _ in range(80):                               # let the old loop finish (up to 8 s); it is cut loose either way
        if not eng.running:
            break
        _time.sleep(0.1)
    out["old_loop_stopped"] = not eng.running
    _focus().set("")
    try:
        from app.harness import speed
        speed.reset_ceiling()
    except Exception:  # noqa: BLE001
        pass
    with _init_lock:
        _engine = _runner_inst = None
        _job_id = None
    out["restarted"] = False
    if req.restart:
        fresh = _get_engine()
        _job_id = jobs.submit("harness_engine", lambda progress, cancelled: fresh.run(progress, cancelled))
        out["restarted"] = True
        out["job_id"] = _job_id
    return out


# ── Queue by region: see what is waiting, drop it, or focus the engine on one market ─────────────
@router.get("/queue")
def queue_overview():
    """Queued / running simulations per region and delay, and the engine's current focus."""
    tr = _get_engine().tracker
    return {"by_region": tr.region_counts(), "focus": _focus().get(), "counts": tr.counts()}


class DropReq(BaseModel):
    region: str
    delay: int | None = None
    pause_tasks: bool = True          # also pause the search tasks of that market, or they refill what you just dropped
    include_running: bool = True      # also abandon simulations already sent to BRAIN (the engine stops waiting and ignores their results)


@router.post("/queue/drop")
def queue_drop(req: DropReq):
    """Drop the simulations of one region: queued ones are removed, ones already at BRAIN are abandoned (nothing is submitted)."""
    need_flag("harness_engine")
    eng = _get_engine()
    out = eng.tracker.drop_queued(region=req.region, delay=req.delay, include_running=req.include_running)
    paused = _get_runner().pause_other_markets(only_region=req.region, only_delay=req.delay) if req.pause_tasks else 0
    return {**out, "paused_tasks": paused}


class FocusReq(BaseModel):
    region: str = ""                  # empty = no focus (every market runs)
    delay: int | None = None
    drop_others: bool = False         # cancel the queued simulations of every other market now
    pause_others: bool = True         # pause the search tasks of other markets so they stop refilling the queue


@router.get("/focus")
def focus_get():
    f = _focus()
    return {"focus": f.get(), "follow": f.follow()}


class FollowReq(BaseModel):
    region: str                       # the region chosen in Autosentry
    delay: int | None = None


@router.post("/focus/follow")
def focus_follow(req: FollowReq):
    """Called whenever the region chosen in Autosentry changes (and at start-up). With 'follow' on (default) the engine switches to that
    region and every other region's QUEUED simulations are dropped immediately and their search tasks paused. Batches already running at
    BRAIN finish normally. With follow off this does nothing."""
    f = _focus()
    if not f.follow() or not req.region.strip():
        return {"followed": False, "focus": f.get(), "follow": f.follow()}
    f.set(req.region, None)                          # by region: both delays of it are kept
    reg = f.get()["region"]
    out = {"followed": True, "focus": f.get(), "follow": True, "dropped": 0, "paused_tasks": 0}
    if flags.enabled("harness_engine"):
        out["dropped"] = _get_engine().tracker.drop_queued(keep_region=reg)["dropped"]
        out["paused_tasks"] = _get_runner().pause_other_markets(keep_region=reg)
    return out


class FollowSetReq(BaseModel):
    on: bool


@router.post("/focus/follow_setting")
def focus_follow_setting(req: FollowSetReq):
    return {"follow": _focus().set_follow(req.on)}


@router.post("/focus")
def focus_set(req: FocusReq):
    """Point the engine at one market. Other markets are parked (kept queued) unless `drop_others` is set. Safe to call while running."""
    f = _focus().set(req.region, req.delay)
    out: dict = {"focus": f, "dropped": 0, "paused_tasks": 0}
    if f["region"]:
        if req.drop_others:
            need_flag("harness_engine")
            out["dropped"] = _get_engine().tracker.drop_queued(keep_region=f["region"], keep_delay=f["delay"], include_running=True)["dropped"]
        if req.pause_others:
            out["paused_tasks"] = _get_runner().pause_other_markets(keep_region=f["region"], keep_delay=f["delay"])
    return out


# ── Relocate lab (free preview + queue; never submits) ────────────────────────────────────────
class RelocateReq(ScopeBase):
    min_sharpe: float = 1.0
    limit: int = 20
    neutralizations: list[str] = ["SUBINDUSTRY"]
    target: int = 500


def _relocate_plan(req: RelocateReq) -> dict:
    from app.harness.labs import ace_sources as src
    from app.harness.labs.relocate import plan
    origin = req.scope()
    return plan(origin=origin, winners=src.winners(origin, req.min_sharpe, req.limit), scopes=src.scopes(),
                fields_in_scope=src.fields_in_scope, leaf_idents=src.leaf_idents,
                neutralizations=req.neutralizations, target=req.target)


@router.post("/relocate/preview")
def relocate_preview(req: RelocateReq):
    """Free: shows exactly what a run would queue and which moves are impossible (and why)."""
    need_flag("harness_engine")
    p = _relocate_plan(req)
    return {**p, "requests": len(p["requests"])}


@router.post("/relocate/run")
def relocate_run(req: RelocateReq):
    """Queue the possible moves on the harness engine (deduplicated). Spends quota only when the engine runs."""
    need_flag("harness_engine")
    p = _relocate_plan(req)
    out = _get_engine().tracker.enqueue_many("relocate", p["requests"])
    return {"possible": p.get("possible", 0), "blocked": p.get("blocked", 0), **{k: out[k] for k in ("queued", "duplicates")}}


# ── Repair lab (free preview + queue; never submits) ──────────────────────────────────────────
class RepairReq(ScopeBase):
    target: int = 300
    checks: list[str] = []
    seeds: int = 40


def _repair_plan(req: RepairReq) -> dict:
    from app.harness.labs import ace_sources as src
    from app.harness.labs.repair import plan
    scope = req.scope()
    unis, neuts = src.legal_settings(scope)
    rows = src.repair_rows(scope)
    partners: dict = {}
    if flags.enabled("harness_vault"):      # self-correlation fixes need the returns vault
        try:
            from app.harness.vault import ace_vault
            wanted = {str(r["alpha_id"]) for r in rows if "SELF_CORRELATION" in str(r.get("checks"))}
            partners = ace_vault.closest_partners(scope.region, scope.delay, scope.universe, wanted)
        except Exception:  # noqa: BLE001
            partners = {}
    from app.harness.plan.skeletons import skeleton
    sat, _sk = src.ledger_args(scope)
    return plan(scope=scope, rows=rows, target=req.target, checks=req.checks or None, seeds=req.seeds,
                universes=unis, neutralizations=neuts, partners=partners, saturated_shapes=sat,
                skeleton_of=skeleton if sat else None)


@router.post("/repair/preview")
def repair_preview(req: RepairReq):
    """Free of simulation quota: reads each near miss's failed checks (cached) and shows the one change each needs."""
    need_flag("harness_engine")
    p = _repair_plan(req)
    return {**p, "requests": len(p["requests"])}


@router.post("/repair/run")
def repair_run(req: RepairReq):
    need_flag("harness_engine")
    p = _repair_plan(req)
    out = _get_engine().tracker.enqueue_many("repair", p["requests"])
    return {"nearMisses": p["nearMisses"], **{k: out[k] for k in ("queued", "duplicates")}}


# ── Harden lab (free preview + queue; never submits) ──────────────────────────────────────────
class HardenReq(ScopeBase):
    min_sharpe: float = 1.25
    limit: int = 10
    target: int = 300


def _harden_plan(req: HardenReq) -> dict:
    from app.harness.labs import ace_sources as src
    from app.harness.labs.harden import plan
    scope = req.scope()
    return plan(scope=scope, rows=src.strong_rows(scope, req.min_sharpe, req.limit), target=req.target)


@router.post("/harden/preview")
def harden_preview(req: HardenReq):
    need_flag("harness_engine")
    p = _harden_plan(req)
    return {**p, "requests": len(p["requests"])}


@router.post("/harden/run")
def harden_run(req: HardenReq):
    need_flag("harness_engine")
    p = _harden_plan(req)
    out = _get_engine().tracker.enqueue_many("harden", p["requests"])
    return {"alphas": p.get("alphas", 0), **{k: out[k] for k in ("queued", "duplicates")}}


# ── Harvest (Sweep) + Diversify labs ──────────────────────────────────────────────────────────
class HarvestReq(ScopeBase):
    target: int = 1000
    patterns: list[str] = []
    windows: list[int] = []
    fields: list[str] = []
    group: str = "industry"
    neutralization: str = "SUBINDUSTRY"
    per_dataset: int = 1
    min_alphas: int = 3
    max_alphas: int | None = None
    skip: int = 0


def _harvest(req: HarvestReq):
    from app.harness.labs import ace_sources as src
    sc = req.scope()
    try:
        return src.harvester(sc).harvest(sc, target=req.target, patterns=req.patterns or None, windows=req.windows or None,
                                         fields=req.fields or None, group=req.group, neutralization=req.neutralization,
                                         per_dataset=req.per_dataset, min_alphas=req.min_alphas,
                                         max_alphas=req.max_alphas, skip=req.skip)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/harvest/preview")
def harvest_preview(req: HarvestReq):
    """Free: what a plain-pattern sweep over this scope would queue (fields x shapes x windows)."""
    need_flag("harness_engine")
    return _harvest(req).summary()


@router.post("/harvest/run")
def harvest_run(req: HarvestReq):
    need_flag("harness_engine")
    h = _harvest(req)
    out = _get_engine().tracker.enqueue_many("harvest", h.requests)
    return {"truncated": h.truncated, **{k: out[k] for k in ("queued", "duplicates")}}


def _diversify_plan(req: HarvestReq) -> dict:
    from app.harness.labs import ace_sources as src
    from app.harness.labs.diversify import plan
    sc = req.scope()
    return plan(scope=sc, expressions=src.scope_expressions(sc), dataset_of_field=lambda ids: src.dataset_of_field(sc, ids),
                fresh_fields=lambda w, pd, lim: src.fresh_fields(sc, w, pd, lim), harvester=src.harvester(sc),
                target=req.target, per_dataset=req.per_dataset, patterns=req.patterns or None,
                windows=req.windows or None, neutralization=req.neutralization)


@router.post("/diversify/preview")
def diversify_preview(req: HarvestReq):
    need_flag("harness_engine")
    p = _diversify_plan(req)
    return {**p, "harvest": p["harvest"].summary() if p["harvest"] else None}


@router.post("/diversify/run")
def diversify_run(req: HarvestReq):
    need_flag("harness_engine")
    p = _diversify_plan(req)
    if not p["harvest"]:
        return {"queued": 0, "duplicates": 0, "note": p["note"]}
    out = _get_engine().tracker.enqueue_many("diversify", p["harvest"].requests)
    return {"freshDatasets": p["freshDatasets"], **{k: out[k] for k in ("queued", "duplicates")}}


# ── Pair lab ──────────────────────────────────────────────────────────────────────────────────
class PairReq(ScopeBase):
    target: int = 500
    shapes: list[str] = []
    windows: list[int] = []
    group: str = "subindustry"
    neutralization: str = "SUBINDUSTRY"
    decay: int = 4
    truncation: float = 0.08
    per_dataset: int = 1
    seed: int | None = None


def _pair_plan(req: PairReq) -> dict:
    from app.harness.labs import ace_sources as src
    from app.harness.labs.pair import plan
    sc = req.scope()
    sat, sk = src.ledger_args(sc)
    try:
        return plan(scope=sc, fields_provider=lambda pd: src.pair_fields(sc, pd), target=req.target,
                    saturated_shapes=sat, skeleton_of=sk,
                    shapes=req.shapes or None, windows=req.windows or None, group=req.group,
                    neutralization=req.neutralization, decay=req.decay, truncation=req.truncation,
                    per_dataset=req.per_dataset, seed=req.seed, known_operators=src.known_operators())
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/pair/preview")
def pair_preview(req: PairReq):
    need_flag("harness_engine")
    p = _pair_plan(req)
    return {**p, "requests": len(p["requests"])}


@router.post("/pair/run")
def pair_run(req: PairReq):
    need_flag("harness_engine")
    p = _pair_plan(req)
    out = _get_engine().tracker.enqueue_many("pair", p["requests"])
    return {"possible": p["possible"], **{k: out[k] for k in ("queued", "duplicates")}}


@router.post("/score")
def score_now(limit: int = 5000):
    """Score finished simulations into Alpha Sentry's Results now (BRAIN reads only; no sim quota)."""
    need_flag("harness_engine")
    from app.harness.scoring import score_pending
    errs: list = []
    return {**score_pending(limit, errors_out=errs), "errors": errs}


class LedgerReq(ScopeBase):
    days: int = 30


@router.post("/plan/skeletons")
def skeleton_ledger(req: LedgerReq):
    """Which alpha SHAPES this market has already answered (planning ledger). Labs drop saturated shapes
    only when the `harness_planning` flag is on."""
    from app.harness.labs import ace_sources as src
    recs = src.shape_records(req.scope(), req.days)
    rows = sorted((r.to_dict() for r in recs.values()), key=lambda r: (-r["tried"], r["shape"]))
    return {"shapes": rows[:200], "saturated": [r for r in rows if r["saturated"]][:100],
            "enabled": flags.enabled("harness_planning")}


@router.get("/plan/yields")
def yields(days: int = 14):
    """Which lab turns simulations into passing alphas best (measures only; allocates nothing)."""
    from app.harness.plan import yields as Y
    return Y.summary(default_store(), days=max(1, min(days, 90)))


# ── Tasks: template search (Search / Template / Power Pool labs) ──────────────────────────────
class TemplateReq(ScopeBase):
    template: str


class TaskReq(TemplateReq):
    lab: str = "search"
    name: str = ""
    sampler: str = "nsga2"
    objectives: list[str] = ["fitness"]
    budget: int = 100
    batch: int = 10
    cores: int = 2
    seed: int | None = None
    params: dict = {}


def _template(req: TemplateReq):
    from app.harness.labs import ace_sources as src
    from app.harness.templates import spec as T
    try:
        spec = T.parse(req.template)
    except T.TemplateError as e:
        raise HTTPException(422, str(e))
    sc = req.scope()
    return spec, sc, (lambda v: src.template_fields(sc, v))


@router.get("/optimizers")
def optimizers():
    """Samplers, objectives and which optimizer backend is in use (Optuna is used automatically when installed)."""
    from app.harness import optimize as O
    from app.harness.optimize import objectives as OB, optuna_backend
    return {"samplers": O.catalogue(), "objectives": OB.catalogue(), "backend": O.default_backend(),
            "optunaInstalled": optuna_backend.available(), "defaultObjectives": list(OB.DEFAULT_OBJECTIVES)}


@router.get("/templates/presets")
def template_presets():
    """Ready-made starter templates (with a suggested sampler, objectives and budget) for the Tasks tab."""
    from app.harness.templates import presets
    return {"presets": presets.catalogue()}


@router.post("/templates/preview")
def template_preview(req: TemplateReq):
    """Free: parse the template, show the search space, which data fields each variable resolves to, and sample alphas."""
    need_flag("harness_engine")
    from app.harness import optimize as O
    from app.harness.templates import realise as R
    spec, sc, prepared = _template(req)
    out = R.summary(spec, prepared)
    fields = {n: len(v.values) if v.values else len(prepared(v)) for n, v in spec.vars.items() if v.type == "datafield" and n not in spec.unused_vars}
    out["fields"] = fields
    out["problems"] = [f"No data fields match ${n} in this market (download data in Data Explorer, or loosen the filters)." for n, c in fields.items() if c == 0]
    space = R.build_space(spec, prepared)
    sample = []
    if space:
        for _, p in O.make_optimizer("random", space, ["maximize"], backend="builtin", seed=1).ask(3):
            payload = R.realise(spec, p, sc, prepared)
            sample.append({"expression": payload["regular"], "settings": payload["settings"], "breaks": R.problems(payload["regular"], spec)})
    out["sample"] = sample
    return out


@router.post("/tasks")
def task_create(req: TaskReq):
    """Create a search task. It advances whenever the engine is running and never submits anything."""
    need_flag("harness_engine")
    from app.harness.tasks import TaskError
    spec, sc, prepared = _template(req)
    try:
        return _get_runner().create(lab=req.lab, name=req.name, spec=spec, scope=sc, sampler=req.sampler, objectives=req.objectives,
                                    budget=req.budget, batch=req.batch, cores=req.cores, seed=req.seed, params=req.params or None,
                                    prepared=prepared)
    except TaskError as e:
        raise HTTPException(422, str(e))


@router.get("/tasks")
def task_list():
    return {"tasks": _get_runner().list_tasks()}


@router.get("/tasks/{task_id}")
def task_detail(task_id: int):
    d = _get_runner().detail(task_id)
    if d is None:
        raise HTTPException(404, "No such task.")
    return d


def _task_action(task_id: int, fn):
    from app.harness.tasks import TaskError
    try:
        return fn(_get_runner())
    except TaskError as e:
        raise HTTPException(409, str(e))


@router.post("/tasks/{task_id}/pause")
def task_pause(task_id: int):
    return _task_action(task_id, lambda r: r.set_status(task_id, "paused"))


@router.post("/tasks/{task_id}/resume")
def task_resume(task_id: int):
    return _task_action(task_id, lambda r: r.set_status(task_id, "running"))


@router.post("/tasks/{task_id}/stop")
def task_stop(task_id: int):
    return _task_action(task_id, lambda r: r.stop(task_id))


@router.delete("/tasks/{task_id}")
def task_remove(task_id: int):
    _get_runner().remove(task_id)
    return {"removed": task_id}


# ── B1 Template lab (grid sweep) ──────────────────────────────────────────────────────────────
class SweepReq(TemplateReq):
    name: str = ""
    objectives: list[str] = ["sharpe"]
    budget: int | None = None            # most simulations you are willing to spend (the template's own cap always applies)
    batch: int = 10
    cores: int = 2
    seed: int | None = None


@router.post("/template/preview")
def sweep_preview(req: SweepReq):
    """Free: the grid size, whether it fits, what would never be tried, plus the usual template preview."""
    need_flag("harness_engine")
    from app.harness.labs import sweep
    out = template_preview(req)
    spec, _, prepared = _template(req)
    try:
        out["sweep"] = sweep.plan(spec, prepared, budget=req.budget, batch=req.batch)
        out["sweepError"] = None
    except sweep.SweepError as e:
        out["sweep"], out["sweepError"] = None, str(e)
    return out


@router.post("/template/run")
def sweep_run(req: SweepReq):
    """Create a sweep task: every combination exactly once (lab "template", exhaustive sampler). Queue-only; never submits."""
    need_flag("harness_engine")
    from app.harness.labs import sweep
    from app.harness.tasks import TaskError
    spec, sc, prepared = _template(req)
    try:
        plan = sweep.plan(spec, prepared, budget=req.budget, batch=req.batch)
        made = _get_runner().create(lab="template", name=req.name, spec=spec, scope=sc, sampler="brute", objectives=req.objectives,
                                    budget=plan["budget"], batch=req.batch, cores=req.cores, seed=req.seed, prepared=prepared)
    except (sweep.SweepError, TaskError) as e:
        raise HTTPException(422, str(e))
    return {**made, "sweep": plan}


# ── B2 Power Pool view ────────────────────────────────────────────────────────────────────────
@router.get("/tasks/{task_id}/power_pool")
def task_power_pool(task_id: int):
    """Which finished alphas of this task could go into the Power Pool (Sharpe, operator / field limits, pool correlation)."""
    v = _get_runner().power_pool_view(task_id)
    if v is None:
        raise HTTPException(404, "No such task.")
    return v


# ── B5 Search polish: sampler advice and saved searches ───────────────────────────────────────
class RecommendReq(TemplateReq):
    objectives: list[str] = ["fitness"]
    budget: int = 50


@router.post("/templates/recommend")
def template_recommend(req: RecommendReq):
    """Free: which sampler suits this template, objectives and budget, and why. Advice only."""
    need_flag("harness_engine")
    from app.harness.optimize import optuna_backend, space as sp
    from app.harness.templates import advice, realise as R
    spec, _, prepared = _template(req)
    space = R.build_space(spec, prepared)
    all_continuous = bool(space) and all(s["kind"] == "float" and not s.get("step") for s in space.values())
    return advice.recommend(grid_size=sp.grid_size(space), dims=len(space), objectives=max(1, len(req.objectives)), budget=req.budget,
                            optuna=optuna_backend.available(), all_continuous=all_continuous)


class SavedReq(BaseModel):
    name: str
    template: str
    sampler: str = ""
    objectives: list[str] = []
    budget: int = 50
    batch: int = 10
    cores: int = 2
    seed: int | None = None
    region: str = ""
    delay: int = 1
    universe: str = "TOP3000"


@router.get("/saved")
def saved_list():
    from app.harness import saved
    return {"saved": saved.list_all(default_store())}


@router.post("/saved")
def saved_save(req: SavedReq):
    """Save (or overwrite, by name) a template with the sampler / objectives / budget / market to run it with."""
    from app.harness import saved
    try:
        return saved.save(default_store(), req.name, req.template, sampler=req.sampler, objectives=req.objectives, budget=req.budget,
                          batch=req.batch, cores=req.cores, seed=req.seed,
                          scope={"region": req.region, "delay": req.delay, "universe": req.universe})
    except ValueError as e:
        raise HTTPException(422, str(e))


@router.delete("/saved/{saved_id}")
def saved_delete(saved_id: int):
    from app.harness import saved
    if not saved.delete(default_store(), saved_id):
        raise HTTPException(404, "No such saved search.")
    return {"removed": saved_id}


# ── B3 Deepen ─────────────────────────────────────────────────────────────────────────────────
class DeepenReq(ScopeBase):
    expression: str = ""
    alpha_id: str = ""
    radius: int = 2
    windows: bool = True
    operators: bool = True
    wrapper: bool = True
    vary_decay: bool = False
    vary_neutralization: bool = False
    neutralization: str = ""
    decay: int = 0
    max_simulations: int = 200
    name: str = ""
    objectives: list[str] = ["sharpe"]
    batch: int = 10
    cores: int = 2
    seed: int | None = None


def _deepen_plan(req: DeepenReq):
    from app.harness.labs import ace_sources as src, deepen as D
    from app.harness.templates import spec as T
    expr, neut = req.expression.strip(), req.neutralization
    if req.alpha_id:
        row = src.alpha_row(req.alpha_id)
        if row is None and not expr:
            raise HTTPException(404, f"Alpha {req.alpha_id} is not in Results.")
        if row is not None:
            expr = expr or row["expression"]
            neut = neut or row["neutralization"]
    if not expr:
        raise HTTPException(422, "Give an alpha id from Results or paste an expression.")
    opts = D.Options(radius=max(1, min(req.radius, 4)), windows=req.windows, operators=req.operators, wrapper=req.wrapper,
                     vary_decay=req.vary_decay, vary_neutralization=req.vary_neutralization, neutralization=neut or "SUBINDUSTRY",
                     decay=req.decay, max_simulations=max(1, min(req.max_simulations, 1000)))
    try:
        d = D.deepen(expr, opts, name=req.name)
        spec = T.parse(d.template)
    except ValueError as e:
        raise HTTPException(422, str(e))
    return expr, d, spec


@router.post("/deepen/preview")
def deepen_preview(req: DeepenReq):
    """Free: the template that explores this alpha's neighbourhood, its size, and a few sample alphas. Nothing is queued."""
    need_flag("harness_engine")
    import yaml
    from app.harness import optimize as O
    from app.harness.templates import realise as R
    expr, d, spec = _deepen_plan(req)
    sc = req.scope()
    space = R.build_space(spec)
    sample = []
    for _, p in (O.make_optimizer("random", space, ["maximize"], backend="builtin", seed=1).ask(4) if space else []):
        payload = R.realise(spec, p, sc)
        sample.append({"expression": payload["regular"], "settings": payload["settings"]})
    return {"expression": expr, "template": d.template, "yaml": yaml.safe_dump(d.template, sort_keys=False, allow_unicode=True),
            "origin": d.origin, "originExpression": R.realise(spec, d.origin, sc)["regular"], "size": d.size, "notes": d.notes,
            "summary": R.summary(spec), "sample": sample}


@router.post("/deepen/run")
def deepen_run(req: DeepenReq):
    """Create an exhaustive task over the neighbourhood (lab "deepen"). It includes the original, which is skipped if already simulated."""
    need_flag("harness_engine")
    from app.harness.tasks import TaskError
    _, d, spec = _deepen_plan(req)
    try:
        made = _get_runner().create(lab="deepen", name=req.name, spec=spec, scope=req.scope(), sampler="brute", objectives=req.objectives,
                                    budget=d.size, batch=req.batch, cores=req.cores, seed=req.seed)
    except TaskError as e:
        raise HTTPException(422, str(e))
    return {**made, "size": d.size, "notes": d.notes}


# ── B4 Evolution ──────────────────────────────────────────────────────────────────────────────
class EvolutionReq(ScopeBase):
    expressions: list[str] = []
    alpha_ids: list[str] = []
    min_sharpe: float = 1.0
    limit: int = 8
    name: str = ""
    objectives: list[str] = ["fitness"]
    budget: int = 100
    population: int = 20
    offspring: int = 10
    power_pool: bool = False
    max_operators: int | None = None
    max_fields: int | None = None
    crossover_rate: float = 0.4
    seed: int | None = None
    neutralization: str = "SUBINDUSTRY"
    decay: int = 0
    truncation: float = 0.08
    fields: list[str] = []


def _evolution_plan(req: EvolutionReq) -> dict:
    from app.harness import evolution
    from app.harness.labs import ace_sources as src
    sc = req.scope()
    seeds, notes = src.evolution_seeds(sc, expressions=req.expressions, alpha_ids=req.alpha_ids, min_sharpe=req.min_sharpe,
                                       limit=max(1, min(req.limit, 50)))
    ops = src.known_operators()
    cfg = evolution.config(fields=src.evolution_fields(sc, seeds, req.fields), power_pool=req.power_pool, max_operators=req.max_operators,
                           max_fields=req.max_fields, allowed_operators=sorted(ops) if ops else None, crossover_rate=req.crossover_rate)
    kept, skipped = evolution.usable_seeds(seeds, evolution._limits(cfg))
    return {"cfg": cfg, "seeds": kept, "notes": notes + skipped, "operatorsKnown": bool(ops),
            "settings": {"neutralization": req.neutralization, "decay": req.decay, "truncation": req.truncation}}


@router.post("/evolution/preview")
def evolution_preview(req: EvolutionReq):
    """Free: which starting alphas would be used, how many fields mutations can pick from, and a sample of first offspring."""
    need_flag("harness_engine")
    from app.harness import evolution
    p = _evolution_plan(req)
    if not p["seeds"]:
        return {"seeds": [], "notes": p["notes"] or ["No usable starting alphas."], "fields": len(p["cfg"]["fields"]), "offspring": [], "operatorsKnown": p["operatorsKnown"]}
    return {"seeds": p["seeds"], "notes": p["notes"], "fields": len(p["cfg"]["fields"]), "operatorsKnown": p["operatorsKnown"],
            "offspring": evolution.breed_preview(p["cfg"], p["seeds"], 8, req.seed or 1),
            "generations": max(1, (max(1, req.budget) - min(len(p["seeds"]), req.population)) // max(1, req.offspring)) + 1}


@router.post("/evolution/run")
def evolution_run(req: EvolutionReq):
    """Create an Evolution task. Generations run only while the engine runs; nothing is ever submitted."""
    need_flag("harness_engine")
    from app.harness.tasks import TaskError
    p = _evolution_plan(req)
    c = p["cfg"]
    try:
        made = _get_runner().create_evolution(
            name=req.name, seeds=p["seeds"], scope=req.scope(), objectives=req.objectives, budget=req.budget, population=req.population,
            offspring=req.offspring, fields=c["fields"], settings=p["settings"], power_pool=req.power_pool, max_operators=req.max_operators,
            max_fields=req.max_fields, allowed_operators=c["allowed_operators"], crossover_rate=req.crossover_rate, seed=req.seed)
    except TaskError as e:
        raise HTTPException(422, str(e))
    return {**made, "notes": p["notes"] + made["notes"]}


# ── C1/C2 LLM adapter status + budget, C3 Invent ──────────────────────────────────────────────
def _llm():
    from app.harness import llm as LL
    return LL.default_llm()


@router.get("/llm/status")
def llm_status():
    """Which providers Alpha Sentry has configured, plus today's estimated usage against the daily caps."""
    return _llm().status()


class LLMBudgetReq(BaseModel):
    max_calls_per_day: float | None = None
    max_tokens_per_day: float | None = None
    usd_per_million_tokens: float | None = None
    max_usd_per_day: float | None = None


@router.post("/llm/budget")
def llm_budget(req: LLMBudgetReq):
    """Set the daily caps (0 = no cap). Usage is an ESTIMATE (characters / 4); Alpha Sentry's LLM layer reports no token counts."""
    try:
        _llm().budget.set_config(max_calls_per_day=req.max_calls_per_day, max_tokens_per_day=req.max_tokens_per_day,
                                   usd_per_million_tokens=req.usd_per_million_tokens, max_usd_per_day=req.max_usd_per_day)
    except ValueError as e:
        raise HTTPException(422, str(e))
    return _llm().budget.summary(7)


@router.get("/llm/usage")
def llm_usage(days: int = 7):
    return _llm().budget.summary(days)


class InventReq(ScopeBase):
    goal: str = ""
    n: int = 6
    power_pool: bool = False
    max_simulations: int = 100
    avoid: list[str] = []


def _invent_ctx(req: InventReq):
    from app.harness.labs import ace_sources as src, invent as I
    sc = req.scope()
    ops = src.known_operators()
    return I.Context(
        scope_label=sc.label, fields=src.best_fields(sc, per_dataset=3, min_alphas=0, min_coverage=0.5, limit=80), operators=ops,
        winners=[w["expression"] for w in src.winners(sc, 1.0, 6)], avoid=list(req.avoid), goal=req.goal, power_pool=req.power_pool,
        max_simulations=max(1, min(req.max_simulations, 1000)), prepared=lambda v: src.template_fields(sc, v))


@router.post("/invent/propose")
def invent_propose(req: InventReq):
    """Ask YOUR LLM for new templates (uses your API key; counted against the daily caps). Every proposal is checked; nothing is queued."""
    need_flag("harness_engine")
    need_flag("harness_llm")
    import yaml
    from app.harness import llm as LL
    from app.harness.labs import invent as I
    llm = _llm()
    try:
        out = I.invent(lambda s, u, n: llm.complete_list(s, u, lab="invent", n=n), _invent_ctx(req), n=max(1, min(req.n, I.MAX_CANDIDATES)))
    except LL.BudgetExceeded as e:
        raise HTTPException(429, str(e))
    except LL.LLMUnavailable as e:
        raise HTTPException(409, str(e))
    except LL.LLMError as e:
        raise HTTPException(502, str(e))
    for a in out["accepted"]:
        a["yaml"] = yaml.safe_dump(a["template"], sort_keys=False, allow_unicode=True)
    out["budget"] = llm.budget.summary(1)["today"]
    return out


class InventRunReq(InventReq):
    template: str
    name: str = ""
    sampler: str = "nsga2"
    objectives: list[str] = ["fitness"]
    budget: int = 60
    batch: int = 10
    cores: int = 2
    seed: int | None = None


@router.post("/invent/run")
def invent_run(req: InventRunReq):
    """Create a task (lab "invent") from a proposed — or hand-edited — template, after checking it again. Queue-only."""
    need_flag("harness_engine")
    from app.harness.labs import invent as I
    from app.harness.tasks import TaskError
    from app.harness.templates import spec as T
    ctx = _invent_ctx(req)
    try:
        raw = I.parse_item(req.template)
    except ValueError as e:
        raise HTTPException(422, f"The template is {e}.")
    v = I.validate(raw, ctx)
    if not v["ok"]:
        raise HTTPException(422, "This template cannot be run: " + "; ".join(v["problems"]))
    try:
        made = _get_runner().create(lab="invent", name=req.name or v["name"], spec=T.parse(v["template"]), scope=req.scope(), sampler=req.sampler,
                                    objectives=req.objectives, budget=req.budget, batch=req.batch, cores=req.cores, seed=req.seed,
                                    prepared=ctx.prepared)
    except TaskError as e:
        raise HTTPException(422, str(e))
    return {**made, "notes": v["notes"]}


# ── D5 Planning: overview, today's plan, PM, advice, queue-the-plan ───────────────────────────
def _plan_settings():
    from pathlib import Path
    from app.core.config import get_settings
    from app.harness.plan.day import PlanSettings
    return PlanSettings(Path(get_settings().data_dir) / "harness" / "plan.json")


class PlanSettingsReq(BaseModel):
    daily_budget: float | None = None
    explore_fraction: float | None = None
    min_chunk: float | None = None
    labs: list[str] | None = None


@router.get("/plan/settings")
def plan_settings_get():
    from app.harness.plan.day import AUTO_LABS
    return {"settings": _plan_settings().config(), "labs": AUTO_LABS}


@router.post("/plan/settings")
def plan_settings_set(req: PlanSettingsReq):
    from app.harness.plan.day import PlanError
    try:
        return {"settings": _plan_settings().set_config(daily_budget=req.daily_budget, explore_fraction=req.explore_fraction,
                                                        min_chunk=req.min_chunk, labs=req.labs)}
    except PlanError as e:
        raise HTTPException(422, str(e))


def _worked_datasets(sc) -> set[str]:
    """Datasets your alphas already use (from the fields their expressions mention). Local reads only."""
    from app.harness.labs import ace_sources as src
    ids: set[str] = set()
    for e in src.scope_expressions(sc)[:400]:
        try:
            ids.update(src.leaf_idents(e))
        except Exception:  # noqa: BLE001
            pass
    return set(src.dataset_of_field(sc, ids).values()) if ids else set()


def _plan_state(sc) -> dict:
    """Everything the plan, PM and advisor share (reads only: no BRAIN calls, nothing queued)."""
    from app.harness.labs import ace_sources as src
    from app.harness.plan import day as DAY, readers as RD, yields as Y
    store, cfg = default_store(), _plan_settings().config()
    counts = RD.results_counts(store, sc)
    deepened = RD.deepened_expressions([dict(r) for r in store.query("SELECT lab, template FROM harness_task WHERE lab='deepen'")])
    rd = RD.readiness(counts, cfg["labs"],
                      fresh_datasets=lambda: len(src.fresh_fields(sc, _worked_datasets(sc), 1, 1)),
                      undeepened=lambda: len([w for w in src.winners(sc, RD.STRONG_SHARPE, 30) if w["expression"] not in deepened]))
    spent = DAY.spent_today(store)
    return {"cfg": cfg, "store": store, "counts": counts, "rd": rd, "spent": spent, "book": Y.by_lab(store, days=14), "summary": Y.summary(store, days=14)}


def _plan_runners(sc) -> dict:
    """One runner per auto lab: each calls the lab's OWN run function, which only queues (nothing simulates or submits here)."""
    from app.harness.labs import ace_sources as src
    base = {"region": sc.region, "delay": sc.delay, "universe": sc.universe, "instrument_type": sc.instrument_type}

    def queue_style(fn, Req):
        def run(target: int, extra: int) -> dict:
            out = fn(Req(**base, target=int(target)))
            return {"queued": int(out.get("queued", 0)), "duplicates": int(out.get("duplicates", 0)), "note": out.get("note")}
        return run

    def evolution(target: int, extra: int) -> dict:
        out = evolution_run(EvolutionReq(**base, budget=int(extra), objectives=["fitness"], population=20, offspring=10))
        return {"queued": int(extra), "duplicates": 0, "task": out["id"]}

    def deepen(target: int, extra: int) -> dict:
        from app.harness.plan import readers as RD
        store = default_store()
        done = RD.deepened_expressions([dict(r) for r in store.query("SELECT lab, template FROM harness_task WHERE lab='deepen'")])
        fresh = [w for w in src.winners(sc, RD.STRONG_SHARPE, 30) if w["expression"] not in done]
        if not fresh:
            return {"queued": 0, "duplicates": 0, "note": "Every strong alpha already has a deepen task."}
        out = deepen_run(DeepenReq(**base, alpha_id=fresh[0]["alpha_id"], max_simulations=max(1, min(int(extra), 200))))
        return {"queued": int(out["size"]), "duplicates": 0, "task": out["id"]}

    return {"repair": queue_style(repair_run, RepairReq), "harden": queue_style(harden_run, HardenReq),
            "relocate": queue_style(relocate_run, RelocateReq), "harvest": queue_style(harvest_run, HarvestReq),
            "diversify": queue_style(diversify_run, HarvestReq), "pair": queue_style(pair_run, PairReq),
            "evolution": evolution, "deepen": deepen}


def _plan_for(state: dict, labs: list[str] | None = None) -> dict:
    """Today's ordinary plan over the labs that are ready (blocked labs are left out and reported)."""
    from app.harness.plan import day as DAY
    cfg, blockers = state["cfg"], state["rd"]["blockers"]
    plan = DAY.make_plan(cfg, state["book"], state["spent"]["total"], capacity=state["rd"]["capacity"],
                         exclude=set(blockers) | (set(cfg["labs"]) - set(labs) if labs else set()))
    return plan


@router.post("/plan/overview")
def plan_overview(req: ScopeBase):
    """The Planning tab in one call: settings, what is spent, readiness per lab, today's plan, yields + trend, advice, history. Reads only."""
    from app.harness.plan import advisor, dispatch as DP, readers as RD
    sc = req.scope()
    s = _plan_state(sc)
    plan = _plan_for(s)
    eng = _engine.status() if _engine is not None else None
    tasks = _get_runner().list_tasks()
    try:
        from app.harness.labs import ace_sources as src
        saturated = len([r for r in src.shape_records(sc).values() if r.saturated])
    except Exception:  # noqa: BLE001
        saturated = 0
    snap = RD.snapshot(s["store"], sc, flags=flags.get_all(), engine=eng, plan=plan, yields=s["summary"], tasks=tasks, saturated=saturated, counts=s["counts"])
    return {"scope": sc.label, "settings": s["cfg"], "spent": s["spent"], "counts": s["counts"], "readiness": s["rd"], "plan": plan,
            "yields": s["summary"], "trend": RD.trend(s["store"], days=14), "advice": advisor.advise(snap), "history": DP.history(s["store"], 10),
            "flags": {"planning": flags.enabled("harness_planning"), "engine": flags.enabled("harness_engine"), "llm": flags.enabled("harness_llm")}}


@router.get("/plan/trend")
def plan_trend(days: int = 14):
    from app.harness.plan import readers as RD
    return RD.trend(default_store(), days=days)


@router.get("/plan/history")
def plan_history(limit: int = 20):
    from app.harness.plan import dispatch as DP
    return {"runs": DP.history(default_store(), limit)}


class AdviceReq(ScopeBase):
    narrate: bool = False


@router.post("/plan/advice")
def plan_advice(req: AdviceReq):
    """Plain-language next steps. `narrate` asks YOUR LLM to rewrite the top ones as a paragraph (only if the LLM flag is on; falls back to the rules)."""
    from app.harness.plan import advisor
    ov = plan_overview(req)
    out: dict = {"items": ov["advice"], "narration": None}
    if req.narrate:
        complete = None
        if flags.enabled("harness_llm"):
            llm = _llm()
            complete = lambda s, u: llm.complete(s, u, lab="advisor").text         # noqa: E731
        out["narration"] = advisor.narrate(ov["advice"], complete)
    return out


class PMReq(ScopeBase):
    use_llm: bool = True


@router.post("/plan/pm")
def plan_pm(req: PMReq):
    """The PM: which desks (labs) should get today's simulations, and why. Uses YOUR LLM only if the LLM flag is on; otherwise (or on any
    failure) it returns the ordinary plan with a rule-written briefing. Proposes only: nothing is queued here."""
    from app.harness.plan import pm as PM
    s = _plan_state(req.scope())
    complete = None
    if req.use_llm and flags.enabled("harness_llm"):
        llm = _llm()
        complete = lambda sy, u: llm.complete(sy, u, lab="pm").text                 # noqa: E731
    out = PM.allocate(s["cfg"], s["book"], s["spent"]["total"], summary=s["summary"], blockers=s["rd"]["blockers"],
                      capacity=s["rd"]["capacity"], complete=complete)
    return {**out, "llmFlag": flags.enabled("harness_llm")}


class PlanRunReq(ScopeBase):
    labs: list[str] = []


@router.post("/plan/run")
def plan_run(req: PlanRunReq):
    """Queue today's plan: each funded lab queues its share through its own run function (deduplicated). Queue-only: simulations start when
    the engine runs, and nothing is ever submitted. `labs` restricts the plan (e.g. to the desks the PM chose)."""
    need_flag("harness_engine")
    need_flag("harness_planning")
    from app.harness.plan import day as DAY, dispatch as DP
    sc = req.scope()
    s = _plan_state(sc)
    cfg = s["cfg"]
    if req.labs:
        bad = [x for x in req.labs if x not in cfg["labs"]]
        if bad:
            raise HTTPException(422, f"Not in the plan's lab list: {', '.join(bad)}.")
        cfg = {**cfg, "labs": list(dict.fromkeys(req.labs))}
    blockers = s["rd"]["blockers"]
    cfg = {**cfg, "labs": [x for x in cfg["labs"] if x not in blockers]}
    if not cfg["labs"]:
        why = "; ".join(f"{k}: {v[0]}" for k, v in blockers.items()) or "no labs are switched on in the plan settings"
        raise HTTPException(422, f"No lab can run today ({why}).")
    outcome = DP.dispatch(cfg, s["book"], s["spent"]["total"], _plan_runners(sc))
    outcome["runId"] = DP.record_run(s["store"], sc.label, outcome)
    return outcome


# ── E2 winner tag for lab results ─────────────────────────────────────────────────────────────
class WinnerReq(BaseModel):
    winner_tag: str | None = None
    winner_color: str | None = None
    tag_winners_above: float | None = None


@router.get("/winner")
def winner_get():
    """The harness-level default winner tag / colour / |Fitness| threshold applied to lab results that pass the gate (blank tag = off)."""
    from app.harness import winner as W
    return {"settings": W.default_settings().config(), "colors": list(W.COLORS)}


@router.post("/winner")
def winner_set(req: WinnerReq):
    from app.harness import winner as W
    try:
        return {"settings": W.default_settings().set_config(winner_tag=req.winner_tag, winner_color=req.winner_color,
                                                            tag_winners_above=req.tag_winners_above), "colors": list(W.COLORS)}
    except W.WinnerError as e:
        raise HTTPException(422, str(e))


# ── F1 Autosentry speed / F2 shipped seed data ─────────────────────────────────────────────────
class SpeedReq(BaseModel):
    parallel: int | None = None
    straggler_s: float | None = None


@router.get("/speed")
def speed_get():
    """Autosentry speed settings (used only while the “Autosentry via engine” switch is on) and what BRAIN has taught the ceiling so far."""
    from app.harness import speed as S
    return {**S.status(), "routing": flags.enabled("autopilot_via_engine")}


@router.post("/speed")
def speed_set(req: SpeedReq):
    from app.harness import speed as S
    try:
        S.set_config(parallel=req.parallel, straggler_s=req.straggler_s)
    except S.SpeedError as e:
        raise HTTPException(422, str(e))
    return {**S.status(), "routing": flags.enabled("autopilot_via_engine")}


class SeedReq(BaseModel):
    force: bool = False
    dry_run: bool = False


@router.get("/seed")
def seed_status():
    """What the shipped seed database holds, and whether it has been merged into yours."""
    from app.core.config import get_settings
    from app.harness import seed as D
    return {**D.status(get_settings().db_path), "enabled": flags.enabled("harness_seed")}


@router.post("/seed/merge")
def seed_merge(req: SeedReq):
    """Add the seed's missing rows to your database (insert-only; never changes or removes a row). dry_run only counts; force repeats a merge
    that was already done (rows you deleted come back)."""
    from app.core.config import get_settings
    from app.harness import seed as D
    s = get_settings()
    out = D.merge(s.db_path, force=req.force, dry_run=req.dry_run, backup_dir=s.data_dir / "backups")
    if out.get("skipped") == "no seed file":
        raise HTTPException(404, "This version has no seed file (seed/ace_studio_v2.seed.db).")
    return out


# ── Slots, missing results, alpha stats and one-by-one prod checks ──────────────────────────────
@router.get("/slots")
def slots_view():
    """Who holds each of the 8 simulation slots: running batches (engine task, Autosentry, Supersentry), how long, and the queue per region."""
    import time
    from app.harness.engine.slots import shared_lease
    tr = _get_engine().tracker
    now = time.time()
    batches = tr.running_batches()
    for b in batches:
        b["elapsed"] = int(now - b["since"])
        b["who"] = {"autopilot": "Autosentry", "superpilot": "Supersentry"}.get(b["task"], f"Engine: {b['task']}")
    snap = shared_lease.snapshot()
    return {"total": snap["total"], "lease": snap, "batches": batches, "queue": tr.region_counts(), "long_after": 20 * 60}


class AbandonReq(BaseModel):
    batch_id: str


@router.post("/slots/abandon")
def slots_abandon(req: AbandonReq):
    n = _get_engine().tracker.abandon_batch(req.batch_id)
    return {"abandoned": n}


@router.get("/missing")
def missing_results(q: str = "", code: str = "", limit: int = 200, offset: int = 0, region: str = "", date_from: str = "", date_to: str = ""):
    from app.harness import diagnose
    return diagnose.missing(default_store(), q=q, code=code, limit=min(limit, 2000), offset=offset, region=region, date_from=date_from, date_to=date_to)


class FixReq(BaseModel):
    ids: list[int]
    action: str            # "score" | "requeue"


@router.post("/missing/fix")
def missing_fix(req: FixReq):
    """Score now (reads BRAIN, no simulation quota) or put the simulations back in the queue."""
    store = default_store()
    ids = [int(i) for i in req.ids][:2000]
    if not ids:
        return {"done": 0}
    from app.harness.store import marks
    if req.action == "score":
        store.execute(f"UPDATE harness_sim_record SET status='done', error='' WHERE alpha_id != '' AND id IN ({marks(len(ids))})", ids)
        from app.harness.scoring import score_pending
        errs: list = []
        return {"done": len(ids), **score_pending(len(ids), errors_out=errs), "errors": errs}
    if req.action == "requeue":
        need_flag("harness_engine")
        n = store.execute(f"UPDATE harness_sim_record SET status='queued', error='', alpha_id='', batch_id='', updated=? "
                          f"WHERE status IN ('error','cancelled','dryrun','running') AND task != 'autopilot' AND id IN ({marks(len(ids))})", [time.time(), *ids])
        return {"done": int(n or 0)}
    raise HTTPException(400, "action must be 'score' or 'requeue'")


_pull_run = None


PULL_MAX = 2000


class PullReq(BaseModel):
    ids: list[int] = []
    delay: float = 1.0
    q: str = ""                  # with no ids: everything that matches these filters (up to PULL_MAX), not just the visible page
    code: str = ""
    region: str = ""
    date_from: str = ""
    date_to: str = ""


@router.post("/missing/pull")
def missing_pull(req: PullReq):
    """Pull the stats of missing results from BRAIN one by one (no correlations; no simulation quota), with a log the screen shows."""
    global _pull_run
    from app.harness import alphas, brain_port
    from app.harness.scoring import score_pending
    if _pull_run is not None and _pull_run.state.get("running"):
        return {"started": False, "message": "a pull is already running"}
    run = alphas.PullRun()
    _pull_run = run
    store = default_store()
    ids = [int(i) for i in req.ids][:PULL_MAX]
    if not ids:
        from app.harness import diagnose
        found = diagnose.missing(store, q=req.q, code=req.code, region=req.region, date_from=req.date_from, date_to=req.date_to, limit=PULL_MAX)
        ids = [int(i["id"]) for i in found["items"] if i.get("alpha_id")]
    fetch = lambda aid, sd: brain_port.alpha_stats(aid, sd, checks=False, corr=False)
    score = lambda limit, errs, only: score_pending(limit, fetch=fetch, store=store, errors_out=errs, only_ids=only)
    jobs.submit("pull_stats", lambda progress, cancelled: run.run(store, ids, score=score, delay=max(0.0, req.delay)))
    return {"started": True, "count": len(ids), "max": PULL_MAX}


@router.get("/missing/pull")
def missing_pull_state():
    return _pull_run.state if _pull_run else {"running": False, "total": 0, "done": 0, "ok": 0, "failed": 0, "log": []}


@router.post("/missing/pull/stop")
def missing_pull_stop():
    if _pull_run:
        _pull_run.stop()
    return {"stopped": True}


@router.get("/alphas/batches")
def alpha_batches(source: str = "engine", limit: int = 15):
    """Latest batches with how many alphas are grey / yellow / green / purple in each."""
    from app.harness import alphas
    return {"batches": alphas.batches(default_store(), source, min(limit, 50))}


@router.get("/alphas")
def alpha_table(q: str = "", region: str = "", passed: str = "", prod: str = "", source: str = "", sort: str = "created_at",
                desc: bool = True, limit: int = 100, offset: int = 0, gate: str = "", batch: str = "", date_from: str = "", date_to: str = "", mark: str = ""):
    from app.harness import alphas
    out = alphas.list_alphas(default_store(), q=q, region=region, passed=passed, prod=prod, source=source, sort=sort, desc=desc,
                             limit=min(limit, 500), offset=offset, gate=gate, batch=batch, date_from=date_from, date_to=date_to, mark=mark)
    out["counts"] = alphas.counts(default_store(), source or "engine")
    out["marks"] = alphas.mark_counts(default_store())
    if offset == 0 and not (region or passed or prod or gate or batch or date_from or date_to) and source in ("", "engine", "autosentry"):    # known alphas that never reached Results: red rows on top
        try:
            from app.autopilot import service as ap
            wins = (ap._load_state() or {}).get("winners", [])
        except Exception:  # noqa: BLE001
            wins = []
        miss = alphas.missing_rows(default_store(), wins, q, source)
        out["rows"] = miss[:100] + out["rows"]
        out["missing"] = len(miss)
    return out


class MarkReq(BaseModel):
    ids: list[str]
    mark: str = ""          # "submitted" | "used" | "" (clear)
    note: str = ""


@router.post("/alphas/mark")
def alpha_mark(req: MarkReq):
    """Mark alphas you submitted or used (or clear the mark). Only records your own note; nothing is sent to BRAIN."""
    from app.harness import alphas
    r = alphas.set_marks(default_store(), req.ids, req.mark or None, req.note)
    if r.get("error"):
        raise HTTPException(400, r["error"])
    return r


class CheckReq(BaseModel):
    ids: list[str]
    delay: int = 60            # seconds to wait before EACH check
    recheck: bool = False      # also re-check alphas that already have a production correlation


_check_run = None


@router.post("/alphas/check")
def alpha_check(req: CheckReq):
    """Check production correlation one after another (BRAIN's submission check; saved to Results; uses no simulation quota; submits nothing)."""
    global _check_run
    from app.harness import alphas, brain_port
    if _check_run is not None and _check_run.state.get("running"):
        return {"started": False, "message": "a check run is already going"}
    run = alphas.CheckRun()
    _check_run = run
    store = default_store()
    ids = [i for i in req.ids if i][:300]
    jobs.submit("prod_check", lambda progress, cancelled: run.run(store, ids, delay=max(0, req.delay), recheck=req.recheck,
                                                                  fetch=brain_port.check_submission,
                                                                  after_pass=lambda aid: alphas.winner_after_check(store, aid)))
    return {"started": True, "count": len(ids)}


@router.get("/alphas/check")
def alpha_check_state():
    return _check_run.state if _check_run else {"running": False, "total": 0, "done": 0, "results": []}


@router.post("/alphas/check/stop")
def alpha_check_stop():
    if _check_run:
        _check_run.stop()
    return {"stopped": True}
