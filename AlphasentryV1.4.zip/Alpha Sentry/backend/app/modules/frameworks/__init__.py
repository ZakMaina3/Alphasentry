"""Frameworks module: upload / review / save research frameworks, the pairing rulebook, and the category chooser data."""
from __future__ import annotations

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from pydantic import BaseModel

from app.autopilot import library as K
from app.frameworks import parse as P
from app.frameworks import plan as PL
from app.frameworks import rules as R
from app.frameworks import store as ST

PREFIX = "/api/frameworks"
router = APIRouter()


@router.get("")
def list_frameworks():
    return {"items": ST.listing()}


class ParseReq(BaseModel):
    text: str
    source: str = ""


@router.post("/parse")
def parse_text(req: ParseReq):
    """Read a pasted framework into structured frameworks for review. Nothing is saved yet."""
    return P.parse(req.text, req.source or "pasted")


@router.post("/upload")
async def upload(file: UploadFile = File(...)):
    """Upload a .txt / .md / .pdf framework; returns the parsed frameworks for review (not saved yet)."""
    data = await file.read()
    name = file.filename or "framework"
    if name.lower().endswith(".pdf"):
        from app.research import service as RS
        try:
            text = RS.extract_pdf_text(data, "")
        except Exception as e:  # noqa: BLE001
            raise HTTPException(400, f"could not read the PDF: {str(e)[:160]}")
    else:
        text = data.decode("utf-8", errors="replace")
    if not text.strip():
        raise HTTPException(400, "the file has no text")
    return {**P.parse(text, name), "text": text[:200000]}


class SuggestReq(BaseModel):
    framework: dict


@router.post("/suggest")
def suggest(req: SuggestReq):
    """Ask the LLM which category pair fits this framework best (checked against the pairing rules; rules alone if no LLM)."""
    from app.autopilot import service as A
    from app.frameworks import advise as AD
    return AD.suggest(req.framework, lambda p: list(A._llm(p, 3).expressions))


class SaveReq(BaseModel):
    frameworks: list[dict]


@router.post("/save")
def save(req: SaveReq):
    return ST.save(req.frameworks)


class SetupReq(BaseModel):
    name: str
    sel: dict


@router.get("/setups")
def setups():
    return {"items": ST.setups()}


@router.post("/setups")
def save_setup(req: SetupReq):
    r = ST.save_setup(req.name, req.sel)
    if r.get("error"):
        raise HTTPException(400, r["error"])
    return r


@router.delete("/{fid}")
def delete(fid: int):
    return K.delete_asset(fid)


class EnableReq(BaseModel):
    enabled: bool


@router.post("/{fid}/enabled")
def enable(fid: int, req: EnableReq):
    return K.update_asset(fid, {"enabled": req.enabled})


@router.get("/rules")
def rules():
    """The pairing rulebook for the chooser: every category and every pair with its verdict."""
    return {"categories": [{"key": c, "label": R.label(c)} for c in R.CATEGORIES], "pairs": R.all_pairs()}


class CheckReq(BaseModel):
    categories: list[str] = []


@router.post("/check")
def check(req: CheckReq):
    cats = [R.normalize(c) or c for c in req.categories]
    return {"categories": cats, "pairs": R.check_set(cats), "blocked": R.blocked(cats)}


@router.get("/categories")
def categories(region: str = "USA", delay: int = 1, min_alphas: int = 0, max_alphas: int = 0):
    """The categories found in the Data Catalog for this market with their field counts (and how many fit the alpha-count range)."""
    return {"items": ST.category_counts(region.upper(), delay, min_alphas or None, max_alphas or None)}
