"""Supersentry — the autonomous SuperAlpha engine (its own section, separate from the regular Autosentry).

There is NO hypothesis stage. Each round it:

  1. SUGGESTS    — the LLM writes selection + combo expressions aimed at GOOD PERFORMANCE and LOW
                   CORRELATION, steered by everything learned so far (results, correlations, lessons) and
                   by your library of selections / combos / SuperAlphas / papers / notes.
  2. VERIFIES    — every selection is counted against your alphas first (BRAIN's selection preview). A
                   selection must pick MORE THAN 10 alphas (configurable) or it is never simulated.
  3. SIMULATES   — (selection -> combo) pairs, single simulations, 3 at a time (BRAIN's cap).
  4. CHECKS      — every metric-passing SuperAlpha gets the full BRAIN submission check (self / prod /
                   power-pool correlation + every IS test).
  5. IMPROVES    — negative results are retried with the combo reversed; alphas that pass everything but
                   correlation are re-built with low-correlation selections (self/prod_correlation filters),
                   other neutralizations and sister/brother operator swaps in the combo.
  6. LEARNS      — results and lessons are written back; winners are parked in the Vault and join your library.

It NEVER submits anything to BRAIN.
"""

from __future__ import annotations

import json
import random
import re
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor

from sqlalchemy import select

from app.autopilot import library as K
from app.autopilot import service as A          # session re-login (Telegram), LLM helper, deep check
from app.autopilot import winners as WN
from app.superpilot import prod as PRD
from app.brain import engine
from app.core.config import get_settings
from app.core.jobs import jobs
from app.db import models as M
from app.db.base import SessionLocal
from app.notify import telegram as TG
from app.simulation import service as S
from app.super import service as SU

import ace_lib as ace          # noqa: E402

SEP = " -> "
_LOCK = threading.Lock()
_FILE = get_settings().data_dir / "superpilot_state.json"
_DEFAULT_STATE = {"rounds": 0, "simulated": 0, "winners": [], "history": [], "started_at": None}


# ── persisted state ──────────────────────────────────────────────────────────────────

def _load_state() -> dict:
    try:
        return {**_DEFAULT_STATE, **json.loads(_FILE.read_text())}
    except Exception:
        return json.loads(json.dumps(_DEFAULT_STATE))


def _save_state(st: dict) -> None:
    try:
        st["history"] = st["history"][-300:]
        _FILE.write_text(json.dumps(st))
    except Exception:
        pass


def reset_state() -> dict:
    with _LOCK:
        _save_state(json.loads(json.dumps(_DEFAULT_STATE)))
    return {"ok": True}


# ── live state ───────────────────────────────────────────────────────────────────────

_LIVE: dict = {"job_id": None, "phase": "idle", "wait": "", "round": 0, "selections": [], "candidates": [],
               "last_batch": [], "events": []}


def _event(msg: str, progress=None) -> None:
    with _LOCK:
        _LIVE["events"].append({"t": time.time(), "msg": str(msg)[:400]})
        del _LIVE["events"][:-300]
    if progress:
        try:
            progress(log=msg)
        except Exception:
            pass


def _live(**kw) -> None:
    with _LOCK:
        _LIVE.update(kw)


def _append_batch(rows: list) -> None:
    with _LOCK:
        _LIVE["last_batch"] = (list(_LIVE.get("last_batch") or []) + rows)[-60:]


def is_running() -> bool:
    jid = _LIVE.get("job_id")
    return bool(jid and jobs.get(jid).get("status") == "running")


def status() -> dict:
    running = is_running()
    with _LOCK:
        live = json.loads(json.dumps(_LIVE, default=str))
    st = _load_state()
    live["running"] = running
    if not running and live["phase"] not in ("idle", "stopped"):
        live["phase"] = "stopped"
    live["state"] = {"rounds": st["rounds"], "simulated": st["simulated"],
                     "winners": st["winners"][-50:], "history": st["history"][-60:]}
    return live


# ── helpers ──────────────────────────────────────────────────────────────────────────

def _norm(e: str) -> str:
    return re.sub(r"\s+", "", str(e)).lower()


def _sleep(sec: float, cancel) -> None:
    end = time.time() + sec
    while time.time() < end and not cancel():
        time.sleep(1)


def _join(sel: str, combo: str) -> str:
    return f"{sel.strip()}{SEP}{combo.strip()}"


def _split(expr: str):
    if SEP not in expr:
        return None
    a, b = expr.split(SEP, 1)
    return a.strip(), b.strip()


def _skeleton(expr: str) -> str:
    return re.sub(r"(?<![\w.])\d+(\.\d+)?", "N", expr)


def _seen(region: str) -> set:
    with SessionLocal() as db:
        rows = db.scalars(select(M.SimResult.expression).where(M.SimResult.region == region)).all()
    return {_norm(r) for r in rows if r}


def _lreg(cfg: dict) -> str:
    return cfg["region"] + ":super"           # this engine's lessons never mix with the regular Autosentry's


def _score(r: dict) -> float:
    return abs(r.get("fitness") or 0) + 0.3 * abs(r.get("sharpe") or 0)


_VAL: dict = {}


def _validator(kind: str):
    if kind not in _VAL:
        _VAL[kind] = SU._validator(kind)
    return _VAL[kind]


def _valid_sel(e: str) -> bool:
    try:
        return bool(_validator("SELECTION").validate(e).ok)
    except Exception:
        return True


def _valid_combo(e: str) -> bool:
    try:
        return bool(_validator("COMBO").validate(e).ok)
    except Exception:
        return True


def _wrap_weight(combo: str, fn) -> str:
    """Apply fn to the WEIGHT part of a combo (its last statement)."""
    if ";" in combo:
        head, last = combo.rsplit(";", 1)
        return head.strip() + "; " + fn(last.strip())
    return fn(combo.strip())


def _flip_weight(w: str) -> str:
    w = w.strip()
    if w == "1":
        return "-1"
    if w == "-1":
        return "1"
    m = re.fullmatch(r"-\s*1\s*\*\s*\((.*)\)", w, re.S)
    if m and A.K._balanced(m.group(1)):
        return m.group(1).strip()
    return f"-1 * ({w})"


def flip_pair(expr: str) -> str | None:
    p = _split(expr)
    return _join(p[0], _wrap_weight(p[1], _flip_weight)) if p else None


# ── 1. suggestions: good performance + low correlation ──────────────────────────────

OBJECTIVE = (
    "=== OBJECTIVE ===\n"
    "Suggest expressions whose SuperAlpha will have (1) GOOD PERFORMANCE — high Sharpe and Fitness, turnover "
    "under {turn:.0%} — and (2) LOW CORRELATION — self / production correlation below {corr}, so it is "
    "submittable and adds something new.\n"
    "How to get LOW CORRELATION with the tools you have:\n"
    "  - select component alphas that are themselves uncorrelated: use the numeric attributes "
    "`self_correlation` and `prod_correlation` (e.g. `prod_correlation < 0.5`, `self_correlation < 0.5`);\n"
    "  - DIVERSIFY across data: vary `category` / `datacategories` / `dataset` / `neutralization` / `universe` "
    "between selections (use `not(in(datacategories, \"news\"))` and OR-groups with `||`);\n"
    "  - favour weights that do not simply replicate the crowd: weight by a component's own trailing statistics "
    "(information ratio, drawdown, hold PnL per traded value) rather than equal weight.\n"
    "How to get GOOD PERFORMANCE: choose components with a proven record (author_sharpe / author_fitness / "
    "author_yield_rate style attributes where useful, `turnover` bounds, `long_count` / `short_count` breadth) and "
    "weights that favour recently strong components.\n"
    "Every selection MUST still pick MORE THAN {minc} alphas — keep thresholds LOOSE (at most two or three "
    "conditions); a selection that picks too few is discarded without being simulated.\n")


def _memory_block(cfg: dict, st: dict) -> str:
    """What this engine has already tried, best first — the LLM must learn from it, not repeat it."""
    rows = [h for h in st["history"] if h.get("sharpe") is not None]
    if not rows:
        return ""
    best = sorted(rows, key=_score, reverse=True)[:8]
    bad = [h for h in rows if (h.get("why") or "").strip()][-6:]
    out = ["=== WHAT HAS BEEN TRIED (learn from it; do NOT repeat these pairs) ==="]
    for h in best:
        cr = f"self {h['self_corr']:.2f}/prod {h['prod_corr']:.2f}" if h.get("self_corr") is not None and h.get("prod_corr") is not None else "corr n/a"
        out.append(f"- BEST  Sharpe {h['sharpe']:.2f} Fit {(h.get('fitness') or 0):.2f} turn {(h.get('turnover') or 0):.2f} {cr}"
                   f"{' ✓PASSED' if h.get('passed') else ''}\n    {h['expr'][:230]}")
    for h in bad:
        out.append(f"- WEAK  {h['why'][:120]}\n    {h['expr'][:200]}")
    return "\n".join(out) + "\n"


def _fw_turn(cfg: dict, progress) -> None:
    """With frameworks: stay on one for `fw_rounds` rounds, then move to the next (its own region / delay / universe), and round again."""
    from app.frameworks import plan as PL
    stages = cfg.get("_fw_stages")
    if not stages:
        return
    per = max(1, int(cfg.get("fw_rounds") or 2)) if len(stages) > 1 else 0
    if cfg.get("_fw") is not None and (not per or cfg["_fw_n"] < per):
        cfg["_fw_n"] += 1
        return
    st, cfg["_fw_i"], skipped = PL.next_stage(stages, cfg["_fw_i"])
    for m in skipped:
        _event("⏭ " + m, progress)
    if st is None:
        raise RuntimeError("No framework can run: " + " | ".join(f"{x['name']}: {x['error']}" for x in stages))
    cfg.update(region=st["region"], delay=st["delay"], universe=st["universe"], universes=[st["universe"]], _fw=st, _fw_n=1)
    _event(f"▶ framework '{st['name']}' · {st['region']}/{st['universe']}/delay {st['delay']} · categories: {', '.join(st['categories'])}"
           + (f" · {per} rounds, then the next framework" if per else ""), progress)


def _fw_text(cfg: dict) -> str:
    st = cfg.get("_fw") if cfg.get("_fw") is not None else None
    if not st:
        return ""
    return ("=== FRAMEWORK AND PAIRING RULES (stay within them) ===\n" + st["guidance"] + "\n"
            "For a SuperAlpha, build the SELECTIONS around the user's alphas that use these data categories: filter with in(datacategories, \"<category id>\") "
            "for each category of the framework (a pair = both categories in the same selection) and never for a rejected pair. Combos weight the "
            "selected alphas by their statistics.\n")


def _fw_filter(cfg: dict, sels: list) -> list:
    from app.frameworks import plan as PL
    return PL.filter_selections(sels, cfg.get("_fw"))


def _guidance(cfg: dict, rnd: int, feedback: str, ctx: dict | None, st: dict) -> str:
    g = OBJECTIVE.format(turn=cfg["max_turnover"], corr=cfg["max_corr"], minc=cfg["min_components"] - 1)
    if cfg.get("goal"):
        g += f"User goal: {cfg['goal']}\n"
    g += _fw_text(cfg)
    g += _memory_block(cfg, st)
    if feedback:
        g += "=== RESULTS OF THE PREVIOUS ROUND (fix what failed, keep what worked) ===\n" + feedback + "\n"
    if ctx:
        g += K.context_text(ctx, "selections", "combos", "alphas", "papers", "notes", "lessons")
    return g


def _suggest(cfg: dict, rnd: int, feedback: str, ctx: dict | None, st: dict):
    quiet = lambda **k: None  # noqa: E731
    extra = _guidance(cfg, rnd, feedback, ctx, st)
    uni = cfg["universes"][0]
    sels = SU.suggest("selection", cfg["region"], cfg["delay"], cfg["instrument"], uni, int(cfg["n_selections"]),
                      bool(cfg.get("own")), quiet, extra=extra)["expressions"]
    sels = _fw_filter(cfg, sels)
    combos = SU.suggest("combo", cfg["region"], cfg["delay"], cfg["instrument"], uni, int(cfg["n_combos"]),
                        False, quiet, extra=extra)["expressions"]
    if rnd == 1 and ctx:       # your own library goes first in round 1
        mine_s = [e if SU._HAS_OWN.search(e) or not cfg.get("own") else f"own && {e}" for e in (ctx.get("seed_selections") or [])]
        mine_c = list(ctx.get("seed_combos") or [])
        mine_s = [e for e in mine_s if _valid_sel(e)]
        mine_c = [e for e in mine_c if _valid_combo(e)]
        sels, combos = list(dict.fromkeys(mine_s + sels)), list(dict.fromkeys(mine_c + combos))
    return sels, combos


# ── 2. verification: a selection must pick MORE THAN 10 alphas ──────────────────────

_COUNTS: dict = {}


def _count_key(cfg: dict) -> tuple:
    return (cfg["region"], cfg["delay"], cfg["instrument"], cfg["selection_limit"], cfg["selection_handling"])


def verify_selections(cfg: dict, sels: list, progress, cancel) -> list:
    """Count the alphas each selection picks (cached). Returns [{selection, count, ok, note}]."""
    key, need = _count_key(cfg), int(cfg["min_components"])
    todo = [e for e in dict.fromkeys(sels) if (key, e) not in _COUNTS]
    if todo and not cancel():
        _live(phase="verifying")
        _event(f"verifying {len(todo)} selection(s): each must pick ≥ {need} alphas…", progress)
        r = SU.selection_preview(todo, cfg["region"], cfg["delay"], cfg["instrument"], cfg["selection_limit"],
                                 cfg["selection_handling"], need, lambda **k: None, cancel)
        for row in r.get("results", []):
            c = row.get("count")
            _COUNTS[(key, row["selection"])] = (c if isinstance(c, int) else None, row.get("message") or "")
        for rej in r.get("rejected", []):
            _COUNTS[(key, rej["expr"])] = (None, "invalid: " + ", ".join(rej.get("issues") or []))
    out = []
    for e in dict.fromkeys(sels):
        c, msg = _COUNTS.get((key, e), (None, "not checked"))
        ok = isinstance(c, int) and c >= need
        out.append({"selection": e, "count": c, "ok": ok,
                    "note": "" if ok else (msg or (f"only {c} alphas" if isinstance(c, int) else "could not be counted"))})
    return out


# ── pairs ────────────────────────────────────────────────────────────────────────────

def _pick_pairs(sels: list, combos: list, seen: set, cap: int) -> list:
    prods = [(a, b) for a in sels for b in combos if _norm(_join(a, b)) not in seen]
    random.shuffle(prods)
    chosen, used_s, used_c = [], set(), set()
    for passno in range(3):
        for a, b in prods:
            if len(chosen) >= cap:
                break
            if (a, b) in chosen:
                continue
            ok = (a not in used_s and b not in used_c) if passno == 0 else ((a not in used_s or b not in used_c) if passno == 1 else True)
            if ok:
                chosen.append((a, b)); used_s.add(a); used_c.add(b)
    return [_join(a, b) for a, b in chosen]


# ── 3-4. simulate + check ────────────────────────────────────────────────────────────

def _simulate(cfg: dict, exprs: list, thr: dict, cancel, neuts: list | None = None) -> dict:
    A._ensure_session()
    pairs = [p for p in (_split(e) for e in exprs) if p]
    if not pairs:
        return {"results": [], "errors": ["no valid selection -> combo pair"]}
    from app.harness.autopilot_route import engine_routing   # SentryEngine: opt-in shared slot lease (flag-gated)
    try:
        with engine_routing():
            return SU.run_simulation(
                selections=[], combos=[], pairs=pairs, region=cfg["region"], delay=cfg["delay"],
                instrument=cfg["instrument"], universes=cfg["universes"], neutralizations=neuts or cfg["neutralizations"],
                decay=cfg["decay"], truncation=cfg["truncation"], test_period="P0Y", pasteurization="ON",
                unit_handling="VERIFY", nan_handling="OFF", max_trade="OFF", selection_limit=cfg["selection_limit"],
                selection_handling=cfg["selection_handling"], concurrency=SU.SUPER_MAX_CONCURRENCY,
                max_turnover=cfg["max_turnover"], min_sharpe=thr["sharpe"], min_fitness=thr["fitness"],
                max_corr=cfg["max_corr"], tag=cfg["tag"], winner_tag="", winner_color="GREEN", tag_winners_above=99.0,
                check_submission=False, progress=lambda **k: None, should_cancel=cancel)
    except RuntimeError as e:
        return {"results": [], "errors": [str(e)[:200]]}


_CORR_ONLY = ("PROD", "SELF", "POWER", "POOL")


def _corr_only(chk: dict) -> bool:
    failed = chk.get("failed") or []
    return bool(failed) and not chk.get("pending") and all(any(k in str(f).upper() for k in _CORR_ONLY) for f in failed)


def _stored_corr(ids: list) -> dict:
    """prod / self / power-pool correlations already saved in Results, by alpha id."""
    if not ids:
        return {}
    try:
        with SessionLocal() as db:
            rows = db.execute(select(M.SimResult.alpha_id, M.SimResult.prod_corr, M.SimResult.self_corr, M.SimResult.powerpool_corr)
                              .where(M.SimResult.alpha_id.in_(list(ids)))).all()
        return {r[0]: {"prod_corr": r[1], "self_corr": r[2], "powerpool_corr": r[3]} for r in rows}
    except Exception:  # noqa: BLE001
        return {}


def _review(cfg: dict, rows: list) -> dict:
    """Full BRAIN check, the same way as the regular Autosentry: EVERY alpha that clears the minimum Sharpe and fitness (or passed the whole gate)
    is checked for production / self correlation unless Results already has its prod correlation; the checks run one at a time with
    `prod_check_delay` seconds before each (0 = up to 4 at once); plus the 2 best near-misses. Prod above `prod_rescue_max` is not rescued."""
    A._ensure_session()
    s = engine.require_session()
    thr0 = S.gate_thresholds(cfg["delay"])
    thr = {"sharpe": cfg.get("min_sharpe") or thr0["sharpe"], "fitness": cfg.get("min_fitness") or thr0["fitness"]}
    todo, reuse = PRD.split_for_prod(rows, thr, _stored_corr([r["alpha_id"] for r in rows if r.get("alpha_id")]))
    cand_ids = {id(r) for r in todo + reuse}
    misses = sorted([r for r in rows if r.get("alpha_id") and id(r) not in cand_ids and not r["passed"]], key=_score, reverse=True)[:2]
    full = {id(r) for r in todo}
    batch = todo + misses
    checks = A._checks_parallel(cfg, s, batch, full) if batch else {}
    stored = _stored_corr([r["alpha_id"] for r in reuse])
    for r in reuse:
        checks[r["alpha_id"]] = PRD.chk_from_stored(stored.get(r["alpha_id"]) or {}, cfg.get("max_corr", 0.70))
    if reuse:
        A._event(f"{len(reuse)} alpha(s) already had their prod correlation in Results: not checked again", A._CTX["progress"])
    checked = [r for r in todo + reuse + misses if r["alpha_id"] in checks]
    for r in checked:
        c = checks.get(r["alpha_id"]) or {}
        r["self_corr"], r["prod_corr"] = c.get("self_corr"), c.get("prod_corr")
    for r in todo + reuse:
        chk = checks.get(r["alpha_id"])
        if chk is None:                                  # cancelled before this one was checked
            r["passed"] = False
            continue
        if not chk.get("stored"):
            A._store_deep(r["alpha_id"], chk)
        r["passed"] = chk["ok"]
        r["corr_only"] = _corr_only(chk) and WN.worth_rescuing(chk.get("prod_corr"), cfg.get("prod_rescue_max", 0.74))
    return checks


def _batch_view(rows: list, checks: dict, tag: str = "") -> list:
    out = []
    for r in rows:
        why = (r.get("reasons") or []) + ((checks.get(r.get("alpha_id")) or {}).get("failed") or [])
        out.append({"expr": r["expr"], "alpha_id": r.get("alpha_id"), "sharpe": r.get("sharpe"), "fitness": r.get("fitness"),
                    "turnover": r.get("turnover"), "self_corr": r.get("self_corr"), "prod_corr": r.get("prod_corr"),
                    "passed": r["passed"], "reasons": ([tag] if tag else []) + why})
    return out


# ── 5. improve: flip negatives, low-correlation rebuilds, operator swaps, other neutralizations ──

def _tighten(sel: str, cfg: dict) -> list:
    """Selection variants that pick LOWER-CORRELATION component alphas."""
    c = float(cfg["max_corr"])
    outs = []
    for attr in ("prod_correlation", "self_correlation"):
        if re.search(rf"\b{attr}\b", sel):
            continue
        for t in sorted({round(max(0.2, c - 0.2), 2), round(max(0.2, c - 0.35), 2)}, reverse=True):
            outs.append(f"{sel} && {attr} < {t}")
    return outs


def _op_swaps(combo: str, limit: int) -> list:
    groups = K.active_opgroups("super")
    try:
        known = set(SU.vocab().get("combo_ops") or [])
    except Exception:
        known = set()
    return [e for e, _ in A._op_mutants(combo, groups, known, limit, validate=_valid_combo)]


def _followups(cfg: dict, rows: list, thr: dict, seen: set, progress, cancel):
    """ONE simulation for: reversed negatives + low-correlation rebuilds (+ combo swaps) of correlation-only
    failures. Returns (wins [(row, check)], new_rows, checks)."""
    cap = max(4, int(cfg["per_round"]) * 2)
    plan: list = []                                   # (expr, kind)
    if cfg.get("flip"):
        neg = [r for r in rows if r.get("sharpe") is not None and (r["sharpe"] < 0 or (r.get("fitness") or 0) < 0)
               and abs(r["sharpe"]) >= float(cfg["flip_min_sharpe"]) and (r.get("turnover") or 0) <= cfg["max_turnover"]]
        for r in sorted(neg, key=lambda r: -abs(r["sharpe"]))[:3]:
            f = flip_pair(r["expr"])
            if f and _valid_combo(_split(f)[1]):
                plan.append((f, "combo reversed"))
    if cfg.get("decorrelate"):
        for r in sorted([r for r in rows if r.get("corr_only")], key=_score, reverse=True)[:2]:
            sel, combo = _split(r["expr"])
            tight = [t for t in _tighten(sel, cfg) if _valid_sel(t)]
            counts = {x["selection"]: x for x in verify_selections(cfg, tight, progress, cancel)} if tight else {}
            for t in tight:
                if counts.get(t, {}).get("ok"):
                    plan.append((_join(t, combo), "low-corr selection"))
            for c2 in _op_swaps(combo, 3):
                plan.append((_join(sel, c2), "sister/brother operator"))
    uniq, kinds = [], {}
    for e, k in plan:
        n = _norm(e)
        if n in seen or n in kinds:
            continue
        kinds[n] = k
        uniq.append(e)
        if len(uniq) >= cap:
            break
    if not uniq:
        return [], [], {}
    for e in uniq:
        seen.add(_norm(e))
    _live(phase="improving")
    _event(f"improving: {len(uniq)} variants in one simulation (reversed combos · low-correlation selections · operator swaps)…", progress)
    res = _simulate(cfg, uniq, thr, cancel)
    nrows = res.get("results") or []
    if not nrows:
        return [], [], {}
    for r in nrows:
        r["via"] = kinds.get(_norm(r["expr"]), "")
    _live(phase="reviewing")
    checks = _review(cfg, nrows)
    _append_batch(_batch_view(nrows, checks))
    wins = [(r, checks.get(r["alpha_id"])) for r in nrows if r["passed"] and r.get("alpha_id")]
    _event(f"improvement round: {len(nrows)} simulated · {len(wins)} passed EVERYTHING", progress)
    for r in nrows:
        if r["passed"] and cfg.get("use_library"):
            K.add_lesson(f"Low-correlation fix that worked ({r['via']}): {_skeleton(r['expr'])[:180]}", "success", _lreg(cfg))
    return wins, nrows, checks


def _cross_neut(cfg: dict, rows: list, thr: dict, seen: set, progress, cancel):
    """For correlation-only failures that remain: the same pair under the other neutralizations."""
    left = sorted([r for r in rows if r.get("corr_only") and not r["passed"]], key=_score, reverse=True)[:2]
    if not left:
        return [], {}
    try:
        valid = engine.valid_neutralizations(cfg["instrument"], cfg["region"]) or set()
    except Exception:
        valid = set()
    others_all = [n for n in sorted(valid or {"FAST", "SLOW", "MARKET", "SECTOR", "INDUSTRY", "SUBINDUSTRY"})]
    wins, checks_all = [], {}
    for base in left:
        if cancel():
            break
        others = [n for n in others_all if n != base.get("neutralization")][:4]
        if not others:
            continue
        _live(phase="improving")
        _event(f"cross-neutralization for {base.get('alpha_id')}: {', '.join(others)}…", progress)
        res = _simulate(cfg, [base["expr"]], thr, cancel, neuts=others)
        nrows = res.get("results") or []
        if not nrows:
            continue
        for r in nrows:
            r["via"] = f"neutralization {r.get('neutralization')}"
        _live(phase="reviewing")
        chk = _review(cfg, nrows)
        checks_all.update(chk)
        _append_batch(_batch_view(nrows, chk))
        wins += [(r, chk.get(r["alpha_id"])) for r in nrows if r["passed"] and r.get("alpha_id")]
    return wins, checks_all


# ── 6. learn + bank ──────────────────────────────────────────────────────────────────

def _remember(rows: list, checks: dict) -> None:
    st = _load_state()
    for r in rows:
        if r.get("sharpe") is None:
            continue
        why = "; ".join((r.get("reasons") or []) + ((checks.get(r.get("alpha_id")) or {}).get("failed") or []))
        st["history"].append({"expr": r["expr"], "sharpe": r.get("sharpe"), "fitness": r.get("fitness"),
                              "turnover": r.get("turnover"), "self_corr": r.get("self_corr"),
                              "prod_corr": r.get("prod_corr"), "passed": bool(r["passed"]),
                              "why": "" if r["passed"] else why, "t": time.time()})
    st["simulated"] += len(rows)
    _save_state(st)


def _learn(cfg: dict, rows: list, checks: dict) -> None:
    if not cfg.get("use_library") or not rows:
        return
    K.learn_from_batch(_lreg(cfg), {"idea": "SuperAlpha batch"}, rows, _skeleton)
    metric_ok = [r for r in rows if r.get("corr_only")]
    if len(metric_ok) >= 2:
        sels = ", ".join(sorted({_split(r["expr"])[0][:70] for r in metric_ok if _split(r["expr"])}))[:240]
        K.add_lesson(f"{len(metric_ok)} SuperAlphas had good metrics but failed ONLY on correlation (selections: {sels}). "
                     "Add prod_correlation / self_correlation filters or diversify data categories.", "insight", _lreg(cfg))


def _feedback(rows: list, checks: dict, thr: dict, cfg: dict, counts: list) -> str:
    per: dict = {}
    for r in rows:
        per.setdefault(_skeleton(r["expr"]), []).append(r)
    lines = [f"Gate: |Sharpe|>={thr['sharpe']}, |Fitness|>={thr['fitness']}, turnover<{cfg['max_turnover']:.0%}, "
             f"self/prod correlation<{cfg['max_corr']}, no failing IS test."]
    for sk, lst in sorted(per.items(), key=lambda kv: -max(_score(x) for x in kv[1]))[:10]:
        b = max(lst, key=_score)
        why = list(b.get("reasons") or []) + list((checks.get(b.get("alpha_id")) or {}).get("failed") or [])
        cr = f" self {b['self_corr']:.2f} prod {b['prod_corr']:.2f}" if b.get("self_corr") is not None and b.get("prod_corr") is not None else ""
        lines.append(f"- {sk[:200]}\n    Sharpe {b.get('sharpe') and round(b['sharpe'], 2)}, Fitness {b.get('fitness') and round(b['fitness'], 2)}, "
                     f"turn {b.get('turnover') and round(b['turnover'], 2)}{cr} · fails: {'; '.join(dict.fromkeys(why)) or 'none'}")
    weak = [f"{x['selection'][:120]}  →  {x['count'] if x['count'] is not None else '?'} alphas" for x in counts if not x["ok"]][:5]
    if weak:
        lines.append(f"Selections discarded (picked fewer than {cfg['min_components']} alphas):\n" + "\n".join(weak))
    return "\n".join(lines)


def _bank(cfg: dict, r: dict, chk: dict | None, progress) -> dict:
    aid = r["alpha_id"]
    try:
        s = engine.require_session()
        ace.set_alpha_properties(s, aid, color="GREEN", tags=[t for t in [cfg["winner_tag"] or cfg["tag"]] if t])
    except Exception:
        pass
    try:
        with SessionLocal() as db:
            sr = db.scalar(select(M.SimResult).where(M.SimResult.alpha_id == aid))
            sid = sr.id if sr else 0
        if sid:
            from app.vault import service as vault
            vault.add_from_result(sid, note="Supersentry" + (f" · {r['via']}" if r.get("via") else ""),
                                  tags=["superpilot"] + (["decorrelated"] if r.get("via") else []))
    except Exception:
        pass
    w = {"alpha_id": aid, "expr": r["expr"], "sharpe": r.get("sharpe"), "fitness": r.get("fitness"),
         "turnover": r.get("turnover"), "self_corr": (chk or {}).get("self_corr"), "prod_corr": (chk or {}).get("prod_corr"),
         "via": r.get("via", ""), "neutralization": r.get("neutralization"), "t": time.time()}
    st = _load_state(); st["winners"].append(w); _save_state(st)
    if cfg.get("use_library"):
        try:
            K.add_asset("superalpha", r["expr"], name=f"Supersentry winner {aid}", source="autopilot",
                        meta={"sharpe": r.get("sharpe"), "fitness": r.get("fitness"), "alpha_id": aid, "engine": "super"})
            K.add_lesson(f"Winning SuperAlpha: {_skeleton(r['expr'])[:200]}", "success", _lreg(cfg))
        except Exception:
            pass
    try:
        if TG.config().get("notify_winners"):
            TG.send_async(f"★ Supersentry winner {aid}\nSharpe {w['sharpe']:.2f} · Fitness {w['fitness']:.2f}"
                          f"{' · ' + w['via'] if w.get('via') else ''}\n{r['expr'][:300]}", silent=True)
    except Exception:
        pass
    _event(f"★ WINNER {aid}: Sharpe {(w['sharpe'] or 0):.2f} · Fitness {(w['fitness'] or 0):.2f} · self {w['self_corr']} prod {w['prod_corr']}", progress)
    return w


# ── the loop ─────────────────────────────────────────────────────────────────────────

DEFAULTS = dict(
    region="USA", delay=1, instrument="EQUITY", universe="ILLIQUID_MINVOL1M", neutralizations=["FAST"],
    decay=10, truncation=0.08, selection_limit=1000, selection_handling="POSITIVE", own=True,
    min_components=11,              # "more than 10 alphas"
    per_round=6, n_selections=6, n_combos=6, goal="", tag="", winner_tag="",
    min_sharpe=None, min_fitness=None, max_turnover=0.70, max_corr=0.70,
    max_rounds=0, max_winners=0, pause_between_rounds=5,
    use_library=True, flip=True, flip_min_sharpe=0.5, decorrelate=True,
    prod_check_delay=60,          # seconds before each production-correlation check (as in Autosentry; 0 = up to 4 at once)
    prod_rescue_max=0.74,         # no rescue attempts for a prod correlation above this
)


_ACTIVE: dict = {"cfg": None}      # the running engine's cfg dict (the Telegram remote edits it in place)


def live_cfg():
    """The running engine's settings dict, or None when it is not running."""
    return _ACTIVE["cfg"] if is_running() else None


def start(cfg_in: dict) -> dict:
    if is_running():
        return {"job_id": _LIVE.get("job_id"), "already_running": True}
    try:
        from app.autopilot import service as _A
        if _A.status().get("running"):
            raise RuntimeError("The regular Autosentry is running — stop it first (they share BRAIN's simulation slots and session).")
    except ImportError:
        pass
    cfg = {**DEFAULTS, **{k: v for k, v in cfg_in.items() if v is not None}}
    cfg["_fw_stages"] = A._fw_plan(cfg, need_fields=False) if (cfg.get("framework_ids") or cfg.get("fw_categories")) else None
    cfg.update(_fw=None, _fw_i=0, _fw_n=0)
    cfg["universes"] = [cfg["universe"]]
    cfg["neutralizations"] = list(cfg["neutralizations"] or ["FAST"])
    cfg["min_components"] = max(1, int(cfg["min_components"]))
    cfg["per_round"] = max(2, min(30, int(cfg["per_round"])))
    with _LOCK:
        _LIVE.update({"phase": "starting", "wait": "", "round": 0, "selections": [], "candidates": [],
                      "last_batch": [], "events": []})
    st = _load_state(); st["started_at"] = time.time(); _save_state(st)

    def task(progress, should_cancel):
        return _run(cfg, progress, should_cancel)

    _ACTIVE["cfg"] = cfg
    try:
        from app.notify import remote as _RC
        _RC.remember_start("super", cfg_in)
    except Exception:
        pass
    jid = jobs.submit("superpilot", task)
    _live(job_id=jid)
    return {"job_id": jid}


def _run(cfg: dict, progress, cancel) -> dict:
    thr0 = S.gate_thresholds(cfg["delay"])
    thr = {"sharpe": cfg["min_sharpe"] or thr0["sharpe"], "fitness": cfg["min_fitness"] or thr0["fitness"],
           "turnover": cfg["max_turnover"]}
    # route the shared session code (Telegram re-login, waits) into THIS engine's panel
    A._HOOKS.update({"event": _event, "live": _live})
    A._CTX.update({"progress": progress, "cancel": cancel})
    stop_hu = threading.Event()
    threading.Thread(target=A._heads_up_loop, args=(stop_hu,), daemon=True).start()
    _COUNTS.clear()
    _event(f"Supersentry started · {cfg['region']}/{cfg['universe']}/delay {cfg['delay']} · {cfg['per_round']} SuperAlphas per round · "
           f"selections must pick ≥ {cfg['min_components']} alphas", progress)
    won_total, fails, feedback, empty = 0, 0, "", 0
    try:
        while not cancel():
            rnd = _load_state()["rounds"] + 1
            try:
                A._ensure_session()
                if cancel():
                    break
                _fw_turn(cfg, progress)
                _live(wait="", round=rnd, selections=[], candidates=[], last_batch=[])
                ctx = K.build_context(cfg["region"], "super") if cfg.get("use_library") else None
                st = _load_state()

                _live(phase="suggesting")
                _event(f"round {rnd}: asking the LLM for selections + combos with good performance and low correlation"
                       + (" (using your library + lessons)" if ctx and ctx["ids"] else "") + "…", progress)
                sels, combos = _suggest(cfg, rnd, feedback, ctx, st)
                if not sels or not combos:
                    raise RuntimeError("the LLM returned no valid selections/combos")

                counts = verify_selections(cfg, sels, progress, cancel)
                _live(selections=counts)
                usable = [x["selection"] for x in counts if x["ok"]]
                _event(f"round {rnd}: {len(usable)}/{len(counts)} selections pick ≥ {cfg['min_components']} alphas", progress)
                seen = _seen(cfg["region"])
                batch = _pick_pairs(usable, combos, seen, cfg["per_round"]) if usable else []
                if not batch:
                    empty += 1
                    feedback = ("No selection picked enough alphas, so nothing could be built. Selections tried:\n" +
                                "\n".join(f"{x['selection'][:120]} → {x['count']} alphas" for x in counts[:8]) +
                                f"\nEach selection MUST pick at least {cfg['min_components']} alphas: loosen thresholds, use at most two conditions."
                                if not usable else "Every selection/combo pair was already simulated. Produce STRUCTURALLY NEW selections and combos.")
                    if empty >= 4:
                        _event("⚠ four rounds without a usable candidate — check you have enough alphas for these settings", progress)
                    st = _load_state(); st["rounds"] += 1; _save_state(st)
                    _sleep(cfg["pause_between_rounds"], cancel)
                    continue
                empty = 0
                _live(candidates=batch)
                for e in batch:
                    seen.add(_norm(e))

                _live(phase="simulating")
                _event(f"round {rnd}: simulating {len(batch)} SuperAlphas (3 at a time)…", progress)
                res = _simulate(cfg, batch, thr, cancel)
                rows = res.get("results") or []
                if not rows:
                    errs = "; ".join(res.get("errors") or [])[:220]
                    _event(f"batch produced no results{(' — ' + errs) if errs else ''}", progress)
                    feedback = f"The last batch failed to simulate ({errs}). Simplify the expressions."
                    st = _load_state(); st["rounds"] += 1; _save_state(st)
                    continue

                _live(phase="reviewing")
                checks = _review(cfg, rows)
                _live(last_batch=_batch_view(rows, checks))
                gate = [r for r in rows if r["passed"]]
                _event(f"round {rnd}: {len(rows)} simulated · {len(gate)} passed EVERYTHING (incl. correlation)", progress)
                _learn(cfg, rows, checks)

                all_rows, wins = list(rows), [(r, checks.get(r["alpha_id"])) for r in gate]
                if (cfg.get("flip") or cfg.get("decorrelate")) and not cancel():
                    w2, n2, c2 = _followups(cfg, rows, thr, seen, progress, cancel)
                    wins += w2; all_rows += n2; checks.update(c2)
                if cfg.get("decorrelate") and not cancel():
                    still = [r for r in all_rows if r.get("corr_only") and not r["passed"]]
                    if still and not wins:
                        w3, c3 = _cross_neut(cfg, still, thr, seen, progress, cancel)
                        wins += w3; checks.update(c3)
                for r, chk in wins:
                    _bank(cfg, r, chk, progress); won_total += 1

                _remember(all_rows, checks)
                feedback = _feedback(rows, checks, thr, cfg, counts)
                st = _load_state(); st["rounds"] += 1; _save_state(st)
                fails = 0
                if cfg["max_winners"] and won_total >= cfg["max_winners"]:
                    _event(f"reached the winner target ({won_total}) — stopping.", progress); break
                if cfg["max_rounds"] and rnd >= cfg["max_rounds"]:
                    _event("reached the round limit — stopping.", progress); break
                _live(phase="cooldown")
                _sleep(cfg["pause_between_rounds"], cancel)
            except Exception as e:  # noqa: BLE001 — one bad round must not kill an unattended run
                fails += 1
                msg = (str(e).strip().splitlines() or [type(e).__name__])[0][:220]
                back = min(900, 20 * (2 ** min(fails, 6)))
                _event(f"⚠ round error ({fails}): {msg} — retrying in {back}s", progress)
                traceback.print_exc()
                _live(phase="waiting", wait=f"error: {msg} · retrying in {back}s")
                _sleep(back, cancel)
    finally:
        stop_hu.set()
        A._HOOKS.update({"event": None, "live": None})
        _live(phase="stopped", wait="")
        _event("Supersentry stopped.", progress)
    return {"winners": won_total}
