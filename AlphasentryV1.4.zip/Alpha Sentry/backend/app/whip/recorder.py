"""Always-on recorder of the backend's own output (Python logging + print/stderr), kept in memory for the Whip tab.
Nothing is written to disk here; output still goes to wherever it went before."""
from __future__ import annotations

import logging
import sys
import threading
import time
from collections import deque

_MAX = 2000
_LOCK = threading.Lock()
_LINES: deque = deque(maxlen=_MAX)
_SEQ = [0]
_INSTALLED = [False]


def _add(text: str, level: str = "") -> None:
    text = text.rstrip("\r\n")
    if not text.strip():
        return
    with _LOCK:
        _SEQ[0] += 1
        _LINES.append({"seq": _SEQ[0], "t": time.time(), "level": level, "text": text[:600]})


class _Handler(logging.Handler):
    def emit(self, record: logging.LogRecord) -> None:
        try:
            _add(f"{record.name}: {record.getMessage()}", record.levelname)
        except Exception:  # noqa: BLE001
            pass


class _Tee:
    """Wraps stdout/stderr: passes everything through unchanged and records complete lines."""
    def __init__(self, inner, level: str):
        self._inner, self._level, self._buf = inner, level, ""

    def write(self, s):
        try:
            self._buf += s if isinstance(s, str) else s.decode("utf-8", "replace")
            while "\n" in self._buf:
                line, self._buf = self._buf.split("\n", 1)
                _add(line, self._level)
        except Exception:  # noqa: BLE001
            pass
        return self._inner.write(s)

    def __getattr__(self, name):
        return getattr(self._inner, name)


def install() -> None:
    if _INSTALLED[0]:
        return
    _INSTALLED[0] = True
    root = logging.getLogger()
    if not any(isinstance(h, _Handler) for h in root.handlers):
        h = _Handler(); h.setLevel(logging.INFO)
        root.addHandler(h)
        if root.level == logging.NOTSET or root.level > logging.INFO:
            root.setLevel(logging.INFO)
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
        lg = logging.getLogger(name)
        if not any(isinstance(x, _Handler) for x in lg.handlers):
            lg.addHandler(_Handler())
    if not isinstance(sys.stdout, _Tee):
        sys.stdout = _Tee(sys.stdout, "OUT")
    if not isinstance(sys.stderr, _Tee):
        sys.stderr = _Tee(sys.stderr, "ERR")
    _add("Whip is recording the backend's output from here.", "INFO")


def lines(since: int = 0, limit: int = 400) -> dict:
    with _LOCK:
        rows = [r for r in _LINES if r["seq"] > since]
        seq = _SEQ[0]
    return {"lines": rows[-limit:], "seq": seq}
