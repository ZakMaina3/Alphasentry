"""Whip: a safe clean-up of temporary files and a recorder of the backend's own output."""
