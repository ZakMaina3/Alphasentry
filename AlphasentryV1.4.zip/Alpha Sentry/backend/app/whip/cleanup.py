"""Whip clean-up (pure, no app imports): remove only TEMPORARY files the tools do not need.

Rules that never bend:
  * an ALLOWLIST builds the plan (known names / patterns in known places); nothing is ever found by "everything except";
  * the final guard `is_safe` refuses anything protected (database, session, keys, licence, LLM cache and budget, Osmosis,
    results, library, settings, backups, symlinks) and anything outside the app folder / the system temp folder;
  * a live log is EMPTIED, not removed (a file another process holds open must keep working); if it is locked it is skipped.
"""
from __future__ import annotations

import os
import shutil
import time
from pathlib import Path

LOG_TRUNCATE = ("ace.log", "backend.log", "backend.err.log", "launcher.log")
LOG_DELETE = ("pip.log", "build.log", "setup_error.txt")
SKIP_DIRS = {".venv", "venv", "node_modules", ".git", "data", "seed"}
PROTECTED_NAMES = {
    "ace_studio_v2.db", "session.pkl", "licence.json", "llm_cache.json", "llm_budget.json", "osmosis_snapshot.json",
    "osmosis_journal.json", "catalog_state.json", "remote_state.json", "pyalpha_guideline.md", "wqb_options.json",
    "inflight.jsonl", "keys.json",
}
PROTECTED_SUFFIX = (".db", ".sqlite", ".pkl", ".key", ".env")
TMP_MIN_AGE_S = 120          # a .tmp younger than this may still be being written


def _within(p: Path, base: Path) -> bool:
    try:
        p.resolve().relative_to(base.resolve())
        return True
    except (ValueError, OSError):
        return False


def is_safe(path: Path, root: Path, data_dir: Path, tmp_dir: Path, kind: str) -> bool:
    """The last gate before anything is touched."""
    try:
        if path.is_symlink():
            return False
        name = path.name.lower()
        if name in PROTECTED_NAMES or name.endswith(PROTECTED_SUFFIX):
            return False
        if "backups" in {x.lower() for x in path.parts}:
            return False
        if _within(path, data_dir):                       # inside data/: only a stale top-level *.tmp
            return kind == "delete_file" and path.parent.resolve() == data_dir.resolve() and name.endswith(".tmp")
        if _within(path, tmp_dir):                        # system temp: only our own updater folders
            return kind == "delete_dir" and name.startswith("ace_upd_")
        if _within(path, root):
            if kind == "delete_dir":
                return name == "__pycache__"
            return name in LOG_TRUNCATE or name in LOG_DELETE
        return False
    except OSError:
        return False


def _size(p: Path) -> int:
    try:
        if p.is_file():
            return p.stat().st_size
        return sum(f.stat().st_size for f in p.rglob("*") if f.is_file() and not f.is_symlink())
    except OSError:
        return 0


def build_plan(root: Path, data_dir: Path, tmp_dir: Path, now: float | None = None) -> list:
    """[{id, label, kind, path, bytes}] of what a clean-up WOULD remove (empty files and empty folders are left out)."""
    now = time.time() if now is None else now
    root, data_dir, tmp_dir = Path(root), Path(data_dir), Path(tmp_dir)
    items: list = []

    def add(group: str, label: str, kind: str, p: Path):
        if not p.exists() or not is_safe(p, root, data_dir, tmp_dir, kind):
            return
        n = _size(p)
        if n > 0 or kind == "delete_dir":
            items.append({"id": f"{group}:{p}", "group": group, "label": label, "kind": kind, "path": str(p), "bytes": n})

    for base in {root, root / "backend", data_dir, root / "logs"}:
        for nm in LOG_TRUNCATE:
            add("logs", nm, "truncate", base / nm)
        for nm in LOG_DELETE:
            add("install_logs", nm, "delete_file", base / nm)
    for dirpath, dirnames, _files in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not (Path(dirpath) / d).is_symlink()]
        if Path(dirpath).name == "__pycache__":
            add("pycache", str(Path(dirpath).relative_to(root)), "delete_dir", Path(dirpath))
            dirnames[:] = []
    if data_dir.is_dir():
        for f in data_dir.glob("*.tmp"):
            try:
                if now - f.stat().st_mtime >= TMP_MIN_AGE_S:
                    add("tmp", f.name, "delete_file", f)
            except OSError:
                pass
    if tmp_dir.is_dir():
        for d in tmp_dir.glob("ace_upd_*"):
            if d.is_dir():
                add("updater_tmp", d.name, "delete_dir", d)
    return items


def summarize(items: list) -> dict:
    groups: dict = {}
    for it in items:
        g = groups.setdefault(it["group"], {"group": it["group"], "files": 0, "bytes": 0})
        g["files"] += 1
        g["bytes"] += it["bytes"]
    return {"groups": sorted(groups.values(), key=lambda g: -g["bytes"]), "bytes": sum(i["bytes"] for i in items), "files": len(items)}


def run_plan(items: list, root: Path, data_dir: Path, tmp_dir: Path) -> dict:
    """Do the plan. Every item is re-checked with `is_safe` right before it is touched; a failure on one never stops the rest."""
    freed, done, skipped = 0, 0, []
    for it in items:
        p = Path(it["path"])
        try:
            if not is_safe(p, Path(root), Path(data_dir), Path(tmp_dir), it["kind"]):
                skipped.append({"path": it["path"], "why": "not on the safe list"})
                continue
            before = _size(p)
            if it["kind"] == "truncate":
                with open(p, "r+b") as fh:
                    fh.truncate(0)
            elif it["kind"] == "delete_file":
                p.unlink()
            elif it["kind"] == "delete_dir":
                shutil.rmtree(p, ignore_errors=False)
            freed += before
            done += 1
        except FileNotFoundError:
            pass
        except OSError as e:
            skipped.append({"path": it["path"], "why": f"in use or locked ({type(e).__name__})"})
    return {"freed": freed, "cleaned": done, "skipped": skipped}


def human(n: int) -> str:
    x = float(n)
    for u in ("B", "KB", "MB", "GB"):
        if x < 1024 or u == "GB":
            return f"{x:.0f} {u}" if u == "B" else f"{x:.1f} {u}"
        x /= 1024
    return f"{n} B"
