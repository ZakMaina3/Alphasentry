"""LLM advice on a pasted framework: which category pair suits it best. The answer is checked against the pairing rules
(blocked pairs are dropped); when the LLM is unavailable or answers badly, the rules alone pick the pair."""
from __future__ import annotations

import re
from itertools import combinations

from app.frameworks import rules as R


def prompt(fw: dict) -> str:
    cats = ", ".join(R.CATEGORIES)
    slots = "\n".join(f"  {s.get('name')}: {s.get('definition') or '?'}" for s in fw.get("slots") or [])
    return (
        "You advise a WorldQuant BRAIN alpha researcher. Read this research framework and choose which TWO BRAIN data "
        "categories should be paired to implement it, following the pairing guide below. Return ONLY a JSON array of up to 3 "
        "strings, best first. Each string has the form: categoryA + categoryB :: one-sentence reason. "
        f"Use only these category names: {cats}.\n"
        f"=== FRAMEWORK: {fw.get('name', '')} (region {fw.get('region') or 'any'}) ===\n"
        f"Expression: {fw.get('expression') or '?'}\nSlots:\n{slots}\n"
        f"Mechanism: {fw.get('mechanism') or '?'}\nRationale: {str(fw.get('rationale') or '')[:1500]}\n"
        "=== PAIRING GUIDE ===\n" + R.guide_text(list(R.CATEGORIES)))


def parse_suggestions(items: list, limit: int = 3) -> list[dict]:
    """['analyst + fundamental :: why', ...] -> checked suggestions; rejected / unknown / duplicate pairs are dropped."""
    out, seen = [], set()
    for raw in items or []:
        head, _, why = str(raw).partition("::")
        parts = [R.normalize(x) for x in re.split(r"\+|&|,|\band\b", head)]
        parts = [p for p in dict.fromkeys(parts) if p]
        if len(parts) != 2:
            continue
        v = R.verdict(parts[0], parts[1])
        key = frozenset(parts)
        if v["verdict"] in ("reject", "same") or key in seen:
            continue
        seen.add(key)
        out.append({"cats": parts, "why": why.strip() or v.get("reason", ""), "verdict": v["verdict"], "source": "llm"})
        if len(out) >= limit:
            break
    return out


def fallback(fw: dict, limit: int = 3) -> list[dict]:
    """Rules-only choice: pairs among the framework's own categories (tier 1 first), else the best tier-1 pairs overall."""
    cats = [c for c in (fw.get("categories") or []) if c in R.CATEGORIES]
    cand = [R.verdict(a, b) for a, b in combinations(dict.fromkeys(cats), 2)]
    if not any(v["verdict"] in ("tier1", "tier2") for v in cand):
        cand += [v for v in R.all_pairs() if v["verdict"] == "tier1" and (not cats or set((v["a"], v["b"])) & set(cats))]
    rank = {"tier1": 0, "tier2": 1, "free": 2}
    cand = sorted((v for v in cand if v["verdict"] in rank), key=lambda v: rank[v["verdict"]])
    out = []
    for v in cand[:limit]:
        out.append({"cats": [v["a"], v["b"]], "verdict": v["verdict"], "source": "rules",
                    "why": v.get("why") or v.get("build") or v.get("reason") or ""})
    return out


def suggest(fw: dict, ask) -> dict:
    """ask(prompt) -> list[str] (the LLM call, injected). Returns {suggestions, best, source, note}."""
    note = ""
    sugg: list[dict] = []
    try:
        sugg = parse_suggestions(ask(prompt(fw)))
        if not sugg:
            note = "The LLM gave no usable pair, so the pairing rules chose."
    except Exception as e:  # noqa: BLE001
        note = f"LLM not available ({str(e)[:100]}); the pairing rules chose."
    if not sugg:
        sugg = fallback(fw)
    return {"suggestions": sugg, "best": sugg[0] if sugg else None, "note": note}
