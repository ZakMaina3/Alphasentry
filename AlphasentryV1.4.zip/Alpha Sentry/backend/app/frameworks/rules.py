"""The pairing rulebook: which data categories may be combined, in which roles, and which pairs are blocked.

Source: "Pairing BRAIN Data Categories Without Overfitting" (Fred M). Roles: signal (supplies the forecast), confirmation (independent view of the
same thing), gate (decides when the signal trades), scaler (decides how much, or relative to what).
A pair the guide does not mention is "free" (allowed). A rejected pair is blocked.
"""
from __future__ import annotations

import re
from itertools import combinations

CATEGORIES = ["analyst", "fundamental", "earnings", "pricevolume", "news", "shortinterest", "insiders", "institutions",
              "option", "sentiment", "socialmedia", "model", "risk", "macro", "imbalance"]
LABEL = {"pricevolume": "Price Volume", "shortinterest": "Short Interest", "socialmedia": "Social Media"}

_ALIASES = {
    "pv": "pricevolume", "price": "pricevolume", "pricevolume": "pricevolume", "pricevol": "pricevolume", "volume": "pricevolume",
    "technical": "pricevolume", "marketdata": "pricevolume",
    "analyst": "analyst", "analysts": "analyst", "analystestimates": "analyst", "estimates": "analyst", "broker": "analyst",
    "fundamental": "fundamental", "fundamentals": "fundamental", "financial": "fundamental",
    "earnings": "earnings", "earning": "earnings",
    "news": "news", "sentiment": "sentiment", "socialmedia": "socialmedia", "social": "socialmedia",
    "shortinterest": "shortinterest", "short": "shortinterest", "insiders": "insiders", "insider": "insiders",
    "institutions": "institutions", "institutional": "institutions", "institution": "institutions", "ownership": "institutions",
    "option": "option", "options": "option", "model": "model", "models": "model", "quant": "model", "quantitative": "model",
    "risk": "risk", "macro": "macro", "macroeconomic": "macro", "imbalance": "imbalance", "orderimbalance": "imbalance",
}


def normalize(name: str) -> str:
    """'Price Volume' / 'pv' / 'Price-Volume' -> 'pricevolume'; '' when it is not a category we know (the original is kept by callers)."""
    k = re.sub(r"[^a-z]", "", str(name or "").lower())
    if k in _ALIASES:
        return _ALIASES[k]
    for a, c in _ALIASES.items():                     # 'Analyst Estimates & Revisions' etc.
        if len(a) >= 5 and a in k:
            return c
    return ""


def label(cat: str) -> str:
    return LABEL.get(cat, cat.capitalize())


def _p(a, b, ra, rb, measure, build, why):
    return {"roles": {a: ra, b: rb}, "measure": measure, "build": build, "why": why}


TIER1 = {
    frozenset(("analyst", "fundamental")): _p("analyst", "fundamental", "signal", "anchor", "expectations vs reality",
        "gap between forward estimates and trailing actuals", "Analysts price the future, fundamentals record the past; the gap is information"),
    frozenset(("analyst", "earnings")): _p("analyst", "earnings", "signal", "event gate", "expectation vs realization",
        "revisions after a surprise, with trade_when around reports", "Analysts update slowly after surprises, so revisions keep drifting"),
    frozenset(("analyst", "pricevolume")): _p("analyst", "pricevolume", "signal", "timing", "information not yet priced",
        "revisions where price has not moved yet", "Targets the window where the market has not caught up"),
    frozenset(("earnings", "pricevolume")): _p("earnings", "pricevolume", "signal", "confirmation", "post-earnings drift",
        "surprise confirmed by abnormal volume", "Volume shows the surprise was noticed but not fully absorbed"),
    frozenset(("news", "pricevolume")): _p("pricevolume", "news", "signal", "gate", "news vs no-news moves",
        "momentum on news days, reversal on no-news days", "Moves with a reason persist; moves without one tend to revert"),
    frozenset(("shortinterest", "pricevolume")): _p("shortinterest", "pricevolume", "signal", "scaler", "crowded shorts",
        "short interest divided by volume (days to cover)", "Scaling by volume measures how hard the short is to exit"),
    frozenset(("insiders", "pricevolume")): _p("insiders", "pricevolume", "signal", "condition", "informed contrarian buying",
        "insider buying after price weakness", "Insiders buying into a drop is a stronger signal than buying into a rally"),
    frozenset(("option", "pricevolume")): _p("option", "pricevolume", "view 1", "view 2", "implied vs realized risk",
        "implied minus realized volatility; skew vs recent returns", "The option market often prices risk before the stock does"),
    frozenset(("option", "earnings")): _p("option", "earnings", "signal", "event gate", "expected vs typical event move",
        "implied move vs historical earnings reaction", "Mispriced event risk shows up as a gap between the two"),
}

TIER2 = {
    frozenset(("analyst", "sentiment")): dict(_p("analyst", "sentiment", "view 1", "view 2", "two views of changing expectations", "",
        "Two views of changing expectations"), watch="Only valid if the sentiment source is independent of analyst data"),
    frozenset(("fundamental", "risk")): dict(_p("fundamental", "risk", "signal", "scaler", "quality or value per unit of risk", "",
        "Quality or value per unit of risk"), watch="Use Risk as a scaler only, never as a second signal"),
    frozenset(("shortinterest", "fundamental")): dict(_p("shortinterest", "fundamental", "signal", "anchor", "shorts targeting weak fundamentals", "",
        "Shorts targeting weak fundamentals"), watch="Both are slow, so out-of-sample evidence builds slowly"),
    frozenset(("insiders", "institutions")): dict(_p("insiders", "institutions", "view 1", "view 2", "two ownership views agreeing", "",
        "Two ownership views agreeing"), watch="Filing lags differ a lot; align them with ts_backfill"),
    frozenset(("sentiment", "pricevolume")): dict(_p("sentiment", "pricevolume", "signal", "confirmation", "sentiment diverging from price", "",
        "Sentiment diverging from price"), watch="Fast and crowded; check prod correlation early"),
    frozenset(("socialmedia", "pricevolume")): dict(_p("socialmedia", "pricevolume", "signal", "confirmation", "attention spikes and retail-flow reversal", "",
        "Attention spikes and retail-flow reversal"), watch="Coverage is thin outside popular names"),
    frozenset(("model", "pricevolume")): dict(_p("model", "pricevolume", "signal", "gate", "model output with a timing or liquidity filter", "",
        "Model output with a timing or liquidity filter"), watch="Use Price Volume as a gate only, since the model may already contain it"),
    frozenset(("macro", "risk")): dict(_p("macro", "risk", "regime", "scaler", "market regime times each stock's exposure", "",
        "Market regime times each stock's exposure"), watch="The only valid route for Macro"),
    frozenset(("imbalance", "pricevolume")): dict(_p("imbalance", "pricevolume", "signal", "confirmation", "auction pressure vs the close", "",
        "Auction pressure vs the close"), watch="Very short horizon; this is Imbalance's only workable partner"),
}

SLOW = {"fundamental", "analyst", "institutions"}
FAST = {"news", "sentiment", "socialmedia", "imbalance"}      # "fast, noisy"; Price Volume is paired explicitly above


def _reject_reason(a: str, b: str) -> str:
    s = {a, b}
    if "macro" in s and s != {"macro", "risk"}:
        return "Macro is the same for every stock, so neutralization removes it; any result is a tuned interaction. Macro only works with Risk."
    if "imbalance" in s and (s - {"imbalance"}) & SLOW:
        return "Imbalance and slow categories (Fundamental, Analyst, Institutions) have horizons that differ by orders of magnitude, so each side is noise to the other."
    if "socialmedia" in s and (s - {"socialmedia"}) & {"fundamental", "institutions"}:
        return "Social Media with Fundamental or Institutions: mismatched horizons and coverage; the overlap is a small, biased set of stocks."
    if s == {"news", "sentiment"}:
        return "News with Sentiment: when from the same source it is the same information counted twice, not confirmation."
    if a in FAST and b in FAST:
        return "Two fast, noisy signals added together: the mixing weight becomes a free parameter fitted to history."
    return ""


def verdict(a: str, b: str) -> dict:
    """How two categories (already normalized) may be combined: tier1 / tier2 / free / reject / same."""
    if a == b:
        return {"a": a, "b": b, "verdict": "same"}
    key = frozenset((a, b))
    why = _reject_reason(a, b)
    if why and key not in TIER1 and key not in TIER2:
        return {"a": a, "b": b, "verdict": "reject", "reason": why}
    if key in TIER1:
        return {"a": a, "b": b, "verdict": "tier1", **TIER1[key]}
    if key in TIER2:
        return {"a": a, "b": b, "verdict": "tier2", **TIER2[key]}
    return {"a": a, "b": b, "verdict": "free", "reason": "Not covered by the guide, so allowed."}


def check_set(cats: list[str]) -> list[dict]:
    """Verdict for every pair inside a set of categories."""
    cs = list(dict.fromkeys(c for c in cats if c))
    return [verdict(a, b) for a, b in combinations(cs, 2)]


def blocked(cats: list[str]) -> list[dict]:
    return [v for v in check_set(cats) if v["verdict"] == "reject"]


def all_pairs() -> list[dict]:
    """Every pair of known categories with its verdict (for the chooser)."""
    return [verdict(a, b) for a, b in combinations(CATEGORIES, 2)]


def guide_text(cats: list[str]) -> str:
    """The rules for these categories as text for the LLM prompt."""
    cs = list(dict.fromkeys(c for c in cats if c))
    lines = []
    for v in check_set(cs):
        if v["verdict"] in ("tier1", "tier2"):
            roles = ", ".join(f"{label(k)} = {r}" for k, r in v["roles"].items())
            s = f"- {label(v['a'])} + {label(v['b'])} ({'strong' if v['verdict'] == 'tier1' else 'use with discipline'}): {roles}."
            if v.get("build"):
                s += f" Build: {v['build']}."
            if v.get("watch"):
                s += f" Watch: {v['watch']}."
            lines.append(s)
    out = ("PAIRING RULES (follow them; a hypothesis may combine datafields only from category pairs that are allowed):\n" + "\n".join(lines)) if lines else ""
    out += ("\nNever combine: Macro with anything except Risk; Imbalance with Fundamental/Analyst/Institutions; Social Media with Fundamental/"
            "Institutions; News with Sentiment from the same source; a Model field with the fields it is built from; any two fast noisy signals.")
    return out
