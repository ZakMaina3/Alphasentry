"""Turn the text of a research framework (pasted or extracted from a file) into structured frameworks you can review and edit.

Understands the shape of a BRAIN community framework post: a rationale, then 'Framework N: title' blocks, each with an expression that has
Field_X / Field_Y placeholders, 'Field_X = definition' lines and a 'Mechanism:' line, optionally under region headings such as
'GBR Region Frameworks'. Anything it cannot read is left empty for you to fill in; it never invents a framework.
"""
from __future__ import annotations

import re

from app.frameworks import rules as R

_REGIONS = {"USA", "EUR", "ASI", "GLB", "CHN", "AMR", "JPN", "HKG", "KOR", "TWN", "IND", "GBR", "DEU"}
_HEAD = re.compile(r"^\s*Framework\s+(\d+)\s*[:\-–—.]\s*(.+?)\s*$", re.I)
_REGION_HEAD = re.compile(r"^\s*([A-Z]{3})\b[^\n]*\bRegion", re.I)
_DEF = re.compile(r"^\s*(Field_[A-Za-z0-9]+)\s*=\s*(.+?)\s*$")
_FUNC = re.compile(r"\b([a-z][a-z0-9_]*)\s*\(")
_NOT_OPS = {"field", "if", "and", "or"}

# keyword -> category, a hit counts 1; phrases count 3 (checked first, so 'earnings yield' is fundamental, not earnings)
_PHRASES = [("earnings yield", "fundamental", 3), ("price volume", "pricevolume", 3), ("short interest", "shortinterest", 3),
            ("social media", "socialmedia", 3), ("p/e", "fundamental", 3)]
_WORDS = {
    "analyst": "analyst", "estimate": "analyst", "estimates": "analyst", "broker": "analyst", "revision": "analyst", "revisions": "analyst",
    "forecast": "analyst", "forecasts": "analyst", "consensus": "analyst", "eps": "analyst",
    "fundamental": "fundamental", "ebitda": "fundamental", "financial": "fundamental", "valuation": "fundamental", "revenue": "fundamental",
    "balance": "fundamental", "cash": "fundamental", "profit": "fundamental", "margin": "fundamental",
    "earnings": "earnings", "surprise": "earnings",
    "volume": "pricevolume", "liquidity": "pricevolume", "microstructure": "pricevolume", "price": "pricevolume", "technical": "pricevolume",
    "momentum": "pricevolume", "turnover": "pricevolume", "reversal": "pricevolume",
    "news": "news", "sentiment": "sentiment", "insider": "insiders", "insiders": "insiders", "institutional": "institutions",
    "institutions": "institutions", "ownership": "institutions", "option": "option", "options": "option", "implied": "option",
    "volatility": "option", "model": "model", "quantitative": "model", "quant": "model", "factor": "model", "proprietary": "model",
    "risk": "risk", "macro": "macro", "imbalance": "imbalance", "short": "shortinterest",
}


def categories_of(text: str) -> list[str]:
    """Best-guess data categories of a field definition such as 'Analyst EPS Consensus / Broker Forecasts' (top one, plus a tie)."""
    t = " " + re.sub(r"[^a-z/ ]", " ", str(text).lower()) + " "
    score: dict[str, int] = {}
    for ph, cat, w in _PHRASES:
        if ph in t:
            score[cat] = score.get(cat, 0) + w
            t = t.replace(ph, " ")
    for w in re.findall(r"[a-z]+", t):
        c = _WORDS.get(w)
        if c:
            score[c] = score.get(c, 0) + 1
    if not score:
        return []
    top = max(score.values())
    return [c for c, s in sorted(score.items(), key=lambda kv: (-kv[1], R.CATEGORIES.index(kv[0]))) if s == top][:2]


def operators_of(expr: str) -> list[str]:
    out: list[str] = []
    for m in _FUNC.findall(expr or ""):
        if m not in _NOT_OPS and m not in out:
            out.append(m)
    return out


def _neutralization(expr: str) -> str:
    m = re.search(r"group_neutralize\s*\(.*,\s*([A-Za-z_]+)\s*\)\s*$", (expr or "").strip())
    return m.group(1).upper() if m else ""


def _region_from(text: str) -> str:
    m = _REGION_HEAD.match(text)
    if m and m.group(1).upper() in _REGIONS:
        return m.group(1).upper()
    return ""


def parse(text: str, source: str = "") -> dict:
    """{frameworks: [...], rationale, warnings}. Each framework: name, region, delay, universe, expression, slots, categories, operators,
    neutralization, mechanism, rationale, warnings."""
    lines = [l.rstrip() for l in str(text or "").replace("\r\n", "\n").split("\n")]
    heads = [i for i, l in enumerate(lines) if _HEAD.match(l)]
    if not heads:
        return {"frameworks": [], "rationale": "", "warnings": ["No 'Framework 1: …' headings were found. Paste a framework or add the framework as a single block by hand."]}
    rationale = "\n".join(l for l in lines[:heads[0]] if l.strip())
    rationale = re.sub(r"\n{3,}", "\n\n", rationale)[:2500]
    # region per heading: the nearest region heading above it, else the first region code in parentheses in the text above
    default_region = ""
    m = re.search(r"\(([A-Z]{3})\)", rationale)
    if m and m.group(1) in _REGIONS:
        default_region = m.group(1)
    fws: list[dict] = []
    cur_region = ""
    bounds = heads + [len(lines)]
    for hi, start in enumerate(heads):
        for l in lines[(heads[hi - 1] + 1 if hi else 0):start]:
            r = _region_from(l)
            if r:
                cur_region = r
        end = bounds[hi + 1]
        # a region heading just before the next framework belongs to the next one, not this block
        block = lines[start + 1:end]
        while block and (not block[-1].strip() or _region_from(block[-1])):
            block.pop()
        name = _HEAD.match(lines[start]).group(2).strip()
        expr, mech, defs = "", "", {}
        for l in block:
            s = l.strip()
            if not s:
                continue
            d = _DEF.match(s)
            if d:
                defs[d.group(1)] = d.group(2)
            elif s.lower().startswith("mechanism"):
                mech = s.split(":", 1)[-1].strip()
            elif s.lower().startswith("field definitions"):
                continue
            elif not expr and "(" in s and ("Field_" in s or _FUNC.search(s)):
                expr = s
        slots = []
        warnings: list[str] = []
        names = list(dict.fromkeys(re.findall(r"Field_[A-Za-z0-9]+", expr)))
        for n in names or list(defs):
            cats = categories_of(defs.get(n, ""))
            slots.append({"name": n, "definition": defs.get(n, ""), "categories": cats})
            if not cats:
                warnings.append(f"{n}: could not tell which data category it is; set it by hand.")
        if not expr:
            warnings.append("No expression found in this block.")
        fw = {"name": name, "region": cur_region or default_region, "delay": 1, "universe": "", "expression": expr, "slots": slots,
              "categories": list(dict.fromkeys(c for s in slots for c in s["categories"][:1])), "operators": operators_of(expr),
              "neutralization": _neutralization(expr), "mechanism": mech, "rationale": rationale, "source": source, "warnings": warnings}
        fw["blocked"] = R.blocked(fw["categories"])
        for b in fw["blocked"]:
            fw["warnings"].append(f"{R.label(b['a'])} + {R.label(b['b'])} is a rejected pair: {b['reason']}")
        fws.append(fw)
    return {"frameworks": fws, "rationale": rationale, "warnings": []}
