"""Frameworks: uploaded research frameworks, the category pairing rulebook (Fred M, "Pairing BRAIN Data Categories Without Overfitting"),
the per-field alpha-count range, and the plan that Autosentry / Supersentry follow. Pure functions; nothing here talks to BRAIN."""
