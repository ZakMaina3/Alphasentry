"""Saved frameworks (kept as Alpha Sentry library assets of kind 'framework') and the catalog rows a run draws from."""
from __future__ import annotations

FIELDS = ("name", "region", "delay", "universe", "expression", "slots", "categories", "operators", "neutralization", "mechanism", "rationale", "source")


def clean(fw: dict) -> dict:
    out = {k: fw.get(k) for k in FIELDS}
    out["name"] = str(out["name"] or "Framework").strip()[:120]
    out["region"] = str(out["region"] or "").strip().upper()
    out["delay"] = int(out["delay"] or 1)
    out["universe"] = str(out["universe"] or "").strip().upper()
    out["slots"] = [{"name": str(s.get("name", "")), "definition": str(s.get("definition", "")),
                     "categories": [str(c) for c in (s.get("categories") or [])]} for s in (out["slots"] or [])]
    out["categories"] = list(out["categories"] or dict.fromkeys(c for s in out["slots"] for c in s["categories"][:1]))
    out["operators"] = [str(o) for o in (out["operators"] or [])]
    for k in ("expression", "neutralization", "mechanism", "rationale", "source"):
        out[k] = str(out[k] or "")
    return out


def save(frameworks: list[dict]) -> dict:
    from app.autopilot import library as K
    saved, errors = [], []
    for fw in frameworks:
        c = clean(fw)
        body = f"{c['name']}\n{c['region']} {c['expression']}"
        r = K.add_asset("framework", body, name=c["name"], meta=c, source="user")
        (errors if r.get("error") else saved).append(r.get("error") or r)
    return {"saved": len(saved), "errors": errors, "ids": [r.get("id") for r in saved if r.get("id")]}


def save_setup(name: str, sel: dict) -> dict:
    """Remember a whole choice (frameworks ticked, categories, pairs, min/max alphas) under a name. Same name = overwrite."""
    from app.autopilot import library as K
    name = (name or "").strip()[:80]
    if not name:
        return {"error": "Give the setup a name."}
    keep = {"ids": [int(i) for i in sel.get("ids") or []], "cats": [str(c) for c in sel.get("cats") or []],
            "pairs": [[str(a), str(b)] for a, b in (sel.get("pairs") or []) if a and b],
            "lo": int(sel.get("lo") or 0), "hi": int(sel.get("hi") or 0)}
    for s in K.list_assets("fwsetup"):
        if s["name"] == name:
            return K.update_asset(s["id"], {"meta": {"sel": keep}})
    return K.add_asset("fwsetup", f"setup:{name}", name=name, meta={"sel": keep}, source="user")


def setups() -> list[dict]:
    from app.autopilot import library as K
    return [{"id": a["id"], "name": a["name"], **(a["meta"].get("sel") or {})} for a in K.list_assets("fwsetup")]


def listing() -> list[dict]:
    from app.autopilot import library as K
    out = []
    for a in K.list_assets("framework", full=True):
        out.append({"id": a["id"], "enabled": a["enabled"], **{k: (a["meta"] or {}).get(k) for k in FIELDS}, "name": a["name"]})
    return out


def get_many(ids: list[int]) -> list[dict]:
    want = {int(i) for i in ids}
    return [f for f in listing() if f["id"] in want]


def catalog_rows(region: str, delay: int) -> list[dict]:
    """Every datafield in the Data Catalog for this market, with its category and alpha count."""
    from app.catalog import service as CS
    from app.db.base import SessionLocal
    stmt = CS._query(region=region, delay=int(delay))
    with SessionLocal() as db:
        return [CS._row(*r) for r in db.execute(stmt.limit(300000)).all()]


def category_counts(region: str, delay: int, lo: int | None = None, hi: int | None = None) -> list[dict]:
    """[{category (as the catalog names it), key (normalized), fields, in_range}] for the chooser."""
    from app.frameworks import plan as PL
    agg: dict[str, dict] = {}
    for r in catalog_rows(region, delay):
        k = PL.row_category(r)
        if not k:
            continue
        a = agg.setdefault(k, {"key": k, "category": r.get("category") or k, "fields": 0, "in_range": 0})
        a["fields"] += 1
        a["in_range"] += 1 if PL.count_ok(r.get("alpha_count"), lo, hi) else 0
    return sorted(agg.values(), key=lambda x: -x["fields"])
