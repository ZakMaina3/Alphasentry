"""What a framework run does: which catalog fields are eligible (categories + alpha-count range), the stages Autosentry/Supersentry cycle through,
the text the LLM gets, and the check that blocks hypotheses that mix categories the rulebook rejects."""
from __future__ import annotations

import random
from itertools import combinations
from typing import Any

from app.frameworks import rules as R

DEFAULT_UNIVERSE = {"USA": "TOP3000", "EUR": "TOP2500", "GLB": "TOP3000", "ASI": "MINVOL1M", "CHN": "TOP2000U", "JPN": "TOP1600", "IND": "TOP500",
                    "KOR": "TOP600", "TWN": "TOP500", "HKG": "TOP800", "GBR": "TOP1200", "DEU": "TOP1000", "AMR": "TOP600"}


def row_category(row: dict) -> str:
    c = str(row.get("category") or "")
    return R.normalize(c) or c.strip().lower()


def count_ok(n: Any, lo: int | None, hi: int | None) -> bool:
    """Is a field's alpha count inside the range? lo / hi of None or 0 mean 'no limit' on that side."""
    try:
        n = int(n or 0)
    except (TypeError, ValueError):
        n = 0
    return (not lo or n >= int(lo)) and (not hi or n <= int(hi))


def eligible_fields(rows: list[dict], categories: list[str], lo: int | None = None, hi: int | None = None, limit: int = 400,
                    seed: int | None = None) -> tuple[list[dict], dict]:
    """Catalog rows ({field_id, dataset_id, type, description, category, alpha_count}) in the chosen categories and alpha-count range.
    Returns (fields in Autosentry's shape {id, description, type, dataset_id}, info). Round-robin over the categories so no category crowds the
    others out of the (capped) list. info = {per_category: {cat: n}, too_few: n, too_many: n}."""
    want = [c for c in dict.fromkeys(categories) if c]
    rnd = random.Random(seed)
    by: dict[str, list[dict]] = {c: [] for c in want}
    few = many = 0
    for r in rows:
        c = row_category(r)
        if c not in by:
            continue
        n = int(r.get("alpha_count") or 0)
        if lo and n < int(lo):
            few += 1
            continue
        if hi and n > int(hi):
            many += 1
            continue
        by[c].append(r)
    for v in by.values():
        rnd.shuffle(v)
    out: list[dict] = []
    i = 0
    while len(out) < limit and any(i < len(v) for v in by.values()):
        for v in by.values():
            if i < len(v) and len(out) < limit:
                r = v[i]
                out.append({"id": r["field_id"], "description": r.get("description", ""), "type": r.get("type", "MATRIX"),
                            "dataset_id": r.get("dataset_id", ""), "category": row_category(r), "alpha_count": int(r.get("alpha_count") or 0)})
        i += 1
    return out, {"per_category": {c: len(v) for c, v in by.items()}, "too_few": few, "too_many": many}


def hyp_check(field_ids: list[str], cat_of: dict[str, str], allowed: list[str] | None = None, pairs: list[list[str]] | None = None) -> str:
    """'' when the fields of one hypothesis may be combined, else why not. cat_of: field id -> category. allowed: categories in play.
    pairs: if you picked specific combinations, only those pairs may appear together (any single category is fine)."""
    cats = list(dict.fromkeys(cat_of.get(f, "") for f in field_ids if cat_of.get(f, "")))
    if allowed:
        out = [c for c in cats if c not in allowed]
        if out:
            return f"uses {R.label(out[0])} fields outside the chosen categories"
    for v in R.check_set(cats):
        if v["verdict"] == "reject":
            return f"{R.label(v['a'])} + {R.label(v['b'])} is a rejected pair: {v['reason']}"
    if pairs:
        okp = {frozenset(p) for p in pairs if len(p) == 2}
        for a, b in combinations(cats, 2):
            if frozenset((a, b)) not in okp:
                return f"{R.label(a)} + {R.label(b)} is not one of the combinations you chose"
    return ""


def guidance(fw: dict | None, cats: list[str]) -> str:
    """Text for the LLM prompt: the framework (kept within) plus the pairing rules for the categories in play."""
    parts: list[str] = []
    if fw:
        parts.append(f"FRAMEWORK TO FOLLOW: {fw.get('name', '')}")
        if fw.get("rationale"):
            parts.append("Rationale and process of the framework:\n" + str(fw["rationale"])[:1500])
        if fw.get("expression"):
            parts.append(f"Its expression skeleton (Field_X, Field_Y are datafield slots): {fw['expression']}")
        for s in fw.get("slots") or []:
            parts.append(f"  {s['name']} = {s.get('definition') or '?'}  (categories: {', '.join(R.label(c) for c in s.get('categories') or []) or 'any'})")
        if fw.get("mechanism"):
            parts.append(f"Mechanism: {fw['mechanism']}")
        if fw.get("operators"):
            parts.append("Operators of the framework: " + ", ".join(fw["operators"]) + ". Windows and neutralization are part of the framework.")
        parts.append("You may vary the datafields (pick real ones from the catalogue for each slot), the windows, and use operators of the same family, "
                     "but keep the structure of the framework: the same kind of steps (backfill, scaling, standardization, neutralization) "
                     "and the same pairing of categories. Do not leave the framework.")
    parts.append(R.guide_text(cats))
    return "\n".join(p for p in parts if p)


def build_stage(fw: dict | None, catalog: list[dict], base: dict, user_cats: list[str], user_pairs: list[list[str]] | None,
                lo: int | None, hi: int | None, seed: int | None = None, need_fields: bool = True) -> dict:
    """One stage of a run: region/delay/universe from the framework (else from base), eligible fields, guidance, the check for hypotheses.
    stage['error'] is set (and fields empty) when the stage cannot run; the caller logs it and moves on."""
    region = (fw or {}).get("region") or base["region"]
    delay = int((fw or {}).get("delay") or base.get("delay") or 1)
    universe = (fw or {}).get("universe") or (base["universe"] if region == base["region"] else DEFAULT_UNIVERSE.get(region, base["universe"]))
    fw_cats = list(dict.fromkeys(c for s in (fw or {}).get("slots") or [] for c in (s.get("categories") or [])[:1])) or list((fw or {}).get("categories") or [])
    cats = list(dict.fromkeys([*fw_cats, *[R.normalize(c) or c for c in user_cats]]))
    st: dict[str, Any] = {"name": (fw or {}).get("name") or "free pairing", "region": region, "delay": delay, "universe": universe, "categories": cats,
                          "neutralization": (fw or {}).get("neutralization") or "", "fields": [], "error": ""}
    blocked = R.blocked(fw_cats)
    if blocked:
        b = blocked[0]
        st["error"] = f"{R.label(b['a'])} + {R.label(b['b'])} is a rejected pair: {b['reason']}"
        return st
    if not cats:
        st["error"] = "no categories: pick categories or a framework"
        return st
    rows = [r for r in catalog if r.get("region", region) == region]
    fields, info = eligible_fields(rows, cats, lo, hi, seed=seed) if need_fields else ([], {})
    st["info"] = info
    if not fields and not need_fields:       # Supersentry picks alphas, not datafields
        st["guidance"], st["cat_of"], st["pairs"] = guidance(fw, cats), {}, user_pairs or []
        return st
    if not fields:
        why = (f"no datafields in {', '.join(R.label(c) for c in cats)} for {region} delay {delay}"
               + (f" with {lo or 0}-{hi or '∞'} alphas" if (lo or hi) else "") + (f" ({info['too_few']} below the minimum, {info['too_many']} above the maximum)" if (lo or hi) else "")
               + ". Download that dataset in the Data Catalog first.")
        st["error"] = why
        return st
    st["fields"] = fields
    st["cat_of"] = {f["id"]: f["category"] for f in fields}
    st["guidance"] = guidance(fw, cats)
    st["pairs"] = user_pairs or []
    return st


import re as _re

_CAT_LITERAL = _re.compile(r'(?<!not\()\bin\(\s*datacategories\s*,\s*"([^"]+)"\s*\)', _re.I)


def filter_selections(sels: list[str], st: dict | None) -> list[str]:
    """Supersentry: drop selections that put (positive) data categories together that the pairing rules reject, or pairs you did not choose."""
    if not st:
        return list(sels)
    out = []
    for e in sels:
        cats = [R.normalize(c) or c.lower() for c in _CAT_LITERAL.findall(e)]
        if cats and hyp_check(cats, {c: c for c in cats}, None, st.get("pairs")):
            continue
        out.append(e)
    return out


def next_stage(stages: list[dict], i: int) -> tuple[dict | None, int, list[str]]:
    """The next runnable stage at or after position i (cycling). Returns (stage or None when none can run, new position, skip messages)."""
    skipped: list[str] = []
    for _ in range(len(stages)):
        st = stages[i % len(stages)]
        i += 1
        if st["error"]:
            skipped.append(f"framework '{st['name']}' skipped: {st['error']}")
            continue
        return st, i, skipped
    return None, i, skipped
