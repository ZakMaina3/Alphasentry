"""Whip: only temporary files are ever touched; results, learning and anything that costs LLM tokens never are."""
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.whip import cleanup as C, recorder as R


def _app(tmp_path):
    root, tmpd = tmp_path / "app", tmp_path / "systmp"
    (root / "data" / "backups").mkdir(parents=True); (root / "data" / "harness").mkdir(); (root / "logs").mkdir()
    (root / "backend" / "app" / "__pycache__").mkdir(parents=True); tmpd.mkdir()
    old = time.time() - 3600
    files = {
        "data/ace_studio_v2.db": b"RESULTS" * 100, "data/llm_cache.json": b"{}" * 50, "data/llm_budget.json": b"{}" * 20,
        "data/osmosis_snapshot.json": b"{}" * 20, "data/licence.json": b"x", "data/backups/ace_studio_v2_1.db": b"BACKUP" * 100,
        "data/harness/inflight.jsonl": b"j" * 30, "session.pkl": b"s" * 30, "data/pyalpha_guideline.md": b"g" * 30,
        "ace.log": b"L" * 5000, "logs/backend.log": b"B" * 3000, "logs/pip.log": b"p" * 400, "logs/setup_error.txt": b"e" * 10,
        "backend/app/__pycache__/x.cpython-312.pyc": b"c" * 200, "data/catalog_state.json.tmp": b"t" * 40,
    }
    for rel, data in files.items():
        f = root / rel; f.parent.mkdir(parents=True, exist_ok=True); f.write_bytes(data)
    os.utime(root / "data" / "catalog_state.json.tmp", (old, old))
    (tmpd / "ace_upd_abc").mkdir(); (tmpd / "ace_upd_abc" / "f").write_bytes(b"u" * 100)
    (tmpd / "other_tool").mkdir(); (tmpd / "other_tool" / "keep").write_bytes(b"k")
    return root, root / "data", tmpd


KEEP = ["data/ace_studio_v2.db", "data/llm_cache.json", "data/llm_budget.json", "data/osmosis_snapshot.json", "data/licence.json",
        "data/backups/ace_studio_v2_1.db", "data/harness/inflight.jsonl", "session.pkl", "data/pyalpha_guideline.md"]


def test_clean_up_removes_only_temporary_files_and_keeps_everything_that_costs_tokens_or_holds_results(tmp_path):
    root, data, tmpd = _app(tmp_path)
    plan = C.build_plan(root, data, tmpd)
    res = C.run_plan(plan, root, data, tmpd)
    for rel in KEEP:
        assert (root / rel).exists() and (root / rel).stat().st_size > 0, rel
    assert (root / "ace.log").exists() and (root / "ace.log").stat().st_size == 0           # emptied, not removed
    assert (root / "logs" / "backend.log").stat().st_size == 0
    assert not (root / "logs" / "pip.log").exists() and not (root / "logs" / "setup_error.txt").exists()
    assert not (root / "backend" / "app" / "__pycache__").exists()
    assert not (root / "data" / "catalog_state.json.tmp").exists()
    assert not (tmpd / "ace_upd_abc").exists() and (tmpd / "other_tool" / "keep").exists()
    assert res["freed"] > 8000 and not res["skipped"]


def test_a_fresh_tmp_file_may_still_be_written_and_is_left_alone(tmp_path):
    root, data, tmpd = _app(tmp_path)
    (data / "osmosis_snapshot.json.tmp").write_bytes(b"half")
    ids = [i["path"] for i in C.build_plan(root, data, tmpd)]
    assert str(data / "osmosis_snapshot.json.tmp") not in ids


def test_the_last_gate_refuses_protected_or_foreign_paths_even_if_a_plan_asks(tmp_path):
    root, data, tmpd = _app(tmp_path)
    outside = tmp_path / "elsewhere.log"; outside.write_bytes(b"x")
    bad = [{"path": str(data / "ace_studio_v2.db"), "kind": "delete_file"}, {"path": str(data / "llm_cache.json"), "kind": "truncate"},
           {"path": str(data / "backups"), "kind": "delete_dir"}, {"path": str(outside), "kind": "delete_file"},
           {"path": str(root / "session.pkl"), "kind": "delete_file"}, {"path": str(data), "kind": "delete_dir"}]
    res = C.run_plan(bad, root, data, tmpd)
    assert res["cleaned"] == 0 and len(res["skipped"]) == len(bad)
    for rel in KEEP:
        assert (root / rel).exists()
    assert outside.exists()


def test_symlinks_are_never_followed(tmp_path):
    root, data, tmpd = _app(tmp_path)
    target = tmp_path / "precious"; target.mkdir(); (target / "r.db").write_bytes(b"R")
    try:
        os.symlink(target, root / "backend" / "__pycache__")
    except (OSError, NotImplementedError):
        return
    C.run_plan(C.build_plan(root, data, tmpd), root, data, tmpd)
    assert (target / "r.db").exists()


def test_report_sums_by_group_and_empty_files_are_ignored(tmp_path):
    root, data, tmpd = _app(tmp_path)
    (root / "logs" / "launcher.log").write_bytes(b"")
    rep = C.summarize(C.build_plan(root, data, tmpd))
    groups = {g["group"] for g in rep["groups"]}
    assert {"logs", "install_logs", "pycache", "tmp", "updater_tmp"} <= groups and rep["bytes"] > 8000
    assert not any(i["path"].endswith("launcher.log") for i in C.build_plan(root, data, tmpd))


def test_recorder_keeps_logging_and_print_output_and_serves_only_new_lines(capsys=None):
    import logging
    R.install()
    seq0 = R.lines()["seq"]
    logging.getLogger("whiptest").warning("hello %s", "log")
    print("a printed line")
    got = R.lines(seq0)
    texts = [r["text"] for r in got["lines"]]
    assert any("whiptest: hello log" in t for t in texts) and "a printed line" in texts
    assert R.lines(got["seq"])["lines"] == []
