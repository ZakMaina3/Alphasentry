"""Autosentry and Supersentry keep separate libraries (engine tag; legacy items fall back by kind)."""
import pathlib
import types

# library.py needs SQLAlchemy (not in the harness), so the pure engine helpers are exec'd from its source.
_src = (pathlib.Path(__file__).resolve().parents[1] / "backend/app/autopilot/library.py").read_text(encoding="utf-8")
_a = _src.index("ENGINES = ")
_b = _src.index("def _meta_clean")
_c = _src.index("def add_asset")
_ns: dict = {"RG": types.SimpleNamespace(clean=lambda r: r)}
exec(_src[_a:_b], _ns)
exec(_src[_b:_c], _ns)
K = types.SimpleNamespace(**{k: _ns[k] for k in ("engine_of", "for_engine", "_meta_clean")})


def test_engine_of_legacy_defaults():
    assert K.engine_of("alpha", {}) == "auto"
    assert K.engine_of("template", None) == "auto"
    assert K.engine_of("superalpha", {}) == "super"
    assert K.engine_of("selection", {}) == "super"
    assert K.engine_of("paper", {}) == "both"
    assert K.engine_of("note", {}) == "both"
    assert K.engine_of("alpha", {"engine": "super"}) == "super"
    assert K.engine_of("alpha", {"engine": "bogus"}) == "auto"


def test_for_engine_filter():
    assert K.for_engine("paper", {}, "auto") and K.for_engine("paper", {}, "super")
    assert K.for_engine("paper", {"engine": "super"}, "super")
    assert not K.for_engine("paper", {"engine": "super"}, "auto")
    assert not K.for_engine("alpha", {}, "super")
    assert K.for_engine("alpha", {}, None)


def test_meta_clean_drops_bad_engine():
    assert "engine" not in K._meta_clean({"engine": "x"})
    assert K._meta_clean({"engine": "auto"})["engine"] == "auto"
