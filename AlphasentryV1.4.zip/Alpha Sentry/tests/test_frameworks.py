"""Frameworks: pairing rulebook, framework reader, alpha-count range, stages and the hypothesis / selection checks."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.frameworks import parse as P
from app.frameworks import plan as PL
from app.frameworks import rules as R
from app.frameworks import store as ST

SAMPLE = (Path(__file__).resolve().parent / "framework_sample.txt").read_text(encoding="utf-8")


def test_rulebook_tiers_rejects_and_free_pairs():
    v = R.verdict
    assert v("analyst", "pricevolume")["verdict"] == "tier1" and v("pricevolume", "analyst")["verdict"] == "tier1"
    assert v("analyst", "earnings")["roles"] == {"analyst": "signal", "earnings": "event gate"}
    assert "trade_when" in v("analyst", "earnings")["build"]
    assert v("fundamental", "risk")["verdict"] == "tier2" and "scaler" in v("fundamental", "risk")["watch"]
    assert v("macro", "risk")["verdict"] == "tier2"
    for a, b in (("macro", "analyst"), ("macro", "pricevolume"), ("imbalance", "fundamental"), ("imbalance", "analyst"), ("imbalance", "institutions"),
                 ("socialmedia", "fundamental"), ("socialmedia", "institutions"), ("news", "sentiment"), ("socialmedia", "imbalance"), ("news", "imbalance")):
        assert v(a, b)["verdict"] == "reject" and v(a, b)["reason"], (a, b)
    assert v("fundamental", "pricevolume")["verdict"] == "free"            # not covered by the guide: allowed
    assert v("model", "risk")["verdict"] == "free" and v("analyst", "analyst")["verdict"] == "same"
    assert [x["verdict"] for x in R.check_set(["analyst", "pricevolume", "macro"])].count("reject") == 2
    assert R.blocked(["analyst", "pricevolume"]) == []


def test_category_names_are_recognised():
    assert R.normalize("Price Volume") == R.normalize("pv") == R.normalize("price-volume") == "pricevolume"
    assert R.normalize("Social Media") == "socialmedia" and R.normalize("Analyst Estimates") == "analyst" and R.normalize("nonsense") == ""
    g = R.guide_text(["analyst", "earnings", "news"])
    assert "Analyst + Earnings" in g and "Never combine" in g


def test_reader_splits_the_pasted_framework_into_five_with_regions_and_slots():
    r = P.parse(SAMPLE, "x.txt")
    fws = r["frameworks"]
    assert [f["region"] for f in fws] == ["GBR", "GBR", "GBR", "GBR", "DEU"]
    assert fws[0]["name"].startswith("Analyst Estimates + Technical Model") and "quantile(ts_max(ts_backfill(Field_X, 21), 126))" in fws[0]["expression"]
    assert [(s["name"], s["categories"][0]) for s in fws[0]["slots"]] == [("Field_X", "analyst"), ("Field_Y", "model")]
    assert [s["categories"][0] for s in fws[1]["slots"]] == ["fundamental", "model"]
    assert [s["categories"][0] for s in fws[3]["slots"]] == ["pricevolume", "fundamental"]      # 'earnings yield' is fundamental, not earnings
    assert fws[2]["neutralization"] == "INDUSTRY" and fws[4]["neutralization"] == "INDUSTRY" and fws[0]["neutralization"] == ""
    assert {"ts_backfill", "ts_max", "ts_decay_linear", "quantile"} <= set(fws[0]["operators"])
    assert fws[0]["mechanism"].startswith("Pairs a 6-month rolling peak") and "ts_backfill" in fws[0]["rationale"]
    assert all(f["blocked"] == [] for f in fws)
    assert P.parse("just some words", "t")["frameworks"] == [] and P.parse("", "t")["warnings"]


def test_saved_framework_is_cleaned():
    c = ST.clean({"name": " F ", "region": "gbr", "delay": None, "slots": [{"name": "Field_X", "categories": ["analyst"]}], "junk": 1})
    assert c["name"] == "F" and c["region"] == "GBR" and c["delay"] == 1 and c["categories"] == ["analyst"] and "junk" not in c


ROWS = ([{"field_id": f"an{i}", "category": "Analyst", "alpha_count": i * 10, "region": "GBR", "dataset_id": "d1", "type": "MATRIX", "description": "x"} for i in range(1, 8)]
        + [{"field_id": f"pv{i}", "category": "Price Volume", "alpha_count": i * 10, "region": "GBR", "dataset_id": "d2", "type": "MATRIX", "description": "y"} for i in range(1, 8)]
        + [{"field_id": "us1", "category": "Analyst", "alpha_count": 20, "region": "USA", "dataset_id": "d3", "type": "MATRIX", "description": "z"}])


def test_alpha_count_range_min_max_or_both():
    ids = lambda lo, hi: sorted(f["id"] for f in PL.eligible_fields(ROWS, ["analyst"], lo, hi)[0])
    assert ids(None, None) == sorted(["an1", "an2", "an3", "an4", "an5", "an6", "an7", "us1"])
    assert ids(30, None) == ["an3", "an4", "an5", "an6", "an7"] and ids(None, 30) == ["an1", "an2", "an3", "us1"] and ids(20, 40) == ["an2", "an3", "an4", "us1"]
    assert ids(0, 0) == ids(None, None)                         # 0 = no limit
    f, info = PL.eligible_fields(ROWS, ["analyst"], 30, 50)
    assert info["too_few"] == 3 and info["too_many"] == 2       # (an1, an2, us1) below, (an6, an7) above
    # round robin: the first fields alternate between the categories
    f2, _ = PL.eligible_fields(ROWS, ["analyst", "pricevolume"], seed=1)
    assert {f2[0]["category"], f2[1]["category"]} == {"analyst", "pricevolume"}


def test_stage_takes_region_from_the_framework_and_reports_why_it_cannot_run():
    base = {"region": "USA", "universe": "TOP3000", "delay": 1}
    fw = {"name": "F", "region": "GBR", "slots": [{"name": "Field_X", "categories": ["analyst"]}, {"name": "Field_Y", "categories": ["pricevolume"]}]}
    st = PL.build_stage(fw, ROWS, base, [], None, None, None, seed=1)
    assert (st["region"], st["universe"], st["error"]) == ("GBR", "TOP1200", "")
    assert all(not f["id"].startswith("us") for f in st["fields"]) and st["cat_of"]["an1"] == "analyst" and "FRAMEWORK TO FOLLOW: F" in st["guidance"]
    assert "Analyst + Price Volume" in st["guidance"]
    none = PL.build_stage(fw, ROWS, base, [], None, 500, None)
    assert "no datafields" in none["error"] and "Data Catalog" in none["error"]
    bad = PL.build_stage({"name": "B", "region": "GBR", "slots": [{"name": "Field_X", "categories": ["macro"]}, {"name": "Field_Y", "categories": ["analyst"]}]}, ROWS, base, [], None, None, None)
    assert "rejected pair" in bad["error"]
    free = PL.build_stage(None, ROWS, {"region": "GBR", "universe": "TOP1200", "delay": 1}, ["analyst", "Price Volume"], [["analyst", "pricevolume"]], None, None)
    assert free["error"] == "" and free["name"] == "free pairing" and free["pairs"] == [["analyst", "pricevolume"]]
    assert PL.build_stage(None, ROWS, base, [], None, None, None)["error"] == "no categories: pick categories or a framework"
    nofields = PL.build_stage(fw, [], base, [], None, 5, None, need_fields=False)          # Supersentry: no datafields needed
    assert nofields["error"] == "" and "FRAMEWORK TO FOLLOW" in nofields["guidance"]


def test_hypotheses_are_checked_against_categories_pairs_and_the_rulebook():
    cat = {"a": "analyst", "p": "pricevolume", "m": "macro", "n": "news", "e": "earnings"}
    assert PL.hyp_check(["a", "p"], cat, ["analyst", "pricevolume"]) == ""
    assert "outside the chosen categories" in PL.hyp_check(["a", "n"], cat, ["analyst", "pricevolume"])
    assert "rejected pair" in PL.hyp_check(["a", "m"], cat, None)
    assert "not one of the combinations you chose" in PL.hyp_check(["a", "e"], cat, None, [["analyst", "pricevolume"]])
    assert PL.hyp_check(["a", "p"], cat, None, [["pricevolume", "analyst"]]) == "" and PL.hyp_check(["a"], cat, ["analyst"], [["analyst", "pricevolume"]]) == ""
    assert PL.hyp_check(["zz"], cat, ["analyst"]) == ""            # an unknown field adds no category


def test_supersentry_selections_with_rejected_category_pairs_are_dropped():
    st = {"pairs": []}
    sels = ['own && in(datacategories, "analyst") && in(datacategories, "pricevolume")',
            'in(datacategories, "macro") && in(datacategories, "analyst")',
            'not(in(datacategories, "macro")) && in(datacategories, "analyst")',          # a negated category is not a pairing
            'turnover < 0.7']
    assert PL.filter_selections(sels, st) == [sels[0], sels[2], sels[3]]
    assert PL.filter_selections(sels, None) == sels
    only = {"pairs": [["analyst", "earnings"]]}
    assert PL.filter_selections(sels, only) == [sels[2], sels[3]]


def test_frameworks_cycle_and_skip_the_ones_that_cannot_run():
    stages = [{"name": "A", "error": ""}, {"name": "B", "error": "no datafields"}, {"name": "C", "error": ""}]
    st, i, sk = PL.next_stage(stages, 0)
    assert st["name"] == "A" and i == 1 and sk == []
    st, i, sk = PL.next_stage(stages, i)
    assert st["name"] == "C" and i == 3 and len(sk) == 1 and "B" in sk[0] and "no datafields" in sk[0]
    st, i, sk = PL.next_stage(stages, i)
    assert st["name"] == "A"                                       # cycles back
    assert PL.next_stage([{"name": "X", "error": "e"}], 0)[0] is None


def test_saved_setups_roundtrip_and_overwrite_by_name():
    import sys, types
    from app.frameworks import store as ST
    rows = []

    def add_asset(kind, body, name="", meta=None, source="user", digest=""):
        a = {"id": len(rows) + 1, "kind": kind, "name": name, "meta": meta}
        rows.append(a)
        return a

    def update_asset(aid, patch):
        [r for r in rows if r["id"] == aid][0]["meta"] = patch["meta"]
        return {"id": aid}

    fake = types.SimpleNamespace(add_asset=add_asset, update_asset=update_asset,
                                 list_assets=lambda kind=None, **k: [r for r in rows if r["kind"] == kind])
    import app.autopilot as pkg
    old = getattr(pkg, "library", None)
    pkg.library = fake
    sys.modules["app.autopilot.library"] = fake
    try:
        assert ST.save_setup("  ", {})["error"]
        ST.save_setup("GBR mix", {"ids": ["3"], "cats": ["fundamental", "analyst"], "pairs": [["analyst", "fundamental"]], "lo": 5, "hi": 0})
        ST.save_setup("GBR mix", {"ids": [3, 4], "cats": ["fundamental"], "pairs": [], "lo": 0, "hi": 20})
        s = ST.setups()
        assert len(s) == 1 and s[0]["name"] == "GBR mix"
        assert s[0]["ids"] == [3, 4] and s[0]["hi"] == 20 and s[0]["cats"] == ["fundamental"]
    finally:
        sys.modules.pop("app.autopilot.library", None)
        if old is not None:
            pkg.library = old


def test_advise_checks_llm_pairs_and_falls_back_to_rules():
    from app.frameworks import advise as AD
    fw = {"name": "F", "categories": ["fundamental", "analyst"], "slots": [], "expression": "x"}
    s = AD.parse_suggestions(["Analyst + Fundamental :: strong pair", "macro + news :: bad", "analyst + analyst", "junk"])
    assert [x["cats"] for x in s] == [["analyst", "fundamental"]] and s[0]["why"] == "strong pair"
    r = AD.suggest(fw, lambda p: ["macro + news :: blocked"])             # only a blocked pair -> rules decide
    assert r["best"]["source"] == "rules" and set(r["best"]["cats"]) == {"fundamental", "analyst"} and r["note"]
    def boom(p): raise RuntimeError("no key")
    assert AD.suggest(fw, boom)["best"]["source"] == "rules"
    ok = AD.suggest(fw, lambda p: ["pricevolume + analyst :: momentum vs revisions"])
    assert ok["best"]["source"] == "llm" and ok["note"] == ""
    assert "FRAMEWORK: F" in AD.prompt(fw)


def test_lanes_assignment_and_per_lane_lists():
    import threading
    from app.autopilot import lanes as LN
    stages = [{"name": "A", "error": ""}, {"name": "B", "error": "none"}, {"name": "C", "error": ""}, {"name": "D", "error": ""}]
    got = LN.assign(stages, 2)
    assert [[s["name"] for s in g] for g in got] == [["A", "D"], ["C"]]
    assert [[s["name"] for s in g] for g in LN.assign(stages, 1)] == [["A", "C", "D"]]
    assert len(LN.assign([stages[0]], 2)) == 1 and LN.assign([stages[1]], 2) == []
    carry, why = LN.PerLane(list), LN.PerLane(dict)
    carry.append("shared")
    seen = {}

    def lane(name):
        LN.enter(name)
        assert len(carry) == 0 and not carry
        carry.extend([1, 2, 3, 4])
        del carry[:2]                                   # what followups.compose does
        carry[:] = [x for x in carry if x > 3]
        why.update({"lane": name})
        seen[name] = (list(carry), dict(why), LN.label())

    ts = [threading.Thread(target=lane, args=(n,)) for n in "AB"]
    [t.start() for t in ts]; [t.join() for t in ts]
    assert seen["A"] == ([4], {"lane": "A"}, "A") and seen["B"] == ([4], {"lane": "B"}, "B")
    assert list(carry) == ["shared"] and len(why) == 0 and LN.label() == ""
