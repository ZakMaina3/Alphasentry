@echo off
REM ============================================================================
REM  Alpha Sentry v2 - one-click launcher (Windows)
REM  First run: finds or INSTALLS everything it needs (Python 3.11/3.12, Node.js 18+, the
REM  private Python environment, backend + frontend packages), then starts the app.
REM  Later runs: re-checks quickly and only installs what is missing or out of date.
REM ============================================================================
setlocal EnableExtensions
cd /d "%~dp0"
set "PIP_DISABLE_PIP_VERSION_CHECK=1"

echo(
echo   Alpha Sentry v2
echo   -------------

REM ---- Long folder paths break Windows installs (260-character limit) ------------
REM  A folder such as ...\WhatsApp...\transfers\...\Alpha Sentry is too deep for Python packages. If this folder's path is
REM  long, copy the app (not the caches) to a short place and carry on from there. Your data is copied too and never overwritten.
if not exist "logs" mkdir "logs" >nul 2>&1
set "PATHLEN=0"
for /f %%L in ('powershell -NoProfile -Command "(Get-Location).Path.Length"') do set "PATHLEN=%%L"
if %PATHLEN% LEQ 80 goto :path_ok
if defined ALPHA_SENTRY_RELOCATED goto :path_ok
if /i "%~1"=="--setup-only" (
  echo [warn] This folder's path is very long ^(%PATHLEN% characters^), which can make the install fail.
  echo        Move the Alpha Sentry folder to a short path such as C:\AlphaSentry and run run.bat there.
  goto :path_ok
)
set "SHORT=%LOCALAPPDATA%\AlphaSentry\app"
if "%LOCALAPPDATA%"=="" set "SHORT=C:\AlphaSentry"
echo [setup] This folder's path is very long ^(%PATHLEN% characters^) and Windows cannot install Python packages that deep.
echo         Copying Alpha Sentry to a short folder and continuing there:
echo         %SHORT%
robocopy "%CD%" "%SHORT%" /E /XD .venv node_modules __pycache__ logs .git /XF *.pyc /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 (
  echo [error] Could not copy to %SHORT%. Move the Alpha Sentry folder to C:\AlphaSentry yourself and run run.bat there.
  goto :err
)
set "ALPHA_SENTRY_RELOCATED=1"
echo         From now on use the copy in %SHORT%  ^(run Install Desktop Icon.bat there to get the shortcuts^).
start "" explorer "%SHORT%"
call "%SHORT%\run.bat" %*
exit /b %errorlevel%
:path_ok

REM ---- Auto-update (recipients only) --------------------------------------
if not exist ".git" if exist "update_url.txt" call :do_update

REM ======================= 1. Python (3.11 or 3.12) ==========================
REM  3.13+ is deliberately NOT accepted: numpy 1.26.4 (pinned for CPUs without SSE4.2)
REM  has no wheels for it.
call :find_python
if defined PYEXE goto :python_ok
echo [setup] Python 3.11/3.12 was not found - installing it now...
echo         ^(Windows may ask for permission - please accept.^)
call :install_pkg Python.Python.3.12 "https://www.python.org/downloads/windows/"
call :refresh_path
call :find_python
if defined PYEXE goto :python_ok
echo(
echo [error] Python 3.12 could not be installed automatically.
echo         Install it from https://www.python.org/downloads/windows/ ^(tick "Add python.exe to PATH"^),
echo         then run run.bat again.
goto :err
:python_ok
echo [ok] Python: %PYEXE%

REM ======================= 2. Node.js (18 or newer) ==========================
call :check_node
if not errorlevel 1 goto :node_ok
echo [setup] Node.js 18+ was not found - installing it now...
echo         ^(Windows may ask for permission - please accept.^)
call :install_pkg OpenJS.NodeJS.LTS "https://nodejs.org/en/download"
call :refresh_path
call :check_node
if not errorlevel 1 goto :node_ok
echo(
echo [error] Node.js 18+ is installed or required but does not run on this PC.
echo         Install it from https://nodejs.org/en/download and run run.bat again.
echo         If it crashes with "illegal instruction", your CPU is too old for the newest Node -
echo         install an older LTS ^(Node 18 or 20^) instead.
goto :err
:node_ok
echo [ok] Node.js ready.

REM ======================= 3. Private Python environment =====================
set "PY=backend\.venv\Scripts\python.exe"
if exist "%PY%" call :check_venv
if exist "%PY%" goto :venv_ok
echo [setup] creating Python virtual environment...
%PYEXE% -m venv "backend\.venv"
if errorlevel 1 goto :err
:venv_ok

REM ======================= 4. Backend packages ===============================
REM  numpy stays pinned to 1.26.4 (CPUs without SSE4.2 crash on numpy 2.x): requirements.txt pins it
REM  and :install_backend installs it first, so no separate constraints file is needed.
set "NEED_PIP=0"
fc /b "backend\requirements.txt" "backend\.venv\requirements.lock" >nul 2>&1
if errorlevel 1 set "NEED_PIP=1"
call :verify_py
if errorlevel 1 set "NEED_PIP=1"
if "%NEED_PIP%"=="0" goto :pip_ok
call :install_backend
if errorlevel 1 goto :err
call :verify_py
if errorlevel 1 (
  echo [error] Backend packages are still not importable after installing. The exact reason:
  "%PY%" -c "import fastapi, uvicorn, sqlalchemy, pydantic_settings, dotenv, requests, tqdm, pandas, jinja2, pypdf, cryptography, openai, anthropic, numpy; from google import genai; assert numpy.__version__.startswith('1.')" 1>"logs\setup_error.txt" 2>&1
  powershell -NoProfile -Command "Get-Content 'logs\setup_error.txt' -Tail 12"
  echo        ^(saved in logs\setup_error.txt - send it to whoever is helping you; pip's own log is logs\pip.log^)
  goto :err
)
:pip_ok
echo [ok] Backend packages ready.

REM ======================= 5. Frontend packages ==============================
set "NEED_NPM=0"
if not exist "frontend\node_modules\.bin\vite.cmd" set "NEED_NPM=1"
fc /b "frontend\package.json" "frontend\node_modules\.ace_pkg.lock" >nul 2>&1
if errorlevel 1 set "NEED_NPM=1"
if "%NEED_NPM%"=="0" goto :npm_ok
call :install_frontend
if errorlevel 1 goto :err
:npm_ok
echo [ok] Frontend packages ready.

REM  Used by the desktop launcher ("Alpha Sentry" shortcut): install/verify everything, start nothing.
if /i "%~1"=="--setup-only" (
  echo [ok] Setup complete.
  exit /b 0
)

REM ---- Launch: backend FIRST, then wait until it answers, then frontend -----
echo [run] starting backend on http://127.0.0.1:8766
start "Alpha Sentry backend" cmd /c ""%PY%" -m uvicorn app.main:app --app-dir backend --host 127.0.0.1 --port 8766 --reload --reload-dir backend\app --reload-dir backend\vendor"

echo [run] waiting for the backend to come up...
powershell -NoProfile -Command "$n=0; while($n -lt 90){ try{ (Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:8766/api' -TimeoutSec 2) | Out-Null; exit 0 }catch{ Start-Sleep -Milliseconds 800; $n++ } }; exit 1"
if errorlevel 1 (
  echo [warn] backend did not respond in time. Check the "Alpha Sentry backend" window for errors.
) else (
  echo [run] backend is up.
)

echo [run] starting frontend on http://localhost:5173
pushd frontend
start "Alpha Sentry frontend" cmd /c "npm run dev"
popd

REM give Vite a moment, then open the browser
timeout /t 4 /nobreak >nul
start "" "http://localhost:5173"

echo(
echo   Alpha Sentry is starting. Two windows opened (backend + frontend).
echo   Open http://localhost:5173 if the browser did not.
echo   Close those two windows to stop the app.
echo(
goto :eof


REM ============================================================================
REM  Helpers
REM ============================================================================

:find_python
set "PYEXE="
call :try_python "py -3.12"
if defined PYEXE exit /b 0
call :try_python "py -3.11"
if defined PYEXE exit /b 0
call :try_python "python"
if defined PYEXE exit /b 0
call :try_python "python3"
exit /b 0

:try_python
REM  Runs the candidate for real, so the Microsoft Store "python" stub is rejected.
set "CAND=%~1"
%CAND% -c "import sys; sys.exit(0 if sys.version_info[:2] in ((3,11),(3,12)) else 1)" >nul 2>&1
if errorlevel 1 exit /b 1
set "PYEXE=%CAND%"
exit /b 0

:check_node
where node >nul 2>&1
if errorlevel 1 exit /b 1
where npm >nul 2>&1
if errorlevel 1 exit /b 1
node -e "process.exit(Number(process.versions.node.split('.')[0])>=18?0:1)" >nul 2>&1
exit /b %errorlevel%

:check_venv
REM  A venv that no longer runs (folder moved, Python removed) is deleted and rebuilt.
"%PY%" -c "import sys" >nul 2>&1
if not errorlevel 1 exit /b 0
echo [setup] the existing virtual environment is broken - rebuilding it...
rmdir /s /q "backend\.venv"
exit /b 0

:verify_py
"%PY%" -c "import fastapi, uvicorn, sqlalchemy, pydantic_settings, dotenv, requests, tqdm, pandas, jinja2, pypdf, cryptography, openai, anthropic, numpy; from google import genai; assert numpy.__version__.startswith('1.')" >nul 2>&1
exit /b %errorlevel%

REM  Retries up to 3 times; the 2nd and 3rd attempt show pip's full output so a conflict is readable.
:install_backend
echo [setup] installing backend packages - this can take several minutes on the first run...
"%PY%" -m pip install --quiet --upgrade pip >> "logs\pip.log" 2>&1
set "TRY=0"
set "QUIET=--quiet"
:ib_retry
set /a TRY+=1
REM  Force the numpy pin first so nothing can pull in numpy 2.x.
"%PY%" -m pip install %QUIET% "numpy==1.26.4" "tqdm>=4.66" >> "logs\pip.log" 2>&1
if errorlevel 1 goto :ib_fail
"%PY%" -m pip install %QUIET% -r "backend\requirements.txt" >> "logs\pip.log" 2>&1
if errorlevel 1 goto :ib_fail
copy /y "backend\requirements.txt" "backend\.venv\requirements.lock" >nul
exit /b 0
:ib_fail
if %TRY% GEQ 3 exit /b 1
echo [setup] that hit a problem - last lines of pip's log:
powershell -NoProfile -Command "Get-Content 'logs\pip.log' -Tail 8"
echo [setup] trying again ^(attempt %TRY% of 3^)...
set "QUIET="
goto :ib_retry

:install_frontend
echo [setup] installing frontend packages - first run or package.json changed...
pushd "frontend"
call npm install
if errorlevel 1 (
  popd
  exit /b 1
)
popd
copy /y "frontend\package.json" "frontend\node_modules\.ace_pkg.lock" >nul
if not exist "frontend\node_modules\.bin\vite.cmd" exit /b 1
exit /b 0

:install_pkg
REM  %1 = winget package id, %2 = manual download page
where winget >nul 2>&1
if errorlevel 1 (
  echo [setup] winget is not available on this PC, so %~1 cannot be installed automatically.
  echo         Download it here: %~2
  exit /b 1
)
winget install -e --id %~1 --silent --accept-package-agreements --accept-source-agreements
exit /b %errorlevel%

:refresh_path
REM  A fresh install updates PATH in the registry only - reload it into this window.
for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable('Path','Machine')+';'+[Environment]::GetEnvironmentVariable('Path','User')"`) do set "PATH=%%P;%PATH%"
exit /b 0



REM ---- Auto-update subroutine ---------------------------------------------
:do_update
echo [update] checking for a newer version...
set "UPD_TOKEN="
set "UPD_URL="
if exist "update_token.txt" set /p UPD_TOKEN=<update_token.txt
set /p UPD_URL=<update_url.txt
if not defined UPD_URL (
  echo [update] update_url.txt is empty — skipping.
  goto :eof
)
REM %~dp0 ends in a backslash; passed as -Dest "...\" the trailing \" escapes the closing
REM quote and swallows -Token (leaving it empty -> unauthenticated -> 404). Strip it first.
set "UPD_DEST=%~dp0"
if "%UPD_DEST:~-1%"=="\" set "UPD_DEST=%UPD_DEST:~0,-1%"
powershell -NoProfile -ExecutionPolicy Bypass -File "_update.ps1" -Url "%UPD_URL%" -Dest "%UPD_DEST%" -Token "%UPD_TOKEN%"
goto :eof

:err
echo(
echo [error] setup failed - see the messages above.
echo         Alpha Sentry needs Python 3.11 or 3.12 and Node.js 18+. This launcher installs them
echo         with winget when they are missing; if that is not possible it tells you where to get them.
pause
exit /b 1
