# _update.ps1 — v2 auto-update. Pulls the latest Alpha Sentry code from a URL and overlays it
# on the current install WITHOUT touching local state (backend\.venv, frontend\node_modules,
# the data\ folder with your database + licence, session, logs) or the launchers themselves.
# Called by run.bat when update_url.txt is present and this is NOT a git checkout. Fails soft:
# any problem = keep the version you already have.
param(
  [string]$Url = '',
  [string]$Dest = '',      # the app root (folder containing backend\ + frontend\)
  [string]$Token = ''      # for a PRIVATE repo: a read-only GitHub token
)

# Fail soft rather than throw a binding error if the launcher passed nothing.
if ([string]::IsNullOrWhiteSpace($Url) -or [string]::IsNullOrWhiteSpace($Dest)) {
  Write-Host "  Update skipped: no update URL configured. Using the version you already have."
  return
}

# Never overwrite the currently-running launchers or your local state.
$skipLeaf = @('run.bat', 'run.sh', 'run.command', '_update.ps1',
              'update_token.txt', 'session.pkl', 'ace.log', 'licence.json')
# Skip whole subtrees: heavy/generated dirs and the recipient's private data folder.
$skipDir  = @('.venv', 'node_modules', '.git', 'dist', '__pycache__', 'data')

function Skip-Path([string]$rel) {
  $leaf = Split-Path $rel -Leaf
  if ($skipLeaf -contains $leaf) { return $true }
  foreach ($d in $skipDir) { if ($rel -like "$d\*" -or $rel -like "*\$d\*") { return $true } }
  return $false
}

try {
  $tmp = Join-Path $env:TEMP ('ace_upd_' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $tmp -Force | Out-Null
  $zip = Join-Path $tmp 'src.zip'

  # A token authenticates a private repo. GitHub's zipball redirects to a pre-signed codeload
  # URL, so the auth header is only needed on the first request.
  $headers = @{ 'User-Agent' = 'ace-studio-updater' }
  if ($Token) { $headers['Authorization'] = "Bearer $Token" }
  Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $zip -Headers $headers -TimeoutSec 40
  Expand-Archive -Path $zip -DestinationPath $tmp -Force

  # GitHub nests everything under a single "<repo>-<sha>/" folder. The v2 app root is the folder
  # that CONTAINS backend\ (with app\main.py). Find it.
  $base = $null
  $top = Get-ChildItem -Path $tmp -Directory |
         Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'backend\app\main.py') } |
         Select-Object -First 1
  if ($top) { $base = $top.FullName }
  if (-not $base) { throw 'could not find the app (backend\app\main.py) in the downloaded archive' }

  $count = 0
  # .NET IO is used for the copies so the '[Master]' brackets in a path are treated literally
  # (PowerShell cmdlets would glob them).
  Get-ChildItem -Path $base -Recurse -File | ForEach-Object {
    $rel = $_.FullName.Substring($base.Length).TrimStart('\')
    if (Skip-Path $rel) { return }
    $target = Join-Path $Dest $rel
    [System.IO.Directory]::CreateDirectory((Split-Path $target -Parent)) | Out-Null
    [System.IO.File]::Copy($_.FullName, $target, $true)
    $count++
  }

  Remove-Item -Recurse -Force -LiteralPath $tmp -ErrorAction SilentlyContinue
  Write-Host "  Updated $count file(s) to the latest version."
}
catch {
  $code = $null
  try { $code = [int]$_.Exception.Response.StatusCode } catch {}
  if ($code -eq 401) {
    Write-Host "  Update skipped: the update token is invalid or expired (401 Bad credentials)."
    Write-Host "  Fix: put a fresh GitHub token in update_token.txt (see the app's update notes)."
  }
  elseif ($code -eq 404) {
    Write-Host "  Update skipped: no access to the update source (404). The repo is private and"
    Write-Host "  update_token.txt is missing or lacks 'Contents: Read' on it."
  }
  else {
    Write-Host "  Update skipped: $($_.Exception.Message)"
    Write-Host "  (Offline or bad URL? Continuing with the version you already have.)"
  }
}
