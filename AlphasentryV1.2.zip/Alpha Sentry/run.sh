#!/usr/bin/env bash
# ============================================================================
#  Alpha Sentry v2 launcher for macOS / Linux.
#  Starts the FastAPI backend, waits for it, then the React (Vite) frontend.
#  Double-click on macOS after renaming to run.command, or run:  bash run.sh
# ============================================================================
set -e
cd "$(dirname "$0")"
DEST="$(pwd)"

echo ""
echo "  Alpha Sentry v2"
echo "  -------------"

# ---- Auto-update (recipients only) --------------------------------------
# On a shared install (no .git) with an update_url.txt, pull the latest code and
# overlay it, keeping local state (data/, .venv, node_modules, session). Skipped
# automatically on a dev machine, where a .git folder is present.
if [ ! -d .git ] && [ -f update_url.txt ]; then
  URL="$(head -n1 update_url.txt | tr -d '[:space:]')"
  TOKEN=""; [ -f update_token.txt ] && TOKEN="$(head -n1 update_token.txt | tr -d '[:space:]')"
  AUTH=(); [ -n "$TOKEN" ] && AUTH=(-H "Authorization: Bearer $TOKEN" -H "User-Agent: ace-studio-updater")
  if [ -n "$URL" ] && command -v curl >/dev/null 2>&1 && command -v unzip >/dev/null 2>&1; then
    echo "[update] checking for a newer version..."
    TMP="$(mktemp -d)"
    if curl -sfL "${AUTH[@]}" "$URL" -o "$TMP/src.zip" 2>/dev/null && unzip -q -o "$TMP/src.zip" -d "$TMP" 2>/dev/null; then
      # The v2 app root is the extracted folder that contains backend/app/main.py.
      MAIN="$(find "$TMP" -type f -path '*/backend/app/main.py' | head -n1)"
      SRC=""; [ -n "$MAIN" ] && SRC="$(cd "$(dirname "$MAIN")/../.." && pwd)"
      if [ -n "$SRC" ] && [ -f "$SRC/backend/app/main.py" ]; then
        ( cd "$SRC" && find . -type f \
            ! -path '*/.git/*' ! -path '*/.venv/*' ! -path '*/node_modules/*' \
            ! -path '*/__pycache__/*' ! -path '*/dist/*' ! -path './data/*' \
            ! -name run.bat ! -name run.sh ! -name run.command ! -name _update.ps1 \
            ! -name update_token.txt \
            ! -name session.pkl ! -name ace.log ! -name licence.json -print0 \
          | while IFS= read -r -d '' f; do
              mkdir -p "$DEST/$(dirname "$f")"; cp -f "$f" "$DEST/$f"
            done )
        echo "  Updated to the latest version."
      fi
    else
      echo "  Update skipped (offline or bad URL). Using the current version."
    fi
    rm -rf "$TMP"
  fi
fi

# ---- Tools: Python 3.11/3.12 and Node 18+ (installed automatically when missing) ----
# 3.13+ is not accepted: numpy 1.26.4 (pinned for CPUs without SSE4.2) has no wheels for it.
py_ok() { "$1" -c 'import sys; sys.exit(0 if sys.version_info[:2] in ((3,11),(3,12)) else 1)' >/dev/null 2>&1; }
find_py() { PY=""; for c in python3.12 python3.11 python3 python; do
  if command -v "$c" >/dev/null 2>&1 && py_ok "$c"; then PY="$c"; return 0; fi; done; return 1; }
node_ok() { command -v node >/dev/null 2>&1 && command -v npm >/dev/null 2>&1 \
  && node -e 'process.exit(Number(process.versions.node.split(".")[0])>=18?0:1)' >/dev/null 2>&1; }

install_tools() {   # $1 = python|node
  if command -v brew >/dev/null 2>&1; then
    if [ "$1" = python ]; then brew install python@3.12; else brew install node; fi
    eval "$(brew shellenv 2>/dev/null)" || true
  elif command -v apt-get >/dev/null 2>&1; then
    echo "[setup] installing with apt-get (you may be asked for your password)..."
    if [ "$1" = python ]; then sudo apt-get update -y && sudo apt-get install -y python3 python3-venv python3-pip
    else sudo apt-get install -y nodejs npm; fi
  elif command -v dnf >/dev/null 2>&1; then
    echo "[setup] installing with dnf (you may be asked for your password)..."
    if [ "$1" = python ]; then sudo dnf install -y python3 python3-pip; else sudo dnf install -y nodejs npm; fi
  else
    return 1
  fi
}

if ! find_py; then
  echo "[setup] Python 3.11/3.12 was not found - installing it..."
  install_tools python || true
  find_py || { echo "[error] Install Python 3.12 from https://www.python.org/downloads/ and run again."; exit 1; }
fi
if ! node_ok; then
  echo "[setup] Node.js 18+ was not found - installing it..."
  install_tools node || true
  node_ok || { echo "[error] Install Node.js 18+ from https://nodejs.org/en/download and run again."; exit 1; }
fi
echo "[ok] Python: $PY ($($PY --version 2>&1)) | Node: $(node --version)"

# ---- Python backend: venv + deps ----------------------------------------
# A venv that no longer runs (folder moved, Python removed) is rebuilt.
if [ -x backend/.venv/bin/python ] && ! backend/.venv/bin/python -c "import sys" >/dev/null 2>&1; then
  echo "[setup] the existing virtual environment is broken - rebuilding it..."
  rm -rf backend/.venv
fi
if [ ! -x backend/.venv/bin/python ]; then
  [ -d backend/.venv ] && rm -rf backend/.venv
  echo "[setup] creating Python virtual environment ($($PY --version))..."
  "$PY" -m venv backend/.venv
fi
VPY=backend/.venv/bin/python

# ---- Old-CPU backstop: pin numpy below the SSE4.2 (x86-64-v2) requirement --
# NumPy 2.0+ wheels crash with "Illegal instruction" on CPUs without SSE4.2.
# backend/requirements.txt already pins numpy==1.26.4, but the auto-update
# block above can overwrite that file from upstream. This constraints file
# lives in .venv (never touched by the updater) and holds the pin regardless.
CONSTRAINTS_ARGS=()
if [ "$(uname -m)" = "x86_64" ] && [ "$(uname -s)" = "Linux" ] && [ -f /proc/cpuinfo ]; then
  if ! grep -qm1 'sse4_2' /proc/cpuinfo; then
    echo "[setup] CPU lacks SSE4.2 - pinning numpy to 1.26.4"
    echo "numpy==1.26.4" > backend/.venv/constraints.txt
    CONSTRAINTS_ARGS=(-c backend/.venv/constraints.txt)
  fi
fi

verify_py() { "$VPY" -c "import fastapi, uvicorn, sqlalchemy, pydantic_settings, dotenv, requests, tqdm, pandas, jinja2, pypdf, cryptography, openai, anthropic, numpy; from google import genai" >/dev/null 2>&1; }
if ! cmp -s backend/requirements.txt backend/.venv/requirements.lock 2>/dev/null || ! verify_py; then
  echo "[setup] installing backend dependencies (can take a few minutes)..."
  "$VPY" -m pip install --quiet --upgrade pip
  # Force the pin explicitly first — a -c constraints file alone won't downgrade a numpy
  # that's already installed and technically "satisfies" an unpinned transitive requirement.
  if [ ${#CONSTRAINTS_ARGS[@]} -gt 0 ]; then
    "$VPY" -m pip install --quiet "numpy==1.26.4"
  fi
  "$VPY" -m pip install --quiet -r backend/requirements.txt "${CONSTRAINTS_ARGS[@]}"
  verify_py || { echo "[error] Backend packages are still not importable after installing - see messages above."; exit 1; }
  cp backend/requirements.txt backend/.venv/requirements.lock
fi
echo "[ok] Backend packages ready."

# ---- Frontend deps ------------------------------------------------------
# Reinstall when node_modules is missing OR an update changed package.json (mirrors the backend
# requirements.lock check), so "update the system" fully refreshes dependencies.
if [ ! -d frontend/node_modules ] || [ ! -e frontend/node_modules/.bin/vite ] || ! cmp -s frontend/package.json frontend/node_modules/.ace_pkg.lock 2>/dev/null; then
  echo "[setup] installing/updating frontend dependencies..."
  ( cd frontend && npm install )
  cp frontend/package.json frontend/node_modules/.ace_pkg.lock 2>/dev/null || true
fi

# ---- Launch: backend FIRST, wait until it answers, then frontend --------
echo "[run] starting backend on http://127.0.0.1:8766"
"$VPY" -m uvicorn app.main:app --app-dir backend --host 127.0.0.1 --port 8766 --reload --reload-dir backend/app --reload-dir backend/vendor &
BACK_PID=$!
# Stop the backend when this script is interrupted or exits.
cleanup() { kill "$BACK_PID" >/dev/null 2>&1 || true; }
trap cleanup INT TERM EXIT

echo "[run] waiting for the backend to come up..."
if command -v curl >/dev/null 2>&1; then
  for _ in $(seq 1 90); do
    curl -sf -o /dev/null "http://127.0.0.1:8766/api" 2>/dev/null && { echo "[run] backend is up."; break; }
    sleep 0.8
  done
else
  sleep 4
fi

echo "[run] starting frontend on http://localhost:5173"
# Open the browser once, shortly after Vite starts.
( sleep 4; (open "http://localhost:5173" 2>/dev/null || xdg-open "http://localhost:5173" 2>/dev/null) >/dev/null 2>&1 ) &

echo ""
echo "  Alpha Sentry is starting. Keep this window open while you use it (Ctrl-C to stop)."
echo ""
( cd frontend && exec npm run dev )
