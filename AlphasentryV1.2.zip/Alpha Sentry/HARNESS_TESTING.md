# Testing the SentryEngine port (safe order)

Nothing here submits an alpha. All new features are OFF until you turn them on in **SentryEngine → Control**.

1. **Unit tests** (offline, ~seconds): `python tests/run_all.py`  → expect `153 passed, 0 failed, 0 skipped`.
   Then the HTTP check of the task endpoints (throwaway data, no BRAIN, no engine): `python tests/a2_http_check.py` → expect `ALL PASSED`.
   (If you use pytest it also works: `pytest tests`.)
2. **Start Alpha Sentry normally.** Check the server log for lines starting `harness:` — any means an Alpha Sentry table/column the harness
   reads is missing (it names which). No such line = schema is fine. Existing screens should behave exactly as before.
3. **Open "SentryEngine"** (sidebar → Run). In **Control**, switch on *SentryEngine + labs*.
4. **Labs → Preview** (free; no simulation, no quota). Try in this order, using a market where you have data/alphas:
   - **Harvest** (needs fields downloaded in Data Explorer) — shows fields × patterns × windows it would queue.
   - **Pair**, **Diversify** — need fields from several datasets.
   - **Harden** — needs alphas with |Sharpe| ≥ the threshold (reads each alpha's settings from BRAIN, cached).
   - **Repair** — needs near-miss alphas; reads each one's failed checks from BRAIN (up to 60 reads per preview, cached 6h).
   - **Relocate** — needs datasets loaded for a second market; says plainly when there is nowhere to move.
5. **Dry run first.** Control → set *Dry-run: on*, Labs → *Queue for the engine* (use a small "Max simulations", e.g. 10),
   then *Start*. Records flip to `dryrun` and **nothing is simulated**. Stop the engine.
6. **Small real run.** Dry-run off, queue ~10, *Start* (confirm dialog). Watch slots/counts. Finished alphas are scored into
   **Results** (tag `harness`) within ~20 s — or press *Score finished now*. *Stop* any time.
7. **Mixing** (turn on *Returns vault + mixing*): *Backfill returns* (job tray; BRAIN reads only) → *Find mixes* → select →
   *Check selected (dry run)* → *Queue selected*, then run the engine. Mixes need ≥2 alphas with returns and 60+ shared days.
8. **Restart test:** queue ~10, Start, kill the app mid-run, restart, Start again — the engine should log
   "adopted orphan batch" and finish them instead of re-simulating.

9. **Autosentry routing** (Control → switch on *Autosentry via engine*; the engine itself need not be on):
   - Run a SMALL Autosentry job (a few expressions). Its job log should start with
     "routing batches through the harness engine (shared slots + crash journal)". Results, tags and gating must look exactly as
     before — if anything differs from a flag-off run, tell me.
   - Control tab: while it runs, `slots: n/8` rises and `external: N` appears in the counts (Autosentry's batches).
   - **Stop** mid-run: it must stop as fast as before. Slots stay "used" until BRAIN finishes those sims, then free.
   - **Crash test:** kill the app mid-batch, restart, switch on *SentryEngine + labs*, Start → log says
     "adopted orphan batch"; the finished alphas are scored into Results (tag `harness`).
   - Run Autosentry and a lab at the same time: both should progress, total slots never above 8.
   - Switch the flag off → the original path is used again (no other change needed).
   - Supersentry is routed separately, on the shared slots only (step 15); the manual SuperAlpha screen is never routed.

10. **Yield by lab** (Control tab, bottom): after a few finished runs, labs and "autopilot" show passing/finished and yield %. A lab
    with fewer than 200 finished simulations is marked "too few to judge" — don't read anything into it yet.

11. **Tasks** (SentryEngine → **Tasks** tab; needs *SentryEngine + labs* on). A task searches a template; nothing is ever submitted.
    - **Presets:** *Start from a preset* offers Reversion, Momentum, Grouped rank, Power Pool and Grid sweep; picking one fills the template,
      sampler, objectives and budget. Preview each before creating (they use `category: fundamental`; edit it if your market has no such data).
    - **Create + preview:** *New task* opens the form with a starter template. Pick region/delay/universe you have data for, then
      *Preview template (free)*: expect a grid size, a field count per `$datafield` variable, and 3 sample alphas. If a field count is 0
      you get a problem line — download that data in Data Explorer or loosen the filters (category / dataset / coverage / alpha count).
      Break the template on purpose (delete a colon): the preview must answer with a plain-language error, not a crash.
    - **Dry run first:** Control → *Dry-run: on*, Tasks → *Create task* with budget ~10, sampler `random`, objective `sharpe`. Start the
      engine. Dry-run does **not** advance tasks (the Tasks tab says so) and nothing is simulated; stop the engine and turn dry-run off.
    - **Small real run:** budget 10, batch 5, cores 1, sampler `random`, seed 1. Start the engine. Within a minute the task shows
      `queued` trials, then `complete`; progress climbs to 100% and the status becomes `done`. Finished alphas appear in
      **Results** (tag `harness`) and in the task's *Best trials* table (with a ✓/✗ gate column). A 2-objective task (e.g. fitness +
      turnover) also shows a *Pareto front* table.
    - **Pause / Resume:** Pause a running task — no new points are queued (ones already queued still finish); Resume continues.
      Pausing a paused task or resuming a running one is refused with a message, not an error page.
    - **Stop:** queued points are dropped, simulations already running finish unseen, status `stopped`. A stopped task cannot resume.
    - **Remove:** deletes the task and its trial list only; alphas already in Results stay.
    - **Restart mid-run:** create a task with budget ~20, Start, kill the app mid-run, restart, Start the engine again. The task should
      continue from its stored trials (no duplicate simulations; in-flight sims are picked up as the engine adopts the orphan batch) and
      still reach `done`.
    - **Bad inputs:** an unknown objective, a template with nothing that varies, or a data-field filter matching nothing must each give
      a readable message in a toast, and create no task.

12. **Fragment B labs** (all queue-only; do each with Dry-run first, then a tiny real run).
    - **Template sweep:** Tasks → *Kind of task* = Template sweep, load the *Grid sweep* preset, *Preview*: it shows combinations / will simulate /
      batches and whether the whole grid fits (shrink `max_simulations` to see the "never tried" warning). *Create sweep*: every combination
      is simulated exactly once, then the task is `done`. A template with a continuous range explains that it needs a `step`.
    - **Sampler advice:** after any Preview a blue note names a suggested sampler and why (*Use it* switches the menu; *other options* lists the rest).
      *Save this search* / *Load…* / *Delete saved* keep named templates with their sampler, objectives, budget and market.
    - **Power Pool:** *Kind of task* = Power Pool (or the Power Pool preset). Open the task: *Show which alphas qualify* lists alphas that meet
      Sharpe >= 1.0, <= 8 operators, <= 3 fields and pool correlation < 0.5, and what stops the near misses. Pool correlation is only known once Alpha Sentry has
      measured it; unmeasured alphas show "pool correlation not measured yet". **Check those numbers against BRAIN's current Power Pool rules**
      (constants `POWER_POOL_MIN_SHARPE`, `POWER_POOL_MAX_CORR` in `optimize/objectives.py`).
    - **Deepen:** Deepen tab, enter an alpha id from Results (or paste an expression), *Preview*: size, the original alpha, sample neighbours, the generated
      template. *Create task* then watch it in Tasks; the original is included (skipped as a duplicate if it was already simulated).
    - **Evolution:** Evolution tab, leave the seeds blank to use your strongest alphas (or paste some), *Preview*, *Create task*. In Tasks the task
      shows a **Generations** table (best objective per generation; it should trend up) and each trial's expression, generation and how it was made.
      Pause/Stop/Restart behave as for other tasks; after a restart it continues from the stored generation. With *Power Pool limits* ticked no offspring
      exceeds 8 operators / 3 fields.
    - Offspring use only operators in Alpha Sentry's operator list when that list is loaded (the preview says if it is not).

13. **LLM + Invent (fragment C)** — needs an API key set up in Settings. Costs real quota, so keep the caps low at first.
    - Control tab → turn on *LLM labs (Invent)*. Invent tab: *LLM use today* lists the providers Alpha Sentry will try (in order) and today's calls / estimated
      tokens against the caps. Set *Max calls per day* to 3 and *Save caps*. Usage is an ESTIMATE (characters ÷ 4): Alpha Sentry's LLM layer reports no token counts.
      Compare with your provider's own dashboard once, to see how close it is; add a price per million tokens if you want an estimated cost cap.
    - *Propose* with 3 templates and no theme. Expect: a few "usable" cards (name, idea, number of combinations, editable template) and possibly some
      "rejected" with reasons (unknown field, operator your market does not offer, nothing varies ...). Rejections are the safety net working; if EVERYTHING is
      rejected for the same reason, send me the reasons.
    - *Create task* on a usable card: a task (lab `invent`) appears in Tasks and behaves like any search task. Edit the template text first to see it re-checked
      (break a field name: the task is refused with the reason).
    - With *Power Pool limits* ticked, every usable template can only produce alphas within 8 operators / 3 fields.
    - Hit the cap: the 4th propose is refused with "call limit" and nothing is sent (the call count does not go up). With no API key: a plain message to add one.
    - Check the field names / operators the model used really exist in your BRAIN account; the operator filter only applies when Alpha Sentry's operator list is loaded.

14. **Planning (fragment D5)** — Planning tab. Reading is free; only *Queue* adds work, and only to the engine's queue.
    - Open the tab with your market selected. *Today's budget* shows the daily budget, what is used or promised (records created today UTC + the unfinished part of
      running/paused tasks), and what is left. *Plan settings*: daily simulations, exploration share, the smallest run worth making, and which labs the plan may use.
    - *What to do next* lists plain-language steps (engine off, dry-run on, unscored results, near-misses, strong alphas ...) with an *Open ...* button to the right tab.
      *Explain in words* needs the LLM switch and uses your key (one call, counted in the Invent tab's caps).
    - *Today's plan*: each funded lab, its simulations, share and why (yield with the 0.1% target as a prior, so a lab with little history is not judged on a few runs).
      Labs that cannot run today are listed under *Closed today* with the reason (e.g. no data downloaded, only one market, no alphas with |Sharpe| above the bar).
      The "near miss" count here is a cheap proxy (unsubmitted, failed the gate, |Sharpe| ≥ 1); Repair itself reads BRAIN's real checks when it runs.
    - *Ask the PM*: with the LLM switch off it shows the ordinary plan with a rule-written briefing; with it on, your model picks desks (at most 4) and explains why.
      It cannot invent labs or numbers: unknown / closed desks are listed as ignored, and sizes always come from the plan arithmetic. *Queue the PM's plan* queues just those desks.
    - *Queue today's plan* (needs engine + Planning switches; asks to confirm): each lab queues its share through its own run function (duplicates skipped). The result table shows
      asked / queued / already known per lab and round; a lab that runs out of new candidates hands its leftover to the others (up to 3 rounds). Evolution and Deepen
      appear as tasks. Nothing runs until the engine is started; nothing is ever submitted. Queue it twice: the second run should add little or nothing new.
    - *Yield*: per-lab table and a 14-day chart (grey = simulations finished that day, coloured = of those, alphas that pass). *Shapes already tried (ledger)*: load it to see which
      alpha shapes are answered. *Recent plan runs* is the audit trail.
    - Queueing runs the labs' own reads, so Repair may take a few seconds and make cached BRAIN requests (same as pressing Repair's own button).

15. **Supersentry on the shared slots (E1)** — only with `autopilot_via_engine` ON; the manual SuperAlpha screen is never routed.
    - Start the engine (Control) with some queued work, then start Supersentry. In Control the *slots* chip should show the engine AND `superpilot` holding slots,
      never more than 8 together, and Super's own cap of 3 still applies. Stop Supersentry: waiting workers give up at once; a simulation already started keeps its
      slot until BRAIN finishes it, then the slot frees. Turn the flag OFF: next run uses Alpha Sentry's original path (no `superpilot` holder). Results are unchanged either way.
    - Lease only: Super simulations are not journalled, so a crash mid-simulation is not re-attached (regular Autosentry's are).
16. **Winner tag for lab results (E2)** — Control tab, bottom: *Winner tag for lab results*. Set a tag (e.g. `harness-winner`), a colour and a fitness threshold, *Save*.
    Run a lab (or let the plan run). Each newly scored alpha that PASSES the gate with |Fitness| at or above the threshold is labelled in BRAIN with that tag and colour and
    shows it in Results (`tag` column); every other lab alpha keeps `harness`. Blank tag = off (the default). Existing results are not re-tagged. If BRAIN refuses a label the
    result is still stored with `harness`. It only labels; nothing is submitted.

17. **Real frontend build (E4)** — in `frontend/`: `npm ci` then `npm run build` (this is `tsc -b && vite build`; `noUnusedLocals` is on, so an unused import FAILS it).
    Expect it to finish with no errors. If it prints any, paste them: the whole Harness screen and the Header/App edits are the only frontend changes. (A first pass
    offline already found and fixed one: `Header.tsx` still imported `useEffect` and `api` after the update-check code was removed.) Then `npm run dev` and click through the
    Harness tabs: Control, Tasks, Planning, Deepen, Evolution, Invent, Labs, Mixing, Guide. Without network use `sh tests/frontend_offline/check.sh` (needs esbuild and tsc on PATH).

18. **Built-in samplers (E5)** — only matters WITHOUT Optuna (with Optuna installed its own samplers are used). In Tasks, make a small task with each of
    `qmc`, `nsga3` and `cmaes` (CMA-ES needs ONE objective), budget 30–60, and Preview/run as in step 11. Expect: no error; the task's notes say it is the built-in
    Sobol / reference-point NSGA-III / separable CMA-ES; points are never repeated; stopping and restarting Alpha Sentry mid-run resumes without re-asking finished points.
    Planning tab *Shapes already tried (ledger)*: the new filter box and *answered only* tick narrow the table. **Guide** tab: one entry per lab; *Open …* jumps to its tab.

19. **Autosentry speed (G1)** — Control tab, *Autosentry via engine* ON, then *Autosentry speed*: leave 6 side by side, 25 minutes, Save. Start a normal Autosentry run (batch 10, concurrency 3).
    Expect the log line "routing batches through the harness engine", then up to 6 batches running at once (the *slots* chip shows autopilot holding up to 6, never more than 8 with the engine).
    Rounds should be larger (up to 60 alphas). If BRAIN refuses (HTTP 429) the panel shows "limited to N at once for about M minutes" and the run keeps going. If a batch is still running 25 minutes after the others
    finished, the log says "continuing without them"; that batch is scored by the harness when it ends (turn the engine on for that). Compare simulated alphas per hour against an earlier run; if BRAIN pushes back, lower the number.
    Flag OFF = Alpha Sentry's original behaviour, no change.
20. **Shipped data (G2)** — start Alpha Sentry once with the new version. The console shows "[ace] seed data merged: N new row(s)" (only the first time), and `data/backups/ace_studio_v2.pre_seed.<id>.db` exists.
    Control tab, *Shipped data*: "Count what is missing" should say nothing is missing; the two columns match or yours is larger. Nothing in your existing rows changes. Delete a few rows in Results, restart:
    they stay deleted; "Merge again (restore deleted)" brings them back. To ship newer data in the next version run `python tools/make_seed.py` first.

21. **Library regions (H1)** — Autosentry > Library > Working alphas (or Boosters). Every item shows region ticks, all on. Untick EUR on one booster: the row says "N region(s)" and that booster is not applied in an EUR run
    (still applied in USA). Click a region in the bar above the list: it unticks that region for every item of the kind (and ticks it back). Tick "Show only those used in <region>". Add a new alpha with only USA ticked
    in "New alphas apply to": it appears with only USA. Run `python tests/run_all.py` where SQLAlchemy is installed: the one test that was skipped in the sandbox (`test_library_filters_boosters_and_context_by_region`) should now PASS;
    if it fails, paste the output. Existing items without any ticks changed keep working in every region.

## What is NOT verified yet (please watch for these)
- Real BRAIN calls (simulate start/poll, alpha detail, daily-pnl, stats) and real Alpha Sentry DB — only tested against a mock DB.
- FastAPI endpoints were compile-checked only (step 1's `a2_http_check.py` and step 11 are what close that); the React screen was type-checked against stub types, not built (`npm run build`).
- Built but never run for real: task scheduling against BRAIN (step 11). Built but never run for real: Template sweep, Power Pool, Deepen, Evolution (step 12). Built but never run for real: LLM adapter, daily budget, Invent (step 13). Also never run for real: the Planning tab (step 14), Supersentry on the shared slots (step 15), winner tags (step 16). Autosentry speed (step 19) and the shipped-data merge (step 20) were checked only against fakes and a copy of the database file. Nothing in the plan is left unbuilt except the real `npm run build` (E4) and E3 (blocked on Alpha Sentry data).
- Lab results feed Alpha Sentry's operator & template credit (new); Alpha Sentry's per-run winner tag/colour is not applied to lab results.
If anything misbehaves, send me the server log lines and the response shown under *raw response* on the Labs tab.

22. **Translator**: open Alpha Translation, paste a Fast Expression, press Translate. You should get code plus a port checklist (and cold-start days) with no guideline setup. "View / edit guideline" shows the built-in text; "Restore built-in" drops any custom one.
23. **Names**: the sidebar says Autosentry, Supersentry, SentryEngine; the browser tab says Alpha Sentry; run `Install Desktop Icon.bat` once for the new shortcuts.

24. **Telegram**: send /engine (status), /engine on, /engine start, /tasks, /task pause <id>, /engine stop. Each should answer within a few seconds; /menu has SentryEngine buttons.
