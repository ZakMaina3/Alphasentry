# Remaining work, fragmented (pick ONE fragment per session; each is independently resumable)

Sizes: XS ≈ 1 tool call · S ≈ 3–6 · M ≈ 8–15 · L = split first. "Gate" = what must be true before you call it done.
Always: tests first (`python tests/run_all.py` stays green, currently 76), checkpoint zip + update PORT_STATUS.md after each fragment.
AH = `alpha-harness-main/backend/src/alpha_harness/`.

## A. Finish what is already half-built (do these first)
| ID | Fragment | Size | Needs | Gate |
|----|----------|------|-------|------|
| A1 ✅ DONE | **Tasks tab in the UI** (`frontend/src/features/harness/Harness.tsx`): list tasks (status/progress chips), create form (template textarea with a starter template, sampler select from `GET /optimizers`, objectives checkboxes, budget/batch/cores/seed), "Preview template" (`POST /templates/preview`: space size, field counts, 3 sample alphas, problems), task detail (best trials table, Pareto, params) with Pause/Resume/Stop/Remove. | S | endpoints exist | stub-type `tsc` clean (see /tmp/tc recipe in HANDOFF §5) |
| A2 ⏳ script ready, needs your env | **HTTP-level check of the new endpoints** — they are compile-checked only. In a real env: run a task end to end (tiny: budget 10, `random`, dry-run first). Fix whatever FastAPI/pydantic surfaces (e.g. `params: dict = {}` defaults, 422 vs 409 codes). | S | user's real env | one real task reaches `done`; results appear in Results (tag `harness`) |
| A3 ✅ DONE | Add task steps to `HARNESS_TESTING.md` (create template, preview, dry-run, small real run, pause/stop, restart mid-run). | XS | A1 | doc only |
| A4 ✅ DONE | Starter template library: 4–5 ready YAML presets (reversion, momentum, grouped rank, power-pool 3-field, grid sweep) served by `GET /templates/presets`, offered in the UI. Port ideas from `templates/library.py` (10 KB). | S | A1 | presets all `parse()` clean (add a test that parses every preset) |

## B. New labs on the existing task machinery — **ALL DONE (B1–B5), see PORT_STATUS.md; user-env check = HARNESS_TESTING.md step 12**
| ID | Fragment | Size | AH source | Notes / Gate |
|----|----------|------|-----------|--------------|
| B1 | **Template lab** (grid sweep): a task with `sampler: brute`; just a UI preset + `lab: "template"` + a "grid size / will it fit the budget" warning. | XS | `labs/template.py` (26 KB; most is the sweep UX) | task over a finite template enumerates every point once (already tested) |
| B2 | **Power Pool lab**: template constraint `power_pool: true` already prunes (≤8 operators, ≤3 fields). Add: Sharpe ≥ 1.0 selection view, POWER_POOL correlation constraint, starter preset (A4). | S | `labs/power_pool.py` (19 KB) | a power-pool task never enqueues a violating alpha (tested) |
| B3 | **Deepen**: given a winning alpha, generate a template that explores around it (windows, wrappers, neighbours) and create a task. | M | `labs/deepen.py` (6.6 KB; uses yaml) | generated template `parse()`s, space ⊇ original point; endpoint `/deepen/preview` + `/deepen/run` |
| B4a | **Evolution (GA) – pure operators**: mutation/crossover over expression trees (operator swap, field swap, window change, wrap/unwrap). | M | `labs/ga.py` first ~40% | deterministic with a seed; every offspring parses and passes `exprtools` |
| B4b | **Evolution – population loop**: seed population from winners, generations run as tasks, selection by objectives + constraints. | M | `labs/ga.py` rest | restart-safe like TaskRunner; test with the fake engine in `tests/test_tasks.py` |
| B4c | Evolution endpoints + UI tab. | S | — | tsc clean |
| B5 | **Search lab polish**: AH's `labs/search.py` extras (saved searches, sampler recommendations/notes in UI, "why this sampler"). | S | `labs/search.py` (13 KB) | — |

## C. LLM-dependent — **ALL DONE (C1, C2, C3a, C3b), see PORT_STATUS.md; user-env check = HARNESS_TESTING.md step 13**
| ID | Fragment | Size | Notes |
|----|----------|------|-------|
| C1 | **LLM adapter to Alpha Sentry's own LLM layer** (look at `backend/app/modules/research` + `prompts`): one `harness/llm.py` with `complete(system, user, json=False)`, budget hook, key handling reuse. Do NOT port AH's `llm/service.py`+vault. | M | gate: unit-tested with a fake provider; real call in user env |
| C2 | **LLM budget + key vault parity** (`llm/budget.py`, `llm/keys.py`): only what Alpha Sentry lacks (per-day spend cap + usage ledger table `harness_llm_usage`). | M | after C1 |
| C3 | **Invent lab** (`labs/invent.py`, 24 KB): LLM proposes new templates/ideas, validated by `templates.spec.parse` + constraints before anything is queued. | L→ split: C3a prompt+parse+validate (pure, fake LLM), C3b endpoint+UI | after C1 |

## D. Planning layer — **ALL DONE (D1–D5), see PORT_STATUS.md; user-env check = HARNESS_TESTING.md step 14**
| ID | Fragment | Size | AH source |
|----|----------|------|-----------|
| D1 ✅ DONE | `plan/day.py` – a daily plan: how much budget per lab by yield | M | 21 KB; uses `plan/yields.py` (done) |
| D2 ✅ DONE (module only; endpoints/runners come with D5) | `plan/dispatch.py` – turn the plan into tasks/queue entries | M | 16 KB |
| D3 ✅ DONE (module only; endpoint/snapshot come with D5) | `plan/advisor.py` – plain-language "what to do next" | S | 8 KB (LLM optional) |
| D4 ✅ DONE (module only; data readers + endpoint + UI come with D5) | `plan/pm.py` – the PM: an LLM picks which labs get today's simulations (+ a plain briefing); numbers always come from D1 | M | ported from AH `plan/pm.py` (11 KB) — this time the AH source WAS available |
| D5 | Planning UI tab (ledger view, yield trend, plan) **plus the wiring D2–D4 left for it**: (1) a snapshot gatherer for `advisor.advise`; (2) per-lab `blockers` (e.g. repair: no near-misses; relocate: no second market; harden/deepen: no strong alphas; evolution: <3 passing) and `capacity` for `pm.allocate`; (3) the model callable as `lambda s, u: llm.complete(s, u, lab="pm", json=True).text` (gate by flag `harness_llm`; budget/provider errors are already caught inside `pm.allocate` and fall back to the ordinary plan); (4) endpoints `/plan/today`, `/plan/advice`, `/plan/pm`, dispatch runners that call the labs' own `/run` functions; (5) the tab | M | frontend + endpoints |

## E. Odds and ends
| ID | Fragment | Size | Notes |
|----|----------|------|-------|
| E1 | **DONE** Supersentry on the shared slot lease only (no batching): `harness/super_route.py` + 2 hooks (`super/service.py`, `superpilot/service.py`). | S | opt-in behind `autopilot_via_engine` |
| E2 | **DONE** Scorer applies a winner tag/colour (harness-level default, `harness/winner.py`, off until a tag is set) to passing lab results. | XS | Control tab panel |
| E3 | Per-field coverage / per-universe field presence if Alpha Sentry ever stores them (today: dataset coverage, region+delay). | — | blocked on Alpha Sentry data |
| E4 | **PARTLY DONE**: offline esbuild bundle + real-tsconfig type-check found and fixed a real unused-import build error in Header.tsx. The real `npm ci && npm run build` still has to be run in a user env (HARNESS_TESTING step 17). | S | user env (needs node_modules) |
| E5 ✅ DONE | Built-in Sobol (Joe-Kuo, 14 dims, scrambled), reference-point NSGA-III and separable CMA-ES, so Optuna is no longer needed for any sampler name. Seeded runs of the other samplers are unchanged. | M | `optimize/sobol.py`, `cma.py`, `niching.py`; 4 new tests |

| G1 ✅ DONE | Autosentry speed through the engine: wider rounds (default 6 batches, max 8), learned ceiling, release of stuck batches. | M | `speed.py`; 8 tests |
| G2 ✅ DONE | Your ace_studio_v2.db shipped in every version as an insert-only, once-per-file seed. | M | `seed.py`, `seed/`, `tools/make_seed.py`; 8 tests |

| H1 ✅ DONE | Library: per-region ticks for alphas and boosters, enforced in Autosentry's prompts, seed alphas and boosters. | S | `autopilot/regions.py`, `library.py`, `AutopilotLibrary.tsx`; 6 tests + 1 DB test (runs in your env) |
| I1 ✅ DONE | One-click Alpha Translation with built-in guidelines + deterministic checks. | S | `pyalpha/guidelines.py`, `PyAlpha.tsx`; 5 tests |
| I2 ✅ DONE | Rebrand to Alpha Sentry / Autosentry / Supersentry / SentryEngine with new logos. | M | `tools/make_logos.py`, `Logo.tsx`, `icons.tsx` |
| J1 ✅ DONE | Telegram remote controls SentryEngine (/engine, /tasks, /task). | S | `notify/engine_remote.py`; 5 tests |
| L1 ✅ DONE | Article added verbatim to translator; Telegram controls SentryEngine; seed has no Library data. | S | `pyalpha/guideline_article.py`, `seed.py` |

## F. Verification gates that only the user's environment can close
F1 Run `python tests/run_all.py` (expect 75 passed). F2 Start Alpha Sentry, no `harness:` schema warnings. F3 Work through HARNESS_TESTING.md.
F4 Run ONE task end to end (A2). F5 Install Optuna and re-run `tests/test_optimize.py` — the Optuna adapter is exercised by the same
contract tests automatically (expect them to pass; if one fails, that is an adapter bug: fix `optimize/optuna_backend.py`).

## Suggested order
A1 ✅ → A3 ✅ → A2 (user) → A4 ✅ → B ✅ → C ✅ → D1 ✅ → D2 ✅ → D3 ✅ → D4 ✅ → D5 ✅ → E1 ✅ E2 ✅ E5 ✅ → G1 ✅ G2 ✅ → remaining: E3 (blocked on Alpha Sentry data) and the user-env gates (E4 real build, A2, F1–F5).
