"""Fragment B: sweep (B1), Power Pool (B2), Deepen (B3), Evolution loop (B4b), search polish (B5)."""
import json
import math
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.harness import saved
from app.harness.labs import deepen as D
from app.harness.labs import exprtree as X
from app.harness.labs import ga, powerpool as PP, sweep
from app.harness.optimize import objectives as OB
from app.harness.payload import Scope
from app.harness.templates import advice
from app.harness.templates import realise as R
from app.harness.templates import spec as T
from tests.ace_db import ace_db
from tests.test_tasks import finish, runner

SC = Scope("USA", 1, "TOP3000")
GRID = "name: g\nexpr: ts_mean(close, $w)\nvars: {w: {type: int, grid: [5, 10, 20, 40, 60]}}\nsettings: {decay: [0, 4], neutralization: [SUBINDUSTRY, INDUSTRY]}\n"


def flat(_payload):
    return {"sharpe": 1.5, "fitness": 1.2, "turnover": 0.3, "returns": 0.1, "drawdown": 0.05}


def drive(r, store, fn, ticks=60, **kw):
    for _ in range(ticks):
        r.tick()
        finish(store, fn, **kw)
    r.tick()


# ── B1: sweep ──────────────────────────────────────────────────────────────────────────────────
def test_sweep_plan_counts_the_grid_and_says_what_will_never_run():
    p = sweep.plan(T.parse(GRID))
    assert p["gridSize"] == 20 and p["budget"] == 20 and p["fits"] and not p["warnings"] and p["batches"] == 2
    q = sweep.plan(T.parse(GRID + "constraints: {max_simulations: 12}"))
    assert q["budget"] == 12 and q["untried"] == 8 and q["capped"] and "40%" in q["warnings"][0] and "max_simulations" in q["warnings"][0]
    assert "budget" in sweep.plan(T.parse(GRID), budget=7)["warnings"][0] and sweep.plan(T.parse(GRID), budget=7)["budget"] == 7
    for doc, msg in (("name: n\nexpr: ts_mean(close, $w)\nvars: {w: {type: float, low: 1.0, high: 5.0}}", "step"), ("name: n\nexpr: rank(close)", "nothing to sweep")):
        try:
            sweep.plan(T.parse(doc))
            assert False
        except sweep.SweepError as e:
            assert msg in str(e)


def test_template_lab_sweep_tries_every_point_exactly_once(tmp_path):
    with ace_db(tmp_path) as s:
        r = runner(s, tmp_path)
        spec = T.parse(GRID)
        plan = sweep.plan(spec)
        tid = r.create(lab="template", name="sweep", spec=spec, scope=SC, sampler="brute", objectives=["sharpe"], budget=plan["budget"], batch=5, cores=2)["id"]
        drive(r, s, flat)
        d = r.detail(tid)
        assert d["status"] == "done" and d["counts"] == {"complete": 20}
        sims = [json.loads(x["payload"]) for x in s.query("SELECT payload FROM harness_sim_record")]
        keys = {(p["regular"], p["settings"]["decay"], p["settings"]["neutralization"]) for p in sims}
        assert len(sims) == 20 and len(keys) == 20


# ── B2: Power Pool ─────────────────────────────────────────────────────────────────────────────
def test_power_pool_constraints_use_the_pool_numbers():
    row = {"delay": 1, "sharpe": 1.1, "fitness": 0.4, "turnover": 0.3, "powerpool_corr": 0.45}
    assert OB.feasible(OB.constraints_from_row(row, power_pool=True))                 # ordinary gate would fail it (fitness, Sharpe < 1.25)
    assert not OB.feasible(OB.constraints_from_row(row))
    c = OB.constraints_from_row({**row, "sharpe": 0.8, "powerpool_corr": 0.62}, power_pool=True)
    assert abs(c["LOW_SHARPE"] - 0.2) < 1e-9 and abs(c["POWER_POOL_CORRELATION"] - 0.12) < 1e-9
    assert OB.constraints_from_row({**row, "powerpool_corr": 0.62})["POWER_POOL_CORRELATION"] == 0.0     # ordinary mode keeps its 0.70 limit
    assert OB.constraints_from_row({"sharpe": None, "delay": 1}, power_pool=True)["LOW_SHARPE"] == 1.0


def test_power_pool_selection_view():
    rows = [{"alpha_id": "a", "expression": "rank(ts_zscore(close, 22))", "sharpe": 1.4, "powerpool_corr": 0.3},
            {"alpha_id": "b", "expression": "rank(ts_zscore(close, 22))", "sharpe": 0.9, "powerpool_corr": 0.3},
            {"alpha_id": "c", "expression": "rank(ts_zscore(close, 22))", "sharpe": 1.6, "powerpool_corr": 0.55},
            {"alpha_id": "d", "expression": "rank(a) + rank(b) + rank(c) + rank(d)", "sharpe": 0.2, "powerpool_corr": None},
            {"alpha_id": "e", "expression": "rank(ts_zscore(close, 22))", "sharpe": 2.0, "powerpool_corr": None}]
    sel = PP.selection(rows)
    assert [x["alpha_id"] for x in sel["qualifying"]] == ["a"] and {x["alpha_id"] for x in sel["almost"]} == {"b", "c", "e"} and sel["other"] == 1
    assert "pool correlation not measured" in sel["almost"][0]["reasons"][0] or any("not measured" in x["reasons"][0] for x in sel["almost"])
    assert sel["limits"]["minSharpe"] == 1.0 and sel["limits"]["maxPoolCorrelation"] == 0.5


POWER = ("name: pp\nexpr: rank(ts_zscore($f1, 22)) + rank(ts_zscore($f2, 22)) + rank(ts_zscore($f3, 22)) + rank($f4)\nvars:\n"
         + "".join(f"  f{i}: {{type: datafield, values: [close, volume, open, vwap]}}\n" for i in range(1, 5))
         + "constraints: {power_pool: true, max_simulations: 300}\n")


def test_a_power_pool_task_never_queues_a_violating_alpha(tmp_path):
    with ace_db(tmp_path) as s:
        r = runner(s, tmp_path)
        tid = r.create(lab="power", name="pp", spec=T.parse(POWER), scope=SC, sampler="brute", objectives=["sharpe"], budget=300, batch=10, cores=3)["id"]
        drive(r, s, flat, ticks=120)
        d = r.detail(tid)
        queued = [json.loads(x["payload"])["regular"] for x in s.query("SELECT payload FROM harness_sim_record")]
        assert queued and all(ga.count_operators(e) <= 8 and len(ga.unique_data_fields(e)) <= 3 for e in queued)
        assert d["counts"].get("pruned") == 24 and d["counts"]["complete"] == 232 and d["status"] == "done"      # the 4! all-different choices are dropped
        assert d["powerPool"] is True


def test_power_pool_task_view_lists_qualifying_alphas(tmp_path):
    with ace_db(tmp_path) as s:
        r = runner(s, tmp_path)
        spec = T.parse("name: pp\nexpr: rank(ts_zscore(close, $w))\nvars: {w: {type: int, grid: [5, 10, 22, 63]}}\nconstraints: {power_pool: true}")
        tid = r.create(lab="power", name="pp", spec=spec, scope=SC, sampler="brute", objectives=["sharpe"], budget=4, batch=4, cores=1)["id"]
        r.tick()
        finish(s, lambda p: {"sharpe": 0.5 + int(p["regular"].split(",")[1].strip(" )")) / 50, "fitness": 1.0, "turnover": 0.3, "returns": 0.1, "drawdown": 0.05})
        s.execute("UPDATE sim_results SET powerpool_corr=0.3")
        r.tick()
        v = r.power_pool_view(tid)
        assert v["taskPowerPool"] and [x["expression"] for x in v["qualifying"]] == ["rank(ts_zscore(close, 63))"]
        assert [x["expression"] for x in v["almost"]] == [f"rank(ts_zscore(close, {w}))" for w in (22, 10, 5)] and v["almost"][0]["reasons"] == ["Sharpe 0.94 < 1"]
        assert r.power_pool_view(999) is None


# ── B3: Deepen ─────────────────────────────────────────────────────────────────────────────────
def test_deepen_space_contains_the_original_and_every_point_is_valid():
    for e in ("rank(ts_zscore(close, 22))", "a = ts_mean(volume, 20); group_rank(ts_delta(a, 5) / ts_std_dev(volume, 20), industry)",
              "ts_mean(close, 5) - ts_mean(close, 60)", "rank(ts_delta(close, 5))"):
        d = D.deepen(e)
        spec = T.parse(d.template)                                                  # parses clean
        space = R.build_space(spec)
        assert R.realise(spec, d.origin, SC)["regular"] and X.canon(R.realise(spec, d.origin, SC)["regular"]) == X.canon(e), e
        for name, values in ((n, s["choices"]) for n, s in space.items()):
            assert d.origin[name] in values, (e, name)                              # the original point is inside the space
        assert d.size <= 200 and spec.constraints.max_simulations == 200 and "$" not in R.realise(spec, d.origin, SC)["regular"]
        for k in range(min(d.size, 25)):                                            # sample points: all parse and keep the shape
            from app.harness.optimize import make_optimizer
            for _, p in make_optimizer("random", space, ["maximize"], backend="builtin", seed=k).ask(3):
                out = R.realise(spec, p, SC)["regular"]
                assert "$" not in out and X.parse(out) and ga.check(out, ga.Limits()) == [], out


def test_deepen_windows_wrapper_and_shrinking():
    d = D.deepen("rank(ts_zscore(close, 22))", D.Options(operators=False))
    assert d.template["vars"]["w1"]["grid"][0] == 22 and set(d.template["vars"]["w1"]["grid"]) == {22, 10, 15, 30, 44}
    assert d.template["vars"]["outer"]["values"] == ["", "zscore", "scale"]            # already ranked: rank is not offered again
    tied = D.deepen("ts_mean(close, 5) - ts_mean(open, 5)", D.Options(operators=False, wrapper=False))
    assert list(tied.template["vars"]) == ["w1"] and D.deepen("ts_mean(close, 5) - ts_mean(open, 5)", D.Options(operators=False, wrapper=False, tie_equal_windows=False)).size > tied.size
    big = D.deepen("ts_mean(close,5)-ts_mean(close,60)+ts_rank(open,10)*ts_std_dev(vwap,30)", D.Options(max_simulations=60))
    assert big.size <= 60 and any("shrunk" in n for n in big.notes)
    assert "fewer windows varied" in big.notes[-1]
    hopeless = D.deepen("ts_mean(close,5)-ts_mean(close,60)+ts_rank(open,10)*ts_std_dev(vwap,30)", D.Options(max_simulations=2))
    assert any("smallest neighbourhood" in n for n in hopeless.notes)
    s = D.deepen("rank(ts_zscore(close, 22))", D.Options(vary_decay=True, vary_neutralization=True, neutralization="INDUSTRY", decay=4))
    assert s.template["settings"]["decay"][0] == 4 and s.template["settings"]["neutralization"][0] == "INDUSTRY"
    assert D.deepen("rank(close)", D.Options(wrapper=False)).notes and D.deepen("rank(close)").size == 9
    try:
        D.deepen("a = rank(close)")
        assert False
    except ValueError as e:
        assert "assignment" in str(e)


def test_deepen_task_retests_the_winner_and_its_neighbours(tmp_path):
    with ace_db(tmp_path) as s:
        r = runner(s, tmp_path)
        d = D.deepen("rank(ts_zscore(close, 22))", D.Options(operators=False))
        spec = T.parse(d.template)
        tid = r.create(lab="deepen", name="d", spec=spec, scope=SC, sampler="brute", objectives=["sharpe"], budget=d.size, batch=10, cores=2)["id"]
        drive(r, s, flat)
        sims = {json.loads(x["payload"])["regular"] for x in s.query("SELECT payload FROM harness_sim_record")}
        assert r.detail(tid)["status"] == "done" and "rank(ts_zscore(close, 22))" in sims and "rank(ts_zscore(close, 30))" in sims and len(sims) == d.size


# ── B4b: Evolution ─────────────────────────────────────────────────────────────────────────────
def expr_quality(payload):
    prog = X.parse(payload["regular"])
    wins = [int(X.get_at(prog, p).text) for p, k in X.classify(prog).items() if k == "window"]
    q = 3.0 - sum(abs(math.log(w / 63.0)) for w in wins) / max(1, len(wins)) + (0.2 if payload["regular"].startswith("rank(") else 0)
    return {"sharpe": q, "fitness": q * 0.8, "turnover": 0.3, "returns": 0.1, "drawdown": 0.05}


EVO = dict(name="evo", seeds=["rank(ts_mean(close, 5))", "rank(ts_zscore(volume, 10))"], scope=SC, objectives=["sharpe"], budget=90, population=8,
           offspring=8, fields=["close", "volume", "open", "vwap"], seed=7)


def evo_exprs(s):
    return [json.loads(x["payload"])["regular"] for x in s.query("SELECT payload FROM harness_sim_record ORDER BY id")]


def test_evolution_improves_over_generations_and_reports_them(tmp_path):
    with ace_db(tmp_path) as s:
        r = runner(s, tmp_path)
        made = r.create_evolution(**EVO)
        assert made["seeds"] == 2
        drive(r, s, expr_quality, ticks=40)
        d = r.detail(made["id"])
        gens = d["generations"]
        assert d["status"] == "done" and d["sampler"] == "ga" and len(gens) >= 5 and gens[0]["alphas"] == 8      # seeds + 6 mutants fill generation 0
        assert max(g["best"] for g in gens[1:]) > gens[0]["best"] + 0.5                                           # it actually climbed
        assert d["best"][0]["values"][0] == max(g["best"] for g in gens)
        e = evo_exprs(s)
        assert len(e) == len({X.canon(x) for x in e}) == 90                                                       # nothing repeated, budget respected
        assert all(ga.check(x, ga.Limits()) == [] for x in e)
        by_gen0 = [t for t in d["recent"] if t["params"]["gen"] == 0]
        assert {t["params"]["how"] for t in by_gen0} >= {"seed"} and all(t["params"]["parents"] == [] for t in by_gen0)
        later = [t for t in d["recent"] if t["params"]["gen"] > 0]
        assert later and all(1 <= len(t["params"]["parents"]) <= 2 for t in later)


def test_evolution_is_deterministic_and_restart_safe(tmp_path):
    (tmp_path / "a").mkdir()
    (tmp_path / "b").mkdir()
    with ace_db(tmp_path / "a") as s1:
        r1 = runner(s1, tmp_path / "a")
        r1.create_evolution(**EVO)
        drive(r1, s1, expr_quality, ticks=40)
        straight = evo_exprs(s1)
    with ace_db(tmp_path / "b") as s2:
        r2 = runner(s2, tmp_path / "b")
        r2.create_evolution(**EVO)
        for _ in range(7):
            r2.tick()
            finish(s2, expr_quality)
        r2 = runner(s2, tmp_path / "b")                                  # the app was restarted: new runner, same database
        drive(r2, s2, expr_quality, ticks=40)
        assert evo_exprs(s2) == straight


def test_evolution_waits_for_a_generation_and_controls_work(tmp_path):
    with ace_db(tmp_path) as s:
        r = runner(s, tmp_path)
        tid = r.create_evolution(**EVO)["id"]
        assert r.tick()[tid] == 8
        assert r.tick()[tid] == 0 and r.counts(tid) == {"queued": 8}      # the next generation does not start while this one is running
        r.set_status(tid, "paused")
        finish(s, expr_quality)
        assert r.tick() == {} and r.counts(tid) == {"queued": 8}          # paused: nothing is harvested or bred
        r.set_status(tid, "running")
        assert r.tick()[tid] == 8 and r.counts(tid)["complete"] == 8
        r.stop(tid)
        assert r.get(tid)["status"] == "stopped" and not s.query("SELECT 1 FROM harness_sim_record WHERE status='queued' AND task=?", (f"evolution-{tid}",))
        r.remove(tid)
        assert r.get(tid) is None


def test_power_pool_evolution_never_queues_a_violation(tmp_path):
    with ace_db(tmp_path) as s:
        r = runner(s, tmp_path)
        kw = {**EVO, "seeds": ["rank(ts_zscore(close, 22)) + rank(ts_delta(volume, 5))"], "power_pool": True, "budget": 60}
        tid = r.create_evolution(**kw)["id"]
        drive(r, s, expr_quality, ticks=40)
        e = evo_exprs(s)
        assert len(e) == 60 and all(ga.count_operators(x) <= 8 and len(ga.unique_data_fields(x)) <= 3 for x in e)
        assert r.detail(tid)["powerPool"] is True
        c = json.loads(s.query("SELECT constraint_json FROM harness_trial WHERE task_id=? AND status='complete' LIMIT 1", (tid,))[0]["constraint_json"])
        assert "LOW_FITNESS" not in c                                      # judged against Power Pool numbers, not the ordinary gate


def test_evolution_create_validation_and_stalls(tmp_path):
    from app.harness.tasks import TaskError
    with ace_db(tmp_path) as s:
        r = runner(s, tmp_path)
        for kw, msg in (({"seeds": []}, "None of the starting"), ({"seeds": ["rank("]}, "None of the starting"),
                        ({"seeds": ["rank(a) + rank(b) + rank(c) + rank(d)"], "power_pool": True}, "None of the starting"),
                        ({"objectives": ["nope"]}, "Unknown objective"), ({"population": 1}, "population"), ({"offspring": 0}, "Offspring"),
                        ({"crossover_rate": 2}, "crossover")):
            try:
                r.create_evolution(**{**EVO, **kw})
                assert False, kw
            except TaskError as e:
                assert msg in str(e), (kw, str(e))
        made = r.create_evolution(**{**EVO, "seeds": ["rank(ts_mean(close, 5))", "rank(ts_mean(close, 5))", "rank(ts_mean(close,5))", "rank("]})
        assert made["seeds"] == 1 and len(made["notes"]) == 1
        # every seed fails to simulate -> a clear error, not an endless loop
        tid = made["id"]
        r.tick()
        finish(s, expr_quality, fail={x["id"] for x in s.query("SELECT id FROM harness_sim_record")})
        r.tick()
        t = r.get(tid)
        assert t["status"] == "error" and "nothing to breed from" in t["error"]
        # a space that cannot produce anything new finishes instead of looping: a lone seed with no windows, fields or wrappers to change
        t2 = r.create_evolution(**{**EVO, "seeds": ["rank(close)"], "fields": [], "budget": 50, "offspring": 5,
                                     "allowed_operators": ["rank"], "crossover_rate": 0.0})["id"]
        drive(r, s, expr_quality, ticks=30)
        d2 = r.detail(t2)
        assert d2["status"] == "done" and d2["counts"]["complete"] < 50 and any("run out" in n for n in d2["notes"])


# ── B5: search polish ──────────────────────────────────────────────────────────────────────────
def test_sampler_advice_explains_itself():
    a = advice.recommend(grid_size=20, dims=2, objectives=1, budget=50)
    assert a["sampler"] == "brute" and "20" in a["why"] and a["alternatives"]
    assert advice.recommend(grid_size=None, dims=2, objectives=1, budget=10)["sampler"] == "qmc"
    assert advice.recommend(grid_size=5000, dims=3, objectives=2, budget=100)["sampler"] == "nsga2"
    assert advice.recommend(grid_size=5000, dims=3, objectives=3, budget=100)["sampler"] == "nsga3"      # built in since E5
    assert advice.recommend(grid_size=5000, dims=3, objectives=1, budget=80)["sampler"] == "tpe"
    assert advice.recommend(grid_size=None, dims=2, objectives=1, budget=100, all_continuous=True)["sampler"] == "cmaes"
    assert advice.recommend(grid_size=1, dims=0, objectives=1, budget=50)["alternatives"] == []
    for kw in ({"grid_size": 30, "dims": 2, "objectives": 2, "budget": 40}, {"grid_size": None, "dims": 1, "objectives": 1, "budget": 500}):
        a = advice.recommend(**kw)
        assert all(x["sampler"] != a["sampler"] for x in a["alternatives"]) and a["why"]


def test_saved_searches_round_trip(tmp_path):
    with ace_db(tmp_path) as s:
        a = saved.save(s, "  reversion v1 ", GRID, sampler="tpe", objectives=["sharpe", "turnover"], budget=80, seed=3, scope={"region": "USA", "delay": 1})
        assert a["name"] == "reversion v1" and a["objectives"] == ["sharpe", "turnover"] and a["scope"]["region"] == "USA" and a["seed"] == 3
        b = saved.save(s, "reversion v1", GRID + "# edited", sampler="nsga2", budget=20)                    # same name overwrites
        assert b["id"] == a["id"] and b["sampler"] == "nsga2" and b["template"].endswith("# edited") and b["created"] == a["created"]
        saved.save(s, "other", GRID)
        assert [x["name"] for x in saved.list_all(s)][0] in ("other", "reversion v1") and len(saved.list_all(s)) == 2
        assert saved.get(s, a["id"])["name"] == "reversion v1" and saved.get(s, "nope") is None
        assert saved.delete(s, a["id"]) and not saved.delete(s, a["id"]) and len(saved.list_all(s)) == 1
        for name, tpl in (("", GRID), ("x", "  "), ("y" * 121, GRID)):
            try:
                saved.save(s, name, tpl)
                assert False
            except ValueError:
                pass
