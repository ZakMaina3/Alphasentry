import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.harness.payload import Scope
from app.harness.templates import realise as R
from app.harness.templates import spec as T

DOC = """
name: reversion on a ranked field
expr: rank(ts_zscore($field, $lookback)) * $sign
vars:
  field: {type: datafield, values: [close, volume, assets]}
  lookback: {type: int, grid: [5, 22, 63]}
  sign: {type: choice, values: [1]}
  decay_unused: {type: int, low: 1, high: 3}
settings:
  region: USA
  neutralization: [SUBINDUSTRY, INDUSTRY]
  decay: {grid: [0, 4]}
  truncation: 0.05
  delay: [0, 1]
constraints: {power_pool: true, max_simulations: 100}
"""


def test_parse_valid_template_and_helpers():
    s = T.parse(DOC)
    assert s.name.startswith("reversion") and s.constraints.power_pool and s.constraints.max_simulations == 100
    assert T.placeholders(s.expr) == {"field", "lookback", "sign"} and s.unused_vars == {"decay_unused"}
    assert set(s.swept_settings) == {"neutralization", "decay", "delay"} and s.batch_splitting_sweeps == ["delay"]
    assert T.substitute("a($x, ${y})", {"x": 1, "y": "b"}) == "a(1, b)" and T.substitute("$k", {}) == "$k"
    assert T.setting_options({"grid": [1, 2]}) == [1, 2] and T.setting_options(3) == [3] and T.setting_options([]) == []
    assert T.parse('{"name": "j", "expr": "rank(close)"}').expr == "rank(close)"            # JSON works without PyYAML


def test_parse_errors_point_at_the_fault():
    cases = {"": "empty", "- a": "mapping", "expr: rank(x)": "name", "name: n\nexpr: rank($a)": "no such variable is declared",
             "name: n\nexpr: x\nbogus: 1": "not a recognised key", "name: n\nexpr: x\nvars: {a: {type: int}}": "`grid` or both",
             "name: n\nexpr: x\nvars: {a: {type: banana}}": "must be one of", "name: n\nexpr: x\nvars: {a: {type: int, low: 5, high: 1}}": "must not exceed",
             "name: n\nexpr: x\nsettings: {decay: []}": "has no values", "name: n\nexpr: x\nconstraints: {max_simulations: 0}": "between 1 and 10,000",
             "name: n\nexpr: x\nvars: {a: {type: choice, values: []}}": "at least one"}
    for doc, want in cases.items():
        try:
            T.parse(doc)
            assert False, doc
        except T.TemplateError as e:
            assert want in str(e) and e.problems, (doc, str(e))


def test_build_space_split_and_realise():
    s = T.parse(DOC)
    space = R.build_space(s)
    assert space["field"]["choices"] == ["close", "volume", "assets"] and space["lookback"] == {"kind": "categorical", "choices": [5, 22, 63]}
    assert "sign" not in space and "decay_unused" not in space                              # single-valued / unused: not searched
    assert space["setting:neutralization"]["choices"] == ["SUBINDUSTRY", "INDUSTRY"] and space["setting:decay"]["choices"] == [0, 4]
    assert "setting:delay" not in space and "setting:delay" in R.build_space(s, search_batch_settings=True)
    ints = R.build_space(T.parse("name: n\nexpr: ts_mean($a, $w)\nvars: {a: {type: float, low: 0.0, high: 1.0, step: 0.25}, w: {type: int, low: 5, high: 50, step: 5, log: false}}\nsettings: {}"))
    assert ints["w"] == {"kind": "int", "low": 5, "high": 50, "step": 5, "log": False} and ints["a"]["kind"] == "float" and ints["a"]["step"] == 0.25
    scope = Scope("EUR", 1, "TOP2500")
    p = R.realise(s, {"field": "volume", "lookback": 22, "setting:neutralization": "INDUSTRY", "setting:decay": 4}, scope)
    assert p["regular"] == "rank(ts_zscore(volume, 22)) * 1"                                  # pinned $sign filled in
    st = p["settings"]
    assert (st["region"], st["delay"], st["universe"]) == ("USA", 0, "TOP2500")              # fixed region + first delay override the scope
    assert (st["neutralization"], st["decay"], st["truncation"], st["nanHandling"]) == ("INDUSTRY", 4, 0.05, "ON")
    d = R.realise(s, {"field": "close", "lookback": 5}, scope)["settings"]                    # unsearched settings take their first value
    assert d["neutralization"] == "SUBINDUSTRY" and d["decay"] == 0


def test_datafield_resolution_via_prepared_and_constraints():
    s = T.parse("name: n\nexpr: rank($f)\nvars: {f: {type: datafield, category: fundamental, limit: 3}}")
    seen = []
    prep = lambda v: (seen.append(v.category), ["a", "b", "c"])[1]                          # noqa: E731
    assert R.build_space(s, prep)["f"]["choices"] == ["a", "b", "c"] and seen == ["fundamental"]
    one = lambda v: ["only"]                                                                  # noqa: E731
    assert "f" not in R.build_space(s, one) and R.realise(s, {}, Scope("USA", 1, "TOP3000"), one)["regular"] == "rank(only)"
    pp = T.parse("name: n\nexpr: x\nconstraints: {power_pool: true}")
    assert R.problems("rank(a)+rank(b)+rank(c)", pp) == [] and "limit is 3" in R.problems("rank(a)+rank(b)+rank(c)+rank(d)", pp)[0]
    nine = "+".join(f"rank(a{i % 2})" for i in range(9))
    assert "9 operators; the limit is 8" in R.problems(nine, pp)[0]
    assert R.problems(nine, T.parse("name: n\nexpr: x\nconstraints: {max_operators: 20}")) == []


def test_summary_reports_size_and_warnings():
    out = R.summary(T.parse(DOC))
    assert out["gridSize"] == 3 * 3 * 2 * 2 and not out["continuous"] and out["dimensions"]["field"] == ("categorical", 3)
    assert any("splits work" in n for n in out["notes"]) and any("$decay_unused" in n for n in out["notes"])
    cont = R.summary(T.parse("name: n\nexpr: ts_mean(close, $w)\nvars: {w: {type: float, low: 1.0, high: 9.0}}"))
    assert cont["continuous"] and cont["gridSize"] is None
    assert any("only one alpha" in n for n in R.summary(T.parse("name: n\nexpr: rank(close)"))["notes"])


def test_every_preset_parses_realises_and_respects_its_limits():
    from app.harness import optimize as O
    from app.harness.labs.exprtools import count_operators, unique_data_fields
    from app.harness.optimize import objectives as OB
    from app.harness.templates import presets as P
    from app.harness.optimize import space as sp
    ids = [p["id"] for p in P.PRESETS]
    assert len(ids) >= 5 and len(set(ids)) == len(ids)
    fields = ["f_a", "f_b", "f_c", "f_d"]
    for p in P.PRESETS:
        spec = T.parse(p["template"])                                        # plain-language errors would surface here
        assert not spec.unused_vars, (p["id"], spec.unused_vars)
        assert p["sampler"] in O.SAMPLERS and OB.resolve(p["objectives"]) and 1 <= p["budget"] <= spec.constraints.max_simulations, p["id"]
        space = R.build_space(spec, lambda v: fields)
        assert space, p["id"]
        opt = O.make_optimizer(p["sampler"] if p["sampler"] == "brute" else "random", space, ["maximize"], backend="builtin", seed=1)
        pts = [x for _, x in opt.ask(30)]
        assert pts, p["id"]
        for params in pts:
            payload = R.realise(spec, params, Scope("USA", 1, "TOP3000"), lambda v: fields)
            expr = payload["regular"]
            assert "$" not in expr, (p["id"], expr)
            if spec.constraints.power_pool:
                assert count_operators(expr) <= 8 and len(unique_data_fields(expr)) <= 3, (p["id"], expr)
            assert R.problems(expr, spec) == [] or p["id"] == "power_pool", (p["id"], expr)
        if p["sampler"] == "brute":
            size = sp.grid_size(R.build_space(spec, lambda v: fields))
            assert size is not None and size <= p["budget"], (p["id"], size)    # the preset's own budget covers the whole grid
