"""Stall detection and the Telegram text when Autosentry is stopped for being stuck."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.autopilot import supervisor as SU


def test_stalled_only_after_the_limit_and_never_when_off():
    assert not SU.stalled(1000, 1000 + 29 * 60, 30)
    assert SU.stalled(1000, 1000 + 31 * 60, 30)
    assert not SU.stalled(0, 10 ** 9, 0)
    assert not SU.stalled(0, 10 ** 9, None)
    assert not SU.stalled(0, 10 ** 9, "abc")


def test_stall_message_has_the_details():
    live = {"phase": "simulating", "wait": "waiting for BRAIN", "hypothesis": {"idea": "broker rank drift"}, "cycle": 4, "round": 2}
    ev = [{"t": 1000, "msg": f"event {i}"} for i in range(10)]
    t = SU.stall_message(5000, 1000, live, ev, 30, [{"region": "USA", "delay": 1, "size": 10, "since": 1200}])
    for need in ("1h 6m", "simulating", "broker rank drift", "Cycle 4", "round 2", "USA D1 × 10 sims", "event 9", "Nothing was submitted"):
        assert need in t, need
    assert "event 3" not in t                       # only the last six events
    assert SU.stall_message(5000, 4000, {}, [], 30)  # never fails on empty input


def test_force_end_marks_a_stuck_job_finished_and_lets_its_thread_end_later():
    import threading
    from app.core.jobs import JobManager
    jm, gate = JobManager(), threading.Event()
    jid = jm.submit("t", lambda progress, cancelled: gate.wait(5))
    assert jm.get(jid)["status"] == "running"
    assert jm.force_end(jid, "cancelled", "stuck")
    assert jm.get(jid)["status"] == "cancelled" and not jm.force_end(jid)
    gate.set()
