"""Telegram remote for SentryEngine: commands go to the right calls, the switch is respected, nothing can submit."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.notify import engine_remote as ER


class FakeApi:
    def __init__(self, on=True, running=False):
        self.f = {"harness_engine": on}
        self.running = running
        self.calls = []
        self.t = [{"id": 3, "name": "decay sweep", "lab": "template", "status": "running", "progress": 0.4, "budget": 50},
                  {"id": 2, "name": "old", "lab": "repair", "status": "done", "progress": 1.0, "budget": 10}]

    def flags(self): return dict(self.f)
    def set_flag(self, n, v): self.f[n] = v; self.calls.append(("flag", n, v))
    def status(self): return {"running": self.running, "counts": {"queued": 4, "running": 2, "done": 7, "scored": 5},
                              "lease": {"used": 2, "total": 8}}
    def start(self): self.calls.append("start"); self.running = True; return {"started": True}
    def stop(self): self.calls.append("stop"); return {"stopped": True}
    def score(self): self.calls.append("score"); return {"scored": 3}
    def tasks(self): return self.t
    def task_action(self, i, a): self.calls.append(("task", i, a))


def run(cmd, args, api):
    out = []
    ok = ER.handle(cmd, args, lambda text, buttons=None: out.append(text), api)
    return ok, "\n".join(out)


def test_foreign_commands_are_not_ours():
    assert run("status", [], FakeApi())[0] is False


def test_status_shows_switch_slots_queue_and_running_tasks():
    ok, text = run("engine", [], FakeApi())
    assert ok and "switch ON" in text and "slots 2/8" in text and "queued 4" in text and "#3 decay sweep — 40%" in text
    assert "#2" not in text                       # finished tasks are not listed in the summary


def test_start_needs_the_switch_and_stop_needs_a_running_engine():
    a = FakeApi(on=False)
    assert "/engine on" in run("engine", ["start"], a)[1] and "start" not in a.calls
    run("engine", ["on"], a)
    assert ("flag", "harness_engine", True) in a.calls
    assert "started" in run("engine", ["start"], a)[1] and "start" in a.calls
    assert "stopping" in run("engine", ["stop"], a)[1].lower() and "stop" in a.calls
    b = FakeApi(running=False)
    assert "not running" in run("engine", ["stop"], b)[1] and "stop" not in b.calls


def test_tasks_and_task_control():
    a = FakeApi()
    assert "#3" in run("tasks", [], a)[1]
    run("task", ["pause", "3"], a); run("task", ["resume", "3"], a); run("task", ["stop", "3"], a)
    assert [c for c in a.calls if c[0] == "task"] == [("task", 3, "pause"), ("task", 3, "resume"), ("task", 3, "stop")]
    assert "Usage" in run("task", ["kill", "3"], a)[1] and "Usage" in run("task", ["pause"], a)[1]


def test_errors_are_reported_not_raised_and_no_submit_command_exists():
    class Boom(FakeApi):
        def start(self): raise RuntimeError("BRAIN down")
    ok, text = run("engine", ["start"], Boom())
    assert ok and "BRAIN down" in text
    assert not any("submit" in s for s in ("on", "off", "start", "stop", "score", "status"))
    assert "submit" not in ER.__doc__.split("Nothing here")[0]
