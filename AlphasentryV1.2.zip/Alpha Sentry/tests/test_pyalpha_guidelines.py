"""Alpha Translation: built-in guidelines, deterministic checks, answer parsing (pure, no DB)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.pyalpha import guidelines as G

EXPR = "rank(ts_decay_linear(ts_backfill(fnd_x, 60), 20)) * group_rank(ts_rank(close, 75), sector)"


def test_default_guideline_is_built_in_and_complete():
    t = G.DEFAULT_GUIDELINE
    for phrase in ("data.universe[-1]", ".astype(np.float32)", "averaged", "ts_decay_linear", "pasteurize"):
        assert phrase in t, phrase


def test_effective_uses_builtin_unless_custom():
    text, builtin = G.effective("")
    assert builtin and text == G.DEFAULT_GUIDELINE
    text, builtin = G.effective("PASTE " + "x" * 50)
    assert builtin
    mine = "my own rules " * 40
    text, builtin = G.effective(mine)
    assert not builtin and text == mine


def test_analyse_classifies_and_counts_cold_start():
    a = G.analyse(EXPR, {"fnd_x": "MATRIX", "close": "MATRIX", "sector": "GROUP"})
    assert a["coldStartDays"] == 155
    assert "close" in a["fields"]["matrix"] and "fnd_x" in a["fields"]["matrix"]
    assert a["unmapped"] == []
    assert any("Cold start" in c for c in a["checks"])


def test_analyse_flags_operators_outside_the_table():
    a = G.analyse("rank(ts_corr(a, b, 10))", {"a": "MATRIX", "b": "MATRIX"})
    assert "ts_corr" in a["unmapped"]


def test_parse_answer_shapes():
    code, chk = G.parse_answer(["import numpy as np\n", "- a\n- b"])
    assert code.startswith("import") and chk.startswith("- a")
    code, chk = G.parse_answer(["```python\nx=1\n```"])
    assert code == "x=1" and chk == ""
    code, chk = G.parse_answer(['["x=2", "- ok"]'])
    assert code == "x=2" and chk == "- ok"
    assert G.parse_answer(None) == ("", "")


def test_the_pasted_article_is_included_exactly_as_given():
    art = (Path(__file__).parent / "data" / "translation_article.txt").read_bytes().decode("utf-8")
    assert G.ARTICLE == art                                  # byte for byte (the file is the user's paste)
    assert art in G.DEFAULT_GUIDELINE and G.DEFAULT_GUIDELINE.endswith(art)
    assert "Part 1 — Prompting an LLM to Translate a Fast Expression Alpha" in G.DEFAULT_GUIDELINE
