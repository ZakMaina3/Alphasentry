"""Boosting: built-in starters, one threshold, smart choice, retirement, nudges, queue care, triage, bookkeeping."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.autopilot import boosting as BO
from app.autopilot import followups as FU


def norm(e): return "".join(e.split()).lower()
def apply(e, b): return b["body"].replace("{alpha}", f"({e.strip()})")
def row(expr, sh, tu=0.3, passed=False, **kw): return {"expr": expr, "sharpe": sh, "turnover": tu, "passed": passed, "_kind": "", **kw}


def kw_floor(kw):
    return kw.get("floor") if kw.get("floor") is not None else 1.0


def plan(rows, boosters=None, stats=None, **kw):
    boosters = BO.STARTERS if boosters is None else boosters
    stats = {} if stats is None else stats
    a = dict(flip_on=True, flip_at=1.0, trigger=1.0, max_turnover=0.7, boosters=boosters, eligible=lambda r, b, t: BO.eligible(r, b, t),
             apply_booster=apply, flip_expr=lambda e: f"-1 * ({e})", norm=norm, seen=set(), queued=set(),
             pick=lambda r: BO.pick(r, boosters, stats, kw_floor(kw), False, 3, set(r.get("_applied") or [])))
    a.update(kw)
    return FU.plan(rows, **a)


def test_starters_are_valid_wrappers_and_live_in_code():
    assert len(BO.STARTERS) >= 6
    for b in BO.STARTERS:
        assert "{alpha}" in b["body"] and b["body"].count("(") == b["body"].count(")") and b["builtin"] and b["id"] < 0


def test_one_threshold_a_boosters_own_limit_is_ignored_unless_asked():
    b = {"name": "x", "body": "rank({alpha})", "min_sharpe": 1.5}
    r = row("a", 1.2)
    assert BO.eligible(r, b, 1.0) is True
    assert BO.eligible(r, b, 1.0, own_limit=True) is False
    assert BO.eligible(row("a", 0.9), b, 1.0) is False


def test_pick_prefers_boosters_with_history_and_those_that_fix_the_failed_check():
    stats = {}
    for _ in range(4):
        BO.record(stats, BO.STARTERS[3], 0.6)           # decay 5 helps a lot
        BO.record(stats, BO.STARTERS[0], -0.3)
    r = row("a", 1.4, reasons=["turnover too high"])
    got = [b["name"] for b in BO.pick(r, BO.STARTERS, stats, 1.0, False, top=3)]
    assert got[0] == "starter: decay 5"
    assert len(got) == 4                                 # top 3 + one exploratory
    assert any("decay" in n or "liquid" in n for n in got[:3])


def test_a_booster_that_keeps_hurting_is_retired():
    stats = {}
    for _ in range(5):
        BO.record(stats, BO.STARTERS[0], -0.4)
    assert BO.retired(stats, BO.STARTERS[0])
    assert BO.STARTERS[0] not in BO.pick(row("a", 1.4), BO.STARTERS, stats, 1.0, False)
    assert not BO.retired({}, BO.STARTERS[0])


def test_pick_never_reapplies_a_booster_already_in_the_expression():
    r = row("a", 1.4)
    got = BO.pick(r, BO.STARTERS[:2], {}, 1.0, False, applied={BO.key_of(BO.STARTERS[0])})
    assert [b["name"] for b in got] == [BO.STARTERS[1]["name"]]


def test_nudges_change_the_first_window_only_and_stay_valid():
    e = "rank(ts_mean(close, 20) / ts_std_dev(close, 60))"
    out = BO.nudges(e)
    assert out == ["rank(ts_mean(close, 12) / ts_std_dev(close, 60))", "rank(ts_mean(close, 32) / ts_std_dev(close, 60))"]
    assert BO.nudges("rank(close)") == []
    assert BO.nudges("ts_mean(x, 2)") == ["ts_mean(x, 3)"] or len(BO.nudges("ts_mean(x, 2)")) <= 2


def test_plan_uses_pick_nudges_and_reports_counts():
    rep = {}
    items = plan([row("rank(ts_mean(close, 20))", 1.5), row("b", 0.4), row("c", -1.6)], nudge=BO.nudges, report=rep)
    kinds = [i[2] for i in items]
    assert kinds.count("flip") == 1 and kinds.count("nudge") == 2 and kinds.count("boost") == 4
    assert rep["candidates"] == 1 and rep["boost"] == 4 and rep["nudge"] == 2 and rep["reverse"] == 1
    assert all(len(i) == 5 for i in items)


def test_boosted_alpha_can_be_boosted_once_more_only_if_the_first_boost_helped():
    helped = row("x", 1.6, _kind="boost", _depth=1, _gain=0.3, _applied=["starter: rank"])
    flat = row("y", 1.6, _kind="boost", _depth=1, _gain=0.02, _applied=["starter: rank"])
    deep = row("z", 1.6, _kind="boost", _depth=2, _gain=0.5, _applied=["a", "b"])
    assert plan([helped], max_depth=2) and not plan([flat]) and not plan([deep])
    assert all("rank" not in i[3]["name"] for i in plan([helped]))        # the booster already applied is skipped


def test_passing_alphas_are_boosted_only_when_asked_and_near_misses_only_when_asked():
    assert plan([row("a", 1.6, passed=True)]) == []
    assert plan([row("a", 1.6, passed=True)], include_passed=True)
    assert plan([row("a", 0.9)]) == []
    assert plan([row("a", 0.9)], floor=0.8)


def test_queue_is_trimmed_to_the_best_and_old_items_drop():
    carry = [(f"e{i}", row(f"e{i}", 1.0 + i / 10), "boost", None, {"hyp": 1 if i < 5 else 5}) for i in range(12)]
    dropped = BO.trim(carry, cap=4, hyp_no=5, max_age=2)
    assert len(carry) == 4 and dropped == 8
    assert [i[0] for i in carry] == ["e11", "e10", "e9", "e8"]            # newest ideas, best Sharpe first
    old = [("o", row("o", 2.0), "boost", None, {"hyp": 1})]
    assert BO.trim(old, 30, hyp_no=9) == 1 and old == []


def test_reserve_fraction_and_compose_use_it():
    strong = [("a", row("a", 1.8), "boost", None, {"hyp": 1})] * 3
    weak = [("a", row("a", 1.1), "boost", None, {"hyp": 1})] * 3
    assert BO.reserve_fraction(strong) == 0.2 and BO.reserve_fraction(weak) == 0.4
    carry = [(f"c{i}", row(f"c{i}", 1.2), "boost", None, {"hyp": 1}) for i in range(10)]
    exprs, meta, used = FU.compose(carry, [f"n{i}" for i in range(10)], 10, reserve_frac=0.4)
    assert len(meta) == 6 and len(used) == 4 and len(exprs) == 10


def test_triage_drops_weak_ideas_after_the_first_batch_only():
    weak = [row("a", 0.2), row("b", -0.3)]
    assert BO.triage_stop(weak, 1, 1, 0.5)[0] is True
    assert BO.triage_stop(weak, 2, 1, 0.5)[0] is False                    # later rounds are never cut by triage
    assert BO.triage_stop([row("a", 0.2), row("b", -0.9)], 1, 1, 0.5)[0] is False   # strongly negative can be reversed
    assert BO.triage_stop(weak, 1, 1, 0.5, winners=1)[0] is False
    assert BO.triage_stop([row("a", 0.1, _kind="boost", **{})] + weak, 1, 1, 0.5)[1] == 0.3   # follow-ups do not count


def test_absorb_tags_variants_learns_and_counts():
    b = BO.STARTERS[3]
    base = row("base", 1.4)
    meta = {0: ("boosted", base, "boost", b, {"hyp": 1}), 1: ("flipped", row("neg", -1.5), "flip", None, {"hyp": 1}),
            2: ("nudged", base, "nudge", None, {"hyp": 1})}
    rows = [row("boosted", 1.9), row("flipped", 1.2), row("nudged", 1.41), row("other", 0.5)]
    stats, run = {}, BO.new_run()
    evs = BO.absorb(rows, meta, stats, run, norm, promising_sharpe=0.9)
    assert len(evs) == 3 and rows[0]["_kind"] == "boost" and rows[0]["_depth"] == 1 and abs(rows[0]["_gain"] - 0.5) < 1e-9
    assert rows[0]["_applied"] == [b["name"]] and "_kind" not in rows[3] or rows[3]["_kind"] == ""
    assert run["boosts"] == 1 and run["boost_helped"] == 1 and run["flips"] == 1 and run["flip_helped"] == 1
    assert run["nudges"] == 1 and run["nudge_helped"] == 0
    assert BO.mean_gain(stats, b) == 0.5


def test_log_lines_say_what_happened_even_when_nothing_did():
    line = BO.queue_line({"candidates": 0, "reverse": 0, "boost": 0, "nudge": 0}, 0, 1.0, "none", 0, 0)
    assert "0 alpha(s) above Sharpe 1" in line and "0 booster(s) (none)" in line
    s = BO.run_summary({**BO.new_run(), "hyps": 12, "abandoned": 8, "boosts": 6, "boost_helped": 2}, {"x": {"n": 3, "gain": 0.9, "hurt": 0}})
    assert "12 idea(s) tested (8 dropped early)" in s and "best booster: x" in s
