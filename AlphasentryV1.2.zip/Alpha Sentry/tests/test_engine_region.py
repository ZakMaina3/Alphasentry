"""SentryEngine region switching: focus, drop-queued, stale records, indexes, local scopes."""
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.catalog import scopes as SCP
from app.harness.engine.batch import BatchEngine
from app.harness.engine.focus import Focus
from app.harness.engine.packer import key_of
from app.harness.engine.slots import SlotLease
from app.harness.engine.tracker import Tracker
from app.harness.payload import Scope
from app.harness.store import Store, ensure_tables
from app.harness.tasks import TaskRunner
from tests.ace_db import add_alpha, make_store
from tests.test_harness_engine import FakePort, make_tracker, sim
from tests.test_tasks import SC, TPL, spec


def _mixed(tr):
    tr.enqueue_many("t", [sim(f"u{i}") for i in range(12)])
    tr.enqueue_many("t", [sim(f"e{i}", region="EUR", universe="TOP2500") for i in range(6)])
    tr.enqueue_many("t", [sim(f"d{i}", delay=0) for i in range(3)])


def test_region_counts(tmp_path):
    tr = make_tracker(tmp_path)
    _mixed(tr)
    got = {(r["region"], r["delay"]): r["queued"] for r in tr.region_counts()}
    assert got == {("USA", 1): 12, ("EUR", 1): 6, ("USA", 0): 3}


def test_drop_region_only_queued_and_prunes_trials(tmp_path):
    tr = make_tracker(tmp_path)
    _mixed(tr)
    run = [r["id"] for r in tr.store.query("SELECT id FROM harness_sim_record WHERE payload LIKE '%u0%' OR payload LIKE '%u1\"%'")]
    tr.claim(run[:1], "B1")                                           # one USA sim is already running: must survive
    now = time.time()
    rid = tr.store.query("SELECT id FROM harness_sim_record WHERE payload LIKE '%\"u5\"%'")[0]["id"]
    tr.store.execute("INSERT INTO harness_trial (task_id, number, params, record_id, status, created, updated) VALUES (1,1,'{}',?,'queued',?,?)", (rid, now, now))
    out = tr.drop_queued(region="USA", delay=1)
    assert out["dropped"] == 11
    c = tr.counts()
    assert c["running"] == 1 and c["cancelled"] == 11 and c["queued"] == 9       # EUR 6 + USA delay 0 untouched
    assert tr.store.query("SELECT status FROM harness_trial")[0]["status"] == "pruned"
    assert tr.drop_queued(region="")["dropped"] == 0                              # no filter drops nothing


def test_drop_everything_except_keep(tmp_path):
    tr = make_tracker(tmp_path)
    _mixed(tr)
    assert tr.drop_queued(keep_region="eur")["dropped"] == 15
    assert tr.counts() == {"queued": 6, "cancelled": 15}
    tr2 = make_tracker(tmp_path / "x") if (tmp_path / "x").mkdir() is None else None
    _mixed(tr2)
    assert tr2.drop_queued(keep_region="USA", keep_delay=1)["dropped"] == 9         # EUR 6 + USA delay 0 (3)


def test_focus_file_roundtrip(tmp_path):
    f = Focus(tmp_path / "f.json")
    assert f.get() == {"region": "", "delay": None} and f.allows(key_of(sim("a")))
    assert f.set("eur", 1) == {"region": "EUR", "delay": 1}
    assert f.allows(key_of(sim("a", region="EUR"))) and not f.allows(key_of(sim("a"))) and not f.allows(key_of(sim("a", region="EUR", delay=0)))
    assert f.set("EUR", None)["delay"] is None and f.allows(key_of(sim("a", region="EUR", delay=0)))
    assert f.set("")["region"] == "" and f.allows(key_of(sim("a")))
    (tmp_path / "f.json").write_text("{broken", encoding="utf-8")
    assert f.get() == {"region": "", "delay": None}                                  # a damaged file means "no focus", never a crash


def test_engine_parks_other_markets(tmp_path, monkeypatch):
    import app.harness.engine.batch as bm
    monkeypatch.setattr(bm._bp, "SlotBusy", FakePort.SlotBusy)
    tr = make_tracker(tmp_path)
    _mixed(tr)
    port = FakePort()
    focus = Focus(tmp_path / "f.json")
    focus.set("EUR", 1)
    focus.set_follow(False)                                                          # parking is what happens when follow is off
    eng = BatchEngine(tr, port=port, lease=SlotLease(8), poll_interval=0.05, focus=focus)
    assert eng.status()["focus"]["region"] == "EUR"
    eng.tick()
    for _ in range(100):
        if tr.counts().get("done") == 6:
            break
        time.sleep(0.05)
    c = tr.counts()
    assert c.get("done") == 6 and c.get("queued") == 15                              # EUR ran; USA is parked, not lost
    assert eng.tick() == 0                                                           # nothing in focus left: no spin on parked items
    focus.set("")                                                                    # switch back: the parked work runs
    assert eng.tick() >= 1


def test_reap_stale_only_dead_batches(tmp_path):
    tr = make_tracker(tmp_path)
    ids = [tr.enqueue("t", sim(f"s{i}"))["record_id"] for i in range(4)]
    tr.claim(ids[:2], "DEAD")
    tr.claim(ids[2:], "LIVE")
    old = time.time() - 3 * 3600
    tr.store.execute("UPDATE harness_sim_record SET updated=?", (old,))
    assert tr.reap_stale({"LIVE"}, 7200) == 2
    c = tr.counts()
    assert c["error"] == 2 and c["running"] == 2
    tr.store.execute("UPDATE harness_sim_record SET updated=? WHERE status='running'", (time.time(),))
    assert tr.reap_stale(set(), 7200) == 0                                           # recent work is never reaped


def test_pause_other_markets_for_tasks(tmp_path):
    s = make_store(tmp_path)
    r = TaskRunner(s, Tracker(s, tmp_path / "j.jsonl"))
    a = r.create(lab="search", name="u", spec=spec(), scope=SC, sampler="tpe", objectives=["sharpe"], budget=20, batch=10, cores=2, seed=1)["id"]
    b = r.create(lab="search", name="e", spec=spec(), scope=Scope("EUR", 1, "TOP2500"), sampler="tpe", objectives=["sharpe"], budget=20, batch=10, cores=2, seed=1)["id"]
    assert r.pause_other_markets(keep_region="EUR") == 1
    assert r.get(a)["status"] == "paused" and r.get(b)["status"] == "running"
    assert r.pause_other_markets(only_region="EUR") == 1 and r.get(b)["status"] == "paused"
    assert r.pause_other_markets() == 0


def test_indexes_created_and_idempotent(tmp_path):
    s = make_store(tmp_path)
    ensure_tables(s)                                                                 # second call must not fail
    names = {x["name"] for x in s.query("SELECT name FROM sqlite_master WHERE type='index'")}
    assert {"ix_hx_simres_scope", "ix_hx_fields_scope", "ix_hx_datasets_scope"} <= names
    bare = Store(tmp_path / "bare.db")                                               # a fresh database without Alpha Sentry tables
    ensure_tables(bare)


def test_local_scopes_from_stored_data(tmp_path):
    s = make_store(tmp_path)
    s.execute("INSERT INTO datasets (dataset_id, region, delay, universe) VALUES ('d1','EUR',1,'TOP2500'),('d2','EUR',1,'TOP2500'),('d3','EUR',1,'TOP1200')")
    s.execute("INSERT INTO fields (field_id, dataset_id, region, delay) VALUES ('f1','d1','JPN',0)")
    add_alpha(s, "A1", "rank(x)", 1.0, region="USA", universe="TOP3000")
    out = SCP.local_scopes(s)["regions"]
    by = {r["region"]: r for r in out}
    assert by["EUR"]["universes"]["1"] == ["TOP2500", "TOP1200"]                     # most used first
    assert by["USA"]["delays"] == [1] and by["JPN"]["delays"] == [0] and by["JPN"]["universes"]["0"] == []
    assert all(r["local"] for r in out) and [r["region"] for r in out][0] == "USA"
    merged = SCP.local_scopes(s, [{"region": "GLB", "delay": 1, "universes": ["TOP3000"]}])["regions"]
    glb = [r for r in merged if r["region"] == "GLB"][0]
    assert glb["local"] is False and merged[-1]["region"] == "GLB"                   # BRAIN-only regions sort after your own data


def test_scopes_fallback_when_nothing_stored(tmp_path):
    s = Store(tmp_path / "empty.db")
    out = SCP.local_scopes(s)["regions"]
    assert out[0]["region"] == "USA" and "TOP3000" in out[0]["universes"]["1"] and not out[0]["local"]


def test_wait_timeout_in_vendor():
    try:
        import ace_lib
    except ModuleNotFoundError:                                                      # tqdm etc. not installed in a bare test environment
        return

    class R:
        status_code = 200
        headers = {"Location": "https://x/sim", "Retry-After": "0.01"}
        def json(self):
            return {"status": "RUNNING"}

    class S:
        def get(self, url):
            return R()

    t0 = time.time()
    res = ace_lib.multisimulation_progress(S(), R(), max_wait=0.2)
    assert res["completed"] is False and "timed out" in res["errors"][0] and time.time() - t0 < 5
    res = ace_lib.simulation_progress(S(), R(), max_wait=0.2)
    assert res["completed"] is False and res.get("timed_out")


def test_dropped_records_never_come_back(tmp_path):
    tr = make_tracker(tmp_path)
    ids = [tr.enqueue("t", sim(f"k{i}"))["record_id"] for i in range(3)]
    tr.claim(ids, "B1")
    assert tr.drop_queued(region="USA", include_running=True) == {"dropped": 3, "abandoned_running": 3}
    tr.requeue(ids)                                                   # BRAIN said "busy" a moment later: must not resurrect them
    tr.mark(ids, "error", "x")
    tr.complete(ids[0], "A1")
    tr.fail(ids[1], "nope")
    assert tr.counts() == {"cancelled": 3} and tr.all_cancelled(ids) and not tr.all_cancelled([])


def test_drop_running_leaves_autosentry_batches_and_other_regions(tmp_path):
    tr = make_tracker(tmp_path)
    mine = [tr.enqueue("t", sim(f"m{i}"))["record_id"] for i in range(2)]
    tr.claim(mine, "B1")
    auto = tr.register_running("autopilot", [sim("a1"), sim("a2")], "AUTO")
    eur = [tr.enqueue("t", sim("e1", region="EUR", universe="TOP2500"))["record_id"]]
    tr.claim(eur, "B2")
    out = tr.drop_queued(region="USA", include_running=True)
    assert out["dropped"] == 2 and out["abandoned_running"] == 2
    assert {r["id"]: r["status"] for r in tr.records(auto + eur)} == {auto[0]: "running", auto[1]: "running", eur[0]: "running"}
    assert tr.drop_queued(region="EUR")["dropped"] == 0               # without include_running a running batch is left alone


def test_engine_stops_waiting_for_a_dropped_batch_and_frees_the_slot(tmp_path):
    class Slow(FakePort):
        def wait(self, handle, payload, cancel=None):
            for _ in range(400):                                      # would wait 20 s for BRAIN unless dropped
                if cancel and cancel():
                    return [{"alpha_id": None, "simulate_data": {}}]
                time.sleep(0.05)
            return [{"alpha_id": "A1", "simulate_data": payload[0] if isinstance(payload, list) else payload}]

    tr = make_tracker(tmp_path)
    tr.enqueue_many("t", [sim(f"w{i}") for i in range(10)])
    lease = SlotLease(8)
    eng = BatchEngine(tr, port=Slow(), lease=lease, poll_interval=0.05)
    assert eng.tick() == 1
    for _ in range(100):
        if tr.counts().get("running") == 10 and lease.held_by("harness") == 1:
            break
        time.sleep(0.05)
    t0 = time.time()
    assert tr.drop_queued(region="USA", include_running=True)["abandoned_running"] == 10
    for _ in range(100):
        if lease.held_by("harness") == 0:
            break
        time.sleep(0.05)
    assert lease.held_by("harness") == 0 and time.time() - t0 < 5     # slot back long before the 20 s wait would have ended
    assert tr.counts() == {"cancelled": 10}


def test_a_batch_dropped_before_it_is_sent_never_starts(tmp_path):
    tr = make_tracker(tmp_path)
    ids = [tr.enqueue("t", sim(f"p{i}"))["record_id"] for i in range(2)]
    tr.claim(ids, "B1")
    tr.drop_queued(region="USA", include_running=True)
    port = FakePort()
    eng = BatchEngine(tr, port=port, lease=SlotLease(8))
    from app.harness.engine.packer import Batch, WorkItem
    items = tuple(WorkItem(i, key_of(sim("x")), "t", sim(f"p{n}")) for n, i in enumerate(ids))
    eng.lease.acquire("harness", 1)
    eng._run_batch("B1", Batch(key=items[0].key, task="t", items=items))
    assert port.started == [] and tr.orphan_batches() == []


def test_reset_all_cancels_engine_work_but_not_autosentry_or_results(tmp_path):
    tr = make_tracker(tmp_path)
    q = [tr.enqueue("t", sim(f"q{i}"))["record_id"] for i in range(3)]
    run = [tr.enqueue("t", sim(f"r{i}", region="EUR", universe="TOP2500"))["record_id"] for i in range(2)]
    tr.claim(run, "B1")
    tr.batch_started("B1", "https://x/1", run, True)
    done = tr.enqueue("t", sim("d"))["record_id"]
    tr.complete(done, "A9")
    auto = tr.register_running("autopilot", [sim("a1")], "AUTO")
    tr.batch_started("AUTO", "https://x/auto", auto, True)
    out = tr.reset_all()
    assert out == {"cancelled": 5, "abandoned_running": 2, "journal_closed": 1}
    assert tr.counts() == {"cancelled": 5, "done": 1, "running": 1}              # Autosentry's batch and the finished result survive
    assert [o["batch_id"] for o in tr.orphan_batches()] == ["AUTO"]
    assert tr.reset_all()["cancelled"] == 0                                      # nothing left: harmless to press twice


def test_runner_stop_all_and_engine_reset_free_everything(tmp_path):
    s = make_store(tmp_path)
    tr = Tracker(s, tmp_path / "j.jsonl")
    r = TaskRunner(s, tr)
    for name in ("a", "b"):
        r.create(lab="search", name=name, spec=spec(), scope=SC, sampler="tpe", objectives=["sharpe"], budget=20, batch=10, cores=2, seed=1)
    r.set_status(r.list_tasks()[0]["id"], "paused")
    assert r.stop_all() == 2 and {t["status"] for t in r.list_tasks()} == {"stopped"} and r.stop_all() == 0
    lease = SlotLease(8)
    lease.acquire("harness", 3)
    lease.acquire("autopilot", 2)
    eng = BatchEngine(tr, port=FakePort(), lease=lease)
    eng._in_flight["t"] = 3
    eng._say("old line")
    assert eng.reset() == {"slots_released": 3}
    assert lease.held_by("harness") == 0 and lease.held_by("autopilot") == 2        # only the engine's own slots are given back
    assert eng.status()["in_flight_by_task"] == {} and eng.status()["log"] == []


def test_old_batch_threads_do_not_release_slots_twice_after_a_reset(tmp_path):
    import threading
    gate = threading.Event()

    class Hold(FakePort):
        def wait(self, handle, payload):
            gate.wait(5)
            return [{"alpha_id": None, "simulate_data": {}}]

    tr = make_tracker(tmp_path)
    tr.enqueue_many("t", [sim(f"h{i}") for i in range(10)])
    lease = SlotLease(8)
    eng = BatchEngine(tr, port=Hold(), lease=lease, poll_interval=0.05)
    assert eng.tick() == 1
    for _ in range(100):
        if lease.held_by("harness") == 1:
            break
        time.sleep(0.05)
    eng.reset()
    lease.acquire("harness", 1)                                                       # a fresh engine's batch takes a slot...
    gate.set()                                                                        # ...then the old thread finally ends
    time.sleep(0.5)
    assert lease.held_by("harness") == 1                                              # and must not have released the new one


def test_follow_setting_defaults_on_and_survives_focus_changes(tmp_path):
    f = Focus(tmp_path / "f.json")
    assert f.follow() is True
    f.set("USA")
    assert f.set_follow(False) is False and f.follow() is False
    f.set("EUR", 1)
    assert f.follow() is False and f.get() == {"region": "EUR", "delay": 1}          # changing the region does not reset the switch
    f.set_follow(True)
    assert f.follow() is True and f.get()["region"] == "EUR"


def test_following_engine_drops_other_regions_immediately_and_pauses_their_tasks(tmp_path, monkeypatch):
    import app.harness.engine.batch as bm
    monkeypatch.setattr(bm._bp, "SlotBusy", FakePort.SlotBusy)
    tr = make_tracker(tmp_path)
    _mixed(tr)                                                                       # 12 USA d1, 6 EUR, 3 USA d0
    focus = Focus(tmp_path / "f.json")
    focus.set("USA", None)                                                           # the region chosen in Autosentry
    paused = []
    eng = BatchEngine(tr, port=FakePort(), lease=SlotLease(8), poll_interval=0.05, focus=focus, on_foreign=paused.append)
    for _ in range(100):
        eng.tick()
        if tr.counts().get("done") == 15:
            break
        time.sleep(0.05)
    c = tr.counts()
    assert c.get("done") == 15 and c.get("cancelled") == 6 and c.get("queued", 0) == 0     # EUR dropped, both USA delays ran
    assert paused == ["USA"] and any("dropped 6 queued" in l for l in eng.status()["log"])
    assert eng.status()["follow"] is True
    tr.enqueue_many("t", [sim("late", region="EUR", universe="TOP2500")])            # work queued later for another region goes too
    eng.tick()
    assert tr.counts()["cancelled"] == 7


def test_follow_off_only_parks(tmp_path, monkeypatch):
    import app.harness.engine.batch as bm
    monkeypatch.setattr(bm._bp, "SlotBusy", FakePort.SlotBusy)
    tr = make_tracker(tmp_path)
    _mixed(tr)
    focus = Focus(tmp_path / "f.json")
    focus.set("EUR", 1)
    focus.set_follow(False)
    eng = BatchEngine(tr, port=FakePort(), lease=SlotLease(8), poll_interval=0.05, focus=focus)
    eng.tick()
    time.sleep(0.5)
    assert tr.counts().get("cancelled", 0) == 0 and tr.counts()["queued"] == 15       # parked, nothing dropped


def test_cancel_queued_leaves_running_and_done_alone(tmp_path):
    tr = make_tracker(tmp_path)
    ids = [tr.enqueue("t", sim(f"c{i}"))["record_id"] for i in range(4)]
    tr.claim(ids[:1], "B")
    tr.complete(ids[1], "A1")
    assert tr.cancel_queued(ids, "x") == 2 and tr.cancel_queued([], "x") == 0
    assert tr.counts() == {"running": 1, "done": 1, "cancelled": 2}
