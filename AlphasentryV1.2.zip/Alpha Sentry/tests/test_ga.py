"""Fragment B4a: expression tree + evolution operators (pure, no database)."""
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.harness.labs import exprtree as X
from app.harness.labs import ga

CASES = ["rank(ts_zscore(close, 22))",
         "a = ts_mean(volume, 20); b = ts_std_dev(volume, 20); group_rank((a - b) / b, industry)",
         "-rank(ts_delta(close, 5) / ts_mean(abs(close), 5)) * 0.5",
         "trade_when(volume > ts_mean(volume, 20), rank(-ts_delta(close, 3)), -1)",
         "x > 1 ? a - (b - c) : d * (e + f)", "ts_rank(close, 22, constant=0) && !x", "a - (b + c) - d", "rank(1e-3 * close + .5)"]


def test_parser_round_trips_and_keeps_precedence():
    for c in CASES:
        p = X.parse(c)
        assert X.parse(X.print_(p)) == p, c                              # printing never changes the tree
    assert X.canon("rank( ( close ) )") == "rank(close)" and X.canon("a-(b-c)") == "a - (b - c)" and X.canon("(a-b)-c") == "a - b - c"
    assert X.parse("a * (b + c)").statements[0].right.op == "+" and X.print_(X.parse("(a + b) * c")) == "(a + b) * c"
    assert X.print_(X.parse("-(a + b)")) == "-(a + b)" and X.print_(X.parse("ts_rank(x, 5, constant=0)")) == "ts_rank(x, 5, constant=0)"
    for bad in ("", "rank(", "rank(close))", "a $$ b", "ts_mean(x,, 5)", "1 +"):
        try:
            X.parse(bad)
            assert False, bad
        except X.ExprError:
            pass


def test_classify_finds_windows_fields_and_groups():
    prog = X.parse("a = ts_mean(volume, 20); group_rank(ts_delta(a, 5) / ts_rank(close, 10, constant=0), industry)")
    kinds = list(X.classify(prog).values())
    assert kinds.count("window") == 3 and kinds.count("group") == 1 and kinds.count("var") == 1       # constant=0 is not a window
    assert X.field_names(prog) == ["volume", "close"]
    assert X.field_names(X.parse("rank(close * 2 + volume)")) == ["close", "volume"]


def test_check_enforces_limits_and_power_pool():
    lim = ga.Limits.power_pool()
    assert ga.check("rank(ts_zscore(close, 22))", lim) == []
    assert any("operators" in p for p in ga.check("rank(" * 6 + "ts_mean(ts_std_dev(ts_rank(close, 5), 5), 5)" + ")" * 6, lim))
    assert any("data fields" in p for p in ga.check("rank(a) + rank(b) + rank(c) + rank(d)", lim))
    assert ga.check("rank(group_rank(close, industry))", lim) == []                                         # a grouping field is not a data field
    assert any("does not parse" in p for p in ga.check("rank(", lim)) and any("no data field" in p for p in ga.check("rank(industry)", lim))
    assert any("assignment" in p for p in ga.check("a = rank(close)", ga.Limits()))
    assert any("does not offer" in p for p in ga.check("my_op(close)", ga.Limits(allowed_operators=frozenset({"rank"}))))
    assert any("long" in p for p in ga.check("rank(" + "close + " * 200 + "close)", ga.Limits(max_length=100)))


def test_every_mutation_changes_something_and_stays_parseable():
    ctx = ga.Context(fields=["close", "volume", "open", "vwap"])
    prog = X.parse("rank(ts_zscore(close, 22) - ts_mean(volume, 10))")
    rng = random.Random(5)
    for name, fn, _ in ga.MUTATIONS:
        got = [fn(prog, rng, ctx) for _ in range(20)]
        made = [g for g in got if g is not None]
        assert made, name
        for g in made:
            assert X.parse(X.print_(g)) == g and g != prog, name
    w = [ga.neighbour_window(22, rng) for _ in range(50)]
    assert 22 not in w and set(w) <= {10, 15, 30, 44} and ga.neighbour_window(100, rng) != 100        # 100 is off the ladder: still finds a neighbour
    assert ga.mut_window(X.parse("rank(close)"), rng, ctx) is None and ga.mut_unwrap(X.parse("ts_delta(close, 5)"), rng, ctx) is None


def test_offspring_are_valid_distinct_and_deterministic():
    ctx = ga.Context(fields=["close", "volume", "open", "vwap"], limits=ga.Limits(max_operators=8, max_fields=3))
    parents = ["rank(ts_zscore(close, 22))", "rank(ts_mean(volume, 10)) - rank(ts_delta(open, 5))"]

    def run(seed):
        rng, seen, out = random.Random(seed), {X.canon(p) for p in parents}, []
        for _ in range(40):
            o = ga.make_offspring(parents, rng, ctx, seen)
            assert o is not None
            seen.add(X.canon(o.expression))
            out.append(o)
        return out
    a, b = run(11), run(11)
    assert [o.expression for o in a] == [o.expression for o in b] and [o.expression for o in a] != [o.expression for o in run(12)]
    assert len({X.canon(o.expression) for o in a}) == 40 and not {X.canon(p) for p in parents} & {X.canon(o.expression) for o in a}
    for o in a:
        assert ga.check(o.expression, ctx.limits) == [], o.expression                      # parses, within limits, has a field and an operator
        assert all(0 <= i < 2 for i in o.parents)
    assert {"window", "operator", "field", "crossover"} <= {o.how for o in a}


def test_power_pool_offspring_never_break_the_limits():
    ctx = ga.Context(fields=[f"f{i}" for i in range(8)], limits=ga.Limits.power_pool())
    rng, seen = random.Random(2), set()
    parents = ["rank(ts_zscore(f0, 22)) + rank(ts_delta(f1, 5))", "rank(f2) - rank(ts_mean(f3, 10))"]
    for _ in range(120):
        o = ga.make_offspring(parents, rng, ctx, seen)
        if o is None:
            continue
        seen.add(X.canon(o.expression))
        parents = [parents[1], o.expression]                                              # keep breeding from the newest: stresses the limits
        assert ga.count_operators(o.expression) <= 8 and len(ga.unique_data_fields(o.expression)) <= 3, o.expression


def test_crossover_swaps_like_for_like_and_respects_variables():
    ctx = ga.Context(fields=["close"])
    a, b = X.parse("rank(ts_mean(close, 5))"), X.parse("zscore(ts_std_dev(volume, 63))")
    rng, seen = random.Random(1), set()
    for _ in range(40):
        c = ga.crossover(a, b, rng, ctx)
        assert c is not None and c != a and c != b and X.parse(X.print_(c)) == c
        seen.add(X.print_(c))
    assert any("63" in s for s in seen) and any("volume" in s for s in seen)
    withvar, plain = X.parse("v = ts_mean(close, 5); rank(v)"), X.parse("rank(ts_mean(open, 10))")
    for _ in range(40):
        c = ga.crossover(plain, withvar, rng, ctx)
        assert c is None or "v" not in {n.id for _, n in X.walk(c) if isinstance(n, X.Name)}      # `v` does not exist in `plain`
    assert ga.make_offspring(["rank("], random.Random(1), ctx, set()) is None                      # unusable parents give nothing, not a crash
