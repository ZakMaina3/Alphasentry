"""Fragment C1 + C2: the LLM adapter and its daily budget / usage ledger (a fake provider; no network, no keys)."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.harness import llm as L
from app.harness.llm_budget import Budget, BudgetExceeded, est_tokens
from tests.ace_db import ace_db


class Res:
    def __init__(self, items, provider="fake", model="m1"):
        self.expressions, self.provider, self.model = items, provider, model


class Fake:
    def __init__(self, items=None, boom=None):
        self.items, self.boom, self.prompts, self.ns = items if items is not None else ["hello"], boom, [], []

    def generate_list(self, prompt, n=None):
        self.prompts.append(prompt)
        self.ns.append(n)
        if self.boom:
            raise self.boom
        return Res(self.items)


class Clock:
    def __init__(self, t=1_800_000_000.0):
        self.t = t

    def __call__(self):
        self.t += 0.01
        return self.t


def make(s, fake, tmp_path=None, **cfg):
    clock = Clock()
    b = Budget(s, (tmp_path / "b.json") if tmp_path else None, clock=clock)
    if cfg:
        b.set_config(**cfg)
    return L.LLM(s, provider=lambda: fake, budget=b, status=lambda: {"available": ["fake"], "preferred": "fake", "used": ["fake"]}, clock=clock), b, clock


def test_complete_builds_the_prompt_and_records_usage(tmp_path):
    with ace_db(tmp_path) as s:
        fake = Fake(['{"a": 1}'])
        llm, b, _ = make(s, fake)
        r = llm.complete("SYS", "USER", lab="invent")
        assert r.text == '{"a": 1}' and r.provider == "fake" and r.model == "m1" and r.est_tokens > 0
        assert "SYS" in fake.prompts[0] and "USER" in fake.prompts[0] and fake.ns == [1]
        row = s.query("SELECT * FROM harness_llm_usage")[0]
        assert row["lab"] == "invent" and row["ok"] == 1 and row["prompt_tokens"] == est_tokens(len(fake.prompts[0])) and row["completion_tokens"] == est_tokens(8)
        assert llm.complete("S", "U", json=True).data == {"a": 1}
        l2 = make(s, Fake(["```json\n{\"x\": [1, 2]}\n```"]))[0]
        assert l2.complete("S", "U", json=True).data == {"x": [1, 2]}
        l3 = make(s, Fake(["Sure! Here it is: {\"k\": 5} hope that helps"]))[0]
        assert l3.complete("S", "U", json=True).data == {"k": 5}
        try:
            make(s, Fake(["not json at all"]))[0].complete("S", "U", json=True)
            assert False
        except L.LLMError as e:
            assert "valid JSON" in str(e)


def test_complete_list_asks_for_n_items(tmp_path):
    with ace_db(tmp_path) as s:
        fake = Fake(["a", "b", "c"])
        r = make(s, fake)[0].complete_list("S", "U", lab="x", n=3)
        assert r.items == ["a", "b", "c"] and fake.ns == [3] and "exactly 3 strings" in fake.prompts[0]


def test_daily_call_cap_refuses_before_sending_and_resets_tomorrow(tmp_path):
    with ace_db(tmp_path) as s:
        fake = Fake()
        llm, b, clock = make(s, fake, max_calls_per_day=2, max_tokens_per_day=0)
        llm.complete("S", "U")
        llm.complete("S", "U")
        try:
            llm.complete("S", "U")
            assert False
        except BudgetExceeded as e:
            assert "call limit (2)" in str(e)
        assert len(fake.prompts) == 2 and b.used() == {"calls": 2, "tokens": b.used()["tokens"], "usd": 0.0}      # the refused call sent nothing, cost nothing
        clock.t += 86400
        llm.complete("S", "U")                                                                                     # a new UTC day: allowed again
        assert len(fake.prompts) == 3 and [d["calls"] for d in b.summary()["days"]] == [1, 2]


def test_token_and_money_caps(tmp_path):
    with ace_db(tmp_path) as s:
        llm, b, _ = make(s, Fake(["x" * 400]), max_calls_per_day=0, max_tokens_per_day=4000)
        try:
            llm.complete("S", "U" * 4000)                                  # ~1000 prompt tokens + 3000 reserved for the answer > 4000? exactly over
            assert False
        except BudgetExceeded as e:
            assert "token limit" in str(e)
        b.set_config(max_tokens_per_day=0, usd_per_million_tokens=10.0, max_usd_per_day=0.04)
        llm.complete("S", "U")                                              # reserve 3000 tokens = $0.03 < $0.04
        try:
            llm.complete("S", "U")                                          # used ~ $0.0001 + reserve $0.03 + ... still ok? tighten the cap
            b.set_config(max_usd_per_day=0.0301)
            llm.complete("S", "U")
            assert False
        except BudgetExceeded as e:
            assert "spend limit" in str(e)
        assert b.summary()["today"]["usd"] > 0 and b.summary()["estimated"] is True


def test_failures_are_recorded_and_reported_plainly(tmp_path):
    with ace_db(tmp_path) as s:
        llm, b, _ = make(s, Fake(boom=RuntimeError("rate limited")))
        try:
            llm.complete("S", "U", lab="invent")
            assert False
        except L.LLMError as e:
            assert "rate limited" in str(e)
        row = s.query("SELECT * FROM harness_llm_usage")[0]
        assert row["ok"] == 0 and "rate limited" in row["error"] and row["completion_tokens"] == 0 and b.used()["calls"] == 1
        empty = make(s, Fake([]))[0]
        try:
            empty.complete("S", "U")
            assert False
        except L.LLMError as e:
            assert "nothing" in str(e)
        assert s.query("SELECT ok FROM harness_llm_usage ORDER BY id DESC")[0]["ok"] == 0
        def unavailable():
            raise L.LLMUnavailable("No LLM providers set up. Add an API key in Settings.")
        n0 = b.used()["calls"]
        u = L.LLM(s, provider=unavailable, budget=b)
        try:
            u.complete("S", "U")
            assert False
        except L.LLMUnavailable as e:
            assert "API key" in str(e)
        assert b.used()["calls"] == n0                                       # nothing was sent, so nothing is recorded


def test_budget_config_is_validated_and_persisted(tmp_path):
    with ace_db(tmp_path) as s:
        b = Budget(s, tmp_path / "x" / "b.json")
        assert b.config()["max_calls_per_day"] == 40
        b.set_config(max_calls_per_day=5, usd_per_million_tokens=3.5)
        assert Budget(s, tmp_path / "x" / "b.json").config()["max_calls_per_day"] == 5 and json.loads((tmp_path / "x" / "b.json").read_text())["usd_per_million_tokens"] == 3.5
        for kw in ({"max_calls_per_day": -1}, {"max_calls_per_day": "abc"}, {"nope": 1}, {"max_usd_per_day": float("nan")}):
            try:
                b.set_config(**kw)
                assert False, kw
            except ValueError:
                pass
        assert b.set_config(max_calls_per_day=None)["max_calls_per_day"] == 5            # None = leave alone
        (tmp_path / "x" / "b.json").write_text("garbage")
        assert b.config()["max_calls_per_day"] == 40                                       # a damaged file falls back to the safe defaults


def test_status_and_per_lab_summary(tmp_path):
    with ace_db(tmp_path) as s:
        llm, b, _ = make(s, Fake())
        llm.complete("S", "U", lab="invent")
        llm.complete("S", "U", lab="invent")
        llm.complete("S", "U", lab="other")
        st = llm.status()
        assert st["available"] == ["fake"] and st["budget"]["today"]["calls"] == 3 and st["budget"]["byLab"][0] == {"lab": "invent", "calls": 2, "tokens": st["budget"]["byLab"][0]["tokens"]}
