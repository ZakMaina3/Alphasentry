import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.autopilot import pacing as PC


def test_delay_runs_one_at_a_time_with_a_wait_before_each():
    log = []
    out = PC.run_checks(["a", "b", "c"], lambda x: log.append(("check", x)) or x.upper(), 60, lambda s: log.append(("sleep", s)), lambda: False)
    assert out == ["A", "B", "C"]
    assert log == [("sleep", 60), ("check", "a"), ("sleep", 60), ("check", "b"), ("sleep", 60), ("check", "c")]


def test_cancel_stops_before_the_next_wait_and_check():
    state = {"n": 0}
    def check(x):
        state["n"] += 1
        return x
    out = PC.run_checks(["a", "b", "c"], check, 60, lambda s: None, lambda: state["n"] >= 1)
    assert out == ["a"] and state["n"] == 1


def test_zero_delay_keeps_parallel_checks_and_drops_none_results():
    slept = []
    out = PC.run_checks([1, 2, 3, 4, 5], lambda x: None if x == 3 else x * 2, 0, slept.append, lambda: False)
    assert out == [2, 4, 8, 10] and slept == []
    assert PC.run_checks([], lambda x: x, 60, lambda s: None, lambda: False) == []


def test_messages_name_each_wait():
    said = []
    PC.run_checks(["a", "b"], lambda x: x, 60, lambda s: None, lambda: False, say=said.append)
    assert said == ["waiting 60 s before prod check 1/2…", "waiting 60 s before prod check 2/2…"]
