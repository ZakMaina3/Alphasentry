#!/bin/sh
# Offline stand-in for `npm run build` when node_modules cannot be installed (no network).
#   1. esbuild (the transformer Vite uses) bundles src/main.tsx: catches syntax errors and any import that does not resolve.
#   2. tsc with the project's REAL tsconfig and REAL src/lib files, with only the external packages (react, react-router-dom ...) stubbed:
#      catches unused variables / imports (noUnusedLocals fails the real build), wrong props, bad calls into src/lib.
# Expect: step 1 silent; step 2 may still print implicit-any / "unknown" errors that come from the STUBS, in files this port did not touch.
# Anything about unused variables (TS6133/TS6196), missing modules (TS2307) or wrong arguments in src/features/harness is REAL.
# In a real environment ignore this and run:  cd frontend && npm ci && npm run build
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"; SRC="$HERE/../../frontend"
ES="${ESBUILD:-esbuild}"
echo "== 1. esbuild bundle =="
"$ES" "$SRC/src/main.tsx" --bundle --outdir=/tmp/ace-eb --jsx=automatic --loader:.css=empty --loader:.png=dataurl --loader:.svg=dataurl \
  --external:react --external:react-dom --external:react-dom/client --external:react-router-dom --external:react/jsx-runtime --format=esm --log-level=warning
echo "ok"
echo "== 2. tsc (real tsconfig, stubbed externals) =="
W=/tmp/ace-tc; rm -rf "$W"; mkdir -p "$W/stubs"; cp -r "$SRC/src" "$W/src"; cp "$SRC/tsconfig.json" "$W/"; cp "$HERE/ext.d.ts" "$W/stubs/"
python3 - "$W" <<'PY'
import json, sys
p = sys.argv[1] + "/tsconfig.json"; d = json.load(open(p))
d["include"] = ["src", "stubs"]; d["compilerOptions"]["ignoreDeprecations"] = "6.0"      # only needed with TypeScript 6
json.dump(d, open(p, "w"))
PY
cd "$W" && { tsc -p . || true; } | tee out.txt | grep -E "TS6133|TS6196|TS2307|TS2304|TS2552|TS2551|TS2554|TS2741|TS2353|harness" || echo "no real errors found"
