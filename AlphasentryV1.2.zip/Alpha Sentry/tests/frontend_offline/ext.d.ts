declare module "react" {
  export type ReactNode = any;
  export type CSSProperties = Record<string, any>;
  export type ChangeEvent<T = any> = { target: T & { value: string; checked: boolean; files: any }; currentTarget: T };
  export type FormEvent<T = any> = { preventDefault(): void; target: T; currentTarget: T };
  export type KeyboardEvent<T = any> = { key: string; preventDefault(): void; stopPropagation(): void; target: T; currentTarget: T; shiftKey: boolean; metaKey: boolean; ctrlKey: boolean };
  export type MouseEvent<T = any> = { preventDefault(): void; stopPropagation(): void; target: T; currentTarget: T };
  export type DragEvent<T = any> = MouseEvent<T> & { dataTransfer: any };
  export type Dispatch<A> = (a: A) => void;
  export type SetStateAction<S> = S | ((p: S) => S);
  export type RefObject<T> = { current: T | null };
  export type MutableRefObject<T> = { current: T };
  export type FC<P = {}> = (props: P) => any;
  export type PropsWithChildren<P = {}> = P & { children?: any };
  export type ComponentType<P = {}> = (props: P) => any;
  export type ErrorInfo = any;
  export type HTMLAttributes<T> = any;
  export type ButtonHTMLAttributes<T> = any;
  export type InputHTMLAttributes<T> = any;
  export type SVGProps<T> = any;
  export function useState<S>(i: S | (() => S)): [S, Dispatch<SetStateAction<S>>];
  export function useEffect(f: () => void | (() => void), d?: readonly unknown[]): void;
  export function useLayoutEffect(f: () => void | (() => void), d?: readonly unknown[]): void;
  export function useRef<T>(i: T): MutableRefObject<T>;
  export function useRef<T>(i: T | null): RefObject<T>;
  export function useRef<T = undefined>(): MutableRefObject<T | undefined>;
  export function useMemo<T>(f: () => T, d: readonly unknown[]): T;
  export function useCallback<T extends (...a: any[]) => any>(f: T, d: readonly unknown[]): T;
  export function useContext(c: any): any;
  export function useReducer(...a: any[]): any;
  export function createContext<T>(d: T): any;
  export function createElement(...a: any[]): any;
  export function memo<T>(c: T): T;
  export function lazy(f: any): any;
  export const Suspense: any, Fragment: any, StrictMode: any;
  export class Component<P = {}, S = {}> { props: P; state: S; setState(s: any): void; constructor(p: P); render(): any }
  const React: any;
  export default React;
}
declare module "react/jsx-runtime" { export const jsx: any, jsxs: any, Fragment: any; }
declare module "react-dom/client" { export function createRoot(e: any): { render(n: any): void }; }
declare module "react-dom" { export function createPortal(...a: any[]): any; }
declare module "react-router-dom" {
  export const BrowserRouter: any, NavLink: any, Routes: any, Route: any, Navigate: any, Link: any, Outlet: any;
  export function useLocation(): { pathname: string; search: string; hash: string; state: any };
  export function useNavigate(): (to: any, o?: any) => void;
  export function useParams(): Record<string, string | undefined>;
  export function useSearchParams(): [URLSearchParams, (p: any) => void];
}
declare namespace JSX {
  type H = (e: any) => void;
  interface Attrs { onChange?: H; onClick?: H; onInput?: H; onKeyDown?: H; onSubmit?: H; onMouseDown?: H; onFocus?: H; onBlur?: H; [k: string]: any }
  interface IntrinsicElements { [k: string]: Attrs }
  interface IntrinsicAttributes { key?: any }
  interface ElementChildrenAttribute { children: {} }
  interface Element {}
}
declare module "*.css" {}
declare module "*.png" { const s: string; export default s; }
declare module "*.svg" { const s: string; export default s; }
interface ImportMetaEnv { [k: string]: any }
interface ImportMeta { env: ImportMetaEnv }
