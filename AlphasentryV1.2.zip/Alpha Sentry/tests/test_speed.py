"""Fragment G1: Autosentry speed through the harness engine (wider rounds, learned ceiling, release of stuck batches)."""
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.harness import autopilot_route as AR
from app.harness import speed
from app.harness.engine.slots import SlotLease
from tests.test_harness_engine import make_tracker, sim


def _cfg(monkeypatch, tmp_path, **kw):
    monkeypatch.setattr(speed, "_path", lambda: tmp_path / "speed.json")
    speed.reset_ceiling()
    if kw:
        speed.set_config(**kw)


class Port:
    """BRAIN stand-in: `hold` names expressions whose batch stays running until `gate` is set; `limit` makes start() refuse (429) beyond it."""
    class SlotBusy(RuntimeError):
        pass

    def __init__(self, hold=(), gate=None, limit=None):
        self.hold, self.gate, self.limit = set(hold), gate or threading.Event(), limit
        self.lock, self.active, self.max_active, self.refused = threading.Lock(), 0, 0, 0

    def start(self, payload):
        with self.lock:
            if self.limit is not None and self.active >= self.limit:
                self.refused += 1
                raise self.SlotBusy("limit")
            self.active += 1
            self.max_active = max(self.max_active, self.active)
        h = type("H", (), {})()
        h.sim_url, h.multi = f"https://x/{id(payload)}", isinstance(payload, list)
        return h

    def wait(self, handle, payload, tag="x"):
        ps = payload if isinstance(payload, list) else [payload]
        if any(p["regular"] in self.hold for p in ps):
            self.gate.wait(10)
        time.sleep(0.15)
        with self.lock:
            self.active -= 1
        return [{"alpha_id": f"A_{p['regular']}", "simulate_data": p} for p in ps]


def _batches(n, size=2):
    return [[sim(f"b{b}_{i}") for i in range(size)] for b in range(n)]


def test_effective_parallel_follows_the_rules(monkeypatch, tmp_path):
    _cfg(monkeypatch, tmp_path)
    assert speed.effective_parallel(False, 3) == 3 and speed.effective_parallel(False, 8) == 3        # off the engine: ACE's own cap
    assert speed.effective_parallel(True, 2) == 2 and speed.effective_parallel(True, 1) == 1          # a gentle setting stays gentle
    assert speed.effective_parallel(True, 3) == 6                                                      # default wider round
    speed.set_config(parallel=8)
    assert speed.effective_parallel(True, 3) == 8
    for bad in (0, 9):
        try:
            speed.set_config(parallel=bad)
            assert False
        except speed.SpeedError:
            pass
    for bad in (10, 20000):
        try:
            speed.set_config(straggler_s=bad)
            assert False
        except speed.SpeedError:
            pass
    assert speed.set_config(straggler_s=0)["straggler_s"] == 0.0                                       # 0 = never release


def test_ceiling_is_learned_then_expires(monkeypatch, tmp_path):
    _cfg(monkeypatch, tmp_path, parallel=8)
    t0 = 1000.0
    assert speed.note_busy(5, now=t0) == 4 and speed.effective_parallel(True, 3, now=t0 + 1) == 4
    assert speed.note_busy(7, now=t0 + 2) == 4                                                         # only ever tightens within the window
    assert speed.note_busy(2, now=t0 + 3) == 2                                                         # never below 2
    assert speed.ceiling(now=t0 + speed.CEILING_TTL + 10) is None                                      # BRAIN is probed again later
    assert speed.effective_parallel(True, 3, now=t0 + speed.CEILING_TTL + 10) == 8


def test_a_wide_round_really_runs_side_by_side_and_shares_the_lease(monkeypatch, tmp_path):
    _cfg(monkeypatch, tmp_path, parallel=6)
    monkeypatch.setattr(AR.flags, "enabled", lambda n: n == "autopilot_via_engine")
    tr, port, lease = make_tracker(tmp_path), Port(), SlotLease(8)
    with AR.engine_routing():
        flat, done, cancelled, errors = AR.maybe_route(_batches(6), 3, lambda **k: None, lambda: False, 12,
                                                       port=port, lease=lease, tracker=tr, poll=0.05)
    assert done == 12 and not errors and port.max_active == 6                                          # 6 at once, not ACE's 3
    assert lease.free() == 8 and tr.counts() == {"external": 12}
    lease2, port2 = SlotLease(4), Port()
    with AR.engine_routing():
        AR.maybe_route(_batches(6), 3, lambda **k: None, lambda: False, 12, port=port2, lease=lease2, tracker=make_tracker(tmp_path / "b" if (tmp_path / "b").mkdir() is None else tmp_path), poll=0.05)
    assert port2.max_active <= 4                                                                       # the lease still caps everything
    port3 = Port()                                                                                     # Autosentry concurrency set to 2: stays at 2
    with AR.engine_routing():
        AR.maybe_route(_batches(6), 2, lambda **k: None, lambda: False, 12, port=port3, lease=SlotLease(8),
                       tracker=make_tracker(tmp_path / "c" if (tmp_path / "c").mkdir() is None else tmp_path), poll=0.05)
    assert port3.max_active == 2


def test_brain_refusing_teaches_the_ceiling_and_nothing_is_lost(monkeypatch, tmp_path):
    _cfg(monkeypatch, tmp_path, parallel=8)
    monkeypatch.setattr(AR.flags, "enabled", lambda n: n == "autopilot_via_engine")
    real_sleep = time.sleep
    monkeypatch.setattr(AR.time, "sleep", lambda s: real_sleep(0.02 if s >= 1 else s))                 # the 5 s retry wait, shortened
    tr, port, lease = make_tracker(tmp_path), Port(limit=3), SlotLease(8)
    with AR.engine_routing():
        flat, done, cancelled, errors = AR.maybe_route(_batches(6), 3, lambda **k: None, lambda: False, 12,
                                                       port=port, lease=lease, tracker=tr, poll=0.05)
    assert done == 12 and not errors and port.max_active <= 3 and port.refused >= 1                    # waited, then ran every batch
    assert speed.ceiling() is not None and speed.ceiling() >= 2


def test_a_stuck_batch_is_released_and_scored_later(monkeypatch, tmp_path):
    _cfg(monkeypatch, tmp_path, parallel=6)
    monkeypatch.setattr(AR.flags, "enabled", lambda n: n == "autopilot_via_engine")
    gate = threading.Event()
    tr, port, lease = make_tracker(tmp_path), Port(hold={"b3_0"}, gate=gate), SlotLease(8)
    logs = []
    t0 = time.time()
    with AR.engine_routing():
        flat, done, cancelled, errors = AR.maybe_route(_batches(4), 4, lambda **k: logs.append(k), lambda: False, 8,
                                                       port=port, lease=lease, tracker=tr, poll=0.05, straggler_s=0.5)
    assert time.time() - t0 < 3 and done == 6 and not cancelled                                        # the round went on without the stuck batch
    assert any("continuing without them" in str(k.get("log")) for k in logs)
    assert lease.free() == 7 and tr.counts() == {"external": 6, "running": 2}                           # its slot is still held, honestly
    gate.set()
    for _ in range(100):
        if lease.free() == 8:
            break
        time.sleep(0.05)
    assert lease.free() == 8 and tr.counts() == {"external": 6, "done": 2}                              # handed to the harness scorer, not lost
    assert tr.orphan_batches() == []


def test_nothing_is_released_when_no_batch_has_finished(monkeypatch, tmp_path):
    _cfg(monkeypatch, tmp_path, parallel=6)
    monkeypatch.setattr(AR.flags, "enabled", lambda n: n == "autopilot_via_engine")
    gate = threading.Event()
    tr, port = make_tracker(tmp_path), Port(hold={"b0_0", "b1_0"}, gate=gate)
    flag = {"stop": False}
    threading.Timer(1.2, lambda: flag.update(stop=True)).start()
    with AR.engine_routing():
        flat, done, cancelled, errors = AR.maybe_route(_batches(2), 3, lambda **k: None, lambda: flag["stop"], 4,
                                                       port=port, lease=SlotLease(8), tracker=tr, poll=0.05, straggler_s=0.3)
    gate.set()
    assert cancelled and done == 0                                                                     # an outage is not mistaken for a slow batch


def test_autopilot_service_hook_is_flag_gated_and_keeps_the_original_line():
    src = (Path(__file__).resolve().parents[1] / "backend" / "app" / "autopilot" / "service.py").read_text(encoding="utf-8")
    i = src.index('cfg["parallel"] = max(1, min(3, int(cfg.get("concurrency") or 1)))')              # ACE's own line stays first
    hook = src[i:i + 700]
    assert 'enabled("autopilot_via_engine")' in hook and "effective_parallel(True" in hook and "except Exception" in hook
