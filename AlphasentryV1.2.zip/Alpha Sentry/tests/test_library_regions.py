"""Library: region ticks for alphas and boosters (stored in each item's meta; none stored = all regions)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.autopilot import regions as RG

KNOWN = ["USA", "EUR", "GLB", "ASI"]


def test_no_regions_key_means_every_region_and_nothing_changes_for_old_items():
    assert RG.applies({}, "USA") and RG.applies(None, "GLB") and RG.applies({"min_sharpe": 1.2}, "EUR")
    assert RG.applies({"regions": ["USA"]}, "") and RG.applies({"regions": ["USA"]}, None)           # no filter asked for: applies


def test_a_list_restricts_and_an_empty_list_parks_the_item_everywhere():
    m = {"regions": ["USA", "eur"]}
    assert RG.applies(m, "USA") and RG.applies(m, "EUR") and not RG.applies(m, "GLB")
    assert RG.applies(m, "usa:super") and not RG.applies(m, "GLB:super")                              # super memory suffix ignored
    assert not any(RG.applies({"regions": []}, r) for r in KNOWN)


def test_clean_drops_junk_and_duplicates_and_non_lists_mean_all():
    assert RG.clean(["usa", "USA", " eur ", "", "x", "TOOLONGCODE", 5, "GLB:super"]) == ["USA", "EUR", "GLB"]
    assert RG.clean("USA") is None and RG.clean(None) is None and RG.clean([]) == []


def test_toggling_one_region_off_and_on_round_trips_to_no_restriction():
    m = {"min_sharpe": 1.5}
    off = RG.toggled(m, "EUR", False, KNOWN)
    assert off == {"min_sharpe": 1.5, "regions": ["ASI", "GLB", "USA"]}                               # all minus EUR; other keys kept
    assert m == {"min_sharpe": 1.5}                                                                  # input not mutated
    back = RG.toggled(off, "EUR", True, KNOWN)
    assert back == {"min_sharpe": 1.5} and "regions" not in back                                      # all ticked again = unrestricted
    only = RG.toggled(RG.toggled(RG.toggled({}, "GLB", False, KNOWN), "ASI", False, KNOWN), "EUR", False, KNOWN)
    assert only["regions"] == ["USA"]
    none = RG.toggled(only, "USA", False, KNOWN)
    assert none["regions"] == [] and not RG.applies(none, "USA")
    assert RG.toggled({"regions": ["USA"]}, "USA", True, KNOWN)["regions"] == ["USA"]                 # idempotent


def test_a_region_added_later_by_brain_still_counts_for_unrestricted_items():
    assert RG.applies({}, "KOR")                                                                     # not in any list, no restriction
    assert not RG.applies({"regions": ["USA", "EUR", "GLB", "ASI"]}, "KOR")                            # ticked explicitly = only those


def test_bad_region_codes_are_refused():
    for bad in ("", "u", "U S A", "WAYTOOLONGREGION"):
        try:
            RG.toggled({}, bad, True, KNOWN)
            assert False, bad
        except ValueError:
            pass


# The database-backed part needs SQLAlchemy (not installed in every environment): run_all skips it there, pytest runs it where it is installed.
try:
    import sqlalchemy  # noqa: F401
    HAVE_DB = True
except ImportError:
    HAVE_DB = False


def test_library_filters_boosters_and_context_by_region(tmp_path, monkeypatch):
    if not HAVE_DB:
        return
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker

    from app.autopilot import library as K
    from app.db import models as M
    from app.db.base import Base
    eng = create_engine(f"sqlite:///{tmp_path / 't.db'}")
    Base.metadata.create_all(eng)
    monkeypatch.setattr(K, "SessionLocal", sessionmaker(eng))
    K.add_asset("booster", "ts_decay_linear({alpha}, 8)", name="all", meta={"min_sharpe": 1.0})
    K.add_asset("booster", "rank({alpha})", name="usa", meta={"regions": ["usa"]})
    K.add_asset("alpha", "rank(close)", name="a-eur", meta={"regions": ["EUR"]})
    K.add_asset("alpha", "rank(volume)", name="a-all")
    assert {b["name"] for b in K.active_boosters("USA")} == {"all", "usa"}
    assert {b["name"] for b in K.active_boosters("EUR")} == {"all"}
    assert {b["name"] for b in K.active_boosters()} == {"all", "usa"}
    assert set(K.build_context("EUR")["seed_alphas"]) == {"rank(close)", "rank(volume)"}
    assert set(K.build_context("USA")["seed_alphas"]) == {"rank(volume)"}
    assert K.toggle_region("booster", "USA", False, KNOWN)["changed"] == 2
    assert {b["name"] for b in K.active_boosters("USA")} == set()
    assert K.toggle_region("booster", "bad code!", True, KNOWN).get("error")
    assert M  # models imported
