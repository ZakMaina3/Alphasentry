"""Data Catalog: one-time pull (resumable, per scope and category), filters, CSV and Excel export."""
import io
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.catalog import pure as C

SC = {"region": "USA", "delay": 1, "universe": "TOP3000"}


def make(n_ds=7, per=3):
    ds = [{"id": f"d{i}", "name": f"Dataset {i}", "category_id": "analyst" if i % 2 else "fundamental", "category_name": "Analyst" if i % 2 else "Fundamental"} for i in range(n_ds)]
    calls = {"list": [], "fetch": [], "saved_ds": [], "saved_fields": [], "states": 0}

    def list_datasets(sc, cats):
        calls["list"].append((sc["region"], tuple(cats)))
        return [d for d in ds if not cats or d["category_id"] in cats]

    def fetch(sc, ids):
        calls["fetch"].append(list(ids))
        return [{"id": f"{d}_f{k}", "description": f"field {k} of {d}", "type": "MATRIX", "dataset_id": d} for d in ids for k in range(per)]

    out = dict(list_datasets=list_datasets, fetch_fields=fetch,
               save_datasets=lambda sc, rows: calls["saved_ds"].append(len(rows)),
               save_fields=lambda sc, rows: calls["saved_fields"].append(len(rows)),
               save_state=lambda st: calls.__setitem__("states", calls["states"] + 1),
               progress=lambda **k: None, cancel=lambda: False)
    return out, calls


def test_pull_downloads_every_dataset_in_chunks_and_saves_as_it_goes():
    kw, calls = make()
    state = {}
    r = C.pull([SC], [], state, **kw, chunk=3)
    assert r[0]["fields"] == 21 and r[0]["datasets"] == 7 and r[0]["errors"] == []
    assert [len(x) for x in calls["fetch"]] == [3, 3, 1] and calls["states"] == 3
    assert len(state["USA|1|TOP3000"]) == 7


def test_pull_is_one_time_a_second_run_downloads_nothing_unless_forced():
    kw, calls = make()
    state = {}
    C.pull([SC], [], state, **kw)
    n = len(calls["fetch"])
    r = C.pull([SC], [], state, **kw)
    assert len(calls["fetch"]) == n and r[0]["skipped"] == 7 and r[0]["fields"] == 0
    C.pull([SC], [], state, **kw, force=True)
    assert len(calls["fetch"]) > n


def test_pull_respects_categories_and_resumes_after_an_interruption():
    kw, calls = make()
    state = {}
    r = C.pull([SC], ["analyst"], state, **kw, chunk=1)
    assert r[0]["datasets"] == 3 and set(state["USA|1|TOP3000"]) == {"d1", "d3", "d5"}
    kw2, calls2 = make()
    stop = {"n": 0}
    def cancel():
        stop["n"] += 1
        return stop["n"] > 4                              # cancelled part-way
    kw2["cancel"] = cancel
    st2 = {}
    C.pull([SC], [], st2, **kw2, chunk=1)
    got = len(st2["USA|1|TOP3000"])
    assert 0 < got < 7
    kw3, calls3 = make()
    C.pull([SC], [], st2, **kw3, chunk=1)                 # resume: only the rest is fetched
    assert len(calls3["fetch"]) == 7 - got and len(st2["USA|1|TOP3000"]) == 7


def test_pull_handles_several_scopes_and_one_failing_chunk():
    kw, calls = make()
    real = kw["fetch_fields"]

    def flaky(sc, ids):
        if "d2" in ids:
            raise RuntimeError("BRAIN said no")
        return real(sc, ids)
    kw["fetch_fields"] = flaky
    state = {}
    r = C.pull([SC, {"region": "GLB", "delay": 1, "universe": "TOP3000"}], [], state, **kw, chunk=1)
    assert len(r) == 2 and r[0]["errors"] and "d2" in r[0]["errors"][0]
    assert "d2" not in state["USA|1|TOP3000"] and len(state["USA|1|TOP3000"]) == 6      # retried next time


def test_fields_without_a_dataset_id_are_fetched_one_dataset_at_a_time():
    kw, calls = make()
    real = kw["fetch_fields"]
    kw["fetch_fields"] = lambda sc, ids: [{k: v for k, v in r.items() if k != "dataset_id"} | ({"dataset_id": ""} if len(ids) > 1 else {}) for r in real(sc, ids)]
    saved = []
    kw["save_fields"] = lambda sc, rows: saved.extend(rows)
    C.pull([SC], [], {}, **kw, chunk=3)
    assert saved and all(r["dataset_id"] for r in saved)


def test_filters_match_text_type_category_and_dataset():
    rows = [{"field_id": "oth143_buy_rank", "description": "Broker buy rank", "type": "MATRIX", "category": "other", "dataset_id": "oth143", "dataset_name": "Brokers"},
            {"field_id": "anl4_eps", "description": "EPS estimate", "type": "VECTOR", "category": "analyst", "dataset_id": "anl4", "dataset_name": "Analyst"}]
    assert [r["field_id"] for r in rows if C.matches(r, q="broker rank")] == ["oth143_buy_rank"]
    assert [r["field_id"] for r in rows if C.matches(r, type_="vector")] == ["anl4_eps"]
    assert [r["field_id"] for r in rows if C.matches(r, category="ANAL")] == ["anl4_eps"]
    assert [r["field_id"] for r in rows if C.matches(r, dataset="brokers")] == ["oth143_buy_rank"]


def test_csv_and_excel_exports_round_trip():
    rows = [{"field_id": "a_1", "dataset_id": "a", "dataset_name": "Name, with comma", "category": "x", "region": "USA", "delay": 1,
             "universe": "TOP3000", "type": "MATRIX", "description": "Say \"hi\" & <go>", "alpha_count": 12, "coverage": 0.9, "prefix": "a"}]
    import csv
    text = C.to_csv(rows).decode("utf-8-sig")
    back = list(csv.DictReader(io.StringIO(text)))
    assert back[0]["dataset_name"] == "Name, with comma" and back[0]["description"] == 'Say "hi" & <go>'
    try:
        import openpyxl
    except ImportError:
        return
    wb = openpyxl.load_workbook(io.BytesIO(C.to_xlsx(rows)))
    ws = wb.active
    assert [c.value for c in ws[1]][:3] == ["field_id", "dataset_id", "dataset_name"]
    assert ws["C2"].value == "Name, with comma" and ws["I2"].value == 'Say "hi" & <go>' and ws["J2"].value == 12 and ws["K2"].value == 0.9


def test_categories_are_counted_from_dataset_rows():
    ds = [{"category_id": "analyst", "category_name": "Analyst"}] * 3 + [{"category_id": "fundamental", "category_name": "Fundamental"}, {"category_id": ""}]
    assert C.categories_from(ds) == [{"id": "analyst", "name": "Analyst", "count": 3}, {"id": "fundamental", "name": "Fundamental", "count": 1}]
