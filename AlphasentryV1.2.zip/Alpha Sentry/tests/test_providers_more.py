"""Ready-made free providers, base-URL overrides and custom OpenAI-compatible providers."""
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "backend"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "vendor"))

import keys as K
import llm_providers as L
import provider_presets as PP


def _fresh(tmp):
    K.KEYS_FILE = os.path.join(tmp, "ace_keys.json")
    for v in [p["key_env"] for p in PP.PRESETS.values()] + [p["base_env"] for p in PP.PRESETS.values()]:
        os.environ.pop(v, None)
    for k in [k for k in os.environ if k.startswith("CUSTOM_")]:
        os.environ.pop(k)
    L._has_module = lambda name: True              # pretend the openai package is installed


def test_every_preset_is_in_the_key_store_and_the_provider_tables():
    assert len(PP.PRESETS) >= 25 and "ninerouter" in PP.PRESETS and "cerebras" in PP.PRESETS and "ollama" in PP.PRESETS
    for n, p in PP.PRESETS.items():
        assert K.PROVIDERS[n] == p["key_env"] and K.MODEL_ENV[n] == p["model_env"]
        assert L.PROVIDER_KEY_ENV[n] == p["key_env"] and L.provider_default(n) == p["default_model"]
        assert PP.valid_base_url(p["base_url"]), n
    assert len({p["key_env"] for p in PP.PRESETS.values()} | set(K.PROVIDERS.values())) == len(K.PROVIDERS.values())   # no two share an env var
    assert K.EXTRA["cloudflare_account"] == "CLOUDFLARE_ACCOUNT_ID"


def test_a_preset_becomes_available_with_a_key_and_uses_its_address():
    with tempfile.TemporaryDirectory() as t:
        _fresh(t)
        names = lambda: [p.name for p in L.all_available()]
        assert "cerebras" not in names()
        K.set_keys({"cerebras": "abc123"})
        assert "cerebras" in names()
        p = L.get_provider("cerebras")
        assert p.base_url == "https://api.cerebras.ai/v1" and p.model == "llama-3.3-70b"
        K.set_keys({"cerebras": K.CLEAR})
        assert "cerebras" not in names()


def test_base_url_override_for_a_local_router_and_validation():
    with tempfile.TemporaryDirectory() as t:
        _fresh(t)
        K.set_keys({"ninerouter": "local"})
        assert L.get_provider("ninerouter").base_url == "http://localhost:20128/v1"
        K.set_base_url("ninerouter", "http://192.168.1.5:20128/v1/")
        assert L.get_provider("ninerouter").base_url == "http://192.168.1.5:20128/v1"
        K.set_base_url("ninerouter", "")
        assert L.get_provider("ninerouter").base_url == "http://localhost:20128/v1"
        try:
            K.set_base_url("ninerouter", "localhost:1")
            assert False
        except ValueError:
            pass
        os.environ.pop("NINEROUTER_BASE_URL", None)


def test_cloudflare_address_needs_the_account_id():
    assert "ACCOUNT_ID" in PP.base_url("cloudflare", {})
    assert "/accounts/abc123/" in PP.base_url("cloudflare", {"CLOUDFLARE_ACCOUNT_ID": "abc123"})


def test_custom_provider_add_use_model_and_delete():
    with tempfile.TemporaryDirectory() as t:
        _fresh(t)
        r = K.custom_set("My Gateway", "https://llm.example.com/v1/", "sk-secret-9999", "gpt-x")
        assert r["name"] == "x_my_gateway"
        lst = K.custom_list()
        assert lst[0]["base_url"] == "https://llm.example.com/v1" and lst[0]["hint"] == "…9999" and "key" not in lst[0]
        assert "x_my_gateway" in [p.name for p in L.all_available()]
        p = L.get_provider("x_my_gateway")
        assert p.base_url == "https://llm.example.com/v1" and p.model == "gpt-x" and L.is_known_provider("x_my_gateway")
        assert K.custom_set_model("x_my_gateway", "gpt-y") and L.provider_model("x_my_gateway") == "gpt-y"
        K.custom_set("My Gateway", "https://llm.example.com/v1", "", "")          # update without retyping the key keeps it
        assert K.custom_entries()[0]["key"] == "sk-secret-9999" and K.custom_entries()[0]["model"] == "gpt-y"
        assert K.custom_delete("x_my_gateway") and not L.is_known_provider("x_my_gateway")
        for bad in ("", "x"):
            try:
                K.custom_set(bad or "A", "nope" if bad == "x" else "ftp://z", "", ""); assert False
            except ValueError:
                pass


def test_models_fall_back_to_the_known_list_without_a_key():
    with tempfile.TemporaryDirectory() as t:
        _fresh(t)
        assert "llama-3.3-70b" in L.list_models("cerebras")
        assert PP.catalog({"cerebras": {"set": True}})[[p["name"] for p in PP.catalog()].index("cerebras")]["set"] is True
