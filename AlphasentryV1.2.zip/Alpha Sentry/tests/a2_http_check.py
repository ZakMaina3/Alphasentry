"""A2: HTTP-level check of the harness task endpoints (FastAPI + pydantic for real). Needs only the app's own requirements.

    python tests/a2_http_check.py

Uses a throwaway data folder (your real ACE data is never touched), mounts ONLY the harness_engine router, never starts the
engine and never calls BRAIN. It exercises create / preview / list / detail / pause / resume / stop / remove, the 404 / 409 / 422
paths, one scheduler pass (points get queued, nothing is simulated) and confirms no route can submit an alpha.
Prints PASS/FAIL per check and exits non-zero on any failure; paste the output back if something fails.
"""
import json
import os
import sys
import tempfile
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix="ace_a2_")
os.environ["ACE_DATA_DIR"] = TMP                       # must be set before the app's settings are read
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "backend"))

from fastapi import FastAPI                              # noqa: E402
from fastapi.testclient import TestClient               # noqa: E402

from app.core.config import get_settings                # noqa: E402
from app.harness.store import Store, ensure_tables, set_default_store   # noqa: E402
from tests.ace_db import DATASETS, FIELDS, SIM_RESULTS  # noqa: E402

TPL = ("name: window search\nexpr: ts_mean(close, $w)\nvars: {w: {type: int, grid: [5, 10, 20, 40, 60]}}\n"
       "settings: {decay: [0, 4]}\nconstraints: {max_simulations: 50}")
BASE = {"region": "USA", "delay": 1, "universe": "TOP3000"}
fails = 0


def check(name, cond, extra=""):
    global fails
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else f"   {extra}"))
    fails += 0 if cond else 1


def main() -> int:
    assert Path(get_settings().data_dir) == Path(TMP), f"ACE_DATA_DIR not honoured: {get_settings().data_dir}"
    store = Store(get_settings().db_path)
    with store.connect() as c:
        for ddl in (SIM_RESULTS, DATASETS, FIELDS):
            c.execute(ddl)
    ensure_tables(store)
    set_default_store(store)

    from app.modules import harness_engine as H
    app = FastAPI()
    app.include_router(H.router, prefix=H.PREFIX)
    cl = TestClient(app)
    u = H.PREFIX

    r = cl.get(f"{u}/optimizers")
    check("GET /optimizers 200 with samplers + objectives", r.status_code == 200 and r.json().get("samplers") and r.json().get("objectives"), r.text[:200])

    r = cl.get(f"{u}/templates/presets")
    check("GET /templates/presets 200 with 5+ presets", r.status_code == 200 and len(r.json().get("presets", [])) >= 5, r.text[:200])

    r = cl.post(f"{u}/tasks", json={**BASE, "template": TPL})
    check("POST /tasks with the flag off -> 409 and a readable detail", r.status_code == 409 and "flag" in str(r.json().get("detail")), f"{r.status_code} {r.text[:200]}")

    r = cl.post(f"{u}/flags", json={"name": "harness_engine", "value": True})
    check("POST /flags turns harness_engine on", r.status_code == 200, f"{r.status_code} {r.text[:200]}")

    r = cl.post(f"{u}/templates/preview", json={**BASE, "template": "name: x\nexpr: [unclosed"})
    check("preview of a broken template -> 422 with a string detail", r.status_code == 422 and isinstance(r.json().get("detail"), str), f"{r.status_code} {r.text[:200]}")
    r = cl.post(f"{u}/templates/preview", json={"template": TPL})
    check("preview without a region -> 422 (pydantic validation)", r.status_code == 422, f"{r.status_code} {r.text[:200]}")
    r = cl.post(f"{u}/templates/preview", json={**BASE, "template": TPL})
    j = r.json() if r.status_code == 200 else {}
    check("preview of a good template: finite grid, 3 samples", r.status_code == 200 and (j.get("gridSize") or 0) >= 5 and len(j.get("sample", [])) == 3,
          f"{r.status_code} {r.text[:300]}")

    r = cl.post(f"{u}/tasks", json={**BASE, "template": TPL, "objectives": ["nope"]})
    check("unknown objective -> 422", r.status_code == 422, f"{r.status_code} {r.text[:200]}")
    r = cl.post(f"{u}/tasks", json={**BASE, "template": TPL, "sampler": "random", "objectives": ["sharpe"], "budget": 6, "batch": 3, "cores": 1, "seed": 1})
    tid = r.json().get("id") if r.status_code == 200 else None
    check("POST /tasks (no params given) -> 200 with an id", bool(tid), f"{r.status_code} {r.text[:300]}")
    if not tid:
        return 1

    r = cl.get(f"{u}/tasks")
    check("GET /tasks lists it as running", r.status_code == 200 and [t["status"] for t in r.json()["tasks"] if t["id"] == tid] == ["running"], r.text[:200])
    r = cl.get(f"{u}/tasks/{tid}")
    check("GET /tasks/{id} detail has best / pareto / recent / space", r.status_code == 200 and all(k in r.json() for k in ("best", "pareto", "recent", "space", "counts")), r.text[:200])
    check("GET unknown task -> 404", cl.get(f"{u}/tasks/99999").status_code == 404)

    ticked = H._get_runner().tick()
    queued = store.query("SELECT COUNT(*) AS n FROM harness_sim_record")[0]["n"]
    check("one scheduler pass queues 3 points and simulates nothing", ticked.get(tid) == 3 and queued == 3, f"ticked={ticked} queued={queued}")
    d = cl.get(f"{u}/tasks/{tid}").json()
    check("detail then shows 3 queued trials", d["counts"].get("queued") == 3 and len(d["recent"]) == 3, json.dumps(d["counts"]))

    r = cl.post(f"{u}/tasks/{tid}/pause")
    check("pause -> 200 paused", r.status_code == 200 and r.json()["status"] == "paused", f"{r.status_code} {r.text[:200]}")
    check("pause again -> 409", cl.post(f"{u}/tasks/{tid}/pause").status_code == 409)
    r = cl.post(f"{u}/tasks/{tid}/resume")
    check("resume -> 200 running", r.status_code == 200 and r.json()["status"] == "running", f"{r.status_code} {r.text[:200]}")
    check("resume a running task -> 409", cl.post(f"{u}/tasks/{tid}/resume").status_code == 409)
    r = cl.post(f"{u}/tasks/{tid}/stop")
    check("stop -> 200 stopped", r.status_code == 200 and r.json()["status"] == "stopped", f"{r.status_code} {r.text[:200]}")
    check("resume a stopped task -> 409", cl.post(f"{u}/tasks/{tid}/resume").status_code == 409)
    left = store.query("SELECT COUNT(*) AS n FROM harness_trial WHERE task_id=? AND status='queued'", (tid,))[0]["n"]
    check("stop leaves no queued trials", left == 0, str(left))
    r = cl.delete(f"{u}/tasks/{tid}")
    check("DELETE -> 200", r.status_code == 200, f"{r.status_code} {r.text[:200]}")
    check("then GET -> 404", cl.get(f"{u}/tasks/{tid}").status_code == 404)

    # ── fragment B routes ──
    GRID = "name: g\nexpr: ts_mean(close, $w)\nvars: {w: {type: int, grid: [5, 10, 20]}}\nsettings: {decay: [0, 4]}"
    r = cl.post(f"{u}/template/preview", json={**BASE, "template": GRID})
    check("sweep preview: grid 6 fits", r.status_code == 200 and (r.json().get("sweep") or {}).get("gridSize") == 6, r.text[:200])
    r = cl.post(f"{u}/template/preview", json={**BASE, "template": "name: n\nexpr: ts_mean(close, $w)\nvars: {w: {type: float, low: 1.0, high: 5.0}}"})
    check("sweep preview of a continuous template explains itself (200, sweepError)", r.status_code == 200 and "step" in str(r.json().get("sweepError")), r.text[:200])
    r = cl.post(f"{u}/template/run", json={**BASE, "template": GRID, "batch": 3})
    sid = r.json().get("id") if r.status_code == 200 else None
    check("sweep run creates a task with budget 6", r.status_code == 200 and r.json().get("budget") == 6, f"{r.status_code} {r.text[:200]}")
    check("sweep run of a template that never varies -> 422", cl.post(f"{u}/template/run", json={**BASE, "template": "name: n\nexpr: rank(close)"}).status_code == 422)
    r = cl.get(f"{u}/tasks/{sid}/power_pool")
    check("power pool view -> 200 with limits", r.status_code == 200 and r.json().get("limits", {}).get("maxOperators") == 8, r.text[:200])
    check("power pool view of a missing task -> 404", cl.get(f"{u}/tasks/99999/power_pool").status_code == 404)
    r = cl.post(f"{u}/templates/recommend", json={**BASE, "template": GRID, "objectives": ["sharpe"], "budget": 50})
    check("sampler recommendation names a sampler and a reason", r.status_code == 200 and r.json().get("sampler") and r.json().get("why"), r.text[:200])
    r = cl.post(f"{u}/saved", json={"name": "s1", "template": GRID, "objectives": ["sharpe"], "region": "USA"})
    sv = r.json().get("id") if r.status_code == 200 else None
    check("saved search: save, list, delete, 404", r.status_code == 200 and len(cl.get(f"{u}/saved").json()["saved"]) == 1 and cl.delete(f"{u}/saved/{sv}").status_code == 200
          and cl.delete(f"{u}/saved/{sv}").status_code == 404, r.text[:200])
    check("saved search with no name -> 422", cl.post(f"{u}/saved", json={"name": "", "template": GRID}).status_code == 422)
    r = cl.post(f"{u}/deepen/preview", json={**BASE, "expression": "rank(ts_zscore(close, 22))"})
    j = r.json() if r.status_code == 200 else {}
    check("deepen preview: original is in the space", r.status_code == 200 and j.get("originExpression") == "rank(ts_zscore(close, 22))" and j.get("size", 0) > 1, r.text[:300])
    check("deepen preview with nothing to go on -> 422", cl.post(f"{u}/deepen/preview", json=BASE).status_code == 422)
    check("deepen run -> 200", cl.post(f"{u}/deepen/run", json={**BASE, "expression": "rank(ts_zscore(close, 22))"}).status_code == 200)
    r = cl.post(f"{u}/evolution/preview", json={**BASE, "expressions": ["rank(ts_zscore(close, 22))", "rank(ts_delta(volume, 5))"]})
    check("evolution preview: 2 seeds and sample offspring", r.status_code == 200 and len(r.json().get("seeds", [])) == 2 and r.json().get("offspring"), r.text[:300])
    r = cl.post(f"{u}/evolution/run", json={**BASE, "expressions": ["rank(ts_zscore(close, 22))"], "budget": 20, "population": 4, "offspring": 4, "objectives": ["sharpe"]})
    eid = r.json().get("id") if r.status_code == 200 else None
    check("evolution run -> 200", r.status_code == 200, f"{r.status_code} {r.text[:200]}")
    check("evolution run with no usable seeds -> 422", cl.post(f"{u}/evolution/run", json={**BASE, "expressions": ["rank("]}).status_code == 422)
    d = cl.get(f"{u}/tasks/{eid}").json() if eid else {}
    check("evolution task detail has a generations list and sampler ga", "generations" in d and d.get("sampler") == "ga", json.dumps(d)[:200])
    check("tasks list shows the lab of every task", all("lab" in t for t in cl.get(f"{u}/tasks").json()["tasks"]))

    # ── fragment C routes (no LLM is ever called here: the llm flag stays off) ──
    r = cl.get(f"{u}/llm/status")
    check("llm status 200 with a budget block", r.status_code == 200 and "budget" in r.json() and "available" in r.json(), r.text[:200])
    r = cl.post(f"{u}/llm/budget", json={"max_calls_per_day": 7})
    check("llm budget saves a cap", r.status_code == 200 and r.json()["config"]["max_calls_per_day"] == 7, r.text[:200])
    check("llm budget rejects a negative cap -> 422", cl.post(f"{u}/llm/budget", json={"max_calls_per_day": -1}).status_code == 422)
    check("llm usage 200", cl.get(f"{u}/llm/usage").status_code == 200)
    r = cl.post(f"{u}/invent/propose", json={**BASE})
    check("invent propose with the llm flag off -> 409 naming the flag, no call made", r.status_code == 409 and "harness_llm" in str(r.json().get("detail")), r.text[:200])
    r = cl.post(f"{u}/invent/run", json={**BASE, "template": '{"name": "n", "expr": "rank(ghost)"}'})
    check("invent run of a template with no variation -> 422 with reasons", r.status_code == 422, r.text[:200])
    r = cl.post(f"{u}/invent/run", json={**BASE, "template": GRID, "sampler": "random", "objectives": ["sharpe"], "budget": 4, "batch": 2})
    check("invent run of a valid template -> 200 and a task", r.status_code == 200 and r.json().get("id"), r.text[:200])

    # ── fragment D5 planning routes (read-only; /plan/run is only probed for its refusals, nothing is queued) ──
    r = cl.post(f"{u}/plan/overview", json=BASE)
    j = r.json() if r.status_code == 200 else {}
    check("plan overview: settings, plan, readiness, yields, trend, advice, history, flags", r.status_code == 200 and all(k in j for k in
          ("settings", "spent", "counts", "readiness", "plan", "yields", "trend", "advice", "history", "flags")) and len(j["trend"]["days"]) == 14, r.text[:300])
    check("plan overview queues nothing", cl.get(f"{u}/status").status_code == 200)
    r = cl.post(f"{u}/plan/settings", json={"daily_budget": 250})
    check("plan settings save", r.status_code == 200 and r.json()["settings"]["daily_budget"] == 250, r.text[:200])
    check("plan settings reject bad labs and shares -> 422", cl.post(f"{u}/plan/settings", json={"labs": ["nope"]}).status_code == 422
          and cl.post(f"{u}/plan/settings", json={"explore_fraction": 2}).status_code == 422)
    check("plan settings read back", cl.get(f"{u}/plan/settings").json()["settings"]["daily_budget"] == 250)
    r = cl.post(f"{u}/plan/advice", json=BASE)
    check("plan advice (no model) returns items and no narration", r.status_code == 200 and isinstance(r.json().get("items"), list) and r.json().get("narration") is None, r.text[:200])
    r = cl.post(f"{u}/plan/pm", json={**BASE, "use_llm": False})
    check("plan pm without a model returns the ordinary plan (fromPM false)", r.status_code == 200 and r.json().get("fromPM") is False and "briefing" in r.json(), r.text[:300])
    check("plan trend + history 200", cl.get(f"{u}/plan/trend?days=7").status_code == 200 and cl.get(f"{u}/plan/history").status_code == 200)
    check("plan run with a lab outside the plan is refused (409 flag off / 422)", cl.post(f"{u}/plan/run", json={**BASE, "labs": ["nope"]}).status_code in (409, 422))

    # ── fragment E2 winner tag settings (left OFF afterwards) ──
    r = cl.post(f"{u}/winner", json={"winner_tag": "a2-check", "winner_color": "BLUE", "tag_winners_above": 1.1})
    check("winner settings save and read back", r.status_code == 200 and cl.get(f"{u}/winner").json()["settings"]["winner_color"] == "BLUE", r.text[:200])
    check("winner settings reject a bad tag / colour -> 422", cl.post(f"{u}/winner", json={"winner_tag": "bad/tag"}).status_code == 422
          and cl.post(f"{u}/winner", json={"winner_color": "PINK"}).status_code == 422)
    check("winner tagging switched back off", cl.post(f"{u}/winner", json={"winner_tag": ""}).json()["settings"]["winner_tag"] == "")

    paths = [getattr(x, "path", "") for x in app.routes]
    check("no route can submit an alpha", not [p for p in paths if "submit" in p.lower()], str(paths))
    print(f"\n{'ALL PASSED' if not fails else str(fails) + ' FAILED'}   (throwaway data in {TMP})")
    return 1 if fails else 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:  # noqa: BLE001
        traceback.print_exc()
        sys.exit(2)
