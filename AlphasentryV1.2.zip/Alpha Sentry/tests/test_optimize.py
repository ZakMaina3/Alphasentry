"""Optimizer tests. The same contract runs against every available backend: the built-in one always, and the Optuna
adapter automatically on any machine where Optuna is installed (it is skipped, silently, where it is not)."""
import math
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.harness import optimize as O
from app.harness.optimize import optuna_backend
from app.harness.optimize import space as sp
from app.harness.optimize.builtin import BuiltinOptimizer, pareto_front

MIXED = {"w": {"kind": "int", "low": 5, "high": 250, "step": 5}, "t": {"kind": "float", "low": 0.01, "high": 0.2, "log": True},
         "d": {"kind": "float", "low": 0.0, "high": 1.0, "step": 0.25}, "f": {"kind": "categorical", "choices": ["a", "b", "c", "d"]}}
XY = {"x": {"kind": "float", "low": 0.0, "high": 1.0}, "y": {"kind": "float", "low": 0.0, "high": 1.0}}


def backends():
    return ["builtin"] + (["optuna"] if optuna_backend.available() else [])


def make(sampler, space, dirs=None, **kw):
    be = kw.pop("backend", "builtin")
    return O.make_optimizer(sampler, space, dirs, backend=be, **kw)


def run(opt, f, rounds, batch=10, constraint=None, two=False):
    """Drive an optimizer with objective f(params)->value(s); returns every (params, values, feasible)."""
    out = []
    for _ in range(rounds):
        for h, p in opt.ask(batch):
            v = f(p)
            c = constraint(p) if constraint else None
            opt.tell(h, v if isinstance(v, list) else [v], constraint=({"C": c} if c is not None else None))
            out.append((p, v, c is None or c <= 0))
    return out


# ── space helpers ──────────────────────────────────────────────────────────────────────────────
def test_space_validation_and_mapping():
    for bad in ({}, {"a": {"kind": "x"}}, {"a": {"kind": "categorical", "choices": []}}, {"a": {"kind": "int", "low": 5, "high": 1}},
                {"a": {"kind": "float", "low": -1, "high": 1, "log": True}}, {"a": {"kind": "int", "low": 1, "high": 5, "step": 0}},
                {"a": {"kind": "float", "low": 1, "high": 5, "step": 1, "log": True}}):
        try:
            sp.check_space(bad)
            assert False, bad
        except sp.SpaceError:
            pass
    sp.check_space(MIXED)
    assert sp.from_unit(MIXED["w"], 0.0) == 5 and sp.from_unit(MIXED["w"], 1.0) == 250 and sp.from_unit(MIXED["w"], 0.5) % 5 == 0
    assert sp.from_unit(MIXED["d"], 0.6) in (0.5, 0.75) and sp.from_unit(MIXED["f"], 0.99) == "d" and sp.from_unit(MIXED["f"], 0.0) == "a"
    assert abs(sp.from_unit(MIXED["t"], 0.0) - 0.01) < 1e-9 and abs(sp.from_unit(MIXED["t"], 1.0) - 0.2) < 1e-9
    assert abs(sp.to_unit(MIXED["t"], sp.from_unit(MIXED["t"], 0.37)) - 0.37) < 1e-6
    assert sp.grid_values(MIXED["d"]) == [0.0, 0.25, 0.5, 0.75, 1.0] and sp.grid_values(MIXED["t"]) is None
    assert sp.grid_size({"a": MIXED["f"], "b": MIXED["d"]}) == 20 and sp.grid_size(MIXED) is None
    assert sp.in_space(MIXED, {"w": 10, "t": 0.05, "d": 0.5, "f": "a"}) and not sp.in_space(MIXED, {"w": 11, "t": 0.05, "d": 0.5, "f": "a"})
    assert not sp.in_space(MIXED, {"w": 10, "t": 0.05, "d": 0.5, "f": "z"}) and not sp.in_space(MIXED, {"w": 10})


# ── contract: every sampler, every backend ─────────────────────────────────────────────────────
def test_every_sampler_proposes_legal_unique_points():
    for be in backends():
        for name in ("random", "qmc", "nsga2", "nsga3", "tpe", "cmaes"):
            opt = make(name, MIXED, ["maximize"], backend=be, seed=3)
            seen = []
            for _ in range(5):                                   # tell between rounds so model-based samplers engage
                for h, p in opt.ask(10):
                    assert sp.in_space(MIXED, p), (be, name, p)
                    seen.append(sp.param_key(p))
                    opt.tell(h, [p["d"] + p["w"] / 250])
            assert len(seen) == 50, (be, name)
            if be == "builtin":
                assert len(set(seen)) == 50, (be, name)           # the built-in never repeats a point it can avoid


def test_brute_enumerates_the_grid_exactly_once():
    grid = {"a": {"kind": "categorical", "choices": [1, 2, 3]}, "b": {"kind": "int", "low": 0, "high": 3}}
    for be in backends():
        opt = make("brute", grid, ["maximize"], backend=be)
        pts = [p for _, p in opt.ask(100)]
        assert len(pts) == 12 and len({sp.param_key(p) for p in pts}) == 12, be
        assert opt.ask(5) == [], be                                # exhausted
    try:
        make("brute", {"x": {"kind": "float", "low": 0, "high": 1}})
        assert False
    except ValueError as e:
        assert "step" in str(e)


def test_qmc_covers_better_than_random():
    one = {"x": {"kind": "float", "low": 0.0, "high": 1.0}}
    xs = sorted(p["x"] for _, p in make("qmc", one, seed=1).ask(64))
    gap = max(b - a for a, b in zip([0.0] + xs, xs + [1.0]))
    assert gap < 0.06, gap                                        # Sobol + shift: no big holes (random typically leaves > 0.08)
    rx = sorted(p["x"] for _, p in make("random", one, seed=1).ask(64))
    assert gap <= max(b - a for a, b in zip([0.0] + rx, rx + [1.0]))


def test_model_based_samplers_actually_improve():
    f = lambda p: -((p["x"] - 0.3) ** 2 + (p["y"] - 0.7) ** 2)                       # noqa: E731  best at (0.3, 0.7)
    for name in ("nsga2", "tpe"):
        wins = 0
        for seed in (1, 2, 3):
            res = run(make(name, XY, ["maximize"], seed=seed), f, rounds=20)
            first, last = [v for _, v, _ in res[:30]], [v for _, v, _ in res[-30:]]
            wins += (sum(last) / 30) > (sum(first) / 30) + 0.05 and max(v for _, v, _ in res) > -0.01
        assert wins == 3, (name, wins)                                                # every seed converges toward the optimum
    # and they beat blind random search on the same budget
    rnd = [max(v for _, v, _ in run(make("random", XY, ["maximize"], seed=s), f, 20)) for s in (1, 2, 3)]
    tpe = [max(v for _, v, _ in run(make("tpe", XY, ["maximize"], seed=s), f, 20)) for s in (1, 2, 3)]
    assert sum(tpe) >= sum(rnd) - 1e-9


def test_multi_objective_finds_a_spread_front():
    sch = {"x": {"kind": "float", "low": -3.0, "high": 3.0}}
    f = lambda p: [p["x"] ** 2, (p["x"] - 2) ** 2]                                  # noqa: E731  Schaffer N.1: front is x in [0, 2]
    for name in ("nsga2", "tpe"):
        opt = make(name, sch, ["minimize", "minimize"], seed=5)
        run(opt, f, rounds=20)
        front = pareto_front(opt.trials, opt.directions)
        xs = sorted(t.params["x"] for t in front)
        assert xs[0] > -0.15 and xs[-1] < 2.15, (name, xs[0], xs[-1])               # on the true front
        assert xs[-1] - xs[0] > 1.2, (name, xs)                                      # and spread along it, not one point


def test_constraints_steer_toward_feasible_points():
    """Minimise x + y subject to x + y >= 1.2: the optimum sits ON the constraint boundary, so a good optimizer
    concentrates its samples around that boundary (about half of them just infeasible, by design) and finds a
    feasible point close to 1.2 — rather than wandering in the infeasible region or far inside the feasible one."""
    f = lambda p: p["x"] + p["y"]                                                    # noqa: E731
    viol = lambda p: 1.2 - (p["x"] + p["y"])                                         # noqa: E731
    for name in ("nsga2", "tpe"):
        res = run(make(name, XY, ["minimize"], seed=4), f, rounds=20, constraint=viol)
        d = lambda r: abs(r[0]["x"] + r[0]["y"] - 1.2)                               # noqa: E731
        near_first = sum(map(d, res[:40])) / 40
        near_last = sum(map(d, res[-40:])) / 40
        assert near_last < near_first * 0.6, (name, near_first, near_last)           # samples concentrate on the boundary
        assert sum(ok for _, _, ok in res[-40:]) >= 8, name                          # and plenty of them are feasible
        best = min((v for _, v, ok in res if ok), default=None)
        assert best is not None and best < 1.3, (name, best)                         # best feasible is close to the optimum 1.2


def test_replay_after_restart_and_bad_input():
    f = lambda p: -((p["x"] - 0.3) ** 2 + (p["y"] - 0.7) ** 2)                       # noqa: E731
    first = make("nsga2", XY, ["maximize"], seed=2, params={"population_size": 20})
    res = run(first, f, rounds=6)
    history = [{"params": p, "values": [v], "constraint": {}, "state": "COMPLETE"} for p, v, _ in res]
    history += [{"params": {"x": 0.5, "y": 0.5}, "values": None, "state": "FAIL"}, {"params": {"x": 0.9, "y": 0.9}, "values": None, "state": "PRUNED"}]
    again = make("nsga2", XY, ["maximize"], seed=9, params={"population_size": 20}, history=history)
    told = {sp.param_key(p) for p, _, _ in res}
    nxt = [p for _, p in again.ask(20)]
    assert not ({sp.param_key(p) for p in nxt} & told)                               # never re-proposes a told point
    assert sp.param_key({"x": 0.5, "y": 0.5}) not in {sp.param_key(p) for p in nxt}  # nor one that failed
    h, p = again.ask(1)[0]
    try:
        again.tell(h, [1.0, 2.0])
        assert False
    except ValueError as e:
        assert "Expected 1" in str(e)
    try:
        again.tell(None, [1.0])
        assert False
    except ValueError as e:
        assert "parameters" in str(e)
    again.tell(h, None)                                                              # a failed trial is accepted and ignored
    assert again.trials[h.number].state == "FAIL"


def test_fallbacks_and_errors_are_stated_not_silent():
    o = make("nsga3", XY, ["maximize", "minimize"], seed=1)
    assert o.effective == "nsga3" and any("NSGA-III" in n and "niching" in n for n in o.notes)
    o = make("cmaes", XY, ["maximize"], seed=1)
    assert o.effective == "cmaes" and any("CMA-ES" in n and "separable" in n for n in o.notes)
    for bad, msg in (("cmaes", "single number"), ("nonsense", "not a sampler")):
        try:
            make(bad, XY, ["maximize", "minimize"] if bad == "cmaes" else ["maximize"])
            assert False
        except ValueError as e:
            assert msg in str(e)
    assert {c["name"] for c in O.catalogue()} == set(O.SAMPLERS) == {"nsga2", "nsga3", "tpe", "cmaes", "qmc", "random", "brute"}


def test_factory_backend_selection(monkeypatch):
    assert make("random", XY, backend="builtin").backend == "builtin"
    if not optuna_backend.available():
        try:
            O.make_optimizer("random", XY, backend="optuna")
            assert False
        except RuntimeError as e:
            assert "not installed" in str(e)
        assert O.default_backend() == "builtin"
    prev = os.environ.get("ACE_HARNESS_OPTIMIZER")
    os.environ["ACE_HARNESS_OPTIMIZER"] = "builtin"
    try:
        assert O.default_backend() == "builtin" and O.make_optimizer("random", XY).backend == "builtin"
    finally:
        os.environ.pop("ACE_HARNESS_OPTIMIZER", None)
        if prev is not None:
            os.environ["ACE_HARNESS_OPTIMIZER"] = prev


def test_seeded_runs_are_reproducible():
    a = [p for _, p in make("nsga2", MIXED, ["maximize"], seed=11).ask(10)]
    b = [p for _, p in make("nsga2", MIXED, ["maximize"], seed=11).ask(10)]
    c = [p for _, p in make("nsga2", MIXED, ["maximize"], seed=12).ask(10)]
    assert a == b and a != c


def test_finite_spaces_are_exhausted_without_repeats():
    grid = {"a": {"kind": "categorical", "choices": list("abcd")}, "b": {"kind": "int", "low": 1, "high": 6}}          # 24 points
    for name in ("random", "qmc", "nsga2", "tpe"):
        opt = make(name, grid, ["maximize"], seed=2, params={"n_startup_trials": 6, "population_size": 10})
        seen = []
        for _ in range(12):
            got = opt.ask(5)
            for h, p in got:
                seen.append(sp.param_key(p))
                opt.tell(h, [hash(sp.param_key(p)) % 7 / 7.0])
        assert len(seen) == 24 and len(set(seen)) == 24, (name, len(seen), len(set(seen)))                           # every point once
        assert opt.ask(5) == [], name                                                                                  # then exhausted


# ── E5: Sobol, NSGA-III, CMA-ES built in ───────────────────────────────────────────────────────
def test_sobol_direction_numbers_are_valid_and_points_stratified():
    from app.harness.optimize import sobol
    for s_, a, m in sobol.JOE_KUO:                               # a must encode a PRIMITIVE polynomial of degree s; m_i odd and < 2^i
        poly = (1 << s_) | (a << 1) | 1
        x, order = 1, 0
        while True:                                              # multiplicative order of x modulo poly over GF(2)
            x <<= 1
            if x >> s_ & 1:
                x ^= poly
            order += 1
            if x == 1:
                break
            assert order <= 2 ** s_
        assert order == 2 ** s_ - 1, (s_, a, order)
        assert len(m) == s_ and all(v % 2 == 1 and v < 2 ** (i + 1) for i, v in enumerate(m))
    import random as _r
    g = sobol.Sobol(sobol.MAX_DIM, _r.Random(3))
    pts = [g.next() for _ in range(64)]
    for d in range(sobol.MAX_DIM):                               # first 2^k points hit each of 2^k equal intervals exactly once
        assert sorted(int(p[d] * 64) for p in pts) == list(range(64)), d
    assert all(0.0 <= v < 1.0 for p in pts for v in p)
    unshifted = sobol.Sobol(2)
    assert [unshifted.next() for _ in range(4)] == [[0.0, 0.0], [0.5, 0.5], [0.75, 0.25], [0.25, 0.75]]    # the textbook start


def test_sobol_beats_random_in_two_dimensions():
    g = make("qmc", XY, seed=2).ask(64)
    cells = {(int(p["x"] * 8), int(p["y"] * 8)) for _, p in g}
    r = {(int(p["x"] * 8), int(p["y"] * 8)) for _, p in make("random", XY, seed=2).ask(64)}
    assert len(cells) == 64 and len(cells) > len(r)               # a (0,6,2)-net fills all 64 cells of an 8x8 grid; random cannot
    wide = {f"p{i}": {"kind": "float", "low": 0.0, "high": 1.0} for i in range(20)}
    pts = make("qmc", wide, seed=1).ask(8)
    assert len(pts) == 8 and any("first 14" in n for n in make("qmc", wide, seed=1).notes)         # >14 dims: stated, still works


def test_nsga3_spreads_over_three_objectives_and_is_restart_safe():
    from app.harness.optimize import niching
    refs = niching.reference_points(3, 4)
    assert len(refs) == 15 and all(abs(sum(r) - 1) < 1e-9 for r in refs)                              # C(4+2, 2)
    sp3 = {k: {"kind": "float", "low": 0.0, "high": 1.0} for k in "xy"}
    f = lambda p: [p["x"], p["y"], (1 - p["x"]) * (1 - p["y"])]                                    # noqa: E731  three minimised trade-offs
    opt = make("nsga3", sp3, ["minimize"] * 3, seed=3)
    run(opt, f, rounds=20)
    front = pareto_front(opt.trials, opt.directions)
    assert len(front) >= 10
    hist = [{"params": t.params, "values": t.values, "constraint": t.constraint, "state": t.state} for t in opt.trials]
    a = make("nsga3", sp3, ["minimize"] * 3, seed=9, history=hist).ask(5)
    b = make("nsga3", sp3, ["minimize"] * 3, seed=9, history=hist).ask(5)
    assert [p for _, p in a] == [p for _, p in b]


def test_cmaes_converges_handles_categoricals_and_replays_exactly():
    f = lambda p: -((p["x"] - 0.3) ** 2 + (p["y"] - 0.7) ** 2)                                      # noqa: E731
    for seed in (1, 2, 3):
        res = run(make("cmaes", XY, ["maximize"], seed=seed), f, rounds=15)
        first, last = [v for _, v, _ in res[:20]], [v for _, v, _ in res[-20:]]
        assert sum(last) / 20 > sum(first) / 20 + 0.05 and max(v for _, v, _ in res) > -0.005, seed
    opt = make("cmaes", MIXED, ["maximize"], seed=4)
    g = lambda p: -abs(p["w"] - 100) / 100 + (0.5 if p["f"] == "c" else 0)                           # noqa: E731
    res = run(opt, g, rounds=12)
    assert all(sp.in_space(MIXED, p) for p, _, _ in res)
    assert sum(p["f"] == "c" for p, _, _ in res[-30:]) > 15                                             # categorical settled on the better value
    hist = [{"params": t.params, "values": t.values, "constraint": t.constraint, "state": t.state} for t in opt.trials]
    rebuilt = make("cmaes", MIXED, ["maximize"], seed=4, history=hist)
    rebuilt._prepare(); opt._prepare()
    assert rebuilt._cma == opt._cma                                                                     # state is a pure function of the trials
    c = make("cmaes", XY, ["maximize"], seed=1)
    res = run(c, lambda p: p["x"], rounds=4, constraint=lambda p: 0.5 - p["y"])                          # constraint steers: feasible ranks first
    assert c._ordered and violation_of(c._ordered[0]) <= violation_of(c._ordered[-1])


def violation_of(t):
    from app.harness.optimize.builtin import violation
    return violation(t.constraint)
