"""Runs the harness_engine module's endpoint FUNCTIONS (the new B1–B5 ones) against a throwaway ACE-shaped database, with tiny stand-ins
for FastAPI / pydantic / app.core.jobs when the real ones are not installed. It checks the code behind the routes (names, wiring,
data shapes, 404/422 paths); it cannot check HTTP itself — run `python tests/a2_http_check.py` in a real environment for that."""
import copy
import importlib
import importlib.util
import sys
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.ace_db import ace_db, add_alpha, add_dataset, add_field

REAL = importlib.util.find_spec("fastapi") is not None and importlib.util.find_spec("pydantic") is not None
GRID = "name: g\nexpr: ts_mean(close, $w)\nvars: {w: {type: int, grid: [5, 10, 20, 40, 60]}}\nsettings: {decay: [0, 4]}\n"


class _HTTPException(Exception):
    def __init__(self, status_code, detail=""):
        super().__init__(detail)
        self.status_code, self.detail = status_code, detail


class _Router:
    def _deco(self, *a, **k):
        return lambda fn: fn
    get = post = delete = put = _deco


class _Base:
    def __init__(self, **kw):
        names = {}
        for klass in reversed(type(self).__mro__):
            names.update(getattr(klass, "__annotations__", {}))
        for n in names:
            if n in kw:
                setattr(self, n, kw[n])
            elif hasattr(type(self), n):
                setattr(self, n, copy.deepcopy(getattr(type(self), n)))
            else:
                raise TypeError(f"missing field {n}")


def _install():
    saved = {k: sys.modules.get(k) for k in ("fastapi", "pydantic", "app.core.jobs")}
    sys.modules["fastapi"] = types.SimpleNamespace(APIRouter=_Router, HTTPException=_HTTPException)
    sys.modules["pydantic"] = types.SimpleNamespace(BaseModel=_Base)
    sys.modules["app.core.jobs"] = types.SimpleNamespace(jobs=None)
    for k in [k for k in sys.modules if k.startswith(("app.modules.harness_engine", "app.harness.api_common"))]:
        del sys.modules[k]
    return saved


def _restore(saved):
    for k, v in saved.items():
        if v is None:
            sys.modules.pop(k, None)
        else:
            sys.modules[k] = v
    for k in [k for k in sys.modules if k.startswith(("app.modules.harness_engine", "app.harness.api_common"))]:
        del sys.modules[k]


def _raises(fn, status):
    try:
        fn()
    except _HTTPException as e:
        assert e.status_code == status, (e.status_code, e.detail)
        return str(e.detail)
    raise AssertionError(f"expected HTTP {status}")


def test_new_endpoint_functions_run_against_a_real_database(tmp_path, monkeypatch):
    if REAL:
        return                                    # the real stack is installed: tests/a2_http_check.py covers the routes properly
    saved = _install()
    try:
        from app.harness import flags
        from app.harness.engine.tracker import Tracker
        from app.harness.store import default_store
        m = importlib.import_module("app.modules.harness_engine")
        with ace_db(tmp_path) as s:
            monkeypatch.setattr(flags, "enabled", lambda name: True)
            monkeypatch.setattr(m, "_tracker", lambda: Tracker(default_store(), tmp_path / "j.jsonl"))
            from app.harness.engine.focus import Focus
            monkeypatch.setattr(m, "_focus", lambda: Focus(tmp_path / "focus.json"))
            m._engine = m._runner_inst = None
            add_dataset(s, "fund")
            for f in ("close", "volume", "open", "vwap"):
                add_field(s, f, "fund")
            add_alpha(s, "A1", "rank(ts_zscore(close, 22))", 1.6, neut="INDUSTRY")
            add_alpha(s, "A2", "rank(ts_mean(volume, 10)) - rank(ts_delta(open, 5))", 1.2)
            base = {"region": "USA", "delay": 1, "universe": "TOP3000"}

            # B1 sweep
            pv = m.sweep_preview(m.SweepReq(template=GRID, **base))
            assert pv["sweep"]["gridSize"] == 10 and pv["sweep"]["fits"] and pv["sweepError"] is None
            bad = m.sweep_preview(m.SweepReq(template="name: n\nexpr: ts_mean(close, $w)\nvars: {w: {type: float, low: 1.0, high: 5.0}}", **base))
            assert bad["sweep"] is None and "step" in bad["sweepError"]
            run = m.sweep_run(m.SweepReq(template=GRID, name="grid", **base))
            assert run["budget"] == 10 and run["sweep"]["gridSize"] == 10 and m.task_list()["tasks"][0]["lab"] == "template"
            _raises(lambda: m.sweep_run(m.SweepReq(template="name: n\nexpr: rank(close)", **base)), 422)
            _raises(lambda: m.sweep_run(m.SweepReq(template="", **base)), 422)

            # B2 power pool view
            v = m.task_power_pool(run["id"])
            assert v["qualifying"] == [] and v["limits"]["maxOperators"] == 8
            _raises(lambda: m.task_power_pool(999), 404)

            # B5 advice + saved
            rec = m.template_recommend(m.RecommendReq(template=GRID, objectives=["sharpe"], budget=50, **base))
            assert rec["sampler"] == "brute" and rec["why"]
            sv = m.saved_save(m.SavedReq(name="mine", template=GRID, sampler="tpe", objectives=["sharpe"], budget=30, region="USA"))
            assert sv["scope"]["region"] == "USA" and [x["name"] for x in m.saved_list()["saved"]] == ["mine"]
            _raises(lambda: m.saved_save(m.SavedReq(name="", template=GRID)), 422)
            assert m.saved_delete(sv["id"]) == {"removed": sv["id"]}
            _raises(lambda: m.saved_delete(sv["id"]), 404)

            # B3 deepen (by alpha id: takes its expression and neutralization from Results)
            dp = m.deepen_preview(m.DeepenReq(alpha_id="A1", **base))
            assert dp["originExpression"] == "rank(ts_zscore(close, 22))" and dp["template"]["settings"]["neutralization"] == "INDUSTRY"
            assert dp["size"] <= 200 and "expr:" in dp["yaml"] and dp["sample"] and dp["summary"]["gridSize"] == dp["size"]
            dr = m.deepen_run(m.DeepenReq(alpha_id="A1", **base))
            assert dr["size"] == dp["size"] and any(t["lab"] == "deepen" for t in m.task_list()["tasks"])
            _raises(lambda: m.deepen_preview(m.DeepenReq(alpha_id="NOPE", **base)), 404)
            _raises(lambda: m.deepen_preview(m.DeepenReq(**base)), 422)
            _raises(lambda: m.deepen_preview(m.DeepenReq(expression="a = rank(close)", **base)), 422)

            # B4 evolution (seeds default to the strongest alphas in the market)
            ep = m.evolution_preview(m.EvolutionReq(**base))
            assert len(ep["seeds"]) == 2 and ep["fields"] >= 4 and ep["offspring"] and ep["operatorsKnown"] is False
            er = m.evolution_run(m.EvolutionReq(budget=40, population=6, offspring=6, seed=3, objectives=["sharpe"], **base))
            assert er["seeds"] == 2 and any(t["lab"] == "evolution" for t in m.task_list()["tasks"])
            empty = m.evolution_preview(m.EvolutionReq(min_sharpe=9.0, **base))
            assert empty["seeds"] == [] and empty["notes"]
            _raises(lambda: m.evolution_run(m.EvolutionReq(min_sharpe=9.0, **base)), 422)
            _raises(lambda: m.evolution_run(m.EvolutionReq(expressions=["rank(close)"], population=1, **base)), 422)
            _raises(lambda: m.evolution_run(m.EvolutionReq(expressions=["rank(a) + rank(b) + rank(c) + rank(d)"], power_pool=True, **base)), 422)

            # C: LLM status / budget / Invent (a fake model; nothing leaves the machine)
            import json as _json
            from app.harness import llm as LL
            from app.harness.llm_budget import Budget

            class _Res:
                def __init__(self, items):
                    self.expressions, self.provider, self.model = items, "fake", "m"

            class _Fake:
                def __init__(self, items):
                    self.items, self.calls = items, 0

                def generate_list(self, prompt, n=None):
                    self.calls += 1
                    return _Res(self.items)
            good = {"name": "rev", "description": "d", "expr": "rank(-ts_zscore($f, $w))",
                    "vars": {"f": {"type": "datafield", "values": ["close", "volume"]}, "w": {"type": "int", "grid": [22, 63]}}}
            fake = _Fake([_json.dumps(good), _json.dumps({**good, "name": "bad", "expr": "rank($f, $w) + rank(ghost)"}), "prose"])
            llm = LL.LLM(s, provider=lambda: fake, budget=Budget(s, tmp_path / "llm.json"), status=lambda: {"available": ["fake"], "preferred": "fake", "used": ["fake"]})
            monkeypatch.setattr(LL, "default_llm", lambda: llm)
            assert m.llm_status()["available"] == ["fake"] and m.llm_status()["budget"]["today"]["calls"] == 0
            assert m.llm_budget(m.LLMBudgetReq(max_calls_per_day=3))["config"]["max_calls_per_day"] == 3
            _raises(lambda: m.llm_budget(m.LLMBudgetReq(max_calls_per_day=-1)), 422)
            monkeypatch.setattr(flags, "enabled", lambda name: name != "harness_llm")
            assert "LLM labs" in _raises(lambda: m.invent_propose(m.InventReq(**base)), 409) and fake.calls == 0       # flag off: no call, no spend
            monkeypatch.setattr(flags, "enabled", lambda name: True)
            out = m.invent_propose(m.InventReq(n=3, **base))
            assert [a["name"] for a in out["accepted"]] == ["rev"] and len(out["rejected"]) == 2 and "yaml" in out["accepted"][0] and out["budget"]["calls"] == 1
            assert any("ghost" in " ".join(r["problems"]) for r in out["rejected"])
            tr = m.invent_run(m.InventRunReq(template=out["accepted"][0]["yaml"], name="mine", budget=4, batch=2, sampler="random", objectives=["sharpe"], **base))
            assert tr["id"] and any(t["lab"] == "invent" for t in m.task_list()["tasks"])
            _raises(lambda: m.invent_run(m.InventRunReq(template=_json.dumps({**good, "expr": "rank(ghost + $f, $w)"}), **base)), 422)
            _raises(lambda: m.invent_run(m.InventRunReq(template="[1,2]", **base)), 422)
            m.llm_budget(m.LLMBudgetReq(max_calls_per_day=1))
            assert "call limit" in _raises(lambda: m.invent_propose(m.InventReq(**base)), 429) and fake.calls == 1       # over the cap: refused, nothing sent
            fake.items = []
            m.llm_budget(m.LLMBudgetReq(max_calls_per_day=0))
            _raises(lambda: m.invent_propose(m.InventReq(**base)), 502)
            assert m.llm_usage(7)["today"]["calls"] == 2

            # the runner ticks all three kinds of task together
            ticked = m._get_runner().tick()
            assert len(ticked) >= 3 and all(n >= 0 for n in ticked.values()) and sum(1 for n in ticked.values() if n > 0) >= 3
            names = set(r["task"] for r in s.query("SELECT DISTINCT task FROM harness_sim_record"))
            assert any(n.startswith("template-") for n in names) and any(n.startswith("evolution-") for n in names)
            assert not [n for n in dir(m) if "submit" in n.lower()]                       # no route (or helper) can submit anything
    finally:
        _restore(saved)


def test_planning_endpoints_run_against_a_real_database(tmp_path, monkeypatch):
    """D5: overview, settings, advice, PM (with and without a model), and queueing the plan through the labs' own run functions."""
    if REAL:
        return
    import json as _json
    saved = _install()
    try:
        from app.harness import flags
        from app.harness import llm as LL
        from app.harness.engine.tracker import Tracker
        from app.harness.llm_budget import Budget
        from app.harness.plan.day import PlanSettings
        from app.harness.store import default_store
        m = importlib.import_module("app.modules.harness_engine")
        with ace_db(tmp_path) as s:
            monkeypatch.setattr(flags, "enabled", lambda name: True)
            monkeypatch.setattr(m, "_tracker", lambda: Tracker(default_store(), tmp_path / "j.jsonl"))
            from app.harness.engine.focus import Focus
            monkeypatch.setattr(m, "_focus", lambda: Focus(tmp_path / "focus.json"))
            monkeypatch.setattr(m, "_plan_settings", lambda: PlanSettings(tmp_path / "plan.json"))
            m._engine = m._runner_inst = None
            add_dataset(s, "fund")
            add_dataset(s, "price")
            for f in ("assets", "debt", "sales"):
                add_field(s, f, "fund")
            for f in ("close", "volume", "open"):
                add_field(s, f, "price")
            add_alpha(s, "A1", "rank(ts_zscore(close, 22))", 1.6)
            add_alpha(s, "A2", "rank(ts_mean(volume, 10)) - rank(ts_delta(open, 5))", 1.2)
            add_alpha(s, "A3", "rank(debt)", 0.3)
            base = {"region": "USA", "delay": 1, "universe": "TOP3000"}

            # settings
            assert m.plan_settings_get()["settings"]["daily_budget"] == 300 and "repair" in m.plan_settings_get()["labs"]
            assert m.plan_settings_set(m.PlanSettingsReq(daily_budget=120, labs=["harvest", "harden", "repair", "relocate", "evolution", "deepen"]))["settings"]["daily_budget"] == 120
            _raises(lambda: m.plan_settings_set(m.PlanSettingsReq(labs=["nope"])), 422)
            _raises(lambda: m.plan_settings_set(m.PlanSettingsReq(explore_fraction=2)), 422)

            # overview: everything the tab shows, no queueing
            ov = m.plan_overview(m.ScopeBase(**base))
            assert ov["scope"] and ov["settings"]["daily_budget"] == 120 and ov["spent"]["total"] == 0 and ov["counts"]["strong"] == 1
            assert set(ov["readiness"]["blockers"]) == {"relocate"} and "only one market" in ov["readiness"]["blockers"]["relocate"][0]
            assert [a["lab"] for a in ov["plan"]["allocations"]] and ov["plan"]["planned"] == 120 and len(ov["trend"]["days"]) == 14
            assert ov["advice"] and all(set(i) >= {"id", "priority", "title", "why"} for i in ov["advice"]) and ov["flags"]["planning"] is True
            assert s.query("SELECT COUNT(*) AS n FROM harness_sim_record")[0]["n"] == 0                              # reading the plan queues nothing

            # advice: rules only, then narrated by a fake model
            plain = m.plan_advice(m.AdviceReq(**base))
            assert plain["items"] and plain["narration"] is None

            class _Res:
                def __init__(self, items):
                    self.expressions, self.provider, self.model = items, "fake", "m"

            class _Fake:
                def __init__(self, items):
                    self.items, self.calls = items, 0

                def generate_list(self, prompt, n=None):
                    self.calls += 1
                    return _Res(self.items)
            fake = _Fake(["Start by harvesting, then harden your best alpha."])
            llm = LL.LLM(s, provider=lambda: fake, budget=Budget(s, tmp_path / "llm.json"), status=lambda: {"available": ["fake"], "preferred": "fake", "used": ["fake"]})
            monkeypatch.setattr(LL, "default_llm", lambda: llm)
            nar = m.plan_advice(m.AdviceReq(narrate=True, **base))["narration"]
            assert nar["usedLLM"] is True and "harvesting" in nar["text"] and fake.calls == 1

            # PM: rule floor with no model; a model's choice is validated (invented desks dropped)
            floor = m.plan_pm(m.PMReq(use_llm=False, **base))
            assert floor["fromPM"] is False and floor["allocations"] and fake.calls == 1 and floor["llmFlag"] is True
            fake.items = [_json.dumps({"briefing": "Fund the proven desks.", "allocations": [{"lab": "harvest", "why": "plain patterns convert"}, {"lab": "ghost", "why": "?"}]})]
            pm = m.plan_pm(m.PMReq(**base))
            assert pm["fromPM"] is True and [a["lab"] for a in pm["allocations"]] == ["harvest"] and pm["rejected"] and fake.calls == 2
            assert sum(a["sims"] for a in pm["allocations"]) <= 120

            # queue the plan: every funded lab runs through its own run function, nothing simulates, history is kept
            out = m.plan_run(m.PlanRunReq(**base))
            assert out["queued"] > 0 and out["runId"] and out["plan"]["planned"] > 0
            tasks_made = {r["task"].split("-")[0] for r in s.query("SELECT DISTINCT task FROM harness_sim_record")}
            assert "harvest" in tasks_made or "harden" in tasks_made
            assert {r["status"] for r in s.query("SELECT DISTINCT status FROM harness_sim_record")} <= {"queued"}      # queued only
            assert {t["lab"] for t in m.task_list()["tasks"]} <= {"evolution", "deepen"}                               # task-style labs became tasks
            hist = m.plan_history()["runs"]
            assert hist[0]["id"] == out["runId"] and hist[0]["queued"] == out["queued"]
            ov2 = m.plan_overview(m.ScopeBase(**base))
            assert ov2["spent"]["total"] > 0 and ov2["plan"]["remaining"] < ov["plan"]["remaining"] and ov2["history"][0]["id"] == out["runId"]
            again = m.plan_run(m.PlanRunReq(labs=["harvest"], **base))                                                  # a second run adds only what is new
            assert again["queued"] <= out["queued"]

            # safety: restricted labs must belong to the plan; nothing ready -> a clear 422; flags gate it
            _raises(lambda: m.plan_run(m.PlanRunReq(labs=["pair", "nope"], **base)), 422)
            empty = {"region": "JPN", "delay": 1, "universe": "TOP1600"}
            assert "No lab can run today" in _raises(lambda: m.plan_run(m.PlanRunReq(**empty)), 422)
            monkeypatch.setattr(flags, "enabled", lambda name: name != "harness_planning")
            assert "harness_planning" in _raises(lambda: m.plan_run(m.PlanRunReq(**base)), 409)
            assert not [n for n in dir(m) if "submit" in n.lower()]
    finally:
        _restore(saved)


def test_winner_endpoints(tmp_path, monkeypatch):
    """E2: the harness-level winner tag settings."""
    if REAL:
        return
    saved = _install()
    try:
        from app.harness import winner as W
        m = importlib.import_module("app.modules.harness_engine")
        monkeypatch.setattr(W, "default_settings", lambda: W.WinnerSettings(tmp_path / "winner.json"))
        g = m.winner_get()
        assert g["settings"]["winner_tag"] == "" and "GREEN" in g["colors"]
        out = m.winner_set(m.WinnerReq(winner_tag="harness-winner", winner_color="BLUE", tag_winners_above=1.2))
        assert out["settings"] == {"winner_tag": "harness-winner", "winner_color": "BLUE", "tag_winners_above": 1.2} and m.winner_get()["settings"]["winner_color"] == "BLUE"
        _raises(lambda: m.winner_set(m.WinnerReq(winner_tag="bad/tag")), 422)
        _raises(lambda: m.winner_set(m.WinnerReq(winner_color="PINK")), 422)
        assert m.winner_set(m.WinnerReq(winner_tag=""))["settings"]["winner_tag"] == ""
    finally:
        _restore(saved)
