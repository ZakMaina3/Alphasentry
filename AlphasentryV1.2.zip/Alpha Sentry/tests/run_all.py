"""Tiny pytest-free runner (works offline): python tests/run_all.py  — pytest also works."""
import importlib, inspect, sys, tempfile, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "backend"))


class MP:
    def __init__(self): self._undo = []
    def setattr(self, obj, name, val):
        self._undo.append((obj, name, getattr(obj, name))); setattr(obj, name, val)
    def undo(self):
        for o, n, v in reversed(self._undo): setattr(o, n, v)


def main() -> int:
    bad = ran = skipped = 0
    for f in sorted(Path(__file__).parent.glob("test_*.py")):
        mod = importlib.import_module(f"tests.{f.stem}")
        have_db = getattr(mod, "HAVE_DB", True)
        for name, fn in inspect.getmembers(mod, inspect.isfunction):
            if not name.startswith("test_") or fn.__module__ != mod.__name__:
                continue
            params = inspect.signature(fn).parameters
            if params and not have_db:
                skipped += 1; print(f"SKIP {name} (needs sqlalchemy/pydantic)"); continue
            mp = MP(); tmp = tempfile.mkdtemp()
            kw = {}
            if "tmp_path" in params: kw["tmp_path"] = Path(tmp)
            if "monkeypatch" in params: kw["monkeypatch"] = mp
            try:
                fn(**kw); ran += 1; print(f"PASS {name}")
            except Exception:
                bad += 1; print(f"FAIL {name}"); traceback.print_exc()
            finally:
                mp.undo()
    print(f"\n{ran} passed, {bad} failed, {skipped} skipped")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
