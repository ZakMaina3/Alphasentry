"""A throwaway SQLite file with ACE's real tables (sim_results / datasets / fields) for testing the sqlite3 layer."""
import time
from contextlib import contextmanager
from pathlib import Path

from app.harness.store import Store, ensure_tables, set_default_store

SIM_RESULTS = """CREATE TABLE sim_results (id INTEGER PRIMARY KEY, created_at FLOAT NOT NULL, alpha_id VARCHAR NOT NULL,
 expression TEXT NOT NULL, region VARCHAR NOT NULL, delay INTEGER NOT NULL, universe VARCHAR NOT NULL,
 neutralization VARCHAR NOT NULL, sharpe FLOAT, fitness FLOAT, turnover FLOAT, "returns" FLOAT, margin FLOAT, drawdown FLOAT,
 self_corr FLOAT, prod_corr FLOAT, powerpool_corr FLOAT, tests_failed INTEGER NOT NULL DEFAULT 0,
 passed_gate BOOLEAN NOT NULL DEFAULT 0, gate_reasons TEXT NOT NULL DEFAULT '[]', n_ops INTEGER NOT NULL DEFAULT 0,
 tagged VARCHAR NOT NULL DEFAULT '', submitted BOOLEAN DEFAULT 0, submitted_at FLOAT)"""
DATASETS = """CREATE TABLE datasets (id INTEGER PRIMARY KEY, dataset_id VARCHAR NOT NULL, region VARCHAR NOT NULL, delay INTEGER NOT NULL,
 instrument VARCHAR NOT NULL DEFAULT 'EQUITY', universe VARCHAR NOT NULL DEFAULT '', category VARCHAR NOT NULL DEFAULT '',
 name VARCHAR NOT NULL DEFAULT '', description TEXT NOT NULL DEFAULT '', coverage FLOAT NOT NULL DEFAULT 0, value_score FLOAT NOT NULL DEFAULT 0,
 alpha_count INTEGER NOT NULL DEFAULT 0, fetch_count INTEGER NOT NULL DEFAULT 1, first_seen FLOAT, last_seen FLOAT,
 UNIQUE (dataset_id, region, delay))"""
FIELDS = """CREATE TABLE fields (id INTEGER PRIMARY KEY, field_id VARCHAR NOT NULL, dataset_id VARCHAR NOT NULL, region VARCHAR NOT NULL,
 delay INTEGER NOT NULL, type VARCHAR NOT NULL DEFAULT 'MATRIX', prefix VARCHAR NOT NULL DEFAULT '', description TEXT NOT NULL DEFAULT '',
 alpha_count INTEGER NOT NULL DEFAULT 0, is_virgin BOOLEAN NOT NULL DEFAULT 0, first_seen FLOAT, last_seen FLOAT,
 UNIQUE (field_id, region, delay))"""


def make_store(tmp, sim_results=SIM_RESULTS, harness=True) -> Store:
    s = Store(Path(tmp) / "ace.db")
    with s.connect() as c:
        for ddl in (sim_results, DATASETS, FIELDS):
            c.execute(ddl)
    if harness:
        ensure_tables(s)
    return s


@contextmanager
def ace_db(tmp, **kw):
    s = make_store(tmp, **kw)
    set_default_store(s)
    try:
        yield s
    finally:
        set_default_store(None)


def add_alpha(s, alpha_id, expr, sharpe, *, region="USA", delay=1, universe="TOP3000", neut="SUBINDUSTRY",
              submitted=0, passed=0, created=None, fitness=1.0, turnover=0.3):
    s.execute("INSERT INTO sim_results (created_at, alpha_id, expression, region, delay, universe, neutralization, sharpe, fitness,"
              " turnover, passed_gate, submitted) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
              (created or time.time(), alpha_id, expr, region, delay, universe, neut, sharpe, fitness, turnover, passed, submitted))


def add_field(s, field_id, dataset_id, *, region="USA", delay=1, alpha_count=5, type_="MATRIX"):
    s.execute("INSERT INTO fields (field_id, dataset_id, region, delay, type, alpha_count) VALUES (?,?,?,?,?,?)",
              (field_id, dataset_id, region, delay, type_, alpha_count))


def add_dataset(s, dataset_id, *, region="USA", delay=1, universe="TOP3000", coverage=0.9):
    s.execute("INSERT INTO datasets (dataset_id, region, delay, universe, coverage) VALUES (?,?,?,?,?)",
              (dataset_id, region, delay, universe, coverage))
