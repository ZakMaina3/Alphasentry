"""Fragments D1-D3: the daily plan, dispatch and the advisor (pure logic + the sqlite readers)."""
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.harness.engine.tracker import Tracker
from app.harness.plan import advisor
from app.harness.plan import day as D
from app.harness.plan import dispatch as DP
from app.harness.plan.yields import LabYield
from tests.ace_db import ace_db
from tests.test_tasks import SC, runner, spec

L = D.LabInput


def book(**kw):                       # lab -> (finished, passing)
    return {k: LabYield(k, f, f, f, p) for k, (f, p) in kw.items()}


# ── D1 ──────────────────────────────────────────────────────────────────────────────────────────
def test_allocation_adds_up_rewards_yield_and_never_starves_anyone():
    labs = [L("repair", 400, 8), L("harvest", 500, 0), L("pair", 30, 0), L("harden", 0, 0), L("relocate", 250, 1)]
    a = D.allocate(300, labs)
    by = {x["lab"]: x["sims"] for x in a}
    assert sum(by.values()) == 300 and a[0]["lab"] == "repair" and by["repair"] > 2 * max(v for k, v in by.items() if k != "repair")
    assert set(by) == {"repair", "harvest", "pair", "harden", "relocate"} and min(by.values()) >= 10       # even a confident zero keeps its floor
    assert by["harden"] > by["harvest"] and by["pair"] > by["harvest"]                                       # unknown labs explore more than a known dud
    assert [x["lab"] for x in a] == sorted(by, key=lambda k: -by[k]) and abs(sum(x["share"] for x in a) - 1) < 0.01
    assert D.allocate(300, labs) == a                                                                        # deterministic
    assert L("x").smoothed == D.TARGET_YIELD and L("x", 1000, 10).smoothed > L("x", 1000, 0).smoothed > 0     # no data = the target; evidence moves it
    assert abs(L("x", 10, 5).smoothed - 0.0238) < 0.001                                                      # a lucky sample of ten is pulled back hard
    assert D.allocate(0, labs) == [] and D.allocate(50, []) == []


def test_capacity_spill_and_minimum_chunk():
    labs = [L("repair", 400, 8, capacity=20), L("harvest", 0, 0), L("pair", 0, 0)]
    a = {x["lab"]: x for x in D.allocate(200, labs)}
    assert a["repair"]["sims"] == 20 and a["repair"]["capped"] and "Limited to the 20" in a["repair"]["why"]
    assert sum(x["sims"] for x in a.values()) == 200                                                          # what repair cannot take goes to the others
    assert D.allocate(100, [L("a", capacity=0), L("b", capacity=0)]) == []                                    # nobody has anything left
    assert sum(x["sims"] for x in D.allocate(500, [L("a", capacity=10), L("b", capacity=15)])) == 25          # capacity is a hard ceiling
    small = D.allocate(25, [L(n) for n in "abcde"], min_chunk=10)                                             # 5 labs cannot each get 10 of 25
    assert sum(x["sims"] for x in small) == 25 and all(x["sims"] >= 10 for x in small) and len(small) <= 2
    tiny = D.allocate(4, [L("a", 400, 8), L("b")], min_chunk=10)                                              # below the chunk: the best lab takes it
    assert [(x["lab"], x["sims"]) for x in tiny] == [("a", 4)]
    assert all(x["sims"] >= 0 for x in D.allocate(7, [L(n, 100 * i, i) for i, n in enumerate("abcdefgh")], min_chunk=3))


def test_make_plan_budget_exclusions_and_notes():
    cfg = dict(D.DEFAULTS, daily_budget=100, labs=["repair", "harden", "pair"])
    p = D.make_plan(cfg, book(repair=(300, 6)), spent=40)
    assert p["remaining"] == 60 and p["planned"] == 60 and {l["lab"] for l in p["labs"]} == {"repair", "harden", "pair"} and not p["notes"]
    p2 = D.make_plan(cfg, book(), spent=100)
    assert p2["allocations"] == [] and "already used or committed" in p2["notes"][0]
    p3 = D.make_plan(cfg, book(), spent=0, exclude={"repair", "harden"})
    assert [a["lab"] for a in p3["allocations"]] == ["pair"] and p3["planned"] == 100
    assert "No labs are switched on" in D.make_plan(dict(cfg, labs=[]), book(), 0)["notes"][0]
    assert "any candidates left" in D.make_plan(cfg, book(), 0, capacity={"repair": 0, "harden": 0, "pair": 0})["notes"][-1]


def test_plan_settings_validate_and_persist(tmp_path):
    s = D.PlanSettings(tmp_path / "x" / "plan.json")
    assert s.config() == D.DEFAULTS
    out = s.set_config(daily_budget=500, explore_fraction=0.2, labs=["repair", "pair", "repair"])
    assert out["daily_budget"] == 500 and out["explore_fraction"] == 0.2 and out["labs"] == ["repair", "pair"]
    assert D.PlanSettings(tmp_path / "x" / "plan.json").config() == out                                       # survives a restart
    for kw in ({"daily_budget": -1}, {"explore_fraction": 1.5}, {"labs": ["nope"]}, {"bogus": 1}, {"min_chunk": 0}, {"daily_budget": "x"}):
        try:
            s.set_config(**kw)
            assert False, kw
        except D.PlanError:
            pass
    assert s.config() == out                                                                                   # a refused change changes nothing
    assert D.PlanSettings().set_config(daily_budget=5)["daily_budget"] == 5                                    # in-memory when no path


def test_spent_today_counts_records_and_unrealised_task_budget(tmp_path):
    with ace_db(tmp_path) as s:
        now = time.time()
        tr = Tracker(s, tmp_path / "j.jsonl")
        for i in range(5):
            tr.enqueue("repair", {"regular": f"rank(x{i})", "settings": {"region": "USA"}})
        s.execute("UPDATE harness_sim_record SET status='dryrun' WHERE id=1")
        s.execute("UPDATE harness_sim_record SET status='cancelled' WHERE id=2")
        s.execute("UPDATE harness_sim_record SET created=? WHERE id=3", (now - 3 * 86400,))                   # an old one
        assert D.spent_today(s, now) == {"records": 2, "committed": 0, "total": 2}
        r = runner(s, tmp_path)
        r.create(lab="search", name="t", spec=spec(), scope=SC, sampler="random", objectives=["sharpe"], budget=30, batch=5, cores=1, seed=1)
        assert D.spent_today(s, now)["committed"] == 30
        r.tick()                                                                                                # 5 points queued: records +5, committed -5
        st = D.spent_today(s, now)
        assert st["committed"] == 25 and st["records"] == 7 and st["total"] == 32
        tid = r.list_tasks()[0]["id"]
        r.stop(tid)
        assert D.spent_today(s, now)["committed"] == 0                                                         # a stopped task commits nothing


# ── D2 ──────────────────────────────────────────────────────────────────────────────────────────
CFG = dict(D.DEFAULTS, daily_budget=100, labs=["repair", "harden", "pair"], explore_fraction=0.3, min_chunk=5)


def test_dispatch_runs_the_plan_and_hands_a_shortfall_to_the_others():
    calls = []
    avail = {"repair": 10, "harden": 1000, "pair": 1000}                                                      # repair runs dry after 10 new candidates

    def make(lab):
        def run(target, extra):
            calls.append((lab, target, extra))
            got = min(extra, avail[lab])
            avail[lab] -= got
            return {"queued": got, "duplicates": 3 if got < extra else 0}
        return run

    out = DP.dispatch(CFG, book(repair=(400, 8)), 0, {l: make(l) for l in CFG["labs"]})
    assert out["queued"] == 100 and out["leftover"] == 0 and out["rounds"] == 2
    rep = [c for c in calls if c[0] == "repair"]
    assert len(rep) == 1 and rep[0][2] > 10                                                                    # asked for more than it had, once
    assert any("repair only had 10 new" in n and "3 already known" in n for n in out["notes"])
    second = [c for c in calls if c is not rep[0]][3:]
    assert second and all(c[0] != "repair" for c in second)                                                    # the shortfall went elsewhere
    for lab in ("harden", "pair"):
        rows = [c for c in calls if c[0] == lab]
        assert len(rows) == 2 and rows[1][1] == rows[0][2] + rows[1][2]                                        # target = asked so far + extra
    assert out["plan"]["planned"] == 100 and out["queued"] == sum(r["queued"] for r in out["results"])


def test_dispatch_isolates_failures_and_reports_unused_budget():
    def boom(t, e):
        raise RuntimeError("no fields downloaded")
    ok = lambda t, e: {"queued": e, "duplicates": 0}                                                            # noqa: E731
    out = DP.dispatch(CFG, book(), 0, {"repair": boom, "pair": ok})                                             # harden has no runner at all
    errs = {r["lab"]: r["error"] for r in out["results"] if r["error"]}
    assert "RuntimeError: no fields downloaded" in errs["repair"] and "cannot be run by the plan" in errs["harden"]
    assert out["queued"] == 100 and {r["lab"] for r in out["results"] if not r["error"]} == {"pair"}          # pair absorbed the day
    none = DP.dispatch(CFG, book(), 0, {l: (lambda t, e: {"queued": 0, "duplicates": e}) for l in CFG["labs"]})
    assert none["queued"] == 0 and none["leftover"] == 100 and any("not used" in n for n in none["notes"])
    assert DP.dispatch(CFG, book(), 100, {})["results"] == [] and DP.dispatch(CFG, book(), 100, {})["queued"] == 0   # budget already spent: runs nothing
    capped = DP.dispatch(CFG, book(), 0, {l: ok for l in CFG["labs"]}, max_rounds=1)
    assert capped["rounds"] == 1


def test_dispatch_audit_trail(tmp_path):
    with ace_db(tmp_path) as s:
        out = DP.dispatch(CFG, book(), 0, {l: (lambda t, e: {"queued": e, "duplicates": 0, "task": 7}) for l in CFG["labs"]})
        rid = DP.record_run(s, "EQUITY/USA/D1/TOP3000", out, clock=lambda: 1_700_000_000.0)
        h = DP.history(s)
        assert h[0]["id"] == rid and h[0]["queued"] == 100 and h[0]["day"] == "2023-11-14" and h[0]["scope"].endswith("TOP3000")
        assert h[0]["results"][0]["task"] == 7 and len(DP.history(s, 1)) == 1


# ── D3 ──────────────────────────────────────────────────────────────────────────────────────────
def ids(items):
    return [i["id"] for i in items]


def test_advisor_orders_the_next_steps_and_stays_quiet_when_all_is_well():
    off = advisor.advise({"flags": {"harness_engine": False}})
    assert ids(off) == ["engine-off"] and off[0]["priority"] == 1 and off[0]["tab"] == "control"
    s = {"flags": {"harness_engine": True}, "engine": {"running": False, "dry_run": False, "counts": {"queued": 12}}, "unscored": 3,
         "plan": {"budget": 300, "spent": 20, "remaining": 280}, "results": {"alphas": 50, "nearMisses": 4, "strong": 2, "passing": 5, "unsubmitted": 2},
         "tasks": [{"id": 9, "name": "bad", "status": "error", "error": "Most points break the constraints"}],
         "yields": {"labs": [{"lab": "repair", "confident": True, "yieldRate": 0.02, "passing": 9, "finished": 450},
                             {"lab": "pair", "confident": True, "yieldRate": 0.0, "passing": 0, "finished": 500}]}, "saturated": 8}
    got = advisor.advise(s, limit=20)
    assert got[0]["id"] == "start-engine" and "12" in got[0]["title"]                                          # a stopped engine with work waiting comes first
    assert {"score", "task-9", "repair", "harden", "evolve", "review", "best-lab", "dead-pair", "saturated", "mix"} <= set(ids(got))
    assert "run-plan" not in ids(got)                                                                          # work is queued, so not "run the plan"
    assert [i["priority"] for i in got] == sorted(i["priority"] for i in got) and len(advisor.advise(s, limit=3)) == 3
    assert advisor.advise({"flags": {"harness_engine": True}, "engine": {"running": True, "counts": {}}, "plan": {"budget": 100, "spent": 0, "remaining": 100}})[0]["id"] == "run-plan"
    assert ids(advisor.advise({"flags": {"harness_engine": True}, "plan": {"budget": 100, "remaining": 0}})) == ["budget-used"]
    assert ids(advisor.advise({"flags": {"harness_engine": True}, "results": {"alphas": 0}})) == ["seed"]
    assert advisor.advise({}) == [] and ids(advisor.advise({"flags": {"harness_engine": True}, "engine": {"dry_run": True, "counts": {"queued": 2}}})) == ["dry-run"]
    assert all(i["title"] and i["why"] and not i["title"].lower().startswith("submit") for i in got)   # every item says what and why; none tells you to submit
    assert "never submits" in next(i for i in got if i["id"] == "review")["why"]


def test_narration_falls_back_to_the_rules_when_the_llm_fails():
    items = advisor.advise({"flags": {"harness_engine": False}})
    assert advisor.narrate(items, None) == {"text": items[0]["title"] + ". " + items[0]["why"], "usedLLM": False}
    assert advisor.narrate(items, lambda sys_, user: "  Turn the engine on first.  ") == {"text": "Turn the engine on first.", "usedLLM": True}
    seen = []
    advisor.narrate(items, lambda sys_, user: seen.append((sys_, user)) or "ok")
    assert "Never suggest submitting" in seen[0][0] and "SentryEngine" in seen[0][1]

    def boom(a, b):
        raise RuntimeError("budget used up")
    bad = advisor.narrate(items, boom)
    assert not bad["usedLLM"] and "budget used up" in bad["error"] and bad["text"]
    assert advisor.narrate(items, lambda a, b: "   ")["usedLLM"] is False
    assert advisor.narrate([], lambda a, b: "x") == {"text": "Nothing needs attention right now.", "usedLLM": False}
