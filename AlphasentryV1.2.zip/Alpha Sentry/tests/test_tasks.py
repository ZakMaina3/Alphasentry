import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.harness.engine.tracker import Tracker
from app.harness.optimize import objectives as OB
from app.harness.payload import Scope
from app.harness.tasks import TaskError, TaskRunner, pareto, rank
from app.harness.templates import spec as T
from tests.ace_db import ace_db

SC = Scope("USA", 1, "TOP3000")
TPL = ("name: window search\nexpr: ts_mean(close, $w)\nvars: {w: {type: int, grid: [5, 10, 20, 40, 60, 80, 120, 160, 200, 250]}}\n"
       "settings: {decay: [0, 4], neutralization: [SUBINDUSTRY, INDUSTRY, MARKET]}")      # 60 distinct points


def spec(doc=TPL):
    return T.parse(doc)


def window_of(payload):
    return int(payload["regular"].split(",")[1].strip(" )"))


def finish(store, fn, fail=()):
    """Stand-in for the engine + scorer: resolve every queued record, writing a real sim_results row for it."""
    n = 0
    for r in store.query("SELECT id, payload FROM harness_sim_record WHERE status='queued'"):
        p = json.loads(r["payload"])
        if r["id"] in fail:
            store.execute("UPDATE harness_sim_record SET status='error' WHERE id=?", (r["id"],))
            continue
        row = fn(p)
        aid = f"A{r['id']}"
        store.execute("UPDATE harness_sim_record SET status='scored', alpha_id=? WHERE id=?", (aid, r["id"]))
        s = p["settings"]
        store.execute("INSERT INTO sim_results (created_at, alpha_id, expression, region, delay, universe, neutralization, sharpe, fitness, turnover, returns, margin, drawdown, passed_gate)"
                      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,0)", (time.time(), aid, p["regular"], s["region"], s["delay"], s["universe"], s["neutralization"],
                                                                  row["sharpe"], row["fitness"], row["turnover"], row.get("returns"), None, row.get("drawdown")))
        n += 1
    return n


def quality(p):                       # best window is 60: quality falls off with distance (log scale)
    import math
    q = 2.4 - abs(math.log(window_of(p) / 60.0))
    return {"sharpe": q, "fitness": q * 0.8, "turnover": 0.2 + window_of(p) / 1000, "returns": 0.1, "drawdown": 0.05}


def runner(store, tmp_path, **kw):
    return TaskRunner(store, Tracker(store, tmp_path / "j.jsonl"), **kw)


def drive(r, store, fn, ticks=40, **kw):
    for _ in range(ticks):
        r.tick()
        finish(store, fn, **kw)
    r.tick()


def test_objectives_and_constraints():
    import random
    rng = random.Random(1)
    steady = [0.1 + rng.gauss(0, 0.05) for _ in range(250)]                               # a rising line with noise (total ~25.8)
    jumpy = [0.0] * 250
    for i in range(0, 250, 50):
        jumpy[i + 25] = 5.0                                                               # the same total (25), earned in five jumps
    assert OB.k_ratio([1.0, 2.0]) is None and OB.k_ratio([0.1] * 200) is None            # too short / perfectly straight -> no number
    assert OB.k_ratio(steady) > 20 and OB.k_ratio(jumpy) < 8 and OB.k_ratio(steady) > 3 * OB.k_ratio(jumpy)   # steadiness is rewarded
    objs = OB.resolve(["sharpe", "turnover", "sharpe_per_turnover", "calmar", "margin"])
    row = {"sharpe": 2.0, "turnover": 0.4, "returns": 0.2, "drawdown": 0.1, "margin": None}
    assert OB.extract(row, objs) == [2.0, 0.4, 5.0, 2.0, -10.0]                         # missing margin -> deliberately terrible, not zero
    assert OB.extract(None, objs) == [-10.0, 10.0, -10.0, -10.0, -10.0]
    assert OB.extract(row, OB.resolve(["k_ratio"]), {"k_ratio": 1.5}) == [1.5]
    for bad in ([], ["nope"]):
        try:
            OB.resolve(bad)
            assert False
        except OB.ObjectiveError:
            pass
    ok = OB.constraints_from_row({"delay": 1, "sharpe": 1.9, "fitness": 1.2, "turnover": 0.3, "self_corr": 0.2})
    assert OB.feasible(ok) and ok["LOW_SHARPE"] == 0.0
    bad = OB.constraints_from_row({"delay": 1, "sharpe": 1.0, "fitness": 1.2, "turnover": 0.9, "self_corr": 0.85, "tests_failed": 2})
    assert abs(bad["LOW_SHARPE"] - 0.58) < 1e-9 and abs(bad["HIGH_TURNOVER"] - 0.2) < 1e-9 and abs(bad["SELF_CORRELATION"] - 0.15) < 1e-9 and bad["IS_TESTS"] == 2.0
    assert not OB.feasible(bad) and OB.constraints_from_row({"delay": 0, "sharpe": 2.0, "fitness": 2.0})["LOW_SHARPE"] > 0     # delay 0 needs 2.69
    assert OB.constraints_from_row(None) == {"NO_RESULT": 1.0} and OB.summarise({"sharpe": 1.0, "delay": 1})["failedChecks"]


def test_ranking_puts_feasible_first_and_finds_the_pareto_front():
    v = lambda n, vals, c=None: {"number": n, "params": {}, "values": vals, "constraint": c or {}}      # noqa: E731
    views = [v(1, [3.0, 0.5], {"X": 0.4}), v(2, [2.0, 0.5]), v(3, [1.0, 0.1]), v(4, [1.5, 0.9])]
    r = rank(views, ["maximize", "minimize"])
    assert [x["number"] for x in r][:2] in ([2, 3], [3, 2]) and r[-1]["number"] == 1                    # infeasible 3.0 ranks last
    assert {x["number"] for x in pareto(views, ["maximize", "minimize"])} == {2, 3}                      # 4 is dominated by 2
    assert [x["number"] for x in rank([v(1, [1.0]), v(2, [3.0]), v(3, [2.0])], ["maximize"])] == [2, 3, 1]


def test_create_validates_and_caps_budget(tmp_path):
    with ace_db(tmp_path) as s:
        r = runner(s, tmp_path)
        for kw, want in (({"spec": spec("name: n\nexpr: rank(close)")}, "nothing to search"), ({"objectives": ["nope"]}, "Unknown objective"),
                         ({"sampler": "cmaes", "objectives": ["sharpe", "turnover"]}, "single number"), ({"sampler": "bogus"}, "not a sampler"),
                         ({"sampler": "brute", "spec": spec("name: n\nexpr: ts_mean(close, $w)\nvars: {w: {type: float, low: 1.0, high: 5.0}}")}, "step")):
            args = dict(lab="search", name="t", spec=spec(), scope=SC, sampler="nsga2", objectives=["sharpe"], budget=50)
            args.update(kw)
            try:
                r.create(**args)
                assert False, kw
            except TaskError as e:
                assert want in str(e), (kw, str(e))
        out = r.create(lab="search", name="", spec=spec(TPL + "\nconstraints: {max_simulations: 30}"), scope=SC, sampler="tpe",
                       objectives=["sharpe"], budget=5000)
        assert out["budget"] == 30 and out["backend"] in ("builtin", "optuna") and any("joint" in n for n in out["notes"]) or out["backend"] == "optuna"
        assert r.list_tasks()[0]["name"] == "window search" and r.get(out["id"])["status"] == "running"


def test_search_runs_end_to_end_and_finds_the_best_window(tmp_path):
    with ace_db(tmp_path) as s:
        r = runner(s, tmp_path)
        t = r.create(lab="search", name="w", spec=spec(), scope=SC, sampler="nsga2", objectives=["sharpe"], budget=40, batch=10, cores=2, seed=3)["id"]
        assert r.tick() == {t: 10} and r.tick() == {t: 10} and r.tick() == {t: 0}          # two whole batches in flight (cores=2), then it waits
        assert s.query("SELECT COUNT(*) AS n FROM harness_sim_record WHERE task=?", (f"search-{t}",))[0]["n"] == 20
        drive(r, s, quality)
        d = r.detail(t)
        assert d["status"] == "done" and d["counts"] == {"complete": 40} and d["progress"] == 1.0         # budget respected exactly
        best = d["best"][0]
        assert best["params"]["w"] in (40, 60, 80) and best["values"][0] > 2.0                            # found the good region of the grid
        assert d["best"][0]["values"][0] >= d["best"][-1]["values"][0] and best["alphaId"]
        assert d["scope"]["region"] == "USA" and d["notes"] == [] or d["notes"]
        assert s.query("SELECT COUNT(*) AS n FROM harness_sim_record WHERE task=?", (f"search-{t}",))[0]["n"] == 40


def test_restart_rebuilds_the_optimizer_and_replays_in_flight_trials(tmp_path):
    with ace_db(tmp_path) as s:
        r1 = runner(s, tmp_path)
        t = r1.create(lab="search", name="w", spec=spec(), scope=SC, sampler="nsga2", objectives=["sharpe"], budget=60, batch=10, cores=2, seed=5)["id"]
        for _ in range(3):
            r1.tick()
            finish(s, quality)
        r1.tick()                                                                         # harvest, then a new batch goes in flight, un-told
        assert r1.counts(t) == {"complete": 30, "queued": 10}
        r2 = runner(s, tmp_path)                                                          # "restart": new runner, optimizer rebuilt, no live handles
        finish(s, quality)                                                                # the engine finishes what was in flight
        r2.tick()
        assert r2.counts(t).get("complete") == 40                                         # in-flight trials were told as replayed trials
        drive(r2, s, quality)
        d = r2.detail(t)
        assert d["status"] == "done" and d["error"] == "" and d["counts"] == {"complete": 60}
        keys = [json.dumps(x["params"], sort_keys=True) for x in d["recent"]]
        assert len(keys) == len(set(keys)) == 60                                          # nothing was ever proposed twice, restart included


def test_pause_resume_stop_remove(tmp_path):
    with ace_db(tmp_path) as s:
        r = runner(s, tmp_path)
        t = r.create(lab="search", name="w", spec=spec(), scope=SC, sampler="random", objectives=["sharpe"], budget=40, seed=1)["id"]
        r.tick()
        n0 = s.query("SELECT COUNT(*) AS n FROM harness_trial WHERE task_id=?", (t,))[0]["n"]
        assert r.set_status(t, "paused")["status"] == "paused"
        r.tick(); r.tick()
        assert s.query("SELECT COUNT(*) AS n FROM harness_trial WHERE task_id=?", (t,))[0]["n"] == n0          # a paused task does nothing
        try:
            r.set_status(t, "paused")                                                                           # already paused
            assert False
        except TaskError:
            pass
        assert r.set_status(t, "running")["status"] == "running"
        try:
            r.set_status(t, "running")                                                                          # already running
            assert False
        except TaskError:
            pass
        assert r.stop(t)["status"] == "stopped"
        assert s.query("SELECT COUNT(*) AS n FROM harness_trial WHERE task_id=? AND status='queued'", (t,))[0]["n"] == 0
        assert {x["status"] for x in s.query("SELECT status FROM harness_sim_record WHERE task=?", (f"search-{t}",))} == {"cancelled"}   # queued work dropped
        r.tick()
        assert r.get(t)["status"] == "stopped"
        for bad in ("paused", "running"):
            try:
                r.set_status(t, bad)                                                                            # a stopped task stays stopped
                assert False
            except TaskError:
                pass
        r.remove(t)
        assert r.get(t) is None and s.query("SELECT COUNT(*) AS n FROM harness_trial")[0]["n"] == 0
        try:
            r.stop(t)
            assert False
        except TaskError:
            pass


def test_template_constraints_prune_without_spending_budget(tmp_path):
    doc = ("name: pp\nexpr: rank($a) + rank($b) + rank($c) + rank($d)\nvars: {a: {type: choice, values: [f1, f2]}, b: {type: choice, values: [f1, f3]},"
           " c: {type: choice, values: [f2, f4]}, d: {type: choice, values: [f1, f5]}}\nconstraints: {power_pool: true}")
    with ace_db(tmp_path) as s:
        r = runner(s, tmp_path)
        t = r.create(lab="power", name="pp", spec=spec(doc), scope=SC, sampler="random", objectives=["sharpe"], budget=6, seed=2)["id"]
        flat = lambda p: {"sharpe": 2.0, "fitness": 1.5, "turnover": 0.3}                                 # noqa: E731
        drive(r, s, flat, ticks=60)
        d = r.detail(t)
        c = d["counts"]
        assert c.get("pruned", 0) > 0 and d["status"] in ("done", "error")
        assert c.get("complete", 0) <= 6                                                  # pruned points never reached the engine or the budget
        pruned = [x for x in d["recent"] if x["status"] == "pruned"]
        assert pruned and "limit is 3" in pruned[0]["error"]
        assert s.query("SELECT COUNT(*) AS n FROM harness_sim_record WHERE task=?", (f"power-{t}",))[0]["n"] == c.get("complete", 0) + c.get("queued", 0)


def test_failed_simulations_and_exhausted_grid_end_cleanly(tmp_path):
    with ace_db(tmp_path) as s:
        r = runner(s, tmp_path)
        small = "name: s\nexpr: ts_mean(close, $w)\nvars: {w: {type: int, grid: [5, 10, 20]}}"
        t = r.create(lab="search", name="s", spec=spec(small), scope=SC, sampler="brute", objectives=["sharpe"], budget=100, batch=3, cores=1)["id"]
        r.tick()
        first = s.query("SELECT id FROM harness_sim_record ORDER BY id")[0]["id"]
        finish(s, quality, fail={first})                                                  # one simulation errors out
        drive(r, s, quality, ticks=6)
        d = r.detail(t)
        assert d["status"] == "done" and any("Every point" in n for n in d["notes"])
        assert d["counts"] == {"complete": 2, "failed": 1}
        assert [x["error"] for x in d["recent"] if x["status"] == "failed"] == ["simulation error"]


def test_multi_objective_task_reports_a_pareto_front(tmp_path):
    with ace_db(tmp_path) as s:
        r = runner(s, tmp_path)
        t = r.create(lab="search", name="mo", spec=spec(), scope=SC, sampler="nsga2", objectives=["fitness", "turnover"], budget=40, batch=10, seed=8)["id"]
        drive(r, s, quality)
        d = r.detail(t)
        assert d["directions"] == ["maximize", "minimize"] and len(d["pareto"]) >= 2
        fronts = {(round(x["values"][0], 4), round(x["values"][1], 4)) for x in d["pareto"]}
        assert len(fronts) >= 2 and all(not (b[0] >= a[0] and b[1] <= a[1]) for a in fronts for b in fronts if a != b)   # a real trade-off, no point dominated


def test_a_broken_task_does_not_stall_the_others(tmp_path):
    with ace_db(tmp_path) as s:
        r = runner(s, tmp_path)
        good = r.create(lab="search", name="g", spec=spec(), scope=SC, sampler="random", objectives=["sharpe"], budget=20, seed=1)["id"]
        bad = r.create(lab="search", name="b", spec=spec(), scope=SC, sampler="random", objectives=["sharpe"], budget=20, seed=1)["id"]
        s.execute("UPDATE harness_task SET template='{not json' WHERE id=?", (bad,))
        out = r.tick()
        assert out[good] > 0 and r.get(bad)["status"] == "error" and "Error" in r.get(bad)["error"]
        assert r.get(good)["status"] == "running"


def test_template_fields_resolves_catalogue_filters(tmp_path):
    from tests.ace_db import add_alpha, add_dataset, add_field
    from app.harness.labs import ace_sources as src
    with ace_db(tmp_path) as s:
        s.execute("INSERT INTO datasets (dataset_id, region, delay, universe, category, coverage) VALUES ('fund','USA',1,'TOP3000','fundamental',0.9)")
        s.execute("INSERT INTO datasets (dataset_id, region, delay, universe, category, coverage) VALUES ('px','USA',1,'TOP3000','price',0.5)")
        for f, d, n in (("assets", "fund", 40), ("sales", "fund", 5), ("debt", "fund", 90), ("close", "px", 500)):
            add_field(s, f, d, alpha_count=n)
        add_field(s, "vec1", "fund", alpha_count=1, type_="VECTOR")
        s.execute("UPDATE fields SET description='Total assets of the company' WHERE field_id='assets'")
        var = lambda **k: T.parse({"name": "n", "expr": "$f", "vars": {"f": {"type": "datafield", **k}}}).vars["f"]   # noqa: E731
        assert src.template_fields(SC, var(category="fundamental")) == ["assets", "debt", "sales"]                # equal coverage: ties by field id
        assert src.template_fields(SC, var(category="fundamental", order_by="alpha_count", order_desc=False)) == ["sales", "assets", "debt"]   # least-worked first
        assert src.template_fields(SC, var(category="fundamental", max_alpha_count=50, order_by="field_id", order_desc=False)) == ["assets", "sales"]
        assert src.template_fields(SC, var(dataset="px")) == ["close"] and src.template_fields(SC, var(search="total assets")) == ["assets"]
        assert src.template_fields(SC, var(category="fundamental", limit=2, order_by="alpha_count")) == ["debt", "assets"]
        assert src.template_fields(SC, var(field_type="vector")) == ["vec1"] and src.template_fields(SC, var(min_coverage=0.8))[0] != "close"
        assert "close" not in src.template_fields(SC, var(min_coverage=0.8)) and src.template_fields(SC, var(dataset="nope")) == []


def test_engine_ticks_tasks_on_a_side_thread_and_not_during_dry_run(tmp_path):
    import threading
    from app.harness.engine.batch import BatchEngine
    from app.harness.engine.slots import SlotLease
    with ace_db(tmp_path) as s:
        tr = Tracker(s, tmp_path / "j.jsonl")
        calls = []
        ev = threading.Event()
        eng = BatchEngine(tr, port=object(), lease=SlotLease(8), ticker=lambda: (calls.append(1), ev.set()), tick_every=0.0)
        eng.dry_run = True
        eng._maybe_side()
        time.sleep(0.1)
        assert calls == []                                                                 # dry-run: tasks must not burn their budget
        eng.dry_run = False
        eng._maybe_side()
        assert ev.wait(2) and calls == [1]
        boom = BatchEngine(tr, port=object(), lease=SlotLease(8), ticker=lambda: 1 / 0, tick_every=0.0)
        boom._maybe_side()
        time.sleep(0.2)
        assert any("tasks error" in m for m in boom.log)                                   # a failing ticker is logged, never fatal


def test_create_rejects_empty_datafield_filters_and_bad_lab_names(tmp_path):
    with ace_db(tmp_path) as s:
        r = runner(s, tmp_path)
        doc = "name: n\nexpr: rank($f)\nvars: {f: {type: datafield, category: nothing}}"
        for kw, want in (({"prepared": lambda v: []}, "No data fields matched $f"), ({"lab": "Bad_Name"}, "lower-case"), ({"lab": "a-b"}, "lower-case")):
            args = dict(lab="search", name="t", spec=spec(doc), scope=SC, sampler="random", objectives=["sharpe"], budget=5, prepared=lambda v: ["x", "y"])
            args.update(kw)
            try:
                r.create(**args)
                assert False, kw
            except TaskError as e:
                assert want in str(e), (kw, str(e))
        ok = r.create(lab="template", name="t", spec=spec(doc), scope=SC, sampler="random", objectives=["sharpe"], budget=5, prepared=lambda v: ["x", "y"])
        assert ok["id"] and r.list_tasks()[0]["lab"] == "template"


def test_single_resolved_datafield_is_pinned_into_every_payload(tmp_path):
    with ace_db(tmp_path) as s:
        r = runner(s, tmp_path)
        doc = "name: n\nexpr: ts_mean($f, $w)\nvars: {f: {type: datafield, category: x}, w: {type: int, grid: [5, 10, 20]}}"
        t = r.create(lab="search", name="n", spec=spec(doc), scope=SC, sampler="brute", objectives=["sharpe"], budget=10, batch=3, cores=1,
                     prepared=lambda v: ["only_field"])["id"]
        r.tick()
        exprs = {json.loads(x["payload"])["regular"] for x in s.query("SELECT payload FROM harness_sim_record")}
        assert exprs == {"ts_mean(only_field, 5)", "ts_mean(only_field, 10)", "ts_mean(only_field, 20)"}       # not left as "$f"
        assert t
