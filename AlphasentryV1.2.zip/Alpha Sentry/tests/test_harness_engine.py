"""Unit tests for the ported harness core (no network, no BRAIN session)."""
import json
import sys
import tempfile
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend" / "vendor"))

from app.harness.engine.dedup import hash_payload
from app.harness.engine.packer import WorkItem, allocate_slots, key_of, pack
from app.harness.engine.slots import SlotLease

from app.harness.engine.batch import BatchEngine
from app.harness.engine.tracker import Tracker
from app.harness.store import Store, ensure_tables


def sim(expr, region="USA", delay=1, universe="TOP3000"):
    return {"type": "REGULAR", "settings": {"instrumentType": "EQUITY", "region": region, "delay": delay,
            "universe": universe, "language": "FASTEXPR"}, "regular": expr}


def make_tracker(tmp):
    store = Store(Path(tmp) / "t.db")
    ensure_tables(store)
    return Tracker(store, Path(tmp) / "j.jsonl")


def test_hash_ignores_key_order():
    assert hash_payload({"a": 1, "b": 2}) == hash_payload({"b": 2, "a": 1})


def test_pack_respects_key_and_size():
    items = [WorkItem(i, key_of(sim(f"rank(x{i})")), "t", sim(f"rank(x{i})")) for i in range(25)]
    items += [WorkItem(100 + i, key_of(sim("y", region="EUR")), "t", sim("y", region="EUR")) for i in range(3)]
    b = pack(items, free_slots=8)
    assert all(2 <= x.size <= 10 or x.size == 3 for x in b)
    assert [x.size for x in b][:3] == [10, 10, 5]
    for x in b:
        assert len({i.key for i in x.items}) == 1


def test_single_item_sent_as_object():
    it = WorkItem(1, key_of(sim("a")), "t", sim("a"))
    assert isinstance(pack([it], free_slots=1)[0].wire_payload(), dict)


def test_allocate_round_robin():
    assert allocate_slots(3, demand={"a": 5, "b": 5}, quotas={}) == {"a": 2, "b": 1}


def test_lease():
    l = SlotLease(8)
    assert l.acquire("x", 8) and not l.acquire("y", 1)
    l.release("x", 3)
    assert l.free() == 3 and l.acquire("y", 3)


def test_tracker_dedup_and_journal_orphans(tmp_path):
    tr = make_tracker(tmp_path)
    a = tr.enqueue("t", sim("a"))
    b = tr.enqueue("t", sim("a"))
    assert not a["duplicate"] and b["duplicate"] and b["record_id"] == a["record_id"]
    ids = [tr.enqueue("t", sim(f"e{i}"))["record_id"] for i in range(3)]
    assert tr.claim(ids, "B1") == ids
    tr.batch_started("B1", "https://x/simulations/1", ids, True)
    orphans = tr.orphan_batches()
    assert len(orphans) == 1 and orphans[0]["sim_url"].endswith("/1")   # survives "crash"
    tr.batch_finished("B1")
    assert tr.orphan_batches() == []


class FakePort:
    class SlotBusy(RuntimeError):
        pass

    def __init__(self):
        self.started = []

    def start(self, payload):
        self.started.append(payload)
        h = type("H", (), {})()
        h.sim_url, h.multi = f"https://x/{len(self.started)}", isinstance(payload, list)
        return h

    def adopt(self, url, multi):
        h = type("H", (), {})()
        h.sim_url, h.multi = url, multi
        return h

    def wait(self, handle, payload):
        ps = payload if isinstance(payload, list) else [payload]
        return [{"alpha_id": f"A{abs(hash(p['regular'])) % 9999}", "simulate_data": p} for p in ps]


def test_engine_runs_queue_and_dry_run(tmp_path, monkeypatch):
    import app.harness.engine.batch as bm
    monkeypatch.setattr(bm._bp, "SlotBusy", FakePort.SlotBusy)
    tr = make_tracker(tmp_path)
    tr.enqueue_many("t", [sim(f"e{i}") for i in range(12)])
    port = FakePort()
    eng = BatchEngine(tr, port=port, lease=SlotLease(8), poll_interval=0.05)
    assert eng.tick() == 2
    for _ in range(100):
        if tr.counts().get("done") == 12:
            break
        time.sleep(0.05)
    assert tr.counts().get("done") == 12 and len(port.started) == 2
    # dry run never calls simulate
    tr.enqueue_many("t", [sim(f"z{i}") for i in range(4)])
    eng.dry_run = True
    n = len(port.started)
    eng.tick()
    time.sleep(0.3)
    assert len(port.started) == n and tr.counts().get("dryrun") == 4


def test_engine_adopts_orphan(tmp_path, monkeypatch):
    import app.harness.engine.batch as bm
    monkeypatch.setattr(bm._bp, "SlotBusy", FakePort.SlotBusy)
    tr = make_tracker(tmp_path)
    ids = [tr.enqueue("t", sim(f"o{i}"))["record_id"] for i in range(2)]
    tr.claim(ids, "B9")
    tr.batch_started("B9", "https://x/orphan", ids, True)       # app "crashed" here
    port = FakePort()
    eng = BatchEngine(tr, port=port, lease=SlotLease(8))
    eng._adopt_orphans()
    for _ in range(100):
        if tr.counts().get("done") == 2:
            break
        time.sleep(0.05)
    assert tr.counts().get("done") == 2 and port.started == [] and tr.orphan_batches() == []


# ── Relocate (pure) ────────────────────────────────────────────────────────────────────────────
def test_relocate_refuses_missing_fields_and_builds_requests():
    from app.harness.labs.relocate import Scope, plan
    usa, eur = Scope("USA", 1, "TOP3000"), Scope("EUR", 1, "TOP2500")
    idents = lambda e: ["close", "fnd_x", "industry", "5"]          # noqa: E731
    have = {"USA/1": {"close", "fnd_x"}, "EUR/1": {"close"}}
    out = plan(origin=usa, winners=[{"alpha_id": "A1", "expression": "rank(close)*fnd_x"}], scopes=[usa, eur],
               fields_in_scope=lambda s: have[f"{s.region}/{s.delay}"], leaf_idents=idents)
    assert out["possible"] == 0 and out["blocked"] == 1 and out["moves"][0]["missing"] == ["fnd_x"]
    have["EUR/1"] = {"close", "fnd_x"}
    out = plan(origin=usa, winners=[{"alpha_id": "A1", "expression": "rank(close)*fnd_x"}], scopes=[usa, eur],
               fields_in_scope=lambda s: have[f"{s.region}/{s.delay}"], leaf_idents=idents, neutralizations=["MARKET", "INDUSTRY"])
    assert out["possible"] == 2 and len(out["requests"]) == 2
    assert out["requests"][0]["settings"]["region"] == "EUR" and out["requests"][0]["settings"]["nanHandling"] == "ON"


# ── Repair (pure) ──────────────────────────────────────────────────────────────────────────────
def _row(**kw):
    base = {"alpha_id": "A1", "expression": "rank(close)", "sharpe": 1.4, "fitness": 0.8, "turnover": 0.9,
            "decay": 0, "truncation": 0.08, "universe": "TOP3000", "neutralization": "INDUSTRY", "status": "UNSUBMITTED",
            "checks": [{"name": "HIGH_TURNOVER", "result": "FAIL"}, {"name": "LOW_SHARPE", "result": "PASS"},
                       {"name": "MATCHES_COMPETITION", "result": "WARNING"}]}
    base.update(kw)
    return base


def test_repair_one_change_each_and_ignored_checks():
    from app.harness.labs.relocate import Scope
    from app.harness.labs.repair import plan
    out = plan(scope=Scope("USA", 1, "TOP3000"), rows=[_row()])
    assert out["nearMisses"] == 1 and out["checks"] == ["HIGH_TURNOVER"]      # MATCHES_COMPETITION ignored
    kinds = [r["kind"] for r in out["repairs"]]
    assert "decay-linear" in kinds and "hump" in kinds and "decay" in kinds
    for rq in out["requests"]:                                                  # settings carried, one patch
        assert rq["settings"]["neutralization"] == "INDUSTRY" and rq["settings"]["nanHandling"] == "ON"


def test_repair_skips_repaired_submitted_and_unfixable():
    from app.harness.labs.relocate import Scope
    from app.harness.labs.repair import plan
    rows = [_row(alpha_id="W", expression="ts_decay_linear(rank(close), 5)"),            # already repaired
            _row(alpha_id="S", status="ACTIVE"),                                         # submitted
            _row(alpha_id="U", checks=[{"name": "LOW_SHARPE", "result": "FAIL"}], sharpe=0.2),   # not fixable
            _row(alpha_id="X", checks=None)]                                             # nothing to judge
    assert plan(scope=Scope("USA", 1, "TOP3000"), rows=rows)["nearMisses"] == 0


def test_repair_flips_reliably_negative_and_self_corr_uses_legal_lists():
    from app.harness.labs.relocate import Scope
    from app.harness.labs.repair import plan
    neg = _row(alpha_id="N", sharpe=-1.8, checks=[{"name": "LOW_SHARPE", "result": "FAIL"}])
    out = plan(scope=Scope("USA", 1, "TOP3000"), rows=[neg])
    assert out["repairs"][0]["kind"] == "flip" and out["requests"][0]["regular"] == "-(rank(close))"
    sc = _row(alpha_id="C", checks=[{"name": "SELF_CORRELATION", "result": "FAIL"}])
    out = plan(scope=Scope("USA", 1, "TOP3000"), rows=[sc], partners={"C": "rank(open)"},
               universes=["TOP200", "TOP1000", "TOP3000"], neutralizations=["MARKET", "INDUSTRY", "SUBINDUSTRY"])
    kinds = {r["kind"]: r for r in out["repairs"]}
    assert kinds["vector-neut"]["expression"] == "vector_neut(rank(close), rank(open))"
    assert kinds["universe"]["settings"] == {"universe": "TOP1000"}             # next smaller LEGAL universe
    out = plan(scope=Scope("USA", 1, "TOP3000"), rows=[sc])     # no legal lists / no partner:
    assert {r["kind"] for r in out["repairs"]} == {"neutralization"}   # only the universally-legal move is offered


def test_repair_wrap_keeps_leading_statements_and_power_pool_limit():
    from app.harness.labs.repair import _wrap, _within_power_pool
    assert _wrap("x = rank(close); group_rank(x, industry)", "hump({alpha}, hump = 0.01)") == \
        "x = rank(close); hump(group_rank(x, industry), hump = 0.01)"
    assert not _within_power_pool("rank(a)+rank(b)+rank(c)+rank(d)")           # 4 fields > 3


# ── Harden (pure) ──────────────────────────────────────────────────────────────────────────────
def test_harden_probes_and_settings_carried():
    from app.harness.labs.harden import neighbours, probes, plan
    from app.harness.labs.relocate import Scope
    assert neighbours(21) == [10, 42] and neighbours(45)[0] in (42, 63)
    ps = probes("ts_rank(close, 21)")
    kinds = [p.kind for p in ps]
    assert kinds.count("twist") == 2 and {"rank", "winsorize", "zscore"} <= set(kinds)
    assert probes("rank(close)") and all(p.kind != "twist" for p in probes("ts_delta(close, 3)"))   # 3 < 5: not a window
    out = plan(scope=Scope("USA", 1, "TOP3000"), rows=[{"alpha_id": "A", "expression": "ts_rank(close, 21)",
               "sharpe": 1.6, "neutralization": "MARKET", "decay": 4, "truncation": 0.05}])
    s = out["requests"][0]["settings"]
    assert s["neutralization"] == "MARKET" and s["decay"] == 4 and s["truncation"] == 0.05


# ── Harvest + Diversify (pure) ─────────────────────────────────────────────────────────────────
def _fake_fields():
    return [{"field_id": f"f{i}", "dataset_id": f"d{i % 3}", "coverage": 0.9 - i * 0.01, "alpha_count": 5 + i}
            for i in range(12)]


def _harvester(**kw):
    from app.harness.harvest.seeds import SeedHarvester
    rows = _fake_fields()

    def best(per_dataset, min_alphas, max_alphas, min_coverage, limit, skip):
        by = {}
        for r in rows:
            by.setdefault(r["dataset_id"], []).append(r)
        out = [r for rs in by.values() for r in rs[skip: skip + per_dataset]]
        return out[:limit]
    return SeedHarvester(best_fields=best, dataset_count=lambda a, b, c: 3,
                         lookup=lambda ids: [r for r in rows if r["field_id"] in ids], **kw)


def test_harvest_target_truncation_and_single_batch_key():
    from app.harness.labs.relocate import Scope
    h = _harvester().harvest(Scope("USA", 1, "TOP3000"), target=20)
    assert h.count == 20 and h.truncated
    assert len({(r["settings"]["region"], r["settings"]["delay"], r["settings"]["language"]) for r in h.requests}) == 1
    assert len({r["regular"] for r in h.requests[:3]}) == 3          # field varies fastest -> broad sweep
    from app.harness.harvest.seeds import SeedHarvester
    try:
        _harvester().harvest(Scope("USA", 1, "TOP3000"), group="bogus")
        assert False
    except ValueError:
        pass


def test_harvest_drops_worked_out_shapes_but_never_all():
    from app.harness.labs.relocate import Scope
    sk = lambda e: "Z" if "ts_rank" in e else e          # noqa: E731
    h = _harvester(saturated_shapes={"Z"}, skeleton_of=sk).harvest(Scope("USA", 1, "TOP3000"), target=500)
    assert "ts_rank" in h.worked_out and "ts_rank" not in h.patterns
    from app.harness.harvest.patterns import PATTERNS
    allsat = {sk(p.render("field", 252, "industry")) for p in PATTERNS}
    h = _harvester(saturated_shapes=allsat, skeleton_of=sk).harvest(Scope("USA", 1, "TOP3000"), target=50)
    assert h.worked_out == [] and len(h.patterns) == len(PATTERNS)   # filter must never find nothing


def test_diversify_only_untouched_datasets():
    from app.harness.labs.diversify import plan
    from app.harness.labs.relocate import Scope
    sc = Scope("USA", 1, "TOP3000")
    ds = {"f0": "d0", "f1": "d1"}
    fresh = lambda worked, per, lim: [r for r in _fake_fields() if r["dataset_id"] not in worked][:lim]   # noqa: E731
    out = plan(scope=sc, expressions=["rank(f0)", "rank(f1)"], dataset_of_field=lambda ids: {i: ds[i] for i in ids if i in ds},
               fresh_fields=fresh, harvester=_harvester(), target=30)
    assert out["workedDatasets"] == 2 and out["freshDatasets"] == 1 and out["harvest"].count == 30
    assert all(f["dataset_id"] == "d2" for f in out["fields"])
    out = plan(scope=sc, expressions=["rank(f0)", "rank(f1)", "rank(f2)"], dataset_of_field=lambda ids: {i: f"d{int(i[1:]) % 3}" for i in ids},
               fresh_fields=fresh, harvester=_harvester())
    assert out["harvest"] is None and "already touched every dataset" in out["note"]


# ── Pair (pure) ────────────────────────────────────────────────────────────────────────────────
def _pair_fields(per_dataset):
    return [{"field_id": f"f{i}", "dataset_id": f"d{i % 3}", "coverage": 0.9} for i in range(9)] + \
           [{"field_id": "close", "dataset_id": "price", "coverage": 1.0}]


def test_pair_crosses_datasets_is_seeded_and_fits_power_pool():
    from app.harness.labs.pair import plan
    from app.harness.labs.relocate import Scope
    sc = Scope("USA", 1, "TOP3000")
    a = plan(scope=sc, fields_provider=_pair_fields, target=40, day="2026-10-07")
    b = plan(scope=sc, fields_provider=_pair_fields, target=40, day="2026-10-07")
    c = plan(scope=sc, fields_provider=_pair_fields, target=40, day="2026-10-08")
    assert [r["regular"] for r in a["requests"]] == [r["regular"] for r in b["requests"]]       # stable within a day
    assert [r["regular"] for r in a["requests"]] != [r["regular"] for r in c["requests"]]       # differs tomorrow
    assert all(p["fromDatasets"][0] != p["fromDatasets"][1] for p in a["pairs"])                  # never within a dataset
    assert len(a["requests"]) == 40 and all("ts_backfill(" in r["regular"] for r in a["requests"])


def test_pair_edge_cases():
    from app.harness.labs.pair import plan
    from app.harness.labs.relocate import Scope
    sc = Scope("USA", 1, "TOP3000")
    assert plan(scope=sc, fields_provider=lambda pd: [{"field_id": "x", "dataset_id": "d"}])["requests"] == []
    same = lambda pd: [{"field_id": "x", "dataset_id": "d"}, {"field_id": "y", "dataset_id": "d"}]   # noqa: E731
    assert "same dataset" in plan(scope=sc, fields_provider=same)["note"]
    out = plan(scope=sc, fields_provider=_pair_fields, shapes=["ratio", "link"], known_operators={"ts_corr", "ts_backfill"}, day="d")
    assert out["shapes"] == ["link"]                                                              # ratio's operators missing
    out = plan(scope=sc, fields_provider=_pair_fields, shapes=["ratio"], known_operators={"nothing"}, day="d")
    assert out["shapes"] == ["ratio"]                                                             # never reduce to zero shapes


# ── Vault / mixing (pure) ──────────────────────────────────────────────────────────────────────
def _noise(seed, n=300, mean=0.05):
    import random
    r = random.Random(seed)
    return [r.gauss(mean, 1.0) for _ in range(n)]


def _mixer(series, submitted=()):
    from app.harness.vault.mixing import Mixer
    dates = [f"d{i}" for i in range(300)]
    return Mixer(lambda **k: (series, dates), lambda scope: list(submitted))


def _series(aid, vals, expr, neut="SUBINDUSTRY", sub=False):
    from app.harness.vault.mixing import Series, sharpe_of
    return Series(alpha_id=aid, values=vals, sharpe=sharpe_of(vals), expression=expr, submitted=sub, neutralization=neut)


def test_sharpe_correlation_degenerate_and_mismatch():
    from app.harness.vault.mixing import correlation, sharpe_of
    assert sharpe_of([]) == 0.0 and sharpe_of([1.0]) == 0.0 and sharpe_of([2.0, 2.0, 2.0]) == 0.0
    assert correlation([1.0], [1.0]) == 0.0 and correlation([1, 2, 3], [1, 2, 3]) > 0.999
    try:
        correlation([1, 2], [1, 2, 3])
        assert False
    except ValueError:
        pass


def test_mixing_pairs_uplift_neutralization_and_growth():
    a, b, c = _noise(1), _noise(2), _noise(3)
    dup = [x + 0.01 for x in a]                                   # near-duplicate of a: correlation ~1
    s = [_series("A", a, "rank(a)"), _series("B", b, "rank(b)"), _series("C", c, "rank(c)"),
         _series("DUP", dup, "rank(a)+0"), _series("X", _noise(4), "rank(x)", neut="MARKET")]
    out = _mixer(s).candidates(region="USA", delay=1, universe="TOP3000", sizes=[2, 3], min_sharpe=0.0, min_uplift=None,
                               check_self_correlation=False)
    pairs = {tuple(sorted(g["members"])) for g in out["groups"] if g["size"] == 2}
    assert ("A", "DUP") not in pairs                              # too correlated: mixing buys nothing
    assert not any("X" in g["members"] for g in out["groups"])    # different neutralization never offered
    assert ("A", "B") in pairs and any(g["size"] == 3 for g in out["groups"])
    best = max((g for g in out["groups"] if g["size"] == 2), key=lambda g: g["uplift"])
    assert best["combinedSharpe"] > best["bestMember"] - 1e-9 or best["uplift"] <= 0.5   # uplift is combined - best member


def test_self_correlation_prediction():
    a, b = _noise(1), _noise(2)
    sub_same = {"alpha_id": "S1", "sharpe": 3.0, "by_date": {f"d{i}": v for i, v in enumerate([x + y for x, y in zip(a, b)])}}
    s = [_series("A", a, "rank(a)"), _series("B", b, "rank(b)")]
    out = _mixer(s).candidates(region="USA", delay=1, universe="TOP3000", min_sharpe=0.0, min_uplift=None)
    assert out["groups"][0]["selfCorrelation"]["passes"] and out["groups"][0]["selfCorrelation"]["compared"] == 0   # nothing submitted
    out = _mixer(s, [sub_same]).candidates(region="USA", delay=1, universe="TOP3000", min_sharpe=0.0, min_uplift=None)
    sc = out["groups"][0]["selfCorrelation"]
    assert sc["against"] == "S1" and sc["maxCorrelation"] > 0.7 and not sc["passes"]     # a clone of a submitted alpha, not 10% better
    sparse = _mixer([s[0]]).candidates(region="USA", delay=1, universe="TOP3000", min_sharpe=0.0)
    assert sparse["groups"] == [] and "at least two" in sparse["note"]


def test_backfill_skips_stored_and_survives_failures():
    from app.harness.vault.store import backfill

    class FakeStore:
        def __init__(self): self.rows = {"HAVE": [("2020-01-01", 1.0)]}
        def ids_with_pnl(self, ids): return {i for i in ids if i in self.rows}
        def save(self, a, rows): self.rows[a] = rows

    def fetch(a):
        if a == "BAD":
            raise RuntimeError("boom")
        return [] if a == "EMPTY" else [("2020-01-01", 0.5)]
    out = backfill(FakeStore(), ["HAVE", "NEW", "BAD", "EMPTY"], fetch)
    assert out == {"requested": 3, "stored": 1, "failed": 2, "alreadyStored": 1, "errors": ["BAD: boom"]}


def test_combine_builds_expression_with_every_part():
    from app.harness.vault.combine import build, recommend
    parts = ["rank(a)", "rank(b)"]
    expr = build(parts, strategy=recommend(parts).strategy)
    assert "rank(a)" in expr and "rank(b)" in expr


def test_mix_run_requires_same_scope_and_neutralization():
    from app.harness.vault.mixrun import build_requests
    base = {"instrument_type": "EQUITY", "region": "USA", "delay": 1, "universe": "TOP3000", "neutralization": "INDUSTRY"}
    lk = {"A": {**base, "alpha_id": "A", "expression": "rank(a)"}, "B": {**base, "alpha_id": "B", "expression": "rank(b)"},
          "C": {**base, "alpha_id": "C", "expression": "rank(c)", "neutralization": "MARKET"},
          "D": {**base, "alpha_id": "D", "expression": "rank(d)", "region": "EUR"}}
    reqs, built, problems = build_requests([["A", "B"], ["A", "C"], ["A", "D"], ["A"], ["A", "ZZ"]], lk)
    assert len(reqs) == 1 and built[0]["group"] == ["A", "B"]
    assert reqs[0]["settings"]["decay"] == 0 and reqs[0]["settings"]["neutralization"] == "INDUSTRY"
    reasons = " ".join(p["reason"] for p in problems)
    assert "neutralized differently" in reasons and "different scopes" in reasons and "between two and four" in reasons and "Not found" in reasons


# ── Skeleton ledger + scoring (pure) ───────────────────────────────────────────────────────────
def test_skeleton_shape_and_saturation():
    from app.harness.plan.skeletons import CROWDED_AT, DEAD_AFTER, drop_saturated, saturated_of, skeleton, tally
    assert skeleton("group_rank(ts_rank(ts_backfill(assets, 120), 252), subindustry)") == "group_rank(ts_rank(ts_backfill(F,N),N),subindustry)"
    assert skeleton("x = rank(a); rank(b) * 0.5") == "rank(F)*D"                     # last statement only
    assert skeleton("group_rank(a, sector)") != skeleton("group_rank(a, industry)")   # grouping is part of the shape
    assert skeleton("rank(assets)") == skeleton("rank(sales)")                        # field is not
    recs = tally([("rank(a%d)" % i, False) for i in range(DEAD_AFTER)] +
                 [("ts_rank(b%d, 5)" % i, True) for i in range(CROWDED_AT)] + [("zscore(c)", False)])
    sat = saturated_of(recs)
    assert set(sat) == {"rank(F)", "ts_rank(F,N)"} and "tried" in sat["rank(F)"].why
    keep, dropped = drop_saturated(["rank(q)", "zscore(q)"], sat)
    assert keep == ["zscore(q)"] and dropped == ["rank(q)"]


def test_scoring_build_row_gate():
    import pandas as pd
    from app.harness.scoring import build_row
    sd = {"regular": "rank(close)", "settings": {"region": "USA", "delay": 1, "universe": "TOP3000", "neutralization": "INDUSTRY"}}
    good = {"is_stats": pd.DataFrame([{"sharpe": 1.9, "fitness": 1.2, "turnover": 0.3, "returns": 0.1, "margin": 5, "drawdown": 0.05}]),
            "is_tests": pd.DataFrame([{"name": "X", "result": "PASS"}]),
            "check_submission": pd.DataFrame([{"name": "SELF_CORRELATION", "result": "PASS", "value": 0.4}])}
    r = build_row("A1", sd, good)
    assert r["passed_gate"] and r["gate_reasons"] == "[]" and r["self_corr"] == 0.4 and r["tagged"] == "harness"
    bad = {**good, "is_stats": pd.DataFrame([{"sharpe": 0.9, "fitness": 0.5, "turnover": 55.0}]),   # turnover given as 55 -> 0.55
           "check_submission": pd.DataFrame([{"name": "SELF_CORRELATION", "result": "FAIL", "value": 0.82}])}
    r = build_row("A2", sd, bad)
    import json
    reasons = json.loads(r["gate_reasons"])
    assert not r["passed_gate"] and "self-corr 0.82≥0.7" in reasons and "|Sharpe| 0.90<1.58" in reasons
    assert not build_row("A3", {**sd, "settings": {**sd["settings"], "delay": 0}}, good)["passed_gate"]   # delay-0 needs Sharpe 2.69
    assert not build_row("A4", sd, {})["passed_gate"]                                                     # nothing returned -> not a pass


# ── sqlite3 layer against a database shaped like ACE's ─────────────────────────────────────────
def test_schema_check_reports_missing_tables_and_columns(tmp_path):
    from tests.ace_db import ace_db, SIM_RESULTS
    from app.harness.store import check_ace_schema
    empty = Store(tmp_path / "e.db")
    assert any("'sim_results' is missing" in p for p in check_ace_schema(empty))
    (tmp_path / "a").mkdir()
    with ace_db(tmp_path / "a") as s:
        assert check_ace_schema(s) == []
    (tmp_path / "b").mkdir()
    old = Store(tmp_path / "b" / "old.db")
    old.execute(SIM_RESULTS.replace(" tagged VARCHAR NOT NULL DEFAULT '',", ""))
    assert any("lacks column(s): tagged" in p for p in check_ace_schema(old))


def _seed(s):
    from tests.ace_db import add_alpha, add_dataset, add_field
    for ds, cov in (("d1", 0.9), ("d2", 0.8), ("d3", 0.4), ("dz", 0.0)):
        add_dataset(s, ds, coverage=cov)
    add_dataset(s, "d1", region="EUR", universe="TOP2500")
    for i, (f, d, n) in enumerate([("a1", "d1", 9), ("a2", "d1", 4), ("b1", "d2", 6), ("c1", "d3", 7), ("z1", "dz", 8),
                                   ("close", "price", 50)]):
        add_field(s, f, d, alpha_count=n)
    add_field(s, "a1", "d1", region="EUR", alpha_count=3)
    add_field(s, "v1", "d1", type_="VECTOR", alpha_count=9)
    add_alpha(s, "X1", "rank(a1)", 2.0)
    add_alpha(s, "X1", "rank(a1)", 2.0)                     # duplicate row for the same alpha
    add_alpha(s, "X2", "rank(b1)", -1.8, neut="MARKET")
    add_alpha(s, "X3", "rank(c1)", 0.5, submitted=1)
    add_alpha(s, "X4", "rank(z1)", None)
    add_alpha(s, "E1", "rank(a1)", 3.0, region="EUR", universe="TOP2500")


def test_ace_sources_alpha_and_field_queries(tmp_path):
    from tests.ace_db import ace_db
    from app.harness.labs import ace_sources as src
    from app.harness.payload import Scope
    with ace_db(tmp_path) as s:
        _seed(s)
        us = Scope("USA", 1, "TOP3000")
        ids = [a["alpha_id"] for a in src.scoped_alphas(us)]
        assert ids == ["X1", "X2", "X3", "X4"] or ids[:3] == ["X1", "X2", "X3"]            # strongest |Sharpe| first, deduped
        assert [a["alpha_id"] for a in src.winners(us, 1.5, 10)] == ["X1", "X2"]            # |Sharpe| >= 1.5, negatives count
        assert [a["alpha_id"] for a in src.scoped_alphas(us, min_abs_sharpe=0.0)] == ["X1", "X2", "X3"]   # no-Sharpe row excluded
        assert [a["alpha_id"] for a in src.scoped_alphas(us, neutralization="MARKET")] == ["X2"]
        assert [a["alpha_id"] for a in src.scoped_alphas(us, submitted=True)] == ["X3"]
        assert [a["alpha_id"] for a in src.scoped_alphas(us, submitted=False, min_abs_sharpe=0.0)] == ["X1", "X2"]
        assert {sc.label for sc in src.scopes()} == {"EQUITY/USA/D1/TOP3000", "EQUITY/EUR/D1/TOP2500"}
        assert src.fields_in_scope(us) >= {"a1", "b1", "close"} and "a1" in src.fields_in_scope(Scope("EUR", 1, "TOP2500"))
        # best_fields: MATRIX only, least-worked first within a dataset, dataset coverage threshold (0.0 = unknown, kept)
        got = {f["field_id"] for f in src.best_fields(us, per_dataset=5, min_alphas=1, min_coverage=0.6)}
        assert got == {"a1", "a2", "b1", "z1", "close"} and "c1" not in got and "v1" not in got
        assert src.dataset_count(us, 1, None, 0.6) == 4        # d1, d2, dz (coverage unknown), price (no dataset row -> unknown)
        assert [f["field_id"] for f in src.lookup_fields(us, ["b1", "nope", "a1"])] == ["b1", "a1"]
        assert src.dataset_of_field(us, {"a1", "b1"}) == {"a1": "d1", "b1": "d2"}
        fresh = {f["dataset_id"] for f in src.fresh_fields(us, worked={"d1"}, per_dataset=1, limit=10, min_coverage=0.5)}
        assert "d1" not in fresh and "d2" in fresh and "d3" not in fresh
        assert sorted(src.scope_expressions(us))[:2] == ["rank(a1)", "rank(a1)"]
        rec = src.shape_records(us)
        assert rec["rank(F)"].tried == 5 and rec["rank(F)"].submittable == 0


def test_repair_rows_use_cached_brain_info(tmp_path):
    import json
    import time
    from tests.ace_db import ace_db, add_alpha
    from app.harness.labs import ace_sources as src
    from app.harness.payload import Scope
    with ace_db(tmp_path) as s:
        add_alpha(s, "R1", "rank(a)", 1.4)
        add_alpha(s, "R2", "rank(b)", 1.2, submitted=1)           # submitted: never a repair seed
        add_alpha(s, "R3", "rank(c)", 1.1, passed=1)              # already passes: nothing to repair
        add_alpha(s, "R4", "rank(d)", 1.0)                        # no cached info and the fetch budget is 0 -> skipped
        s.execute("INSERT INTO harness_alpha_info VALUES (?,?,?,?,?)",
                  ("R1", json.dumps({"decay": 3, "truncation": 0.05, "neutralization": "MARKET"}),
                   json.dumps([{"name": "HIGH_TURNOVER", "result": "FAIL"}]), "UNSUBMITTED", time.time()))
        rows = src.repair_rows(Scope("USA", 1, "TOP3000"), max_fetch=0)
        assert [r["alpha_id"] for r in rows] == ["R1"]
        assert rows[0]["decay"] == 3 and rows[0]["neutralization"] == "MARKET" and rows[0]["checks"][0]["name"] == "HIGH_TURNOVER"
        strong = src.strong_rows(Scope("USA", 1, "TOP3000"), 1.3, 10, max_fetch=0)
        assert [r["alpha_id"] for r in strong] == ["R1"] and strong[0]["truncation"] == 0.05


def _fake_stats(sharpe=2.0):
    import pandas as pd
    return {"is_stats": pd.DataFrame([{"sharpe": sharpe, "fitness": 1.2, "turnover": 0.3, "returns": 0.1}]),
            "is_tests": pd.DataFrame([{"name": "X", "result": "PASS"}]),
            "check_submission": pd.DataFrame([{"name": "SELF_CORRELATION", "result": "PASS", "value": 0.2}])}


def test_scorer_writes_sim_results_and_keeps_dedup(tmp_path):
    from tests.ace_db import ace_db
    from app.harness.scoring import score_pending
    with ace_db(tmp_path) as s:
        tr = Tracker(s, tmp_path / "j.jsonl")
        r = tr.enqueue("relocate", sim("rank(a)"))
        tr.claim([r["record_id"]], "B")
        tr.complete(r["record_id"], "ALPHA1")
        calls = []
        out = score_pending(fetch=lambda aid, sd: calls.append(aid) or _fake_stats(), store=s)
        assert out == {"scored": 1, "failed": 0} and calls == ["ALPHA1"]
        row = s.query("SELECT * FROM sim_results WHERE alpha_id='ALPHA1'")[0]
        assert row["tagged"] == "harness" and row["passed_gate"] == 1 and row["region"] == "USA" and row["expression"] == "rank(a)"
        assert tr.counts() == {"scored": 1}
        assert tr.enqueue("relocate", sim("rank(a)"))["duplicate"]                     # a scored alpha is still a duplicate
        assert score_pending(fetch=lambda *a: 1 / 0, store=s) == {"scored": 0, "failed": 0}   # nothing left to score


def test_scorer_survives_older_ace_layout_and_fetch_errors(tmp_path):
    from tests.ace_db import ace_db, SIM_RESULTS
    from app.harness.scoring import score_pending
    old = SIM_RESULTS.replace(" margin FLOAT, drawdown FLOAT,", "")                     # a DB from before margin/drawdown existed
    with ace_db(tmp_path, sim_results=old) as s:
        tr = Tracker(s, tmp_path / "j.jsonl")
        ids = [tr.enqueue("t", sim(f"rank(x{i})"))["record_id"] for i in range(2)]
        tr.claim(ids, "B")
        tr.complete(ids[0], "OK1")
        tr.complete(ids[1], "BAD1")
        def fetch(aid, sd):
            if aid == "BAD1":
                raise RuntimeError("BRAIN down")
            return _fake_stats()
        assert score_pending(fetch=fetch, store=s) == {"scored": 1, "failed": 1}
        assert tr.counts() == {"scored": 1, "done": 1}                                  # the failed one stays 'done' to retry


def test_vault_series_mixing_and_partners_over_sqlite(tmp_path):
    import json
    from tests.ace_db import ace_db, add_alpha
    from app.harness.vault import ace_vault as v
    from app.harness.vault.mixrun import build_requests
    with ace_db(tmp_path) as s:
        a, b = _noise(1), _noise(2)
        mix = [x + y for x, y in zip(a, b)]
        from app.harness.vault.mixing import sharpe_of
        for aid, expr, vals, sub in (("A", "rank(a)", a, 0), ("B", "rank(b)", b, 0), ("S", "rank(a)+rank(b)", mix, 1)):
            add_alpha(s, aid, expr, round(sharpe_of(vals), 3), submitted=sub)      # stored Sharpe = the series' true Sharpe
            assert v.pnl_store().save(aid, [(f"d{i:03d}", x) for i, x in enumerate(vals)]) == 300
        assert v.pnl_store().save("A", [("d000", 99.0)]) == 0                           # existing days are never overwritten
        assert v.pnl_store().ids_with_pnl(["A", "Z"]) == {"A"}
        series, dates = v.load_series(region="USA", delay=1, universe="TOP3000", min_sharpe=0.0)
        assert {x.alpha_id for x in series} == {"A", "B", "S"} and len(dates) == 300
        assert {x.alpha_id for x in v.load_series(region="USA", delay=1, universe="TOP3000", min_sharpe=0.0, include_submitted=False)[0]} == {"A", "B"}
        out = v.mixer.candidates(region="USA", delay=1, universe="TOP3000", min_sharpe=0.0, min_uplift=None, include_submitted=False)
        sc = out["groups"][0]["selfCorrelation"]
        assert sc["against"] == "S" and sc["maxCorrelation"] > 0.99 and not sc["passes"]   # A+B is a clone of the submitted S, not 10% better
        assert v.closest_partners("USA", 1, "TOP3000", {"A"}) == {"A": "rank(a)+rank(b)"}   # S correlates with A most
        lk = v.by_ids(["A", "B", "nope"])
        assert set(lk) == {"A", "B"} and lk["A"]["instrument_type"] == "EQUITY"
        reqs, built, problems = build_requests([["A", "B"]], lk)
        assert len(reqs) == 1 and problems == [] and "rank(a)" in built[0]["expression"]


# ── Autosentry routing ──────────────────────────────────────────────────────────────────────────
class RoutePort:
    class SlotBusy(RuntimeError):
        pass

    def __init__(self, gate=None):
        import threading
        self.gate, self.lock, self.active, self.max_active, self.started, self.tags = gate, threading.Lock(), 0, 0, [], []

    def start(self, payload):
        with self.lock:
            self.active += 1
            self.max_active = max(self.max_active, self.active)
            self.started.append(payload)
            n = len(self.started)
        h = type("H", (), {})()
        h.sim_url, h.multi = f"https://x/{n}", isinstance(payload, list)
        return h

    def adopt(self, url, multi):
        h = type("H", (), {})()
        h.sim_url, h.multi = url, multi
        return h

    def wait(self, handle, payload, tag="harness"):
        self.tags.append(tag)
        if self.gate:
            self.gate.wait(10)
        time.sleep(0.02)
        with self.lock:
            self.active -= 1
        ps = payload if isinstance(payload, list) else [payload]
        if any("BOOM" in p["regular"] for p in ps):
            raise RuntimeError("boom: BRAIN fell over")
        rows = [{"alpha_id": f"A_{p['regular']}", "simulate_data": p} for p in ps if "ERR" not in p["regular"]]
        return rows + [{"alpha_id": None, "simulate_data": {}, "error": "bad operator"} for p in ps if "ERR" in p["regular"]]


def _routing(monkeypatch, on=True):
    import app.harness.autopilot_route as ar
    monkeypatch.setattr(ar.flags, "enabled", lambda name: on and name == "autopilot_via_engine")
    return ar


def _batches(n_batches, size=3, tag=""):
    return [[sim(f"{tag}e{b}_{i}") for i in range(size)] for b in range(n_batches)]


def test_route_is_off_unless_wrapped_and_flag_on(monkeypatch):
    ar = _routing(monkeypatch, on=False)
    assert ar.maybe_route(_batches(1), 2, lambda **k: None, lambda: False, 3) is None          # not inside engine_routing
    with ar.engine_routing():
        assert not ar.routing_on() and ar.maybe_route(_batches(1), 2, lambda **k: None, lambda: False, 3) is None   # flag off
    ar = _routing(monkeypatch, on=True)
    assert not ar.routing_on()                                                                  # flag on but not wrapped
    with ar.engine_routing():
        assert ar.routing_on()
    assert not ar.routing_on()                                                                  # context restored


def test_route_shares_slots_journals_and_returns_original_shape(monkeypatch, tmp_path):
    ar = _routing(monkeypatch)
    tr, port, lease = make_tracker(tmp_path), RoutePort(), SlotLease(2)
    batches = _batches(5) + [[sim("single")]]                                   # five multi batches and a lone leftover
    logs = []
    with ar.engine_routing():
        flat, done, cancelled, errors = ar.maybe_route(batches, 8, lambda **k: logs.append(k), lambda: False, 16,
                                                       port=port, lease=lease, tracker=tr, poll=0.05)
    assert done == 16 and len(flat) == 16 and not cancelled and errors == []
    assert all(set(x) == {"alpha_id", "simulate_data"} for x in flat)                          # same row shape as ace_lib
    assert port.max_active <= 2                                                                # never more than the shared lease
    assert set(port.tags) == {"ace_tag"}                                                       # ACE's own BRAIN-side tag
    assert sum(isinstance(p, dict) for p in port.started) == 1 and sum(isinstance(p, list) for p in port.started) == 5   # lone alpha = single sim
    assert lease.free() == 2 and tr.counts() == {"external": 16} and tr.orphan_batches() == []
    assert tr.enqueue("t", sim("e0_0"))["duplicate"]                                           # simulated by Autosentry = already known


def test_route_collects_errors_like_the_original_loop(monkeypatch, tmp_path):
    ar = _routing(monkeypatch)
    tr, port = make_tracker(tmp_path), RoutePort()
    batches = [[sim("ok1"), sim("ERR1"), sim("ok2")], [sim("BOOM1"), sim("x")], [sim("ok3"), sim("ok4")]]
    logs = []
    with ar.engine_routing():
        flat, done, cancelled, errors = ar.maybe_route(batches, 3, lambda **k: logs.append(k), lambda: False, 7,
                                                       port=port, lease=SlotLease(8), tracker=tr, poll=0.05)
    assert done == 4 and {x["alpha_id"] for x in flat} == {"A_ok1", "A_ok2", "A_ok3", "A_ok4"}
    assert "bad operator" in errors and "boom: BRAIN fell over" in errors
    assert any("BATCH ERROR: boom" in str(k.get("log")) for k in logs)
    assert tr.counts() == {"external": 5, "error": 2} and tr.orphan_batches() == []             # failed batch is closed, not orphaned


def test_route_waits_for_a_slot_the_engine_holds(monkeypatch, tmp_path):
    import threading
    ar = _routing(monkeypatch)
    tr, port, lease = make_tracker(tmp_path), RoutePort(), SlotLease(2)
    assert lease.acquire("harness", 2)                                                         # the harness engine has every slot
    res = {}

    def go():
        with ar.engine_routing():
            res["r"] = ar.maybe_route(_batches(2), 4, lambda **k: None, lambda: False, 6, port=port, lease=lease, tracker=tr, poll=0.05)
    th = threading.Thread(target=go)
    th.start()
    time.sleep(0.4)
    assert port.started == []                                                                  # nothing starts while slots are taken
    lease.release("harness", 2)
    th.join(5)
    assert not th.is_alive() and res["r"][1] == 6 and lease.free() == 2


def test_route_stop_returns_fast_and_slots_free_when_brain_finishes(monkeypatch, tmp_path):
    import threading
    ar = _routing(monkeypatch)
    gate = threading.Event()
    tr, port, lease = make_tracker(tmp_path), RoutePort(gate), SlotLease(2)
    flag, logs = {"stop": False}, []
    threading.Timer(0.3, lambda: flag.update(stop=True)).start()
    t0 = time.time()
    with ar.engine_routing():
        flat, done, cancelled, errors = ar.maybe_route(_batches(6), 8, lambda **k: logs.append(k), lambda: flag["stop"], 18,
                                                       port=port, lease=lease, tracker=tr, poll=0.05)
    assert cancelled and time.time() - t0 < 2.5 and done == 0                                  # abandoned at once (like pool.terminate)
    assert any(k.get("log") == "STOP requested" for k in logs) and len(port.started) == 2      # queued batches never started
    assert lease.free() == 0                                                                   # BRAIN still has those 2 sims running
    gate.set()
    for _ in range(100):
        if lease.free() == 2:
            break
        time.sleep(0.05)
    assert lease.free() == 2 and tr.orphan_batches() == []                                     # released only when really finished


def test_crashed_autopilot_batch_is_rescued_by_orphan_adoption(tmp_path):
    tr = make_tracker(tmp_path)
    payloads = [sim("r1"), sim("r2")]
    ids = tr.register_running("autopilot", payloads, "AP1")
    tr.batch_started("AP1", "https://x/ap1", ids, True)                                        # ...then the app dies
    assert tr.counts() == {"running": 2} and tr.queued_items() == []                            # never picked up as queue work
    port = FakePort()
    eng = BatchEngine(tr, port=port, lease=SlotLease(8))
    eng._adopt_orphans()
    for _ in range(100):
        if tr.counts().get("done") == 2:
            break
        time.sleep(0.05)
    assert tr.counts() == {"done": 2} and port.started == [] and tr.orphan_batches() == []     # finished by re-attaching, no re-simulate


def test_engine_leaves_a_slot_for_a_waiting_autopilot_worker(tmp_path):
    lease = SlotLease(4)
    lease.acquire("harness", 2)
    lease.begin_wait("autopilot")                                  # one Autosentry worker is blocked
    assert lease.free() == 2 and lease.free_for("harness") == 1 and lease.free_for("autopilot") == 2
    tr = make_tracker(tmp_path)
    tr.enqueue_many("t", [sim(f"w{i}") for i in range(40)])         # four full batches' worth
    eng = BatchEngine(tr, port=FakePort(), lease=lease, poll_interval=0.05)
    eng.dry_run = True                                              # count scheduling only; no simulate
    assert eng.tick() == 1                                          # engine takes ONE slot, not both
    lease.end_wait("autopilot")
    assert lease.free_for("harness") >= 1 and lease.snapshot()["waiting"] == {}


# ── learning hooks, row matching, yield book ───────────────────────────────────────────────────
def test_scorer_feeds_ace_learning_once_per_new_alpha(tmp_path):
    from tests.ace_db import ace_db, add_alpha
    from app.harness.scoring import score_pending
    with ace_db(tmp_path) as s:
        tr = Tracker(s, tmp_path / "j.jsonl")
        ids = [tr.enqueue("t", sim(f"rank(x{i})"))["record_id"] for i in range(3)]
        tr.claim(ids, "B")
        for i, rid in enumerate(ids):
            tr.complete(rid, f"L{i}")
        add_alpha(s, "L2", "rank(x2)", 1.0)                                      # ACE already has this alpha's result
        seen = []
        out = score_pending(fetch=lambda aid, sd: _fake_stats(), store=s, learn=lambda row: seen.append(row))
        assert out == {"scored": 3, "failed": 0}
        assert sorted(r["alpha_id"] for r in seen) == ["L0", "L1"]               # no double credit for an existing result
        r = seen[0]
        assert r["region"] == "USA" and r["fitness"] == 1.2 and r["passed_gate"] == 1 and r["expression"].startswith("rank(x")
        # a crashing hook must never cost the stored result
        tr.enqueue("t", sim("rank(y)"))
        rid = tr.queued_items()[0].record_id
        tr.claim([rid], "B2")
        tr.complete(rid, "L9")
        assert score_pending(fetch=lambda a, b: _fake_stats(), store=s, learn=lambda row: 1 / 0) == {"scored": 1, "failed": 0}
        assert s.query("SELECT COUNT(*) AS n FROM sim_results WHERE alpha_id='L9'")[0]["n"] == 1


def test_match_rows_by_expression_and_lone_fallback():
    from app.harness.engine.match import match_rows
    ps = [sim("a"), sim("b"), sim("c")]
    rows = [{"alpha_id": "B1", "simulate_data": {"regular": "b"}}, {"alpha_id": "A1", "simulate_data": {"regular": "a"}},
            {"alpha_id": None, "simulate_data": {}, "error": "bad op"}]
    assert match_rows(ps, rows) == (["A1", "B1", None], ["bad op"])
    assert match_rows([sim("x")], [{"alpha_id": "Z", "simulate_data": {"regular": "x_normalised"}}])[0] == ["Z"]   # lone alpha
    assert match_rows([sim("x"), sim("y")], [{"alpha_id": "Z", "simulate_data": {"regular": "q"}}])[0] == [None, None]
    dup = match_rows([sim("a"), sim("a")], [{"alpha_id": "A1", "simulate_data": {"regular": "a"}},
                                            {"alpha_id": "A2", "simulate_data": {"regular": "a"}}])[0]
    assert dup == ["A1", "A2"]                                                                                   # same expr, two settings


def test_routed_autopilot_records_keep_alpha_ids_for_yield(monkeypatch, tmp_path):
    ar = _routing(monkeypatch)
    tr, port = make_tracker(tmp_path), RoutePort()
    with ar.engine_routing():
        ar.maybe_route([[sim("p1"), sim("p2"), sim("ERR3")]], 2, lambda **k: None, lambda: False, 3,
                       port=port, lease=SlotLease(8), tracker=tr, poll=0.05)
    rows = {r["payload"]["regular"]: r for r in tr.records(list(range(1, 4)))}
    assert rows["p1"]["status"] == "external" and rows["p1"]["alpha_id"] == "A_p1" and rows["p2"]["alpha_id"] == "A_p2"
    assert rows["ERR3"]["alpha_id"] == ""                                                                        # BRAIN returned an error for it


def test_yield_book_per_lab_with_honest_denominator(tmp_path):
    import time
    from tests.ace_db import ace_db, add_alpha
    from app.harness.plan import yields as Y
    with ace_db(tmp_path) as s:
        tr = Tracker(s, tmp_path / "j.jsonl")
        def rec(task, status, alpha=""):
            r = tr.enqueue(task, sim(f"{task}-{status}-{alpha}-{time.time_ns()}"))["record_id"]
            s.execute("UPDATE harness_sim_record SET status=?, alpha_id=? WHERE id=?", (status, alpha, r))
        for i in range(4):
            rec("repair-2026-10-07-1", "scored", f"R{i}")                                  # task names may carry a day
        rec("repair", "error")                                                              # attempted, never finished
        rec("repair", "queued")                                                             # not finished: never in the denominator
        rec("pair", "dryrun")                                                               # dry run: never simulated
        rec("autopilot", "external", "P1")
        rec("autopilot", "external", "P2")
        add_alpha(s, "R0", "a", 2.0, passed=1); add_alpha(s, "R1", "b", 1.0, passed=1); add_alpha(s, "R2", "c", 0.4)
        add_alpha(s, "P1", "d", 3.0, passed=1)
        b = Y.by_lab(s)
        r = b["repair"]
        assert (r.simulated, r.finished, r.alphas, r.passing, r.best_sharpe) == (5, 4, 4, 2, 2.0)
        assert "pair" not in b and b["autopilot"].passing == 1 and b["autopilot"].finished == 2
        d = r.to_dict()
        assert d["yieldRate"] == 0.5 and d["meetsTarget"] and not d["confident"]            # 4 results are not a trend
        sm = Y.summary(s)
        assert sm["labs"][0]["lab"] == "repair" and sm["finished"] == 6 and sm["passing"] == 3
        assert "3 of your last 6" in sm["plainly"]
        assert Y.summary(s, days=14, now=time.time() + 40 * 86400)["finished"] == 0          # outside the window
        assert "Nothing has finished" in Y.summary(s, days=14, now=time.time() + 40 * 86400)["plainly"]
