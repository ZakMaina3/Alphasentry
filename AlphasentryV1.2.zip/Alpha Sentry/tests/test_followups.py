"""Autosentry follow-ups: reverse only below -1, boost every alpha above 1, and both ride in the NEXT standard batch."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.autopilot import followups as FU


def _norm(e): return "".join(e.split()).lower()
def _flip(e): return f"-1 * ({e})"
def _apply(e, b): return f"{b['name']}({e})"
def _elig(r, b, trig): return (r.get("sharpe") or 0) >= (b.get("min_sharpe") or trig)


B1, B2 = {"name": "decay", "id": 1}, {"name": "trade_when", "id": 2, "min_sharpe": 1.5}


def plan(rows, **kw):
    a = dict(flip_on=True, flip_at=1.0, trigger=1.0, max_turnover=0.7, boosters=[B1, B2], eligible=_elig, apply_booster=_apply,
             flip_expr=_flip, norm=_norm, seen=set(), queued=set())
    a.update(kw)
    return FU.plan(rows, **a)


def row(expr, sh, tu=0.3, passed=False, kind=""):
    return {"expr": expr, "sharpe": sh, "turnover": tu, "passed": passed, "_kind": kind}


def test_reverse_only_below_minus_one():
    items = plan([row("a", -1.01), row("b", -1.0), row("c", -0.99), row("d", -0.2), row("e", 0.3)], boosters=[])
    assert [(i[0], i[2]) for i in items] == [("-1 * (a)", "flip")]            # -1.0 itself and anything above is left alone


def test_a_negative_fitness_alone_no_longer_triggers_a_reversal():
    r = row("x", -0.6); r["fitness"] = -0.5
    assert plan([r], boosters=[]) == []


def test_every_alpha_above_one_is_boosted_not_just_the_top_three():
    rows = [row(f"s{i}", 1.1 + i / 100) for i in range(8)]
    items = plan(rows, boosters=[B1])
    assert len(items) == 8 and all(i[2] == "boost" for i in items)
    assert plan([row("edge", 1.0)], boosters=[B1]) == []                       # strictly above 1


def test_a_boosters_own_threshold_still_wins_and_passers_are_not_boosted():
    items = plan([row("p", 1.2), row("q", 1.7), row("done", 2.0, passed=True)])
    got = sorted((i[0], i[2]) for i in items)
    assert got == [("decay(p)", "boost"), ("decay(q)", "boost"), ("trade_when(q)", "boost")]


def test_reverse_then_boost_but_never_a_chain():
    items = plan([row("-1 * (a)", 1.4, kind="flip"), row("decay(z)", 1.4, kind="boost"), row("w", -1.5, kind="flip")], boosters=[B1])
    assert [(i[0], i[2]) for i in items] == [("decay(-1 * (a))", "flip+boost")]   # a reversed alpha is boosted; boosted/flipped ones are not re-reversed


def test_high_turnover_negatives_are_not_reversed_and_duplicates_are_skipped():
    assert plan([row("hot", -2.0, tu=0.9)], boosters=[]) == []
    assert plan([row("a", -2.0)], boosters=[], seen={_norm("-1 * (a)")}) == []
    assert plan([row("a", -2.0)], boosters=[], queued={_norm("-1 * (a)")}) == []


def test_follow_ups_ride_in_the_next_standard_batch_and_leave_room_for_new_ideas():
    carry = [(f"f{i}", {}, "boost", B1) for i in range(30)]
    new = [f"n{i}" for i in range(10)]
    exprs, meta, used = FU.compose(carry, new, 10)
    assert len(exprs) == 10 and len(meta) == 8 and used == ["n0", "n1"]       # 10 per batch; 8 follow-ups + 2 new
    assert len(carry) == 22                                                     # the rest wait for the batch after
    exprs, meta, used = FU.compose(carry, [], 10)
    assert len(exprs) == 10 and used == [] and len(carry) == 12                 # no new ideas: follow-ups use the whole batch
    exprs, meta, used = FU.compose([], new, 10)
    assert exprs == new and meta == {} and used == new                          # nothing queued: a plain batch of 10


def test_small_queue_shares_the_batch_with_new_expressions():
    carry = [("f1", {}, "flip", None), ("f2", {}, "boost", B1)]
    exprs, meta, used = FU.compose(carry, [f"n{i}" for i in range(10)], 10)
    assert exprs[:2] == ["f1", "f2"] and len(exprs) == 10 and len(used) == 8 and carry == []
