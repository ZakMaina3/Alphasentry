CREATE TABLE harness_alpha_info (
        alpha_id TEXT PRIMARY KEY, settings_json TEXT NOT NULL DEFAULT '{}', checks_json TEXT NOT NULL DEFAULT '[]',
        status TEXT NOT NULL DEFAULT '', fetched REAL NOT NULL);
CREATE TABLE hypothesis_log (
	id INTEGER NOT NULL, 
	fingerprint VARCHAR NOT NULL, 
	category VARCHAR NOT NULL, 
	region VARCHAR NOT NULL, 
	idea TEXT NOT NULL, 
	times_suggested INTEGER NOT NULL, 
	first_suggested_at FLOAT NOT NULL, 
	last_suggested_at FLOAT NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_hypothesis UNIQUE (fingerprint, category, region)
);
CREATE TABLE sim_results (
	id INTEGER NOT NULL, 
	created_at FLOAT NOT NULL, 
	alpha_id VARCHAR NOT NULL, 
	expression TEXT NOT NULL, 
	region VARCHAR NOT NULL, 
	delay INTEGER NOT NULL, 
	universe VARCHAR NOT NULL, 
	neutralization VARCHAR NOT NULL, 
	sharpe FLOAT, 
	fitness FLOAT, 
	turnover FLOAT, 
	returns FLOAT, 
	margin FLOAT, 
	drawdown FLOAT, 
	self_corr FLOAT, 
	prod_corr FLOAT, 
	powerpool_corr FLOAT, 
	tests_failed INTEGER NOT NULL, 
	passed_gate BOOLEAN NOT NULL, 
	gate_reasons TEXT NOT NULL, 
	n_ops INTEGER NOT NULL, 
	tagged VARCHAR NOT NULL, 
	submitted BOOLEAN NOT NULL, 
	submitted_at FLOAT, 
	PRIMARY KEY (id)
);
CREATE TABLE template_stats (
	id INTEGER NOT NULL, 
	skeleton TEXT NOT NULL, 
	region VARCHAR NOT NULL, 
	category VARCHAR NOT NULL, 
	pass_count INTEGER NOT NULL, 
	fail_count INTEGER NOT NULL, 
	best_fitness FLOAT NOT NULL, 
	best_sharpe FLOAT NOT NULL, 
	example_expression TEXT NOT NULL, 
	last_used_at FLOAT NOT NULL, 
	blocked BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_template_region UNIQUE (skeleton, region)
);
CREATE TABLE usage (
	id INTEGER NOT NULL, 
	kind VARCHAR NOT NULL, 
	"key" VARCHAR NOT NULL, 
	region VARCHAR NOT NULL, 
	count INTEGER NOT NULL, 
	sum_abs_fitness FLOAT NOT NULL, 
	last_at FLOAT NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_usage UNIQUE (kind, "key", region)
);
CREATE TABLE vault_alphas (
	id INTEGER NOT NULL, 
	created_at FLOAT NOT NULL, 
	updated_at FLOAT NOT NULL, 
	alpha_id VARCHAR NOT NULL, 
	expression TEXT NOT NULL, 
	region VARCHAR NOT NULL, 
	delay INTEGER NOT NULL, 
	universe VARCHAR NOT NULL, 
	neutralization VARCHAR NOT NULL, 
	sharpe FLOAT, 
	fitness FLOAT, 
	turnover FLOAT, 
	status VARCHAR NOT NULL, 
	note TEXT NOT NULL, 
	tags_json TEXT NOT NULL, 
	source_sim_result_id INTEGER NOT NULL, 
	PRIMARY KEY (id)
);
