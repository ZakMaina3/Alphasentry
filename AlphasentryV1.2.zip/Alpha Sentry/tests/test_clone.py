"""Clone and swap: similar datafields, the similarity slider, safe expression swaps, round-robin planning."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.autopilot import clone as CL


def norm(e): return "".join(e.split()).lower()


CAT = [
    {"field_id": "oth143_buy_tier1_broker_rank1", "dataset_id": "oth143", "type": "MATRIX", "description": "Rank of tier 1 brokers by buy volume"},
    {"field_id": "oth143_sell_tier1_broker_rank1", "dataset_id": "oth143", "type": "MATRIX", "description": "Rank of tier 1 brokers by sell volume"},
    {"field_id": "oth143_short_sell_tier1_broker_rank1", "dataset_id": "oth143", "type": "MATRIX", "description": "Rank of tier 1 brokers by short sell volume"},
    {"field_id": "oth143_buy_tier2_broker_rank1", "dataset_id": "oth143", "type": "MATRIX", "description": "Rank of tier 2 brokers by buy volume"},
    {"field_id": "mdl77_broker_flow", "dataset_id": "mdl77", "type": "MATRIX", "description": "Broker buy flow score from the model"},
    {"field_id": "fnd6_eps", "dataset_id": "fnd6", "type": "MATRIX", "description": "Earnings per share fundamental"},
    {"field_id": "anl4_eps_est", "dataset_id": "anl4", "type": "MATRIX", "description": "Analyst earnings per share estimate"},
    {"field_id": "nws18_buy_vec", "dataset_id": "nws18", "type": "VECTOR", "description": "Broker buy news vector"},
]
IDX = CL.Index(CAT)
BASE = "oth143_buy_tier1_broker_rank1"


def test_the_nearest_fields_are_the_sibling_variants():
    got = [f for f, _ in CL.similar(IDX, BASE, slider=0.5, top=3)]
    assert got[0] in ("oth143_sell_tier1_broker_rank1", "oth143_short_sell_tier1_broker_rank1", "oth143_buy_tier2_broker_rank1")
    assert "fnd6_eps" not in got


def test_slider_zero_is_same_dataset_only_and_one_is_other_datasets_only():
    same = [f for f, _ in CL.similar(IDX, BASE, slider=0.0, top=10, min_sim=0)]
    other = [f for f, _ in CL.similar(IDX, BASE, slider=1.0, top=10, min_sim=0)]
    assert same and all(CAT_ds(f) == "oth143" for f in same)
    assert other and all(CAT_ds(f) != "oth143" for f in other)


def CAT_ds(f): return IDX.rows[f]["dataset_id"]


def test_other_dataset_mode_still_ranks_by_meaning_broker_flow_before_eps():
    other = [f for f, _ in CL.similar(IDX, BASE, slider=1.0, top=10, min_sim=0)]
    assert other.index("mdl77_broker_flow") < other.index("fnd6_eps")


def test_types_must_match_so_vec_wrappers_stay_valid():
    got = [f for f, _ in CL.similar(IDX, BASE, slider=0.5, top=20, min_sim=0)]
    assert "nws18_buy_vec" not in got
    assert BASE not in got


def test_excluded_fields_and_weak_matches_are_left_out():
    got = [f for f, _ in CL.similar(IDX, BASE, slider=0.5, top=20, exclude={"oth143_sell_tier1_broker_rank1"})]
    assert "oth143_sell_tier1_broker_rank1" not in got
    assert all(s >= 0.08 for _, s in CL.similar(IDX, BASE, slider=0.5, top=20))


def test_swap_only_replaces_the_whole_field_name():
    e = "rank(ts_mean(oth143_buy_tier1_broker_rank1, 20)) + oth143_buy_tier1_broker_rank10"
    out = CL.swap_expression(e, "oth143_buy_tier1_broker_rank1", "mdl77_broker_flow")
    assert out == "rank(ts_mean(mdl77_broker_flow, 20)) + oth143_buy_tier1_broker_rank10"


def test_plan_keeps_the_shape_caps_per_alpha_and_skips_seen():
    src = [{"id": "A1", "expr": f"rank(ts_mean({BASE}, 20))"}]
    plan = CL.plan_swaps(src, CAT, 0.5, per_alpha=3, seen=set(), norm=norm)
    assert len(plan) == 3 and all(p["expr"].startswith("rank(ts_mean(") and p["expr"].endswith(", 20))") and p["old"] == BASE for p in plan)
    assert all(p["new"] != BASE and p["source_id"] == "A1" for p in plan)
    seen = {norm(plan[0]["expr"])}
    plan2 = CL.plan_swaps(src, CAT, 0.5, 3, seen, norm)
    assert norm(plan[0]["expr"]) not in {norm(p["expr"]) for p in plan2}


def test_plan_mixes_sources_round_robin_and_never_duplicates():
    src = [{"id": "A1", "expr": f"rank({BASE})"}, {"id": "A2", "expr": "rank(fnd6_eps)"}, {"id": "A3", "expr": "rank(close)"}]
    plan = CL.plan_swaps(src, CAT, 0.5, 4, set(), norm)
    ids = [p["source_id"] for p in plan]
    assert ids[:2] == ["A1", "A2"] and "A3" not in ids                       # A3 has no catalogue field: nothing to swap
    assert len({norm(p["expr"]) for p in plan}) == len(plan)


def test_two_field_alphas_swap_one_field_at_a_time():
    src = [{"id": "A1", "expr": "rank(fnd6_eps / oth143_buy_tier1_broker_rank1)"}]
    plan = CL.plan_swaps(src, CAT, 0.5, 20, set(), norm)
    olds = {p["old"] for p in plan}
    assert olds == {"fnd6_eps", BASE}
    assert all((p["old"] in ("fnd6_eps", BASE)) and (("fnd6_eps" in p["expr"]) != (BASE in p["expr"]) or True) for p in plan)


def test_pasted_alphas_one_per_line_with_bullets_comments_and_duplicates():
    txt = "1. rank(ts_mean(fnd6_eps, 20))  # my eps\n- zscore(anl4_eps_est)\n\nRANK( ts_mean(fnd6_eps,20) )\n# only a comment\n"
    got = CL.parse_pasted(txt)
    assert [g["expr"] for g in got] == ["rank(ts_mean(fnd6_eps, 20))", "zscore(anl4_eps_est)"]
    assert [g["id"] for g in got] == ["mine1", "mine2"]


def test_pasted_multiline_alpha_stays_in_one_piece():
    txt = "a = ts_mean(fnd6_eps, 20);\nb = rank(\n  anl4_eps_est);\nrank(a - b)\n\nrank(close)"
    got = CL.parse_pasted(txt)
    assert len(got) == 2
    assert got[0]["expr"].startswith("a = ts_mean(fnd6_eps, 20); b = rank( anl4_eps_est); rank(a - b)")
    assert got[1]["expr"] == "rank(close)"


def test_pasted_alpha_leading_minus_is_kept_and_empty_input_is_empty():
    assert CL.parse_pasted("-rank(fnd6_eps)")[0]["expr"] == "-rank(fnd6_eps)"
    assert CL.parse_pasted("") == [] and CL.parse_pasted(None) == []


def test_describe_pasted_flags_unusable_alphas_and_plans_swaps_from_the_rest():
    d = CL.describe_pasted("rank(fnd6_eps)\nrank(close)\nrank(ts_mean(fnd6_eps, 5)", CAT)
    assert d["total"] == 3 and d["usable"] == 1
    assert d["alphas"][0]["swappable"] == ["fnd6_eps"] and d["alphas"][0]["problem"] == ""
    assert "Data Catalog" in d["alphas"][1]["problem"] and "brackets" in d["alphas"][2]["problem"]
    plan = CL.plan_swaps(CL.parse_pasted("rank(fnd6_eps)"), CAT, 1.0, 3, set(), norm)
    assert plan and plan[0]["source_id"] == "mine1" and plan[0]["new"] == "anl4_eps_est"


def test_empty_plan_says_which_of_the_three_reasons():
    st = {}
    assert CL.plan_swaps([{"id": "a", "expr": "rank(not_in_catalogue_x)"}], CAT, 0.5, 5, set(), norm, stats=st) == []
    assert st["with_fields"] == 0 and st["missing"] == ["not_in_catalogue_x"]
    assert "not_in_catalogue_x" in CL.why_empty(st, "USA", 1) and "Data Catalog" in CL.why_empty(st, "USA", 1)
    full = CL.plan_swaps([{"id": "a", "expr": "rank(fnd6_eps)"}], CAT, 0.5, 5, set(), norm)
    assert full
    st = {}
    assert CL.plan_swaps([{"id": "a", "expr": "rank(fnd6_eps)"}], CAT, 0.5, 5, {norm(p["expr"]) for p in full}, norm, stats=st) == []
    assert st["found"] and st["already_seen"] == st["found"] and "already simulated" in CL.why_empty(st, "USA", 1)
    st = {}
    CL.plan_swaps([{"id": "a", "expr": "rank(fnd6_eps)"}], [CAT[5]], 0.5, 5, set(), norm, stats=st)       # a catalogue of one field has no neighbour
    assert st["found"] == 0 and "No similar datafield" in CL.why_empty(st, "USA", 1)


def test_widening_finds_swaps_the_default_threshold_misses():
    src = [{"id": "a", "expr": "rank(fnd6_eps)"}]
    tight = CL.plan_swaps(src, CAT, 1.0, 3, set(), norm, min_sim=0.99)
    wide = CL.plan_swaps(src, CAT, 1.0, 9, set(), norm, min_sim=0.0)
    assert not tight and wide


def test_field_names_match_ignoring_case_and_the_swap_keeps_the_written_form():
    plan = CL.plan_swaps([{"id": "a", "expr": "rank(FND6_EPS)"}], CAT, 1.0, 3, set(), norm, min_sim=0.0)
    assert plan and all("FND6_EPS" not in p["expr"] and p["old"] == "FND6_EPS" for p in plan)
    d = CL.describe_pasted("rank(FND6_EPS)", CAT)
    assert d["usable"] == 1 and d["alphas"][0]["swappable"] == ["FND6_EPS"]


def test_python_alphas_are_recognised_and_fast_expressions_are_not():
    assert not CL.is_python_alpha(code="rank(ts_mean(close, 5))")
    assert not CL.is_python_alpha(code="a = ts_mean(close,5);\nrank(a)")
    assert CL.is_python_alpha(code="import numpy as np\ndef alpha(data):\n    return data")
    assert CL.is_python_alpha({"language": "python"})
    assert not CL.is_python_alpha({"language": "FASTEXPR"}, "rank(close)")


def test_pasted_python_is_flagged_as_skipped():
    d = CL.describe_pasted("def alpha(data):\n    return data['close']", [])
    assert d["usable"] == 0 and "python" in d["alphas"][0]["problem"].lower()
