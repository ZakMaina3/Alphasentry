"""Fragment E1 (Supersentry on the shared slot lease) and E2 (winner tag / colour for lab results)."""
import json
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.harness import autopilot_route as AR
from app.harness import super_route as SR
from app.harness import winner as W
from app.harness.engine.slots import SlotLease
from app.harness.engine.tracker import Tracker
from app.harness.scoring import score_pending
from tests.ace_db import ace_db
from tests.test_harness_engine import _fake_stats, sim


# ── E1 ─────────────────────────────────────────────────────────────────────────────────────────
def test_routing_is_off_unless_the_flag_is_on_in_the_calling_thread(monkeypatch):
    from app.harness import flags
    f = lambda s, cfg: {"alpha_id": "X", "simulate_data": cfg}
    ev = threading.Event()
    assert SR.routed(f, ev) is f                                              # no context at all: the original function, untouched
    monkeypatch.setattr(flags, "enabled", lambda name: name == "autopilot_via_engine")
    with AR.engine_routing():
        assert SR.routed(f, ev) is not f                                      # on, inside Supersentry's call
    assert SR.routed(f, ev) is f                                              # and off again outside it (the manual SuperAlpha screen)
    monkeypatch.setattr(flags, "enabled", lambda name: False)
    with AR.engine_routing():
        assert SR.routed(f, ev) is f                                          # flag off: never routed


def test_super_simulations_share_the_lease_and_never_exceed_it():
    lease = SlotLease(2)
    running, peak, lock = [0], [0], threading.Lock()

    def sim_one(s, cfg):
        with lock:
            running[0] += 1
            peak[0] = max(peak[0], running[0])
        time.sleep(0.03)
        with lock:
            running[0] -= 1
        return {"alpha_id": cfg["n"], "simulate_data": cfg}
    wrapped = SR.routed(sim_one, threading.Event(), lease=lease, poll=0.005, active=lambda: True)
    from multiprocessing.pool import ThreadPool
    with ThreadPool(3) as pool:                                               # Super's own concurrency is 3, the lease only has 2
        out = pool.map(lambda n: wrapped(None, {"n": n}), range(9))
    assert [o["alpha_id"] for o in out] == list(range(9)) and peak[0] == 2
    assert lease.snapshot()["used"] == 0 and lease.snapshot()["waiting"] == {}   # every slot returned, nobody left waiting


def test_slot_is_returned_when_a_simulation_raises_and_the_engine_leaves_room_while_one_waits():
    lease = SlotLease(2)
    def boom(s, cfg):
        raise RuntimeError("BRAIN down")
    wrapped = SR.routed(boom, threading.Event(), lease=lease, poll=0.005, active=lambda: True)
    try:
        wrapped(None, {})
        assert False
    except RuntimeError:
        pass
    assert lease.snapshot()["used"] == 0
    lease.acquire("harness", 2)
    started = threading.Event()
    done = []
    def run():
        started.set()
        done.append(SR.routed(lambda s, c: {"alpha_id": "S1", "simulate_data": c}, threading.Event(), lease=lease, poll=0.005, active=lambda: True)(None, {}))
    t = threading.Thread(target=run)
    t.start()
    started.wait()
    for _ in range(200):
        if lease.snapshot()["waiting"].get(SR.OWNER):
            break
        time.sleep(0.005)
    assert lease.snapshot()["waiting"] == {SR.OWNER: 1} and lease.free_for("harness") == 0       # the engine is told someone is waiting
    lease.release("harness", 1)
    t.join(2)
    assert done and done[0]["alpha_id"] == "S1" and lease.held_by(SR.OWNER) == 0


def test_stop_releases_waiting_workers_without_simulating():
    lease = SlotLease(1)
    lease.acquire("harness", 1)                                               # the engine holds the only slot
    calls, abandon, out = [], threading.Event(), []
    wrapped = SR.routed(lambda s, c: calls.append(c) or {"alpha_id": "X"}, abandon, lease=lease, poll=0.005, active=lambda: True)
    t = threading.Thread(target=lambda: out.append(wrapped(None, {"k": 1})))
    t.start()
    time.sleep(0.05)
    abandon.set()                                                             # Fast Stop
    t.join(2)
    assert not t.is_alive() and calls == [] and out[0]["alpha_id"] is None and "stopped" in out[0]["error"]
    assert lease.held_by("harness") == 1 and lease.held_by(SR.OWNER) == 0 and lease.snapshot()["waiting"] == {}


def test_setup_problems_fall_back_to_the_original_function():
    f = lambda s, c: {}
    def explode():
        raise RuntimeError("flag store unreadable")
    assert SR.routed(f, threading.Event(), active=explode) is f              # never breaks a run before it starts


def test_the_two_ace_hooks_are_in_place_and_small():
    root = Path(__file__).resolve().parents[1] / "backend" / "app"
    sup = (root / "super" / "service.py").read_text(encoding="utf-8")
    pil = (root / "superpilot" / "service.py").read_text(encoding="utf-8")
    assert "from app.harness.super_route import routed" in sup and "abandon.set(); pool.terminate()" in sup and "partial(sim_one, s)" in sup
    assert "engine_routing" in pil and pil.count("with engine_routing():") == 1
    assert "engine_routing" not in (root / "modules" / "super" / "__init__.py").read_text(encoding="utf-8")        # the manual screen is untouched


# ── E2 ─────────────────────────────────────────────────────────────────────────────────────────
def test_winner_settings_validate_and_persist(tmp_path):
    ws = W.WinnerSettings(tmp_path / "h" / "winner.json")
    assert ws.config() == {"winner_tag": "", "winner_color": "GREEN", "tag_winners_above": 1.0}                   # off by default
    out = ws.set_config(winner_tag="  harness-winner ", winner_color="blue", tag_winners_above=1.3)
    assert out == {"winner_tag": "harness-winner", "winner_color": "BLUE", "tag_winners_above": 1.3}
    assert W.WinnerSettings(tmp_path / "h" / "winner.json").config()["winner_tag"] == "harness-winner"
    assert ws.set_config(winner_tag="")["winner_tag"] == "" and ws.set_config()["winner_color"] == "BLUE"           # blank = off; None = leave alone
    for kw in ({"winner_tag": "bad/tag"}, {"winner_tag": "x" * 41}, {"winner_tag": "a;b"}, {"winner_color": "PINK"}, {"tag_winners_above": -1},
               {"tag_winners_above": "abc"}, {"tag_winners_above": float("nan")}, {"tag_winners_above": 101}):
        try:
            ws.set_config(**kw)
            assert False, kw
        except W.WinnerError:
            pass
    (tmp_path / "h" / "winner.json").write_text("garbage")
    assert ws.config()["winner_tag"] == ""                                                                          # a damaged file means off


def test_only_passing_strong_alphas_are_tagged_and_failures_keep_the_plain_tag():
    cfg = {"winner_tag": "win", "winner_color": "GREEN", "tag_winners_above": 1.0}
    calls = []
    tag = lambda a, t, c: calls.append((a, t, c))
    assert W.apply({"alpha_id": "A", "passed_gate": True, "fitness": 1.2}, cfg, tag) == "win" and calls == [("A", "win", "GREEN")]
    assert W.apply({"alpha_id": "B", "passed_gate": True, "fitness": -1.4}, cfg, tag) == "win"                       # |Fitness|, like ACE
    for row in ({"alpha_id": "C", "passed_gate": False, "fitness": 2.0}, {"alpha_id": "D", "passed_gate": True, "fitness": 0.9},
                {"alpha_id": "E", "passed_gate": True, "fitness": None}, {"alpha_id": "", "passed_gate": True, "fitness": 2.0}):
        assert W.apply(row, cfg, tag) == "harness"
    assert len(calls) == 2
    assert W.apply({"alpha_id": "F", "passed_gate": True, "fitness": 5}, {**cfg, "winner_tag": ""}, tag) == "harness" and len(calls) == 2     # off
    def refuse(a, t, c):
        raise RuntimeError("BRAIN refused")
    assert W.apply({"alpha_id": "G", "passed_gate": True, "fitness": 2}, cfg, refuse) == "harness"                   # a labelling failure is not a lost result


def test_scorer_applies_the_winner_tag_and_records_it(tmp_path):
    with ace_db(tmp_path) as s:
        tr = Tracker(s, tmp_path / "j.jsonl")
        ids = [tr.enqueue("harden", sim(f"rank(x{i})"))["record_id"] for i in range(3)]
        tr.claim(ids, "B")
        for i, rid in enumerate(ids):
            tr.complete(rid, f"AL{i}")
        tagged = []
        def stats(aid, sd):
            st = _fake_stats()
            if aid == "AL2":
                st["is_stats"].loc[0, "fitness"] = 0.4                       # fails the fitness gate -> not a winner
            return st
        out = score_pending(fetch=stats, store=s, winner={"winner_tag": "win", "winner_color": "PURPLE", "tag_winners_above": 1.0},
                            tagger=lambda a, t, c: tagged.append((a, t, c)))
        assert out == {"scored": 3, "failed": 0}
        assert sorted(tagged) == [("AL0", "win", "PURPLE"), ("AL1", "win", "PURPLE")]
        rows = {r["alpha_id"]: r for r in s.query("SELECT alpha_id, tagged, passed_gate FROM sim_results")}
        assert rows["AL0"]["tagged"] == "win" and rows["AL1"]["tagged"] == "win" and rows["AL2"]["tagged"] == "harness" and rows["AL2"]["passed_gate"] == 0


def test_scorer_with_no_winner_tag_behaves_as_before_and_survives_a_refusing_brain(tmp_path):
    with ace_db(tmp_path) as s:
        tr = Tracker(s, tmp_path / "j.jsonl")
        a, b = (tr.enqueue("t", sim(f"rank(y{i})"))["record_id"] for i in range(2))
        tr.claim([a, b], "B")
        tr.complete(a, "N1")
        tr.complete(b, "N2")
        def never(*x):
            raise AssertionError("must not tag when winner tagging is off")
        assert score_pending(limit=1, fetch=lambda *x: _fake_stats(), store=s, winner={"winner_tag": "", "tag_winners_above": 1.0}, tagger=never) == {"scored": 1, "failed": 0}
        def refuse(a_, t, c):
            raise RuntimeError("HTTP 500")
        assert score_pending(fetch=lambda *x: _fake_stats(), store=s, winner={"winner_tag": "win", "winner_color": "GREEN", "tag_winners_above": 1.0}, tagger=refuse) == {"scored": 1, "failed": 0}
        rows = {r["alpha_id"]: r["tagged"] for r in s.query("SELECT alpha_id, tagged FROM sim_results")}
        assert rows == {"N1": "harness", "N2": "harness"}                       # stored either way, plain tag kept when BRAIN refuses the label
