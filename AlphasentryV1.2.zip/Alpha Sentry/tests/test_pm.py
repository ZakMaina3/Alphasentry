"""Fragment D4: the PM (plan/pm.py). Pure module; the model is a fake callable."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.harness.plan import day as D
from app.harness.plan import pm as PM
from tests.test_plan import book

CFG = {**D.DEFAULTS}                                                   # 300 a day, 30% exploration, 8 labs
BOOK = book(repair=(400, 8), harvest=(500, 0), pair=(30, 0), harden=(0, 0), evolution=(250, 1))
BLOCK = {"relocate": ["no second market has data"], "deepen": ["no strong alpha to deepen"]}
SUMMARY = {"plainly": "9 of your last 1,180 finished simulations passed the gate.", "meetsTarget": True, "yieldRate": 0.0076}


class Model:
    def __init__(self, reply):
        self.reply, self.calls = reply, []

    def __call__(self, system, user):
        self.calls.append((system, user))
        if isinstance(self.reply, Exception):
            raise self.reply
        return self.reply if isinstance(self.reply, str) else json.dumps(self.reply)


def run(reply, spent=0, **kw):
    m = Model(reply)
    out = PM.allocate(CFG, BOOK, spent, summary=SUMMARY, blockers=BLOCK, complete=m, **kw)
    return out, m


GOOD = {"briefing": "Repair has been converting best, so it gets the most today. Evolution gets a real chance.",
        "allocations": [{"lab": "repair", "why": "It turns near-misses into passes."}, {"lab": "evolution", "why": "Too early to judge, worth a chance."},
                        {"lab": "pair", "why": "Looks somewhere nothing else does."}]}


def test_brief_lists_every_desk_with_readiness_and_record():
    b = PM.brief(CFG, BOOK, SUMMARY, BLOCK, capacity={"pair": 0})
    by = {d["id"]: d for d in b["desks"]}
    assert set(by) == set(D.AUTO_LABS) and b["fund"] is SUMMARY
    assert not by["relocate"]["ready"] and by["relocate"]["blockedBy"] == ["no second market has data"]
    assert not by["pair"]["ready"] and "no candidates left" in by["pair"]["blockedBy"][0]          # capacity 0 closes a desk
    assert by["repair"]["ready"] and by["repair"]["record"]["passing"] == 8 and by["harden"]["record"]["finished"] == 0
    assert PM.brief({**CFG, "labs": ["repair"]}, BOOK)["desks"][0]["id"] == "repair"
    assert PM.brief(CFG, {})["fund"]["finished"] == 0                                              # an empty fund still has a report


def test_the_prompt_shows_only_real_facts_and_marks_closed_and_unconfident_desks():
    out, m = run(GOOD)
    system, user = m.calls[0]
    assert "THE DESKS YOU MAY FUND:" in user and "repair: searches" in user and "NOT CONFIDENT" in user       # pair/harden/evolution lack evidence
    assert "CLOSED TODAY (do not fund): relocate (no second market has data), deepen" in user
    assert "THE ORDINARY PLAN" in user and "300 simulations to spend today" in user and "9 of your last 1,180" in user
    assert "never suggest submitting" in system and "Do NOT give numbers" in system
    for d in out["brief"]["desks"]:
        if not d["ready"]:
            assert f"  {d['id']}: searches" not in user                                              # a closed desk is never offered
    assert len(m.calls) == 1                                                                           # exactly one model call


def test_happy_path_keeps_the_budget_exact_and_the_models_reasons():
    out, m = run(GOOD)
    assert out["fromPM"] and out["usedLLM"] and out["error"] is None
    labs = [a["lab"] for a in out["allocations"]]
    assert set(labs) == {"repair", "evolution", "pair"} and sum(a["sims"] for a in out["allocations"]) == 300     # whole budget, only chosen desks
    by = {a["lab"]: a for a in out["allocations"]}
    assert by["repair"]["sims"] > by["evolution"]["sims"] and by["repair"]["why"] == "It turns near-misses into passes."
    assert by["repair"]["numbersWhy"].startswith("Proven") and by["repair"]["pmWhy"]                        # the arithmetic's reason is kept beside the model's
    assert out["briefing"].startswith("Repair has been converting") and out["plan"]["planned"] == 300
    ordinary = {a["lab"] for a in out["ordinary"]["allocations"]}
    assert out["changes"] == {"added": sorted(set(labs) - ordinary), "removed": sorted(ordinary - set(labs))} and "harvest" in out["changes"]["removed"]


def test_the_model_cannot_invent_close_repeat_or_over_fund_desks():
    reply = {"briefing": "Fund everything.", "allocations": [
        {"lab": "magic", "why": "x"}, {"lab": "relocate", "why": "closed"}, {"lab": "  Repair ", "why": "ok"}, {"lab": "repair", "why": "again"},
        {"lab": "harvest"}, {"lab": "harden"}, {"lab": "evolution"}, {"lab": "diversify"}, "junk", {"nolab": 1}, {"lab": ""}]}
    out, _ = run(reply)
    funded = [a["lab"] for a in out["allocations"]]
    assert funded == ["repair", "harvest", "harden", "evolution"] or set(funded) <= {"repair", "harvest", "harden", "evolution"}   # at most four, all real, all ready
    assert len(funded) <= PM.MAX_FUNDED and "magic" not in funded and "relocate" not in funded
    why = {(r["lab"], r["reason"]) for r in out["rejected"]}
    assert ("magic", "that is not one of the labs") in why and ("relocate", "it cannot run today") in why and ("repair", "named twice") in why
    assert any(r["reason"].startswith("only 4") for r in out["rejected"]) and ("(unnamed)", "no lab was named") in why
    assert sum(a["sims"] for a in out["allocations"]) == 300


def test_numbers_in_the_models_answer_are_ignored():
    reply = {"briefing": "Go.", "allocations": [{"lab": "repair", "why": "ok", "sims": 99999, "cores": 50, "budget": 1}, {"lab": "harvest", "why": "ok", "sims": 1}]}
    out, _ = run(reply)
    assert sum(a["sims"] for a in out["allocations"]) == 300 and max(a["sims"] for a in out["allocations"]) <= 300
    assert {a["lab"] for a in out["allocations"]} == {"repair", "harvest"}


def test_every_failure_falls_back_to_the_ordinary_plan():
    ordinary = PM.make_plan(CFG, BOOK, 0, exclude={"relocate", "deepen"})                         # exactly the two closed desks
    for reply, why in ((RuntimeError("provider down"), "could not be used"), ("I think repair is great.", "not valid JSON"), ("[1, 2]", "expected shape"),
                       ({"briefing": "x", "allocations": []}, "Nothing the model chose"), ({"briefing": "x", "allocations": [{"lab": "magic"}]}, "Nothing the model chose"),
                       ({"briefing": "x"}, "Nothing the model chose")):
        out, m = run(reply)
        assert not out["fromPM"] and not out["usedLLM"] and why in out["error"], (reply, out["error"])
        assert out["allocations"] == ordinary["allocations"] and sum(a["sims"] for a in out["allocations"]) == 300      # the floor is a good plan
        assert out["briefing"] and "converted lately" in out["briefing"]
    out = PM.allocate(CFG, BOOK, 0, summary=SUMMARY, blockers=BLOCK, complete=None)                                       # no model at all
    assert not out["fromPM"] and out["error"] is None and out["allocations"] == ordinary["allocations"]


def test_no_model_call_when_there_is_nothing_to_decide():
    out, m = run(GOOD, spent=300)                                                                      # today's budget is already used
    assert m.calls == [] and out["allocations"] == [] and not out["fromPM"] and "already used" in out["briefing"]
    m = Model(GOOD)
    out = PM.allocate(CFG, BOOK, 0, blockers={x: ["closed"] for x in CFG["labs"]}, complete=m)       # every desk closed
    assert m.calls == [] and out["allocations"] == [] and "Nothing can run today" in out["briefing"]
    assert PM.allocate({**CFG, "labs": []}, BOOK, 0, complete=Model(GOOD))["allocations"] == []


def test_a_chosen_desk_below_the_smallest_run_is_reported_not_silently_lost():
    cfg = {**CFG, "daily_budget": 25, "min_chunk": 10}
    m = Model({"briefing": "Three desks.", "allocations": [{"lab": "repair", "why": "a"}, {"lab": "evolution", "why": "b"}, {"lab": "pair", "why": "c"}]})
    out = PM.allocate(cfg, BOOK, 0, blockers=BLOCK, complete=m)
    assert sum(a["sims"] for a in out["allocations"]) == 25 and all(a["sims"] >= 10 for a in out["allocations"])
    assert out["dropped"] and all("smallest run" in d["reason"] for d in out["dropped"])
    assert {a["lab"] for a in out["allocations"]} | {d["lab"] for d in out["dropped"]} == {"repair", "evolution", "pair"}


def test_capacity_limits_still_apply_to_what_the_model_picked():
    out, _ = run(GOOD, capacity={"repair": 40})
    by = {a["lab"]: a for a in out["allocations"]}
    assert by["repair"]["sims"] == 40 and by["repair"]["capped"] and sum(a["sims"] for a in out["allocations"]) == 300       # the spill went to the others


def test_briefing_never_suggests_submitting_and_is_bounded():
    t = "Repair leads today. Submit the best three to be safe. Evolution gets a chance. You should submitting all of them."
    assert PM.clean_briefing(t) == "Repair leads today. Evolution gets a chance."
    out, _ = run({"briefing": "Submit everything now. Then submit again!", "allocations": GOOD["allocations"]})
    assert "submit" not in out["briefing"].lower() and "converted lately" in out["briefing"]            # nothing left -> the rule briefing
    long = " ".join(f"Sentence number {i} is a perfectly ordinary one." for i in range(60))
    assert len(PM.clean_briefing(long)) <= PM.MAX_BRIEFING and PM.clean_briefing(long).endswith(".")
    assert PM.clean_briefing(None) == "" and PM.clean_briefing("   ") == ""
    why = PM.validate([{"lab": "repair", "why": "x " * 500}], {"repair"}, set())[0][0]["why"]
    assert len(why) <= PM.MAX_WHY


def test_fenced_json_and_chatter_are_tolerated_and_the_result_is_deterministic():
    wrapped = "Sure! Here is my plan:\n```json\n" + json.dumps(GOOD) + "\n```\nHope that helps."
    a, _ = run(wrapped)
    b, _ = run(json.dumps(GOOD))
    assert a["fromPM"] and a["allocations"] == b["allocations"] and a["briefing"] == b["briefing"]
    again, _ = run(wrapped)
    assert again["allocations"] == a["allocations"]
