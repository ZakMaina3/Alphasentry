"""Fragment G2: the shipped seed database is merged into the live one, insert-only."""
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.harness import seed as D

ROOT = Path(__file__).resolve().parents[1]
REAL_SEED = ROOT / "seed" / D.SEED_NAME          # what ships: the public catalogue only
import tempfile


def _history_seed() -> Path:
    """A seed that ALSO carries made-up history (results, vault, usage, alpha info): the merge code still supports that
    (tools/make_seed.py --with-history), so it is tested with invented rows, never anyone's real alphas."""
    out = Path(tempfile.mkdtemp()) / D.SEED_NAME
    out.write_bytes(REAL_SEED.read_bytes())
    c = sqlite3.connect(out)
    c.executescript((ROOT / "tests" / "data" / "history_schema.sql").read_text())
    for i in range(1, 41):
        c.execute("INSERT INTO sim_results (id, created_at, alpha_id, expression, region, delay, universe, neutralization, tests_failed, passed_gate, "
                  "gate_reasons, n_ops, tagged, submitted) VALUES (?, ?, ?, ?, 'USA', 1, 'TOP3000', 'MARKET', 0, ?, '', 2, 'test', 0)",
                  (i, float(i), f"TESTALPHA{i:03d}", f"rank(ts_mean(close, {i}))", i % 2))
    for i in range(1, 6):
        c.execute("INSERT INTO vault_alphas (id, created_at, updated_at, alpha_id, expression, region, delay, universe, neutralization, status, note, "
                  "tags_json, source_sim_result_id) VALUES (?, 1, 1, ?, ?, 'USA', 1, 'TOP3000', 'MARKET', 'kept', '', '[]', ?)",
                  (i, f"TESTALPHA{i:03d}", f"rank(ts_mean(close, {i}))", i))
    for i in range(1, 4):
        c.execute("INSERT INTO harness_alpha_info (alpha_id, fetched) VALUES (?, 1)", (f"TESTALPHA{i:03d}",))
    c.execute("INSERT INTO usage (id, kind, key, region, count, sum_abs_fitness, last_at) VALUES (1, 'operator', 'rank', 'USA', 3, 1.0, 1)")
    c.commit()
    c.close()
    return out


SEED = _history_seed()


def _live(tmp_path, with_rows=True):
    """An ACE database with the same tables as the seed, empty (or holding a few rows that conflict with it on purpose)."""
    db = tmp_path / "live.db"
    s, c = sqlite3.connect(SEED), sqlite3.connect(db)
    for (sql,) in s.execute("SELECT sql FROM sqlite_master WHERE type='table'"):
        c.execute(sql)
    if with_rows:
        a = s.execute("SELECT alpha_id, expression, region, delay, universe, neutralization FROM sim_results ORDER BY id LIMIT 1").fetchone()
        c.execute("INSERT INTO sim_results (created_at, alpha_id, expression, region, delay, universe, neutralization, sharpe, fitness, turnover, returns, margin, "
                  "drawdown, self_corr, prod_corr, powerpool_corr, tests_failed, passed_gate, gate_reasons, n_ops, tagged, submitted) "
                  "VALUES (1, ?, ?, ?, ?, ?, ?, 99.0, 9.0, 0.1, 0, 0, 0, 0, 0, 0, 0, 1, '', 1, 'mine', 1)", a)
        o = s.execute("SELECT name, scope FROM operator_ref LIMIT 1").fetchone()
        c.execute("INSERT INTO operator_ref VALUES (?, ?, 'mine()', '[]', 'my edited example', 'x', 1, 5)", o)
        c.execute("INSERT INTO sim_results (created_at, alpha_id, expression, region, delay, universe, neutralization, tests_failed, passed_gate, gate_reasons, n_ops, tagged, submitted) "
                  "VALUES (2, 'LIVE_ONLY', 'rank(close)', 'USA', 1, 'TOP3000', 'MARKET', 0, 0, '', 1, '', 0)")
    c.commit()
    c.close()
    s.close()
    return db


def _n(db, t, where=""):
    c = sqlite3.connect(db)
    try:
        return c.execute(f'SELECT COUNT(*) FROM "{t}" {where}').fetchone()[0]
    finally:
        c.close()


def test_the_shipped_seed_is_the_public_catalogue_only():
    """No results, vault alphas, library, lessons, usage, or any record of anyone's own work ships with the app."""
    assert REAL_SEED.exists()
    c = sqlite3.connect(f"file:{REAL_SEED.as_posix()}?mode=ro", uri=True)
    names = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert names == set(D.SHIPPED) == {"datasets", "fields", "operator_ref"}
    assert not names & {"sim_results", "vault_alphas", "autopilot_assets", "autopilot_lessons", "usage", "hypothesis_log", "template_stats", "harness_alpha_info"}                                    # no simulation records, tasks, plan runs, LLM usage, flags
    assert not names & {"harness_sim_record", "harness_task", "harness_trial", "harness_plan_run", "harness_llm_usage"}
    assert c.execute("SELECT COUNT(*) FROM fields").fetchone()[0] > 0


def test_merge_adds_only_what_is_missing_and_never_overwrites(tmp_path):
    db = _live(tmp_path)
    before = {t: _n(db, t) for t in D.TABLES if _n(db, t) is not None}
    seed_rows = {t: _n(SEED, t) for t in D.TABLES if t in {r[0] for r in sqlite3.connect(SEED).execute("SELECT name FROM sqlite_master WHERE type='table'")}}
    r = D.merge(db, SEED, backup_dir=tmp_path / "backups")
    assert r["ok"] and not r["problems"], r
    c = sqlite3.connect(db)
    assert c.execute("SELECT sharpe, tagged, submitted FROM sim_results WHERE alpha_id=(SELECT alpha_id FROM sim_results WHERE tagged='mine')").fetchone() == (99.0, "mine", 1)
    assert c.execute("SELECT example, user_edited FROM operator_ref WHERE user_edited=1").fetchone() == ("my edited example", 1)       # edits survive
    assert c.execute("SELECT COUNT(*) FROM sim_results WHERE alpha_id='LIVE_ONLY'").fetchone()[0] == 1                               # live-only rows survive
    assert c.execute("SELECT COUNT(*) FROM sim_results WHERE tagged='mine'").fetchone()[0] == 1                                       # the conflicting alpha was not added again
    c.execute("ATTACH ? AS s", (str(SEED),))
    for t in seed_rows:
        key = ",".join(f'"{k}"' for k in D.TABLES[t])
        live_keys = c.execute(f'SELECT COUNT(*) FROM (SELECT DISTINCT {key} FROM main."{t}")').fetchone()[0]
        seed_keys = c.execute(f'SELECT COUNT(*) FROM (SELECT DISTINCT {key} FROM s."{t}")').fetchone()[0]
        extra_live = {"sim_results": 1, "operator_ref": 0}.get(t, 0)                                                                 # 'LIVE_ONLY'
        assert live_keys == seed_keys + extra_live, (t, live_keys, seed_keys)                                                        # every seed key present, nothing lost
        assert c.execute(f'SELECT COUNT(*) FROM main."{t}"').fetchone()[0] == before[t] + r["added"].get(t, 0), t                    # total = had + added
    c.close()


def test_merge_is_once_per_seed_force_repeats_and_dry_run_changes_nothing(tmp_path):
    db = _live(tmp_path, with_rows=False)
    dry = D.merge(db, SEED, dry_run=True)
    assert dry["dryRun"] and dry["added"]["fields"] > 0 and _n(db, "fields") == 0                   # counted, not written
    st = D.status(db, SEED)
    assert st["applied"] is None and st["tables"]["fields"]["live"] == 0
    first = D.merge(db, SEED, backup_dir=tmp_path / "bk")
    assert first["added"]["fields"] == _n(SEED, "fields") == _n(db, "fields")
    assert D.merge(db, SEED)["skipped"] == "this seed was already merged"
    c = sqlite3.connect(db)
    c.execute("DELETE FROM sim_results WHERE id IN (SELECT id FROM sim_results LIMIT 5)")
    c.commit()
    c.close()
    assert D.merge(db, SEED)["skipped"]                                                               # deleted rows stay deleted on a normal start
    again = D.merge(db, SEED, force=True)
    assert again["added"]["sim_results"] == 5 and again["added"]["fields"] == 0                       # force restores exactly the missing ones
    assert D.status(db, SEED)["applied"]["forced"] is True


def test_backup_is_taken_once_and_matches_the_live_data_before_the_merge(tmp_path):
    db = _live(tmp_path)
    n_before = _n(db, "sim_results")
    D.merge(db, SEED, backup_dir=tmp_path / "backups")
    files = list((tmp_path / "backups").glob("*pre_seed*"))
    assert len(files) == 1 and _n(files[0], "sim_results") == n_before                                # the snapshot is the state BEFORE
    D.merge(db, SEED, force=True, backup_dir=tmp_path / "backups")
    assert len(list((tmp_path / "backups").glob("*pre_seed*"))) == 1                                   # not overwritten by later merges


def test_vault_links_are_repointed_to_live_ids(tmp_path):
    db = _live(tmp_path)
    D.merge(db, SEED)
    c = sqlite3.connect(db)
    c.execute("ATTACH ? AS s", (str(SEED),))
    bad = c.execute("""SELECT COUNT(*) FROM main.vault_alphas v JOIN s.vault_alphas sv ON sv.alpha_id = v.alpha_id
                       WHERE sv.source_sim_result_id <> 0 AND v.source_sim_result_id <> 0
                         AND (SELECT alpha_id FROM main.sim_results WHERE id = v.source_sim_result_id)
                          IS NOT (SELECT alpha_id FROM s.sim_results WHERE id = sv.source_sim_result_id)""").fetchone()[0]
    linked = c.execute("SELECT COUNT(*) FROM main.vault_alphas WHERE source_sim_result_id <> 0").fetchone()[0]
    assert bad == 0 and linked > 0


def test_schema_drift_is_reported_not_fatal(tmp_path):
    db = _live(tmp_path, with_rows=False)
    c = sqlite3.connect(db)
    c.execute("DROP TABLE datasets")
    c.execute("CREATE TABLE datasets (id INTEGER PRIMARY KEY, name TEXT)")                              # lacks the key columns
    c.execute("ALTER TABLE fields ADD COLUMN extra TEXT")                                                # an extra live column is fine
    c.commit()
    c.close()
    r = D.merge(db, SEED)
    assert "datasets" in r["problems"] and r["added"]["fields"] == _n(SEED, "fields") and not r["ok"]


def test_startup_merge_respects_the_flag_and_never_raises(monkeypatch, tmp_path):
    import types
    from app.harness import flags
    db = _live(tmp_path, with_rows=False)
    st = type("S", (), {})()
    st.db_path, st.data_dir = db, tmp_path
    fake = types.ModuleType("app.core.config")                                                         # the real one needs pydantic-settings
    fake.get_settings = lambda: st
    old = sys.modules.get("app.core.config")
    sys.modules["app.core.config"] = fake
    monkeypatch.setattr(D, "seed_path", lambda repo_root=None: SEED)
    try:
        monkeypatch.setattr(flags, "enabled", lambda n: False)
        assert D.merge_on_startup()["skipped"] == "switched off" and _n(db, "fields") == 0
        monkeypatch.setattr(flags, "enabled", lambda n: n == "harness_seed")
        r = D.merge_on_startup()
        assert r["added"]["fields"] > 0 and _n(db, "fields") > 0
        assert D.merge_on_startup()["skipped"] == "this seed was already merged"                   # the second start does nothing
        st.db_path = tmp_path / "nonexistent_dir" / "x.db"
        assert "error" in D.merge_on_startup()                                                     # a broken path is reported, not raised
    finally:
        if old is None:
            sys.modules.pop("app.core.config", None)
        else:
            sys.modules["app.core.config"] = old
    assert flags.DEFAULTS["harness_seed"] is True


def test_make_seed_builds_a_compact_knowledge_only_copy(tmp_path):
    db = _live(tmp_path)
    c = sqlite3.connect(db)
    c.execute("CREATE TABLE harness_sim_record (id INTEGER PRIMARY KEY, status TEXT)")
    c.execute("INSERT INTO harness_sim_record VALUES (1, 'running')")
    c.commit()
    c.close()
    out = tmp_path / "s" / "seed.db"
    counts = D.build_seed(db, out)
    names = {r[0] for r in sqlite3.connect(out).execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert "harness_sim_record" not in names and "sim_results" in names and counts["sim_results"] == 2
    assert _n(out, "sim_results") == 2


def test_make_seed_ships_only_the_catalogue_unless_history_is_asked_for(tmp_path):
    live = _live(tmp_path)
    shipped = tmp_path / "shipped.db"
    assert set(D.build_seed(live, shipped, D.SHIPPED)) <= set(D.SHIPPED)
    names = {r[0] for r in sqlite3.connect(shipped).execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert names <= set(D.SHIPPED) and "sim_results" not in names and "vault_alphas" not in names
    full = tmp_path / "full.db"
    assert "sim_results" in D.build_seed(live, full)               # history only when explicitly requested (private use)
