"""Fragment D5 (data side): readiness, results counts, yield trend and the advisor snapshot, against a throwaway ACE-shaped database."""
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.harness.payload import Scope
from app.harness.plan import advisor
from app.harness.plan import readers as RD
from tests.ace_db import ace_db, add_alpha, add_dataset, add_field

SC = Scope("USA", 1, "TOP3000")
DAY = 86400.0


def rec(s, task, status, alpha, created):
    s.execute("INSERT INTO harness_sim_record (task, payload, payload_hash, status, alpha_id, created, updated) VALUES (?,?,?,?,?,?,?)",
              (task, "{}", f"h{time.time_ns()}", status, alpha, created, created))


def test_results_counts_use_the_market_and_never_double_count(tmp_path):
    with ace_db(tmp_path) as s:
        add_dataset(s, "d1")
        add_dataset(s, "d2", universe="TOP1000")
        for i, f in enumerate(("close", "volume")):
            add_field(s, f, "d1")
        add_field(s, "assets", "d2")
        add_alpha(s, "a1", "rank(close)", 1.6, passed=1)
        add_alpha(s, "a1", "rank(close)", 1.6, passed=1)                      # same alpha twice (two settings): counted once
        add_alpha(s, "a2", "rank(volume)", 1.1)                               # winner, near miss (unsubmitted, not passed)
        add_alpha(s, "a3", "rank(assets)", 0.4)
        add_alpha(s, "a4", "rank(open)", 1.4, submitted=1)                    # strong but submitted: not a near miss
        add_alpha(s, "e1", "rank(close)", 2.0, region="EUR")                  # another market: ignored
        add_alpha(s, "a5", "rank(vwap)", 1.3, passed=1)
        c = RD.results_counts(s, SC)
        assert c["alphas"] == 5 and c["strong"] == 3 and c["winners"] == 4 and c["passing"] == 2 and c["unsubmitted"] == 2
        assert c["nearMisses"] == 1 and c["fields"] == 3 and c["datasets"] == 2 and c["markets"] == 2
        assert RD.results_counts(s, Scope("JPN", 1, "TOP1600"))["alphas"] == 0


def test_readiness_names_why_a_lab_cannot_run():
    full = {"alphas": 50, "strong": 5, "winners": 9, "nearMisses": 4, "passing": 3, "unsubmitted": 1, "fields": 80, "datasets": 6, "markets": 3}
    labs = ["repair", "harden", "relocate", "harvest", "diversify", "pair", "evolution", "deepen"]
    assert RD.readiness(full, labs)["blockers"] == {}                                               # everything ready
    empty = {k: 0 for k in full}
    b = RD.readiness(empty, labs)["blockers"]
    assert set(b) == set(labs) and "|Sharpe|" in b["repair"][0] and "Data Explorer" in b["harvest"][0] and "only one market" in " ".join(b["relocate"])
    one_ds = RD.readiness({**full, "datasets": 1}, labs)["blockers"]
    assert list(one_ds) == ["pair"] and "two datasets" in one_ds["pair"][0]
    only = RD.readiness(empty, ["repair"])["blockers"]
    assert list(only) == ["repair"]                                                                  # labs not in the plan are not reported
    probes = RD.readiness(full, labs, fresh_datasets=lambda: 0, undeepened=lambda: 0)["blockers"]
    assert "already used" in probes["diversify"][0] and "already has a deepen task" in probes["deepen"][0]
    def boom():
        raise RuntimeError("no database")
    assert RD.readiness(full, labs, fresh_datasets=boom, undeepened=boom)["blockers"] == {}          # a failing probe never closes a lab
    weak = RD.readiness({**full, "strong": 0}, labs, undeepened=lambda: 0)["blockers"]
    assert len(weak["deepen"]) == 1 and "|Sharpe|" in weak["deepen"][0]                              # the strength reason wins; the probe adds nothing on top


def test_deepened_expressions_are_read_from_task_descriptions():
    tasks = [{"lab": "deepen", "template": json.dumps({"description": "Neighbourhood of: rank(ts_zscore(close, 22))"})},
             {"lab": "search", "template": json.dumps({"description": "Neighbourhood of: ignored"})},
             {"lab": "deepen", "template": "not json"}, {"lab": "deepen", "template": json.dumps({"description": "something else"})}]
    assert RD.deepened_expressions(tasks) == {"rank(ts_zscore(close, 22))"}


def test_trend_has_every_day_counts_each_alpha_once_and_splits_by_lab(tmp_path):
    now = 1_800_000_000.0
    today = now - now % DAY
    with ace_db(tmp_path) as s:
        add_alpha(s, "p1", "rank(close)", 1.5, passed=1)
        add_alpha(s, "n1", "rank(open)", 0.3)
        rec(s, "repair-1", "scored", "p1", today + 100)
        rec(s, "repair-1", "scored", "p1", today + 200)                       # same alpha twice the same day: passes once
        rec(s, "harvest-2", "scored", "n1", today + 300)
        rec(s, "harvest-2", "error", "", today + 400)                         # errors are not finished
        rec(s, "repair-1", "scored", "p1", today - 2 * DAY + 50)
        rec(s, "pair-1", "dryrun", "", today + 500)                           # dry runs never count
        rec(s, "old-1", "scored", "p1", today - 40 * DAY)                     # outside the window
        t = RD.trend(s, days=5, now=now)
        assert [d["day"] for d in t["days"]] == [time.strftime("%Y-%m-%d", time.gmtime(today + i * DAY)) for i in range(-4, 1)]
        last, mid = t["days"][-1], t["days"][-3]
        assert last["finished"] == 3 and last["passing"] == 1 and abs(last["yieldRate"] - 1 / 3) < 1e-4
        assert last["byLab"] == {"repair": {"finished": 2, "passing": 1}, "harvest": {"finished": 1, "passing": 0}}
        assert mid["finished"] == 1 and mid["passing"] == 1
        assert [d["finished"] for d in t["days"]] == [0, 0, 1, 0, 3] and t["targetYield"] == 0.001
        assert len(RD.trend(s, days=999, now=now)["days"]) == 90 and len(RD.trend(s, days=0, now=now)["days"]) == 1


def test_snapshot_feeds_the_advisor(tmp_path):
    with ace_db(tmp_path) as s:
        add_dataset(s, "d1")
        add_field(s, "close", "d1")
        add_alpha(s, "a2", "rank(volume)", 1.1)
        add_alpha(s, "a1", "rank(close)", 1.6)
        rec(s, "harvest-1", "done", "", time.time())                         # finished but not in Results yet
        rec(s, "harvest-1", "scored", "a1", time.time())
        snap = RD.snapshot(s, SC, flags={"harness_engine": True}, engine={"running": False, "dry_run": False, "counts": {"queued": 7}},
                           plan={"budget": 300, "spent": 20, "remaining": 280, "allocations": []}, yields=None, tasks=[{"id": 4, "name": "t", "status": "error", "error": "bad template"}])
        assert snap["unscored"] == 1 and snap["results"]["strong"] == 1 and snap["plan"] == {"budget": 300, "spent": 20, "remaining": 280} and snap["vaultAlphas"] == 0
        ids = {i["id"] for i in advisor.advise(snap)}
        assert {"start-engine", "score", "task-4", "harden", "repair"} <= ids          # queued + engine stopped, unscored, errored task, strong alpha, near miss
        assert "run-plan" not in ids                                                    # something is queued, so "run the plan" stays quiet
        bare = advisor.advise(RD.snapshot(s, Scope("JPN", 1, "TOP1600"), flags={"harness_engine": True}, engine=None,
                                           plan={"budget": 300, "spent": 0, "remaining": 300}, yields=None, tasks=[]))
        assert {"seed", "run-plan"} <= {i["id"] for i in bare}                          # nothing here yet: start with Harvest, and the day's budget is unused
