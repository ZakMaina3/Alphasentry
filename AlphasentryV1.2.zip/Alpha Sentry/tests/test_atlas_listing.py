"""Operator Atlas rows -> prompt text for Autosentry and Supersentry."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.operators.listing import atlas_listing

OPS = [
    {"name": "ts_mean", "signature": "ts_mean(x, d)", "example": "ts_mean(close, 5)", "notes": "", "user_edited": False},
    {"name": "vec_avg", "signature": "vec_avg(x)", "example": "vec_avg(v)", "notes": "", "user_edited": False},
    {"name": "bucket", "signature": "bucket(r, range=)", "example": "", "notes": "", "user_edited": False},
    {"name": "ts_rank", "signature": "ts_rank(x, d)", "example": "ts_rank(x, 20)", "notes": "my   note\nwith  gaps", "user_edited": True},
    {"name": "", "signature": "x"},
]


def test_listing_skips_excluded_puts_my_edits_first_and_keeps_notes():
    t = atlas_listing(OPS, skip_prefixes=("vec_",), skip_names={"bucket"})
    lines = t.rstrip("\n").splitlines()
    assert len(lines) == 2 and lines[0].startswith("  ts_rank(x, d)")
    assert "-- my note with gaps" in lines[0] and "# e.g. ts_mean(close, 5)" in lines[1]
    assert "vec_avg" not in t and "bucket" not in t


def test_listing_limit_and_empty():
    assert atlas_listing([]) == ""
    assert len(atlas_listing(OPS, limit=1).strip().splitlines()) == 1
