import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.autopilot import winners as WN


def test_prod_rescue_limit_is_074_inclusive_and_unknown_is_tried():
    assert WN.worth_rescuing(0.71, 0.74) and WN.worth_rescuing(0.74, 0.74) and WN.worth_rescuing(-0.73, 0.74)
    assert not WN.worth_rescuing(0.741, 0.74) and not WN.worth_rescuing(0.9, 0.74) and not WN.worth_rescuing(-0.8, 0.74)
    assert WN.worth_rescuing(None, 0.74) and WN.worth_rescuing("junk", 0.74)
    assert WN.worth_rescuing(0.8, 0.85)                                              # the limit is a setting


def test_winner_text_never_fails_on_missing_numbers():
    full = WN.winner_text({"alpha_id": "ab12", "sharpe": 1.8, "fitness": 1.2, "turnover": 0.3, "prod_corr": 0.55, "self_corr": 0.4,
                           "neutralization": "INDUSTRY", "via": "cloned from x1: a -> b", "expr": "rank(a)"}, "USA", 1)
    assert "ab12" in full and "USA D1" in full and "Sharpe 1.80" in full and "Prod corr 0.55" in full and "rank(a)" in full and "cloned from" in full
    bare = WN.winner_text({"alpha_id": "z", "sharpe": None, "fitness": None, "expr": "rank(b)"})
    assert "Sharpe n/a" in bare and "Fitness n/a" in bare and "Prod corr n/a" in bare and "rank(b)" in bare
    assert WN.winner_text({}) and len(WN.winner_text({"expr": "x" * 5000})) < 700
