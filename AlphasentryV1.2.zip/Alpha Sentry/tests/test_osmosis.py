"""Osmosis planner: scope eligibility, screens, correlation pruning, caps, exact 100k points, gradual moves."""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.osmosis import planner as P

DAYS = [f"2024-{1 + i // 28:02d}-{1 + i % 28:02d}" for i in range(300)]
DS = ["pv1", "fnd6", "anl4", "news12", "oth143", "mdl77", "sent1", "opt9"]
CATS = ["price", "fundamental", "analyst", "news", "other", "model", "social", "option"]


def alpha(i, scope="USA D1", ds=None, sharpe=2.0, inv=1.8, tu=0.1, seed=None, drift=0.05, pnl=True, pts=0, neut="INDUSTRY"):
    rng = np.random.default_rng(1000 + i if seed is None else seed)
    ds = ds or DS[i % len(DS)]
    series = {d: float(v) for d, v in zip(DAYS, rng.normal(drift, 1.0, len(DAYS)))} if pnl else None
    return {"id": f"{scope[:3]}{i}", "scope": scope, "sharpe": sharpe, "inv_sharpe": inv, "turnover": tu,
            "neutralization": neut, "dataset": ds, "category": CATS[DS.index(ds)], "ops": ["rank", f"op{i % 5}"],
            "pnl": series, "points": pts}


def scope_alphas(scope, n, **kw):
    return [alpha(i, scope, **kw) for i in range(n)]


def test_round_points_sum_exactly():
    for w in ([1, 1, 1], [0.1234, 0.5, 0.3766], list(np.random.default_rng(1).random(13))):
        assert sum(P.round_points(w, 100_000)) == 100_000


def test_scope_needs_ten_passing_alphas():
    r = P.plan_account(scope_alphas("USA D1", 9) + scope_alphas("GLB D1", 12))
    s = {x["scope"]: x for x in r["scopes"]}
    assert not s["USA D1"]["eligible"] and s["USA D1"]["short_by"] == 1 and s["USA D1"]["plan"] == []
    assert s["GLB D1"]["eligible"]


def test_exactly_ten_qualifies_and_gets_exactly_100k():
    r = P.plan_account(scope_alphas("USA D1", 10))
    s = r["scopes"][0]
    assert s["eligible"] and sum(p["points"] for p in s["plan"]) == 100_000


def test_fewer_than_three_scopes_means_no_valid_allocation():
    r = P.plan_account(scope_alphas("USA D1", 12) + scope_alphas("GLB D1", 12) + scope_alphas("IND D1", 5))
    assert r["valid"] is False and "needs" in r["message"] and "IND D1" in r["message"]


def test_three_good_scopes_is_valid_and_every_scope_sums_to_100k():
    a = scope_alphas("USA D1", 12) + scope_alphas("USA D0", 12) + scope_alphas("GLB D1", 12) + scope_alphas("ASI D1", 3)
    r = P.plan_account(a)
    assert r["valid"]
    for s in r["scopes"]:
        if s["allocate"]:
            assert sum(p["points"] for p in s["plan"]) == 100_000
    assert not [s for s in r["scopes"] if s["scope"] == "ASI D1"][0]["allocate"]


def test_investability_loss_drops_alpha_unless_it_is_the_only_one_on_its_dataset():
    a = scope_alphas("USA D1", 12)
    a[0]["inv_sharpe"] = 0.5                       # loses 75%
    a[1]["inv_sharpe"] = 0.5; a[1]["dataset"] = "solo"; a[1]["category"] = "solo"
    scr = P.screen(a, P.DEFAULTS)
    assert scr[a[0]["id"]]["verdict"] == "drop"
    assert scr[a[1]["id"]]["verdict"] == "watch"   # unique dataset exemption


def test_high_turnover_needs_robust_constrained_sharpe():
    a = scope_alphas("USA D1", 12)
    a[0]["turnover"] = 0.35; a[0]["inv_sharpe"] = 0.6
    a[1]["turnover"] = 0.35; a[1]["inv_sharpe"] = 1.7
    a[2]["turnover"] = 0.35; a[2]["inv_sharpe"] = None
    scr = P.screen(a, P.DEFAULTS)
    assert scr[a[0]["id"]]["verdict"] == "drop"
    assert scr[a[1]["id"]]["verdict"] == "keep"
    assert scr[a[2]["id"]]["verdict"] == "watch"


def test_highly_correlated_alphas_are_pruned():
    a = scope_alphas("USA D1", 12)
    a.append({**alpha(99, "USA D1", seed=1000), "id": "twin"})      # same PnL as alpha 0
    scr = P.screen(a, P.DEFAULTS)
    sel, pruned = P.select(a, scr, P.DEFAULTS)
    assert "twin" not in [x["id"] for x in sel] or a[0]["id"] not in [x["id"] for x in sel]
    assert any("correlation" in p["reason"] for p in pruned)


def test_dataset_cap_is_respected():
    a = [alpha(i, "USA D1", ds="pv1") for i in range(7)] + [alpha(i, "USA D1") for i in range(10, 16)]
    s = P.plan_scope("USA D1", a, P.DEFAULTS)
    assert s["eligible"]
    pts = {p["id"]: p["points"] for p in s["plan"]}
    pv = sum(pts.get(x["id"], 0) for x in a if x["dataset"] == "pv1")
    assert pv <= 0.35 * 100_000 + 1
    assert max(pts.values()) <= 0.20 * 100_000 + 1


def test_moves_are_gradual_and_still_sum_to_100k():
    a = scope_alphas("USA D1", 12)
    start = P.round_points(np.ones(12), 100_000)
    for x, p in zip(a, start):
        x["points"] = p
    s = P.plan_scope("USA D1", a, {**P.DEFAULTS})
    assert sum(p["points"] for p in s["plan"]) == 100_000
    moved = sum(max(0, p["points"] - p["was"]) for p in s["plan"])
    assert moved <= P.DEFAULTS["max_move"] + 12


def test_no_pnl_still_plans_with_equal_style_weights():
    s = P.plan_scope("USA D1", scope_alphas("USA D1", 11, pnl=False), P.DEFAULTS)
    assert s["eligible"] and sum(p["points"] for p in s["plan"]) == 100_000
    assert s["stats"]["sharpe"] is None


def test_weak_scope_is_left_out_when_three_good_ones_exist():
    weak = scope_alphas("IND D1", 12, drift=-0.01)
    good = scope_alphas("USA D1", 12, drift=0.12) + scope_alphas("GLB D1", 12, drift=0.12) + scope_alphas("GBR D1", 12, drift=0.12)
    r = P.plan_account(weak + good)
    d = {s["scope"]: s for s in r["scopes"]}
    assert d["IND D1"]["weak"] and not d["IND D1"]["allocate"]
    assert r["valid"] and all(d[x]["allocate"] for x in ("USA D1", "GLB D1", "GBR D1"))


def test_weak_scope_is_added_only_to_reach_three():
    r = P.plan_account(scope_alphas("IND D1", 12, drift=-0.01) + scope_alphas("USA D1", 12, drift=0.12) + scope_alphas("GLB D1", 12, drift=0.12))
    assert r["valid"] and "minimum" in r["message"]


def test_a_cap_that_cannot_be_met_is_reported_and_does_not_spoil_the_others():
    a = [alpha(i, "USA D1", ds="pv1") for i in range(7)] + [alpha(i, "USA D1") for i in range(10, 16)]   # all INDUSTRY
    s = P.plan_scope("USA D1", a, P.DEFAULTS)
    assert any("neutralization" in x for x in s["caps_relaxed"])
    assert not any("dataset pv1" in x for x in s["caps_relaxed"])


# ── extraction from BRAIN records ────────────────────────────────────────────────────

from app.osmosis import extract as X


def _raw(**kw):
    r = {"id": "AbC1", "type": "REGULAR", "stage": "OS", "status": "ACTIVE",
         "settings": {"region": "GLB", "delay": 1, "neutralization": "SUBINDUSTRY"},
         "regular": {"code": "rank(ts_mean(oth143_buy_tier1_broker_rank1, 20) / ts_std_dev(close, 60))"},
         "is": {"sharpe": 1.9, "fitness": 1.2, "turnover": 0.12, "investabilityConstrained": {"sharpe": 1.4}}}
    r.update(kw)
    return r


def test_normalise_reads_scope_metrics_and_constrained_sharpe():
    a = X.normalise(_raw())
    assert a["scope"] == "GLB D1" and a["sharpe"] == 1.9 and a["inv_sharpe"] == 1.4 and a["turnover"] == 0.12
    assert a["neutralization"] == "SUBINDUSTRY" and a["points"] == 0


def test_operators_and_datafields_are_told_apart():
    e = "rank(ts_mean(oth143_buy_tier1_broker_rank1, 20) / ts_std_dev(close, 60))"
    assert X.operators_in(e) == ["rank", "ts_mean", "ts_std_dev"]
    assert X.fields_in(e) == ["oth143_buy_tier1_broker_rank1", "close"]
    assert X.dataset_of(e) == "oth143"
    assert X.dataset_of("rank(close)") == "pv"
    assert X.fields_in("group_neutralize(x_1, industry)") == ["x_1"]


def test_missing_pieces_do_not_crash_and_points_are_read_when_present():
    a = X.normalise(_raw(**{"is": {}}))
    assert a["sharpe"] is None and a["inv_sharpe"] is None
    assert X.normalise(_raw(osmosisPoints=12500))["points"] == 12500
    assert X.normalise({"id": "x"}) is None


def test_submitted_detection():
    assert X.is_submitted(_raw())
    assert not X.is_submitted(_raw(stage="IS", status="UNSUBMITTED"))


# ── service with a fake BRAIN (no network, no database) ──────────────────────────────

def _load_service(tmp, accept=True, n_alphas=5, scope_of_i=lambda i: ("USA", 1)):
    import importlib, types
    import pandas as pd
    saved = {k: sys.modules.get(k) for k in ("app.brain", "app.brain.engine", "app.core", "app.core.config", "ace_lib", "app.osmosis.service")}
    calls = {"get": []}

    class Resp:
        def __init__(self, d): self._d, self.status_code, self.headers = d, 200, {}
        def json(self): return self._d

    raws = [_raw(id=f"A{i}", settings={"region": scope_of_i(i)[0], "delay": scope_of_i(i)[1], "neutralization": "INDUSTRY"}) for i in range(n_alphas)]
    state = {}
    raws.append(_raw(id="U1", stage="IS", status="UNSUBMITTED"))

    class Sess:
        def get(self, url, params=None, timeout=None):
            calls["get"].append((url, dict(params or {})))
            if "/alphas/" in url and "users/self" not in url:
                aid = url.rsplit("/", 1)[1]
                return Resp({**next(r for r in raws if r["id"] == aid), "osmosisPoints": state.get(aid, 0)})
            if params.get("status") == "ACTIVE":
                rows = [{**r, "osmosisPoints": state.get(r["id"], 0)} for r in raws if r["status"] == "ACTIVE"]
                o = params["offset"]
                return Resp({"count": len(rows), "results": rows[o:o + params["limit"]]})
            return Resp({"count": 0, "results": []})

    ace = types.ModuleType("ace_lib"); ace.brain_api_url = "https://x/api"
    ace.get_alpha_daily_pnl = lambda s, aid: pd.DataFrame({"pnl": [1.0, 2.0, -1.0]}, index=pd.to_datetime(["2024-01-01", "2024-01-02", "2024-01-03"]))
    def setp(sess, aid, osmosis_points=None):
        calls.setdefault("patch", []).append((aid, osmosis_points))
        r = Resp({}); r.text = ""
        if accept:
            if osmosis_points is None: state.pop(aid, None)
            else: state[aid] = osmosis_points
        return r
    ace.set_alpha_properties = setp
    eng = types.ModuleType("app.brain.engine")
    eng.require_session = lambda: Sess()
    eng.brain_call = lambda what, fn, *a, **k: fn(*a, **k)
    cfg = types.ModuleType("app.core.config")
    cfg.get_settings = lambda: types.SimpleNamespace(data_dir=Path(tmp))
    brain = types.ModuleType("app.brain"); brain.engine = eng
    core = types.ModuleType("app.core")
    sys.modules.update({"ace_lib": ace, "app.brain": brain, "app.brain.engine": eng, "app.core": core, "app.core.config": cfg})
    sys.modules.pop("app.osmosis.service", None)
    svc = importlib.import_module("app.osmosis.service")

    def restore():
        for k, v in saved.items():
            if v is None: sys.modules.pop(k, None)
            else: sys.modules[k] = v
    calls["state"] = state
    return svc, calls, restore


def test_service_reads_only_submitted_alphas_with_get_only_and_caches_pnl(tmp_path=None):
    import tempfile
    tmp = tempfile.mkdtemp()
    svc, calls, restore = _load_service(tmp)
    try:
        out = svc.refresh(lambda **k: None, lambda: False)
        assert out["alphas"] == 5 and out["scopes"] == ["USA D1"] and out["no_pnl"] == 0
        snap = svc.load_snapshot()
        assert {a["id"] for a in snap["alphas"]} == {f"A{i}" for i in range(5)}
        assert snap["alphas"][0]["pnl"]["2024-01-02"] == 2.0
        assert all(u.startswith("https://x/api/users/self/alphas") for u, _ in calls["get"])   # only reads
        plan = svc.make_plan()
        assert plan["scopes"][0]["scope"] == "USA D1" and plan["scopes"][0]["eligible"] is False
        assert plan["valid"] is False
        plan2 = svc.make_plan(current={"A0": 500})
        assert plan2["scopes"][0]["current_total"] == 500
    finally:
        restore()


def test_make_plan_without_a_snapshot_says_so():
    import tempfile
    svc, _, restore = _load_service(tempfile.mkdtemp())
    try:
        assert svc.make_plan()["empty"] is True
    finally:
        restore()


# ── editing and implementing ─────────────────────────────────────────────────────────

from app.osmosis import apply as AP


def _snap(n=12, scope="USA D1", pts=None):
    return [{"id": f"{scope[:3]}{i}", "scope": scope, "points": (pts or {}).get(i, 0)} for i in range(n)]


def _edit(scope="USA D1", n=12, total=100_000):
    base = P.round_points([1] * n, total)
    return {scope: {f"{scope[:3]}{i}": p for i, p in enumerate(base)}}


def test_validate_accepts_an_exact_allocation_and_lists_the_writes():
    d = AP.validate_and_diff(_snap() + _snap(12, "GLB D1") + _snap(12, "IND D1"),
                             {**_edit("USA D1"), **_edit("GLB D1"), **_edit("IND D1")})
    assert d["ok"] and len(d["writes"]) == 36 and d["clears"] == []


def test_validate_rejects_wrong_total_too_few_alphas_and_too_few_scopes():
    a = _snap() + _snap(12, "GLB D1") + _snap(12, "IND D1")
    e = {**_edit("USA D1"), **_edit("GLB D1"), **_edit("IND D1")}
    e["USA D1"]["USA0"] += 5
    d = AP.validate_and_diff(a, e)
    assert not d["ok"] and any("exactly 100,000" in x and "over by 5" in x for x in d["errors"])
    d = AP.validate_and_diff(a, {**_edit("USA D1", 9), **_edit("GLB D1"), **_edit("IND D1")})
    assert any("at least 10" in x for x in d["errors"])
    d = AP.validate_and_diff(a, {**_edit("USA D1"), **_edit("GLB D1")})
    assert any("at least 3 scopes" in x for x in d["errors"])


def test_validate_rejects_unknown_alpha_wrong_scope_and_bad_numbers():
    a = _snap() + _snap(12, "GLB D1") + _snap(12, "IND D1")
    e = {**_edit("USA D1"), **_edit("GLB D1"), **_edit("IND D1")}
    e["USA D1"]["nope"] = 5; e["USA D1"]["GLB0"] = 5; e["USA D1"]["USA1"] = -3
    msgs = " | ".join(AP.validate_and_diff(a, e)["errors"])
    assert "nope is not one of your submitted alphas" in msgs and "belongs to GLB D1" in msgs and "between 0 and" in msgs


def test_validate_skips_unchanged_alphas_and_clears_dropped_ones():
    base = _edit("USA D1", 10)["USA D1"]
    snap = _snap(12, "USA D1", {i: p for i, p in enumerate(P.round_points([1] * 12, 100_000))})
    snap[0]["points"] = base["USA0"]                            # identical to the new value
    a = snap + _snap(12, "GLB D1") + _snap(12, "IND D1")
    d = AP.validate_and_diff(a, {"USA D1": base, **_edit("GLB D1"), **_edit("IND D1")})
    assert d["ok"] and d["unchanged"] == 1
    assert {c["id"] for c in d["clears"]} == {"USA10", "USA11"}      # had points, not in the new plan


def _three_scope_service(accept=True):
    import tempfile
    sc = lambda i: [("USA", 1), ("GLB", 1), ("IND", 1)][i // 12]
    svc, calls, restore = _load_service(tempfile.mkdtemp(), accept=accept, n_alphas=36, scope_of_i=sc)
    svc.refresh(lambda **k: None, lambda: False)
    ids = [f"A{i}" for i in range(36)]
    edits = {s: {ids[i]: p for i, p in zip(range(k * 12, k * 12 + 12), P.round_points([1] * 12, 100_000))}
             for k, s in enumerate(["USA D1", "GLB D1", "IND D1"])}
    return svc, calls, restore, edits


def test_implement_writes_every_alpha_verifies_and_can_be_undone():
    svc, calls, restore, edits = _three_scope_service()
    try:
        r = svc.implement(edits, {}, lambda **k: None, lambda: False)
        assert r["written"] == 36 and r["failed"] == [] and all(v["ok"] for v in r["verified"].values())
        assert sum(calls["state"].values()) == 300_000
        assert len(svc.journal()) == 1
        u = svc.undo(lambda **k: None, lambda: False)
        assert u["restored"] == 36 and calls["state"] == {}
        assert svc.journal()[0]["undone"] is True
    finally:
        restore()


def test_implement_never_submits_and_only_patches_points():
    svc, calls, restore, edits = _three_scope_service()
    try:
        svc.implement(edits, {}, lambda **k: None, lambda: False)
        assert len(calls["patch"]) == 36
        assert all(isinstance(p, int) for _, p in calls["patch"])
    finally:
        restore()


def test_implement_stops_after_the_first_write_if_brain_does_not_keep_it():
    svc, calls, restore, edits = _three_scope_service(accept=False)
    try:
        try:
            svc.implement(edits, {}, lambda **k: None, lambda: False)
            assert False, "should have refused"
        except RuntimeError as e:
            assert "did not keep it" in str(e)
        assert len(calls["patch"]) == 1                      # only the canary was sent
        assert svc.journal() == []
    finally:
        restore()


def test_implement_rejects_an_invalid_allocation_without_touching_brain():
    svc, calls, restore, edits = _three_scope_service()
    try:
        edits["USA D1"]["A0"] += 1
        try:
            svc.implement(edits, {}, lambda **k: None, lambda: False)
            assert False
        except ValueError as e:
            assert "exactly 100,000" in str(e)
        assert "patch" not in calls
    finally:
        restore()


def test_dry_run_changes_nothing():
    svc, calls, restore, edits = _three_scope_service()
    try:
        r = svc.implement(edits, {}, lambda **k: None, lambda: False, dry_run=True)
        assert r["dry_run"] and r["writes"] == 36 and "patch" not in calls
    finally:
        restore()


def test_only_the_best_ten_of_each_scope_get_points():
    al = [{**alpha(i, "USA D1", sharpe=1.5 + i * 0.1, inv=1.5 + i * 0.1, pnl=False), "id": f"U{i}"} for i in range(16)]
    r = P.plan_scope("USA D1", al, {**P.DEFAULTS})
    ids = [p["id"] for p in r["plan"]]
    assert len(ids) == 10 and set(ids) == {f"U{i}" for i in range(6, 16)}          # the 10 highest Sharpe
    assert sum(p["points"] for p in r["plan"]) == 100_000
    assert any("best 10" in x["reason"] for x in r["pruned"])
    assert len(P.plan_scope("USA D1", al, {**P.DEFAULTS, "top_n": 0})["plan"]) > 10


def test_delays_are_ranked_separately():
    al = [{**alpha(i, "USA D1"), "id": f"A{i}"} for i in range(12)] + [{**alpha(i, "USA D0", seed=500 + i), "id": f"B{i}"} for i in range(12)]
    r = P.plan_account(al, {})
    assert {s["scope"]: len(s["plan"]) for s in r["scopes"]} == {"USA D0": 10, "USA D1": 10}


def test_usa_alphas_submitted_before_becoming_a_consultant_get_no_points_and_lose_the_ones_they_hold():
    old = [{**alpha(i, "USA D1", pts=10_000), "id": f"O{i}", "region": "USA", "date_submitted": "2026-03-05T10:00:00-05:00"} for i in range(10)]
    new = [{**alpha(i + 20, "USA D1"), "id": f"N{i}", "region": "USA", "date_submitted": "2026-09-01T10:00:00-05:00"} for i in range(10)]
    eur = [{**alpha(i, "EUR D1"), "id": f"E{i}", "region": "EUR", "date_submitted": "2026-03-05T10:00:00-05:00"} for i in range(10)]
    cfg = {**P.DEFAULTS, "consultant_start": "2026-08-01"}
    r = P.plan_scope("USA D1", old + new, cfg)
    assert r["uncompensated"] == 10 and {p["id"] for p in r["plan"]} == {f"N{i}" for i in range(10)}
    assert set(r["remove_from_allocation"]) == {f"O{i}" for i in range(10)}
    assert r["released_uncompensated"] and not r["gradual"]
    assert any("uncompensated" in d["reason"] for d in r["dropped"])
    assert P.plan_scope("EUR D1", eur, cfg)["eligible"]                                # other regions are untouched
    off = P.plan_scope("USA D1", old + new, P.DEFAULTS)
    assert off["uncompensated"] == 0
    assert "not set" in P.plan_account(old + new + eur, {})["message"]
