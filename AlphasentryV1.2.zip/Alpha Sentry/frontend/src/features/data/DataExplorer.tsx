import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../../lib/api";
import { useResearch, type Dataset, type Field } from "../../lib/store";
import { NumberInput } from "../../lib/NumberInput";
import { useToast } from "../../lib/toast";
import "./data.css";

// Delay 0 is a real, valid delay but 0 is falsy — parse without the `|| default` trap.
const intOr = (v: any, d: number) => { const n = parseInt(v, 10); return Number.isFinite(n) ? n : d; };

// The category tag comes ONLY from the real fetched category (never guessed from the id, which
// doesn't reliably encode it) — better no tag than a wrong one.
const catOf = (d: Dataset) => d.category_id || d.category_name || "";

// Coarse data-nature label (mirrors the backend heuristic) so you can see at a glance whether a
// field is continuous/ratio/count/event/group/vector — and pick operators that fit it.
function fieldNature(f: any): string {
  if (String(f.type).toUpperCase() === "VECTOR") return "vector";
  const d = ((f.description || "") + " " + (f.id || "")).toLowerCase();
  const has = (...ws: string[]) => ws.some((w) => d.includes(w));
  if (has("flag", "indicator", "dummy", "binary", "1 if", "event", "announc", "rating", "recommendation", "upgrade", "downgrade", "surprise", "beat", "miss")) return "event";
  if (has("number of", "count", "# of", "days since", "days to", "days from", "quarters", "how many")) return "count";
  if (has("ratio", "percent", "%", "yield", "margin", "growth", " rate", "per share", "return", "score")) return "ratio";
  if (has("sector", "industry", "country", "currency", "exchange", "classification", "grouping")) return "group";
  return "continuous";
}

export function DataExplorer() {
  const R = useResearch();
  const nav = useNavigate();
  const { toast, toastErr } = useToast();
  const [busyDs, setBusyDs] = useState(false);
  const [busyF, setBusyF] = useState(false);

  // Guided flow: carry a pushed strategy's prompt into Generation once its data is ready.
  function continueToGeneration() {
    localStorage.setItem("ace2:gen:prompt", JSON.stringify(R.flow.promptBody || ""));
    localStorage.setItem("ace2:gen:reqds", JSON.stringify(R.flow.datasets || []));
    R.clearFlow();
    nav("/generate");
  }

  // dataset panel state
  const [dsFilter, setDsFilter] = useState("");
  const [dsCat, setDsCat] = useState("");        // category filter ("" = all)
  const [covMin, setCovMin] = useState(0);       // min coverage
  const [valMin, setValMin] = useState(0);       // min valueScore
  // field panel state
  const [fQuery, setFQuery] = useState("");
  const [fType, setFType] = useState<"ALL" | "VECTOR" | "MATRIX" | "GROUP">("ALL");
  const [fVirgin, setFVirgin] = useState(false);
  const [fPrefix, setFPrefix] = useState<string[]>([]);
  const [sampleN, setSampleN] = useState(50);

  const insts = R.instruments();
  const regions = R.regions(R.ctx.instrument);
  const delays = R.delays(R.ctx.instrument, R.ctx.region);
  const universes = R.universes(R.ctx.instrument, R.ctx.region, R.ctx.delay);

  // Change context but always keep delay/universe VALID for the chosen instrument+region, so a
  // fetch never sends a mismatched combination (e.g. JPN with TOP3000).
  function setCtxValid(patch: { instrument?: string; region?: string; delay?: number }) {
    const inst = patch.instrument ?? R.ctx.instrument;
    const region = patch.region ?? R.ctx.region;
    const ds = R.delays(inst, region);
    let delay = patch.delay ?? R.ctx.delay;
    if (ds.length && !ds.includes(delay)) delay = ds[0];
    const us = R.universes(inst, region, delay);
    let universe = R.ctx.universe;
    if (us.length && !us.includes(universe)) universe = us[0];
    R.setCtx({ instrument: inst, region, delay, universe });
  }

  // Once options load, snap any stale/invalid delay+universe (e.g. a persisted JPN + TOP3000) to a
  // real one for the region, so the fetch request itself sends the correct universe.
  useEffect(() => {
    if (!R.options.length) return;
    const ds = R.delays(R.ctx.instrument, R.ctx.region);
    const delay = (ds.length && !ds.includes(R.ctx.delay)) ? ds[0] : R.ctx.delay;
    const us = R.universes(R.ctx.instrument, R.ctx.region, delay);
    const universe = (us.length && !us.includes(R.ctx.universe)) ? us[0] : R.ctx.universe;
    if (delay !== R.ctx.delay || universe !== R.ctx.universe) R.setCtx({ delay, universe });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [R.options.length, R.ctx.instrument, R.ctx.region]);

  async function fetchDatasets() {
    setBusyDs(true);
    const q = new URLSearchParams({
      region: R.ctx.region || "USA", universe: R.ctx.universe || "TOP3000", delay: String(R.ctx.delay ?? 1),
      instrument_type: R.ctx.instrument || "EQUITY",
    });
    const d = await api.get<{ datasets: Dataset[]; error?: string }>(`/data/datasets?${q}`);
    setBusyDs(false);
    if (d.error) return toastErr(d.error);
    R.setDatasets(d.datasets || []);
    // In a guided flow, auto-tick the strategy's required datasets that are present.
    if (R.flow.datasets.length) {
      const present = (d.datasets || []).filter((x) => R.flow.datasets.includes(x.id)).map((x) => x.id);
      if (present.length) R.setSelDatasets([...new Set([...R.selDatasets, ...present])]);
    }
    toast(`Loaded ${d.datasets?.length ?? 0} datasets.`);
  }

  async function fetchFields() {
    if (!R.selDatasets.length) return toast("Tick at least one dataset first.", "warn");
    setBusyF(true);
    const d = await api.post<{ fields: Field[]; count: number; vector: number; matrix: number; error?: string }>(
      "/data/datafields",
      { dataset_ids: R.selDatasets, region: R.ctx.region, universe: R.ctx.universe, delay: R.ctx.delay, instrument_type: R.ctx.instrument }
    );
    setBusyF(false);
    if (d.error) return toastErr(d.error);
    R.setFields(d.fields || []);
    setFPrefix([]);
    toast(`Fetched ${d.count} fields (${d.vector}V / ${d.matrix}M).`);
  }

  // ── dataset list (text filter + category + coverage/value floors) ───────────────────
  const dsCategories = useMemo(() => [...new Set(R.datasets.map((d) => catOf(d)).filter(Boolean))].sort(), [R.datasets]);
  const shownDatasets = R.datasets.filter((x) => {
    const q = dsFilter.toLowerCase();
    const textOk = !q || String(x.id).toLowerCase().includes(q) || String(x.name || "").toLowerCase().includes(q)
      || String(catOf(x)).toLowerCase().includes(q);
    const catOk = !dsCat || catOf(x) === dsCat;
    const covOk = !covMin || (Number(x.coverage) || 0) >= covMin;
    const valOk = !valMin || (Number(x.valueScore) || 0) >= valMin;
    return textOk && catOk && covOk && valOk;
  });
  const toggleDs = (id: string) => {
    const s = new Set(R.selDatasets);
    s.has(id) ? s.delete(id) : s.add(id);
    R.setSelDatasets([...s]);
  };
  const [dsN, setDsN] = useState(20);
  const selectAllDs = () => R.setSelDatasets([...new Set([...R.selDatasets, ...shownDatasets.map((d) => d.id)])]);
  const randomDs = () => {
    const pool = shownDatasets.map((d) => d.id).sort(() => Math.random() - 0.5).slice(0, Math.max(1, dsN));
    R.setSelDatasets(pool);
    toast(`Randomly selected ${pool.length} of ${shownDatasets.length} dataset(s).`);
  };

  // ── field faceting (prefix computed against the OTHER filters) ──────────────────────
  const fieldsBase = useMemo(() => R.fields.filter((f) => {
    if (fType !== "ALL" && String(f.type).toUpperCase() !== fType) return false;
    if (fVirgin && !f.is_virgin) return false;
    const q = fQuery.toLowerCase();
    if (q && !(String(f.id).toLowerCase().includes(q) || String(f.description || "").toLowerCase().includes(q))) return false;
    return true;
  }), [R.fields, fType, fVirgin, fQuery]);

  const prefixCounts = useMemo(() => {
    const m: Record<string, number> = {};
    fieldsBase.forEach((f) => { const p = (f.prefix || String(f.id).slice(0, 3)).toLowerCase(); if (p) m[p] = (m[p] || 0) + 1; });
    return m;
  }, [fieldsBase]);
  const prefixKeys = Object.keys(prefixCounts).sort((a, b) => prefixCounts[b] - prefixCounts[a] || a.localeCompare(b));

  const shownFields = useMemo(() =>
    fPrefix.length ? fieldsBase.filter((f) => fPrefix.includes((f.prefix || String(f.id).slice(0, 3)).toLowerCase())) : fieldsBase,
    [fieldsBase, fPrefix]);

  const togglePrefix = (p: string) => setFPrefix((x) => x.includes(p) ? x.filter((v) => v !== p) : [...x, p]);
  const toggleField = (id: string) => {
    const s = new Set(R.selFields);
    s.has(id) ? s.delete(id) : s.add(id);
    R.setSelFields([...s]);
  };
  const selectShown = () => R.setSelFields([...new Set([...R.selFields, ...shownFields.map((f) => f.id)])]);
  const sample = () => {
    const pool = shownFields.map((f) => f.id).sort(() => Math.random() - 0.5).slice(0, Math.max(1, sampleN));
    R.setSelFields(pool);
    toast(`Sampled ${pool.length} of ${shownFields.length} shown field(s).`);
  };
  // Sample an EQUAL number of fields FROM EACH dataset, so every selected dataset is represented
  // and you can test several datasets at once (not just whichever has the most fields).
  const samplePerDataset = () => {
    const byDs: Record<string, string[]> = {};
    shownFields.forEach((f) => { const d = (f as any).dataset_id || "?"; (byDs[d] = byDs[d] || []).push(f.id); });
    const picked: string[] = [];
    for (const ids of Object.values(byDs))
      picked.push(...ids.sort(() => Math.random() - 0.5).slice(0, Math.max(1, sampleN)));
    if (!picked.length) return toast("No shown fields to sample.", "warn");
    R.setSelFields([...new Set(picked)]);
    toast(`Sampled up to ${sampleN} field(s) from each of ${Object.keys(byDs).length} dataset(s) — ${picked.length} total.`, "ok");
  };

  const nSelV = R.fields.filter((f) => R.selFields.includes(f.id) && String(f.type).toUpperCase() === "VECTOR").length;
  const nSelDs = new Set(R.fields.filter((f) => R.selFields.includes(f.id)).map((f) => (f as any).dataset_id).filter(Boolean)).size;

  return (
    <div className="dx">
      {R.flow.goal ? (
        <div className="panel" style={{ padding: "9px 14px", borderColor: "var(--acc)", background: "var(--acc-weak)" }}>
          <div className="dx-head" style={{ margin: 0 }}>
            <b style={{ color: "var(--acc)" }}>Guided · {R.flow.promptName || "Strategy"}</b>
            <span className="mut" style={{ fontSize: 12 }}>
              {R.flow.datasets.length ? <>Fetch {R.flow.datasets.map((d) => <code key={d}>{d}</code>).reduce((a, b) => <>{a}, {b}</>)}, tick them, select fields, then continue.</> : "Fetch data, select fields, then continue."}
            </span>
            <button className="btn sm" style={{ marginLeft: "auto" }} disabled={!R.selFields.length} onClick={continueToGeneration}>Continue To Generation →</button>
            <button className="btn ghost sm" onClick={() => R.clearFlow()}>Dismiss</button>
          </div>
        </div>
      ) : null}
      {/* context bar */}
      <div className="panel dx-ctx">
        <div className="dx-ctx-row">
          <label className="fld"><span>Instrument</span>
            <select value={R.ctx.instrument} onChange={(e) => setCtxValid({ instrument: e.target.value })}>
              {insts.map((i) => <option key={i}>{i}</option>)}
            </select></label>
          <label className="fld"><span>Region</span>
            <select value={R.ctx.region} onChange={(e) => setCtxValid({ region: e.target.value })}>
              {regions.map((r) => <option key={r}>{r}</option>)}
            </select></label>
          <label className="fld"><span>Delay</span>
            <select value={String(R.ctx.delay)} onChange={(e) => setCtxValid({ delay: intOr(e.target.value, 1) })}>
              {delays.map((d) => <option key={d} value={String(d)}>{d}</option>)}
            </select></label>
          <label className="fld"><span>Universe</span>
            <select value={R.ctx.universe} onChange={(e) => R.setCtx({ universe: e.target.value })}>
              {universes.map((u) => <option key={u}>{u}</option>)}
            </select></label>
          <button className="btn" style={{ alignSelf: "end" }} onClick={fetchDatasets} disabled={busyDs}>
            {busyDs ? <span className="spin" /> : null} Fetch datasets
          </button>
        </div>
      </div>

      {/* Post-selection guidance: once fields are picked, tell the user what to do next with
          buttons that route correctly. Hidden during a guided strategy flow (which has its own bar). */}
      {R.selFields.length && !R.flow.goal ? (
        <div className="panel dx-next">
          <div className="dx-next-lead">
            <b>{R.selFields.length} field{R.selFields.length === 1 ? "" : "s"} selected</b>
            <span className="mut">{nSelDs} dataset{nSelDs === 1 ? "" : "s"} · {nSelV}V / {R.selFields.length - nSelV}M · {R.ctx.region} D{R.ctx.delay} — what next?</span>
          </div>
          <div className="dx-next-actions">
            <button className="btn sm" onClick={() => nav("/generate")} title="Research hypotheses and generate alphas from these fields">✦ Alpha Lab →</button>
            <button className="btn ghost sm" onClick={() => nav("/templates")} title="Hand-build {field} templates and expand them over these fields">⛭ Template Studio →</button>
            <button className="btn ghost sm" onClick={() => nav("/strategies")} title="AI + semantic per-field hypotheses & operators for these fields">🧭 Strategy Lab →</button>
          </div>
        </div>
      ) : null}

      <div className="dx-split">
        {/* datasets */}
        <div className="panel dx-panel">
          <div className="dx-head">
            <b>Datasets</b>
            <span className="mut">{R.selDatasets.length} selected</span>
            <input placeholder="filter id / name / category" value={dsFilter}
              onChange={(e) => setDsFilter(e.target.value)} style={{ maxWidth: 180, marginLeft: "auto" }} />
            <button className="btn ghost sm" onClick={fetchFields} disabled={busyF}>
              {busyF ? <span className="spin" /> : null} Fetch fields →
            </button>
          </div>
          {R.datasets.length ? <>
            <div className="dx-filters wrap">
              <select value={dsCat} onChange={(e) => setDsCat(e.target.value)} style={{ maxWidth: 150 }} title="Filter by category">
                <option value="">all categories ({dsCategories.length})</option>
                {dsCategories.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
              <label className="fld" style={{ width: 96 }}><span>Coverage ≥</span>
                <NumberInput min={0} fallback={0} step="0.05" value={covMin} onChange={setCovMin} /></label>
              <label className="fld" style={{ width: 96 }}><span>Value ≥</span>
                <NumberInput min={0} fallback={0} step="0.5" value={valMin} onChange={setValMin} /></label>
              <span className="mut" style={{ fontSize: 11, alignSelf: "center" }}>{shownDatasets.length} shown</span>
            </div>
            <div className="dx-filters">
              <button className="btn ghost sm" onClick={selectAllDs}>Select all shown</button>
              <button className="btn ghost sm" onClick={() => R.setSelDatasets([])}>Clear</button>
              <button className="btn ghost sm" onClick={randomDs}>Random</button>
              <NumberInput min={1} fallback={20} value={dsN} onChange={setDsN} style={{ width: 64 }} />
            </div></> : null}
          <div className="panel-scroll">
            {!R.datasets.length ? <div className="empty">Pick a context and fetch datasets.</div> :
              <table><thead><tr><th></th><th>dataset</th><th>value</th><th>alphas</th></tr></thead>
                <tbody>{shownDatasets.map((d) => (
                  <tr key={d.id}>
                    <td><input type="checkbox" checked={R.selDatasets.includes(d.id)} onChange={() => toggleDs(d.id)} /></td>
                    <td><code>{d.id}</code>
                      {catOf(d) ? <span className="cat-tag" title="category">{catOf(d)}</span> : null}
                      <div className="mut sub">{(d.name || d.description || "").slice(0, 46)}</div></td>
                    <td>{d.valueScore ?? "—"}</td><td>{d.alphaCount ?? "—"}</td>
                  </tr>))}</tbody></table>}
          </div>
        </div>

        {/* fields */}
        <div className="panel dx-panel">
          <div className="dx-head">
            <b>Fields</b>
            <span className="mut">{R.selFields.length} selected · {nSelV}V</span>
          </div>
          <div className="dx-filters">
            <input placeholder="filter id / description" value={fQuery} onChange={(e) => setFQuery(e.target.value)} style={{ flex: 1, minWidth: 90 }} />
            {(["ALL", "VECTOR", "MATRIX", "GROUP"] as const).map((t) =>
              <span key={t} className={"pill" + (fType === t ? " on" : "")} onClick={() => setFType(t)}>{t.toLowerCase()}</span>)}
            <span className={"pill" + (fVirgin ? " on" : "")} onClick={() => setFVirgin((v) => !v)}>virgin</span>
          </div>
          {prefixKeys.length > 1 &&
            <div className="dx-filters wrap">
              <span className="mut" style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: ".5px" }}>prefix</span>
              <span className={"pill" + (fPrefix.length ? "" : " on")} onClick={() => setFPrefix([])}>all</span>
              {prefixKeys.slice(0, 10).map((p) =>
                <span key={p} className={"pill" + (fPrefix.includes(p) ? " on" : "")} onClick={() => togglePrefix(p)}>
                  {p} <span className="mut">{prefixCounts[p]}</span></span>)}
            </div>}
          <div className="dx-filters">
            <button className="btn ghost sm" onClick={selectShown}>Select shown</button>
            <button className="btn ghost sm" onClick={() => R.setSelFields([])}>Clear</button>
            <button className="btn ghost sm" onClick={sample}>Sample</button>
            <button className="btn ghost sm" onClick={samplePerDataset} title="Sample this many fields from EACH dataset (equal coverage)">Per dataset</button>
            <NumberInput min={1} fallback={50} value={sampleN} onChange={setSampleN} style={{ width: 64 }} />
          </div>
          <div className="panel-scroll">
            {!R.fields.length ? <div className="empty">Select datasets, then fetch fields.</div> :
              !shownFields.length ? <div className="empty">No fields match the filter.</div> :
                <table><thead><tr><th></th><th>field</th><th>type</th><th>alphas</th></tr></thead>
                  <tbody>{shownFields.map((f) => {
                    const t = String(f.type).toUpperCase();
                    return <tr key={f.id}>
                      <td><input type="checkbox" checked={R.selFields.includes(f.id)} onChange={() => toggleField(f.id)} /></td>
                      <td><code>{f.id}</code><div className="mut sub">{(f.description || "").slice(0, 50)}</div></td>
                      <td><span className={"badge " + (t === "VECTOR" ? "vec" : "mat")}>{t}</span>
                        <span className="badge" style={{ marginLeft: 4, opacity: 0.85 }} title="Data nature — pick operators that fit it">{fieldNature(f)}</span>
                        {f.is_virgin ? <span className="badge virgin">virgin</span> : null}</td>
                      <td>{f.alphaCount ?? "—"}{(f as any).coverage != null ? <div className="mut sub">{Math.round((Number((f as any).coverage) || 0) * 100)}% cov</div> : null}</td>
                    </tr>;
                  })}</tbody></table>}
          </div>
        </div>
      </div>
    </div>
  );
}
