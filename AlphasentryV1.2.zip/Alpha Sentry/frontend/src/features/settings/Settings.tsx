import { useEffect, useState } from "react";
import { api } from "../../lib/api";
import { useToast } from "../../lib/toast";
import { NumberInput } from "../../lib/NumberInput";

const PROVIDERS: Record<string, string> = {
  claude: "Claude (Anthropic)", openai: "OpenAI", gemini: "Gemini", deepseek: "DeepSeek",
  groq: "Groq (free)", huggingface: "Hugging Face", openrouter: "OpenRouter", mistral: "Mistral",
  together: "Together AI", xai: "xAI (Grok)",
};

type Preset = { name: string; label: string; free: string; local: boolean; key_optional: boolean; needs_account: boolean; base_url: string; default_base_url: string; overridden: boolean; set: boolean; hint: string };
type Custom = { name: string; label: string; base_url: string; model: string; set: boolean; hint: string };

// Settings: API keys, the active LLM provider + model with a live key test, BRAIN login,
// your simulation tags, and appearance.
export function Settings() {
  const { toast, toastErr } = useToast();
  const [status, setStatus] = useState<Record<string, { set: boolean; hint: string }>>({});
  const [prov, setProv] = useState<{ available: string[]; preferred: string; used: string[] }>({ available: [], preferred: "", used: [] });
  const [keyProv, setKeyProv] = useState("claude");
  const [keyVal, setKeyVal] = useState("");
  const [presets, setPresets] = useState<Preset[]>([]);
  const [customs, setCustoms] = useState<Custom[]>([]);
  const [acct, setAcct] = useState(""); const [acctSet, setAcctSet] = useState(false);
  const [baseUrl, setBaseUrl] = useState("");
  const [cu, setCu] = useState({ label: "", base_url: "", key: "", model: "" });
  const [modelProv, setModelProv] = useState("gemini");
  const [models, setModels] = useState<{ models: string[]; current: string }>({ models: [], current: "" });
  const [testOut, setTestOut] = useState<string>("");
  const [testing, setTesting] = useState(false);
  const [tag, setTag] = useState(() => localStorage.getItem("ace2-tag") || "");
  const [winnerTag, setWinnerTag] = useState(() => localStorage.getItem("ace2-winnertag") || "");
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [loginMsg, setLoginMsg] = useState("");
  const [bioUrl, setBioUrl] = useState("");
  const [pruneSharpe, setPruneSharpe] = useState(0.5);
  const [pruneFit, setPruneFit] = useState(0.5);
  // Auto-update-from-upstream is disabled in this fork — updates are applied manually by
  // its owner only (pull/rebuild yourself).

  async function clearResults() {
    if (!window.confirm("Delete ALL simulation results? This cannot be undone.")) return;
    const d = await api.post<any>("/analytics/results/clear");
    return d.error ? toastErr(d.error) : toast(`Deleted ${d.deleted} result(s).`, "ok");
  }
  async function pruneResults() {
    if (!window.confirm(`Delete results with |Sharpe| < ${pruneSharpe} AND |Fitness| < ${pruneFit}?`)) return;
    const d = await api.post<any>("/analytics/results/prune", { min_sharpe: pruneSharpe, min_fitness: pruneFit });
    return d.error ? toastErr(d.error) : toast(`Deleted ${d.deleted} weak result(s).`, "ok");
  }
  async function clearPrompts() {
    if (!window.confirm("Delete ALL saved prompts? This cannot be undone.")) return;
    const d = await api.post<any>("/generate/prompts/clear");
    return d.error ? toastErr(d.error) : toast(`Deleted ${d.deleted} prompt(s).`, "ok");
  }
  async function resetAll() {
    if (!window.confirm("RESET EVERYTHING? This wipes results, prompts, usage, research sessions and catalogued datasets/fields. Your BRAIN session and API keys are kept. Cannot be undone.")) return;
    const d = await api.post<any>("/analytics/reset");
    return d.error ? toastErr(d.error) : toast("Everything reset.", "ok");
  }

  const loadKeys = () => api.get<any>("/settings/keys").then((d) => setStatus(d.status || {}));
  const loadProv = () => api.get<any>("/settings/providers").then((d) => {
    // Never trust a degraded/404 response to have the shape we want — default every field
    // so a backend still starting up can't white-screen this whole screen.
    const av: string[] = Array.isArray(d?.available) ? d.available : [];
    const pref: string = d?.preferred ?? "";
    setProv({ available: av, preferred: pref, used: Array.isArray(d?.used) ? d.used : [] });
    // Point the model panel at the PREFERRED provider so its models preload and stay selected
    // until the user changes provider. Falls back to the current pick, then the first available.
    if (av.length) setModelProv((m) => (pref && av.includes(pref)) ? pref : (av.includes(m) ? m : av[0]));
  });
  const loadCat = () => api.get<any>("/settings/provider_catalog").then((d) => {
    setPresets(Array.isArray(d?.presets) ? d.presets : []); setCustoms(Array.isArray(d?.custom) ? d.custom : []); setAcctSet(!!d?.account_set);
  });
  useEffect(() => { loadKeys(); loadProv(); loadCat(); }, []);
  const label = (k: string) => PROVIDERS[k] ?? presets.find((x) => x.name === k)?.label ?? customs.find((x) => x.name === k)?.label ?? k;
  const sel = presets.find((x) => x.name === keyProv);
  useEffect(() => { setBaseUrl(sel?.base_url ?? ""); }, [keyProv, presets]);
  async function saveBase(reset = false) {
    const r = await api.post<any>(`/settings/providers/${keyProv}/base_url`, { url: reset ? "" : baseUrl });
    if (r.detail || r.error) return toastErr(String(r.detail ?? r.error));
    toast(reset ? "Address reset to the default." : "Address saved."); loadCat();
  }
  async function saveAcct() {
    if (!acct.trim()) return;
    await api.post("/settings/keys", { updates: { cloudflare_account: acct.trim() } });
    setAcct(""); toast("Cloudflare account ID saved."); loadCat();
  }
  async function addCustom() {
    const r = await api.post<any>("/settings/custom", cu);
    if (r.detail || r.error) return toastErr(String(r.detail ?? r.error));
    setCu({ label: "", base_url: "", key: "", model: "" }); toast("Provider saved."); loadCat(); loadProv();
  }
  async function delCustom(n: string) {
    if (!window.confirm("Remove this provider?")) return;
    await api.post(`/settings/custom/${n}/delete`); loadCat(); loadProv();
  }
  useEffect(() => {
    if (modelProv) api.get<any>(`/settings/providers/${modelProv}/models`)
      .then((d) => setModels({ models: Array.isArray(d?.models) ? d.models : [], current: d?.current ?? "" }));
  }, [modelProv]);

  async function saveKey() {
    if (!keyVal.trim()) return;
    const d = await api.post("/settings/keys", { updates: { [keyProv]: keyVal.trim() } });
    if (d.error) return toastErr(d.error);
    setKeyVal(""); toast(`${label(keyProv)} key saved.`); loadKeys(); loadProv(); loadCat();
  }
  async function deleteKey() {
    if (!window.confirm(`Delete the ${label(keyProv)} API key?`)) return;
    const d = await api.post<any>(`/settings/keys/${keyProv}/delete`);
    if (d.error) return toastErr(d.error);
    setStatus(d.status || {}); loadProv(); loadCat(); toast(`${label(keyProv)} key deleted.`);
  }
  async function clearAllKeys() {
    if (!window.confirm("Delete ALL stored API keys? This cannot be undone.")) return;
    const d = await api.post<any>("/settings/keys/clear");
    if (d.error) return toastErr(d.error);
    setStatus(d.status || {}); loadProv(); toast("All API keys deleted.");
  }
  async function setPreferred(p: string) {
    await api.post("/settings/providers", { preferred: p }); loadProv();
  }
  async function setModel(m: string) {
    await api.post(`/settings/providers/${modelProv}/model`, { model: m });
    setModels((s) => ({ ...s, current: m })); toast(`${modelProv} → ${m}`);
  }
  async function testKey() {
    setTesting(true); setTestOut("testing…");
    const r = await api.post<any>(`/settings/providers/${modelProv}/test`);
    setTesting(false);
    setTestOut(r.ok ? `✓ works — ${r.model} replied` : `✗ ${r.error}${r.raw ? " · " + r.raw : ""}`);
  }
  function saveTags() {
    localStorage.setItem("ace2-tag", tag); localStorage.setItem("ace2-winnertag", winnerTag);
    toast("Tags saved — used when you simulate.");
  }
  async function beginLogin(force = false): Promise<void> {
    setLoginMsg("contacting BRAIN…"); setBioUrl("");
    const r = await api.post<any>("/settings/login/begin", { email: email || null, password: pass || null, force });
    // A task is running — re-login would cancel the BRAIN session and fail it. Confirm before forcing.
    if (r.job_running && !force) {
      setLoginMsg("");
      if (window.confirm(`${r.error}\n\nLog in anyway and lose the running task?`)) await beginLogin(true);
      return;
    }
    if (r.error) { setLoginMsg(""); toastErr(r.error); return; }
    const url = r.url || "";
    if (url) setBioUrl(url);   // always surface a clickable link as a fallback
    if (r.state === "biometrics" && url) {
      const w = window.open(url, "_blank", "noopener");   // try to open the biometrics page for them
      setLoginMsg(w
        ? "Biometrics opened in a new tab — complete it there, then click Finish login."
        : "Couldn't open the tab automatically (popup blocked). Click “Open biometrics page” below, complete it, then Finish login.");
    } else {
      setLoginMsg(r.message || (url
        ? "Click “Open biometrics page” below, complete it, then Finish login."
        : "Open the biometrics link in your browser, then click Finish login."));
    }
  }
  async function completeLogin() {
    const r = await api.post<any>("/settings/login/complete");
    if (r.error) return toastErr(r.error);
    setLoginMsg("Login complete."); setBioUrl(""); toast("Logged in.");
  }

  return (
    <div className="dx-split" style={{ flex: 1, minHeight: 0 }}>
      {/* keys + providers */}
      <div className="panel panel-scroll" style={{ padding: 14 }}>
        <div className="dx-head"><b>LLM providers</b></div>
        <div className="mut" style={{ fontSize: 12, marginBottom: 8 }}>The selected provider is the only one used for generation.</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
          <label className="fld"><span>Active provider</span>
            <select value={prov.preferred} onChange={(e) => setPreferred(e.target.value)}>
              <option value="">auto (first available)</option>
              {prov.available.map((p) => <option key={p} value={p}>{label(p)}</option>)}
            </select></label>
          <label className="fld"><span>Model for {modelProv}</span>
            <select value={models.current} onChange={(e) => setModel(e.target.value)}>
              {models.models.map((m) => <option key={m}>{m}</option>)}
            </select></label>
        </div>
        <div className="dx-filters" style={{ marginTop: 8 }}>
          <select value={modelProv} onChange={(e) => setModelProv(e.target.value)} style={{ maxWidth: 150 }}>
            {[...Object.keys(PROVIDERS), ...presets.map((x) => x.name), ...customs.map((x) => x.name)].map((p) => <option key={p} value={p}>{label(p)}</option>)}
          </select>
          <button className="btn ghost sm" onClick={testKey} disabled={testing}>{testing ? <><span className="spin" /> Testing…</> : "✓ Test Key"}</button>
        </div>
        {testOut ? <div className="mut" style={{ fontSize: 12, marginTop: 6, color: testOut.startsWith("✓") ? "var(--ok)" : testOut.startsWith("✗") ? "var(--bad)" : "var(--mut)" }}>{testOut}</div> : null}

        <div className="dx-head" style={{ marginTop: 14 }}><b>API keys</b>
          <span className="mut">{[...Object.keys(PROVIDERS), ...presets.map((x) => x.name)].filter((k) => status[k]?.set).length} of {Object.keys(PROVIDERS).length + presets.length} set</span></div>
        <div className="dx-filters">
          <select value={keyProv} onChange={(e) => setKeyProv(e.target.value)} style={{ maxWidth: 150 }}>
            <optgroup label="Main providers">
              {Object.entries(PROVIDERS).map(([k, v]) => <option key={k} value={k}>{v}{status[k]?.set ? " ✓" : ""}</option>)}
            </optgroup>
            <optgroup label="Free and extra providers">
              {presets.map((x) => <option key={x.name} value={x.name}>{x.label}{status[x.name]?.set ? " ✓" : ""}</option>)}
            </optgroup>
          </select>
          <input type="password" placeholder="paste key…" value={keyVal} onChange={(e) => setKeyVal(e.target.value)} style={{ flex: 1 }} />
          <button className="btn sm" onClick={saveKey}>Save</button>
          <button className="btn ghost sm" onClick={deleteKey} disabled={!status[keyProv]?.set} title="Delete this provider's stored key" style={{ color: "var(--bad)" }}>Delete</button>
        </div>
        {sel ? (
          <div style={{ marginTop: 8, padding: 8, border: "1px solid var(--line, #8884)", borderRadius: 8 }}>
            <div style={{ fontSize: 12 }}><b>{sel.label}</b> · {sel.free}</div>
            {sel.key_optional ? <div className="mut" style={{ fontSize: 12 }}>No real key needed: type any word (for example “local”) in the key box and Save to switch it on. Make sure the program is running.</div> : null}
            <div className="dx-filters" style={{ marginTop: 6 }}>
              <input value={baseUrl} onChange={(e) => setBaseUrl(e.target.value)} style={{ flex: 1 }} title="Address of the provider's OpenAI-compatible API" />
              <button className="btn sm" onClick={() => saveBase(false)}>Save address</button>
              <button className="btn ghost sm" disabled={!sel.overridden} onClick={() => saveBase(true)}>Reset</button>
            </div>
            {sel.needs_account ? (
              <div className="dx-filters" style={{ marginTop: 6 }}>
                <input placeholder={acctSet ? "Cloudflare account ID saved ✓ (type to replace)" : "Cloudflare account ID"} value={acct} onChange={(e) => setAcct(e.target.value)} style={{ flex: 1 }} />
                <button className="btn sm" onClick={saveAcct}>Save ID</button>
              </div>) : null}
          </div>) : null}
        <div className="dx-head" style={{ marginTop: 14 }}><b>Your own provider</b></div>
        <div className="mut" style={{ fontSize: 12, marginBottom: 6 }}>Any service that speaks the OpenAI API (Azure-style deployments excluded). Leave the key empty for a local server.</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
          <input placeholder="Name (e.g. My gateway)" value={cu.label} onChange={(e) => setCu({ ...cu, label: e.target.value })} />
          <input placeholder="Address, e.g. https://api.example.com/v1" value={cu.base_url} onChange={(e) => setCu({ ...cu, base_url: e.target.value })} />
          <input type="password" placeholder="Key (optional)" value={cu.key} onChange={(e) => setCu({ ...cu, key: e.target.value })} />
          <input placeholder="Model (optional, can be picked later)" value={cu.model} onChange={(e) => setCu({ ...cu, model: e.target.value })} />
        </div>
        <div className="dx-filters" style={{ marginTop: 6 }}><button className="btn sm" onClick={addCustom}>Add / update provider</button></div>
        {customs.map((c) => (
          <div key={c.name} className="dx-filters" style={{ marginTop: 4, fontSize: 12 }}>
            <span style={{ flex: 1 }}><b>{c.label}</b> · {c.base_url}{c.model ? ` · ${c.model}` : ""}{c.hint ? ` · key ${c.hint}` : ""}</span>
            <button className="btn ghost sm" style={{ color: "var(--bad)" }} onClick={() => delCustom(c.name)}>Remove</button>
          </div>))}
        <div className="dx-filters" style={{ marginTop: 6 }}>
          <button className="btn ghost sm" onClick={clearAllKeys} style={{ color: "var(--bad)" }}>Delete all keys</button>
        </div>
        <div className="mut" style={{ fontSize: 11, marginTop: 6 }}>Keys are stored locally in ~/secrets/ace_keys.json and never leave your machine.</div>
      </div>

      {/* login + tags + appearance */}
      <div className="panel panel-scroll" style={{ padding: 14 }}>
        <div className="dx-head"><b>Updates</b></div>
        <div className="mut" style={{ fontSize: 12 }}>
          Auto-update-from-upstream is turned off in this build — this copy is updated manually,
          on its owner's own schedule, not pulled automatically from any remote source.
        </div>

        <div className="dx-head" style={{ marginTop: 14 }}><b>BRAIN session</b></div>
        <div className="mut" style={{ fontSize: 12, marginBottom: 8 }}>Login is never automatic. Enter your BRAIN details, open the biometrics link, then Finish.</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
          <label className="fld"><span>Email (blank uses saved)</span><input value={email} onChange={(e) => setEmail(e.target.value)} /></label>
          <label className="fld"><span>Password</span><input type="password" value={pass} onChange={(e) => setPass(e.target.value)} /></label>
        </div>
        <div className="dx-filters" style={{ marginTop: 8 }}>
          <button className="btn sm" onClick={() => beginLogin()}>Begin login</button>
          <button className="btn ghost sm" onClick={completeLogin}>Finish login</button>
        </div>
        {loginMsg ? <div className="mut" style={{ fontSize: 12, marginTop: 6, wordBreak: "break-all" }}>{loginMsg}</div> : null}
        {bioUrl ? <div style={{ marginTop: 8 }}>
          <a className="btn sm" href={bioUrl} target="_blank" rel="noopener noreferrer">Open biometrics page →</a>
        </div> : null}

        <div className="dx-head" style={{ marginTop: 14 }}><b>Your tags</b></div>
        <div className="mut" style={{ fontSize: 12, marginBottom: 8 }}>Applied when you simulate — nothing is hardcoded.</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr auto", gap: 8 }}>
          <label className="fld"><span>Tag every alpha</span><input value={tag} onChange={(e) => setTag(e.target.value)} placeholder="my_news" /></label>
          <label className="fld"><span>Winner tag</span><input value={winnerTag} onChange={(e) => setWinnerTag(e.target.value)} placeholder="my_winner" /></label>
          <button className="btn sm" style={{ alignSelf: "end" }} onClick={saveTags}>Save</button>
        </div>

        <div className="dx-head" style={{ marginTop: 14 }}><b>Appearance</b></div>
        <div className="mut" style={{ fontSize: 12 }}>Use the sun / moon toggle in the top bar to switch between light and dark mode.</div>

        <div className="dx-head" style={{ marginTop: 16 }}><b>Data management</b></div>
        <div className="mut" style={{ fontSize: 12, marginBottom: 8 }}>Local database only — your BRAIN session and API keys are never touched.</div>
        <div className="dx-filters wrap">
          <button className="btn ghost sm" onClick={clearResults}>Delete all results</button>
          <button className="btn ghost sm" onClick={clearPrompts}>Delete all prompts</button>
          <button className="btn ghost sm" onClick={resetAll} style={{ color: "var(--bad)", borderColor: "var(--bad)" }}>Reset everything</button>
        </div>
        <div className="dx-filters" style={{ marginTop: 8, alignItems: "end" }}>
          <label className="fld" style={{ width: 92 }}><span>|Sharpe| &lt;</span>
            <NumberInput min={0} fallback={0.5} step="0.1" value={pruneSharpe} onChange={setPruneSharpe} /></label>
          <label className="fld" style={{ width: 92 }}><span>|Fitness| &lt;</span>
            <NumberInput min={0} fallback={0.5} step="0.1" value={pruneFit} onChange={setPruneFit} /></label>
          <button className="btn ghost sm" onClick={pruneResults}>Delete weak results</button>
        </div>
        <div className="mut" style={{ fontSize: 11, marginTop: 4 }}>“Delete weak results” removes alphas whose absolute Sharpe AND Fitness are both below these floors.</div>
      </div>
    </div>
  );
}
