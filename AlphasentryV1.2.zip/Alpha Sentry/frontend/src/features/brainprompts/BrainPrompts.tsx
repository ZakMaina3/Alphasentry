import { useEffect, useMemo, useState, type CSSProperties } from "react";
import { api } from "../../lib/api";
import { useToast } from "../../lib/toast";
import { NumberInput } from "../../lib/NumberInput";

// BRAIN "LLM prompt" submissions: build the prompt from a thesis, validate the model's sample output
// against the 7-field JSON contract, and keep every field of the BRAIN form ready to copy.

const MAX = 10000;
const EMPTY = { id: 0, name: "", model: "", model_version: "", update_frequency: "", weight: "", prompt: "",
  sample_output: "", thesis: "", status: "draft", notes: "" };
const SEC: CSSProperties = { fontSize: 11, color: "var(--mut)", textTransform: "uppercase", letterSpacing: ".5px", marginTop: 14 };

export function BrainPrompts() {
  const { toast, toastErr } = useToast();
  const [items, setItems] = useState<any[]>([]);
  const [cur, setCur] = useState<any>({ ...EMPTY });
  const [presets, setPresets] = useState<Record<string, any>>({});
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState(false);
  const [showBuilder, setShowBuilder] = useState(true);
  // builder inputs
  const [role, setRole] = useState("");
  const [task, setTask] = useState("");
  const [universe, setUniverse] = useState("");
  const [n, setN] = useState(50);
  const [horizon, setHorizon] = useState(21);
  const [windowDays, setWindowDays] = useState(90);
  const [language, setLanguage] = useState("");
  const [extra, setExtra] = useState("");
  // validation
  const [out, setOut] = useState<any>(null);
  const [formErr, setFormErr] = useState<Record<string, string>>({});

  async function load() {
    const [l, p] = await Promise.all([api.get<any>("/brain-prompts"), api.get<any>("/brain-prompts/presets")]);
    if (!l.error) setItems(l.items || []);
    if (!p.error) setPresets(p.presets || {});
  }
  useEffect(() => { load(); }, []);

  const set = (k: string, v: any) => { setCur((c: any) => ({ ...c, [k]: v })); setDirty(true); };
  const chars = (cur.prompt || "").length;

  function open(it: any) {
    if (dirty && !window.confirm("Discard unsaved changes?")) return;
    setCur({ ...EMPTY, ...it }); setDirty(false); setOut(null); setFormErr({});
  }
  function fresh() { open({ ...EMPTY }); }

  async function save(status?: string) {
    setBusy(true);
    const body = { ...cur, ...(status ? { status } : {}) };
    const r = cur.id ? await api.patch<any>(`/brain-prompts/${cur.id}`, body) : await api.post<any>("/brain-prompts", body);
    setBusy(false);
    if (r.error) return toastErr(r.error);
    setCur(r); setDirty(false); toast("Saved.", "ok"); load();
  }
  async function del() {
    if (!cur.id || !window.confirm(`Delete “${cur.name || "this prompt"}”?`)) return;
    await api.delete(`/brain-prompts/${cur.id}`); fresh(); load();
  }

  function usePreset(key: string) {
    const p = presets[key]; if (!p) return;
    setRole(p.role); setTask(p.task); setUniverse(p.universe);
    toast(`${p.label} loaded — edit the three boxes, then Generate prompt.`);
  }
  async function draft() {
    if (!cur.thesis.trim()) return toast("Write the thesis first (one or two lines).", "warn");
    setBusy(true);
    const r = await api.post<any>("/brain-prompts/draft", { thesis: cur.thesis });
    setBusy(false);
    if (r.error) return toastErr(r.error);
    setRole(r.role); setTask(r.task); setUniverse(r.universe);
    toast("Drafted — review and edit, then Generate prompt.", "ok");
  }
  async function build() {
    const r = await api.post<any>("/brain-prompts/build", { role, task, universe, n, horizon, window_days: windowDays, language, extra });
    if (r.error) return toastErr(r.error);
    set("prompt", r.prompt);
    toast(r.too_long ? `Generated, but ${r.chars} characters is over the ${MAX} limit — shorten the three boxes.` : "Prompt generated.", r.too_long ? "warn" : "ok");
  }
  async function check() {
    const r = await api.post<any>("/brain-prompts/check", { sample_output: cur.sample_output, expect_n: n, form: cur });
    if (r.error) return toastErr(r.error);
    setOut(r.output); setFormErr(r.form || {});
    const bad = Object.keys(r.form || {}).length + (r.output?.errors?.length || 0);
    toast(bad ? `${bad} problem(s) found.` : "Everything checks out — ready to paste into BRAIN.", bad ? "warn" : "ok");
  }
  const copy = async (text: string, what: string) => { try { await navigator.clipboard.writeText(text || ""); toast(`${what} copied.`, "ok"); } catch { toast("Copy failed.", "warn"); } };

  const FieldErr = ({ k }: { k: string }) => formErr[k] ? <div style={{ color: "var(--bad)", fontSize: 11, marginTop: 2 }}>{formErr[k]}</div> : null;
  const CopyBtn = ({ k, what }: { k: string; what: string }) =>
    <span className="pill" onClick={() => copy(cur[k], what)} title="Copy for the BRAIN form">copy</span>;
  const rows = useMemo(() => (out?.errors || []).slice(0, 60), [out]);

  return (
    <div className="dx-split" style={{ flex: 1, minHeight: 0 }}>
      <div className="panel" style={{ padding: 14, maxWidth: 300 }}>
        <div className="dx-head"><b>BRAIN Prompts</b>
          <button className="btn sm" style={{ marginLeft: "auto" }} onClick={fresh}>+ New</button></div>
        <div className="panel-scroll">
          {!items.length ? <div className="empty">No prompts yet. Build one on the right.</div> :
            items.map((it) => (
              <div key={it.id} onClick={() => open(it)} style={{ padding: "8px 6px", cursor: "pointer", borderRadius: 6,
                background: cur.id === it.id ? "var(--hover, rgba(255,255,255,.06))" : undefined }}>
                <div style={{ fontSize: 12, fontWeight: 600 }}>{it.name || "(unnamed)"}</div>
                <div className="mut" style={{ fontSize: 11 }}>{[it.model, it.update_frequency, it.weight && `w ${it.weight}`].filter(Boolean).join(" · ") || "incomplete"}
                  {" · "}<span style={{ color: it.status === "submitted" ? "var(--ok)" : undefined }}>{it.status}</span></div>
              </div>))}
        </div>
      </div>

      <div className="panel" style={{ padding: 14 }}>
        <div className="dx-head"><b>{cur.id ? "Edit prompt" : "New prompt"}</b>
          {dirty ? <span className="badge" style={{ marginLeft: 8 }}>unsaved</span> : null}
          <span style={{ marginLeft: "auto", display: "flex", gap: 6 }}>
            <button className="btn sm" disabled={busy} onClick={() => save()}>Save</button>
            <button className="btn ghost sm" disabled={busy} onClick={() => save("submitted")} title="Mark as submitted on BRAIN">Mark submitted</button>
            {cur.id ? <button className="btn ghost sm" onClick={del}>Delete</button> : null}</span></div>
        <div className="panel-scroll">

          <div style={{ ...SEC, marginTop: 0, cursor: "pointer" }} onClick={() => setShowBuilder((v) => !v)}>{showBuilder ? "▾" : "▸"} 1 · Build the prompt from a thesis</div>
          {showBuilder ? <div style={{ marginTop: 6 }}>
            <label className="fld"><span>Thesis (what is the idea?)</span>
              <textarea value={cur.thesis} onChange={(e) => set("thesis", e.target.value)} style={{ minHeight: 50 }}
                placeholder="e.g. semiconductor momentum combined with fresh earnings and export-control catalysts" /></label>
            <div className="dx-filters wrap" style={{ marginTop: 6 }}>
              {Object.entries(presets).map(([k, p]: any) => <span key={k} className="pill" onClick={() => usePreset(k)}>{p.label}</span>)}
              <span className="pill on" onClick={draft} title="Let the LLM write the three boxes from your thesis">✨ Draft with AI</span>
            </div>
            <label className="fld" style={{ marginTop: 8 }}><span>Role</span>
              <textarea value={role} onChange={(e) => setRole(e.target.value)} style={{ minHeight: 44 }} placeholder="You are a senior … analyst specializing in …" /></label>
            <label className="fld" style={{ marginTop: 6 }}><span>Task</span>
              <textarea value={task} onChange={(e) => setTask(e.target.value)} style={{ minHeight: 64 }} placeholder="What to search, assess and decide…" /></label>
            <label className="fld" style={{ marginTop: 6 }}><span>Equity universe</span>
              <textarea value={universe} onChange={(e) => setUniverse(e.target.value)} style={{ minHeight: 44 }} placeholder="Which listed companies, regions, sectors…" /></label>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8, marginTop: 8 }}>
              <label className="fld" title="About 50 gives the model enough context per name"><span>Instruments</span><NumberInput min={5} max={200} fallback={50} value={n} onChange={setN} /></label>
              <label className="fld"><span>Horizon (trading days)</span><NumberInput min={1} max={252} fallback={21} value={horizon} onChange={setHorizon} /></label>
              <label className="fld"><span>Recency window (days)</span><NumberInput min={7} max={365} fallback={90} value={windowDays} onChange={setWindowDays} /></label>
              <label className="fld"><span>Language</span><input value={language} onChange={(e) => setLanguage(e.target.value)} placeholder="English" /></label>
            </div>
            <label className="fld" style={{ marginTop: 6 }}><span>Extra rule (optional)</span>
              <input value={extra} onChange={(e) => setExtra(e.target.value)} placeholder="e.g. exclude companies under USD 2bn market cap" /></label>
            <button className="btn sm" style={{ marginTop: 8 }} onClick={build}>Generate prompt</button>
          </div> : null}

          <div style={SEC}>2 · BRAIN form fields</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginTop: 6 }}>
            <label className="fld"><span>Prompt name <CopyBtn k="name" what="Name" /></span>
              <input value={cur.name} onChange={(e) => set("name", e.target.value)} /><FieldErr k="name" /></label>
            <label className="fld"><span>Model <CopyBtn k="model" what="Model" /></span>
              <input value={cur.model} onChange={(e) => set("model", e.target.value)} placeholder="as listed in BRAIN's Model dropdown" /><FieldErr k="model" /></label>
            <label className="fld"><span>Model version <CopyBtn k="model_version" what="Model version" /></span>
              <input value={cur.model_version} onChange={(e) => set("model_version", e.target.value)} /><FieldErr k="model_version" /></label>
            <label className="fld"><span>Update frequency <CopyBtn k="update_frequency" what="Frequency" /></span>
              <input value={cur.update_frequency} onChange={(e) => set("update_frequency", e.target.value)} list="bp-freq" placeholder="as listed in BRAIN" />
              <datalist id="bp-freq"><option value="Daily" /><option value="Weekly" /><option value="Monthly" /></datalist><FieldErr k="update_frequency" /></label>
            <label className="fld"><span>Prompt weight (0–1, ≤2 decimals) <CopyBtn k="weight" what="Weight" /></span>
              <input value={cur.weight} onChange={(e) => set("weight", e.target.value)} placeholder="0.25" /><FieldErr k="weight" /></label>
          </div>

          <label className="fld" style={{ marginTop: 8 }}>
            <span>Prompt <CopyBtn k="prompt" what="Prompt" />
              <span className="mut" style={{ marginLeft: 8, color: chars > MAX ? "var(--bad)" : undefined }}>{chars} / {MAX}</span></span>
            <textarea value={cur.prompt} onChange={(e) => set("prompt", e.target.value)} style={{ minHeight: 220, fontFamily: "monospace", fontSize: 12 }} /><FieldErr k="prompt" /></label>

          <div style={SEC}>3 · Sample prompt output</div>
          <div className="mut" style={{ fontSize: 11, margin: "4px 0" }}>Run the prompt in a fresh chat of the same model (with web search on), then paste the exact response here.</div>
          <label className="fld"><span>Sample output <CopyBtn k="sample_output" what="Sample output" /></span>
            <textarea value={cur.sample_output} onChange={(e) => set("sample_output", e.target.value)} style={{ minHeight: 160, fontFamily: "monospace", fontSize: 12 }}
              placeholder='[ { "company_name": "…", "ticker": "…", "isin": "…", "mic": "…", "confidence_score": 0.6, "investment_horizon": 21, "return_prediction": 0.04 } ]' /><FieldErr k="sample_output" /></label>
          <button className="btn sm" style={{ marginTop: 8 }} onClick={check}>Check everything</button>

          {out ? <div style={{ marginTop: 10 }}>
            <div style={{ fontSize: 12 }}>
              <span className={"badge" + (out.ok ? " ok" : "")}>{out.ok ? "output valid" : `${out.errors.length} error(s)`}</span>{" "}
              {out.summary?.instruments ? <span className="mut">{out.summary.instruments} instruments · {out.summary.long} long · {out.summary.short} short
                {out.summary.avg_abs_confidence != null ? ` · avg |confidence| ${out.summary.avg_abs_confidence}` : ""}
                {out.summary.horizons?.length ? ` · horizon ${out.summary.horizons.join("/")}d` : ""}</span> : null}</div>
            {(out.warnings || []).map((w: string, i: number) => <div key={i} className="mut" style={{ fontSize: 11, marginTop: 4 }}>⚠ {w}</div>)}
            {rows.length ? <table style={{ marginTop: 6 }}><thead><tr><th>Row</th><th>Field</th><th>Problem</th></tr></thead>
              <tbody>{rows.map((e: any, i: number) => <tr key={i}><td className="mut">{e.row || "—"}</td><td style={{ fontSize: 11 }}>{e.field || "—"}</td><td style={{ fontSize: 12 }}>{e.msg}</td></tr>)}</tbody></table> : null}
            {out.errors?.length > rows.length ? <div className="mut" style={{ fontSize: 11 }}>…and {out.errors.length - rows.length} more.</div> : null}
          </div> : null}

          <label className="fld" style={{ marginTop: 14 }}><span>Notes</span>
            <textarea value={cur.notes} onChange={(e) => set("notes", e.target.value)} style={{ minHeight: 44 }} placeholder="what you changed between versions, results, …" /></label>
        </div>
      </div>
    </div>
  );
}
