import React, { useEffect, useMemo, useState } from "react";
import { api } from "../../lib/api";
import { useToast } from "../../lib/toast";

type Res = Record<string, any>;
async function call(method: "get" | "post", path: string, body?: unknown): Promise<{ d: Res; err?: string }> {
  const d: Res = method === "get" ? await api.get<Res>(path) : await api.post<Res>(path, body);
  const raw = d.error ?? d.detail;
  return { d, err: raw == null ? undefined : typeof raw === "string" ? raw : JSON.stringify(raw) };
}
const B = "/harness_engine";
const n3 = (v: any) => (v == null ? "—" : typeof v === "number" ? v.toFixed(3) : String(v));
const dur = (s: number) => (s >= 3600 ? `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m` : s >= 60 ? `${Math.floor(s / 60)}m ${s % 60}s` : `${s}s`);

/** The 8 simulation slots: who holds each one, where, how long; click a busy tile to abandon its batch. */
export function SlotsPanel() {
  const { toast, toastErr } = useToast();
  const [v, setV] = useState<Res | null>(null);
  const load = async () => { const { d, err } = await call("get", `${B}/slots`); if (!err) setV(d); };
  useEffect(() => { load(); const t = setInterval(load, 3000); return () => clearInterval(t); }, []);
  const total: number = v?.total ?? 8;
  const batches: Res[] = v?.batches ?? [];
  const held: Record<string, number> = v?.lease?.held ?? {};
  // slots held through the shared lease that have no batch record (Supersentry runs single simulations)
  const covered = { harness: 0, autopilot: 0, superpilot: 0 } as Record<string, number>;
  batches.forEach((b) => { const k = b.task === "autopilot" ? "autopilot" : b.task === "superpilot" ? "superpilot" : "harness"; covered[k]++; });
  const extra: Res[] = [];
  Object.entries(held).forEach(([o, nn]) => { for (let i = 0; i < Math.max(0, (nn as number) - (covered[o] ?? 0)); i++) extra.push({ who: o === "superpilot" ? "Supersentry" : o === "autopilot" ? "Autosentry" : "Engine", extra: true }); });
  const tiles: Res[] = [...batches, ...extra].slice(0, total);
  while (tiles.length < total) tiles.push({ free: true });
  async function abandon(b: Res) {
    if (!window.confirm(`Abandon this batch (${b.who}, ${b.region}, ${b.size} simulation(s))?\n\nThe engine stops waiting and ignores its results. BRAIN finishes what it started. Nothing is submitted.`)) return;
    const { d, err } = await call("post", `${B}/slots/abandon`, { batch_id: b.batch_id });
    if (err) return toastErr(err);
    toast(`Abandoned ${d.abandoned} simulation(s).`, "ok"); load();
  }
  const longAfter: number = v?.long_after ?? 1200;
  return (
    <>
      <div className="dx-head" style={{ marginTop: 18 }}><b>Simulation slots</b>
        <span className="mut">{tiles.filter((t) => !t.free).length} of {total} in use</span></div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(150px,1fr))", gap: 8, marginTop: 6 }}>
        {tiles.map((t, i) => {
          const long = !t.free && t.elapsed > longAfter;
          return (
            <div key={i} onClick={() => t.batch_id && abandon(t)} title={t.batch_id ? "Click to abandon this batch" : t.free ? "Free slot" : "Held by another runner"}
              style={{ border: "1px solid var(--line, #8884)", borderRadius: 8, padding: "8px 10px", minHeight: 62, cursor: t.batch_id ? "pointer" : "default",
                       background: t.free ? "transparent" : long ? "rgba(245,158,11,.18)" : "rgba(34,197,94,.12)", opacity: t.free ? 0.55 : 1 }}>
              <div className="mut" style={{ fontSize: 11 }}>Slot {i + 1}</div>
              {t.free ? <div className="mut">free</div> : (
                <>
                  <div><b>{t.who}</b></div>
                  {t.extra ? <div className="mut" style={{ fontSize: 12 }}>running</div> :
                    <div style={{ fontSize: 12 }}>{t.region} D{t.delay} · {t.size} sim{t.size === 1 ? "" : "s"} · {dur(t.elapsed)}{long ? " ⚠ long" : ""}</div>}
                </>)}
            </div>);
        })}
      </div>
    </>
  );
}

/** Every simulation that never reached Results, with one plain reason each. */
export function MissingView() {
  const { toast, toastErr } = useToast();
  const [q, setQ] = useState(""); const [code, setCode] = useState("");
  const [d, setD] = useState<Res | null>(null); const [busy, setBusy] = useState(false);
  const load = async () => {
    const { d: r, err } = await call("get", `${B}/missing?q=${encodeURIComponent(q)}&code=${code}`);
    if (!err) setD(r);
  };
  useEffect(() => { const t = setTimeout(load, 300); return () => clearTimeout(t); }, [q, code]);
  async function fix(ids: number[], action: "score" | "requeue") {
    if (!ids.length) return;
    setBusy(true);
    const { d: r, err } = await call("post", `${B}/missing/fix`, { ids, action });
    setBusy(false);
    if (err) return toastErr(err);
    toast(action === "score" ? `Scored ${r.scored ?? 0}, failed ${r.failed ?? 0}.` : `Requeued ${r.done} simulation(s).`, "ok"); load();
  }
  const items: Res[] = d?.items ?? [];
  const counts: Record<string, number> = d?.counts ?? {};
  return (
    <>
      <div className="hx-row" style={{ marginTop: 8 }}>
        {Object.keys(counts).length === 0 ? <span className="mut">Nothing is missing.</span> :
          Object.entries(counts).map(([k, nn]) => (
            <button key={k} className={"btn sm" + (code === k ? "" : " ghost")} title={d?.labels?.[k]} onClick={() => setCode(code === k ? "" : k)}>{k.replace(/_/g, " ")}: {nn}</button>))}
        <input placeholder="Search alpha id or expression" value={q} onChange={(e) => setQ(e.target.value)} style={{ minWidth: 240 }} />
        <button className="btn ghost sm" disabled={busy || !items.some((i) => i.action === "score")} onClick={() => fix(items.filter((i) => i.action === "score").map((i) => i.id), "score")}>Score all shown</button>
        <button className="btn ghost sm" disabled={busy || !items.some((i) => i.action === "requeue")} onClick={() => fix(items.filter((i) => i.action === "requeue").map((i) => i.id), "requeue")}>Requeue all shown</button>
      </div>
      <table className="hx-table"><thead><tr><th>alpha</th><th>expression</th><th>why it is missing</th><th></th></tr></thead>
        <tbody>{items.map((i) => (
          <tr key={i.id}><td>{i.alpha_id || "—"}</td><td style={{ maxWidth: 320, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }} title={i.expression}>{i.expression}</td>
            <td>{i.label}</td>
            <td>{i.action === "score" ? <button className="btn sm" disabled={busy} onClick={() => fix([i.id], "score")}>Score now</button> : null}
              {i.action === "requeue" ? <button className="btn sm" disabled={busy} onClick={() => fix([i.id], "requeue")}>Requeue</button> : null}</td></tr>))}</tbody></table>
      {d && d.total > items.length ? <div className="mut">Showing {items.length} of {d.total}.</div> : null}
    </>
  );
}

const COLS: [string, string][] = [["region", "region"], ["delay", "delay"], ["universe", "universe"], ["neutralization", "neutralization"], ["sharpe", "Sharpe"], ["fitness", "fitness"],
  ["turnover", "turnover"], ["returns", "returns"], ["drawdown", "drawdown"], ["margin", "margin"], ["self_corr", "self corr"], ["prod_corr", "prod corr"], ["powerpool_corr", "power pool"],
  ["tests_failed", "failed checks"], ["source", "source"]];
const SORTABLE = new Set(["sharpe", "fitness", "turnover", "returns", "margin", "drawdown", "self_corr", "prod_corr", "powerpool_corr", "tests_failed"]);

/** All alphas with their stats; check production correlation one by one. */
export function AlphaStats() {
  const { toast, toastErr } = useToast();
  const [rows, setRows] = useState<Res[]>([]); const [total, setTotal] = useState(0);
  const [f, setF] = useState({ q: "", region: "", passed: "", prod: "", source: "", sort: "created_at", desc: true });
  const [sel, setSel] = useState<Set<string>>(new Set());
  const [delay, setDelay] = useState(Number(localStorage.getItem("hx:proddelay") || 60)); const [recheck, setRecheck] = useState(false);
  const [run, setRun] = useState<Res>({ running: false });
  const load = async () => {
    const qs = new URLSearchParams({ ...f, desc: String(f.desc), limit: "200" } as any).toString();
    const { d, err } = await call("get", `${B}/alphas?${qs}`);
    if (!err) { setRows(d.rows ?? []); setTotal(d.total ?? 0); }
  };
  const poll = async () => { const { d, err } = await call("get", `${B}/alphas/check`); if (!err) setRun((p) => { if (p.running && !d.running) load(); return d; }); };
  useEffect(() => { const t = setTimeout(load, 300); return () => clearTimeout(t); }, [f]);
  useEffect(() => { poll(); const t = setInterval(poll, 2000); return () => clearInterval(t); }, []);
  const sortBy = (k: string) => SORTABLE.has(k) && setF((p) => ({ ...p, sort: k, desc: p.sort === k ? !p.desc : true }));
  async function check(ids: string[], dly: number) {
    if (!ids.length) return;
    localStorage.setItem("hx:proddelay", String(delay));
    const { d, err } = await call("post", `${B}/alphas/check`, { ids, delay: dly, recheck: ids.length === 1 ? true : recheck });
    if (err) return toastErr(err);
    if (!d.started) return toastErr(d.message);
    toast(`Checking ${d.count} alpha(s) one after another${dly ? `, waiting ${dly} s before each` : ""}. No simulations are used and nothing is submitted.`, "ok"); poll();
  }
  async function stop() { await call("post", `${B}/alphas/check/stop`); toast("Stopping after the current check.", "ok"); }
  const toggle = (id: string) => setSel((p) => { const n = new Set(p); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const real = useMemo(() => rows.filter((r) => !r.missing), [rows]);
  const prodCell = (r: Res) => {
    const st = r.prod_state;
    const style = st === "too_high" ? { color: "#ef4444", fontWeight: 700 } : st === "high" ? { color: "#ef4444" } : undefined;
    return <td style={style} title={st === "too_high" ? "Above 0.74: too high to fix" : st === "high" ? "Above 0.70: fails the check, may be fixable" : st === "unchecked" ? "Not checked yet" : "Passes"}>
      {n3(r.prod_corr)}{st === "too_high" ? " ✕ too high" : ""}</td>;
  };
  return (
    <>
      <div className="hx-row" style={{ marginTop: 8 }}>
        <input placeholder="Search alpha id or expression" value={f.q} onChange={(e) => setF({ ...f, q: e.target.value })} style={{ minWidth: 240 }} />
        <input placeholder="Region" value={f.region} onChange={(e) => setF({ ...f, region: e.target.value })} style={{ width: 80 }} />
        <select value={f.passed} onChange={(e) => setF({ ...f, passed: e.target.value })}><option value="">all checks</option><option value="yes">passing</option><option value="no">failing</option></select>
        <select value={f.prod} onChange={(e) => setF({ ...f, prod: e.target.value })}><option value="">any prod corr</option><option value="unchecked">not checked</option><option value="checked">checked</option><option value="ok">under 0.70</option><option value="high">0.70 and over</option></select>
        <select value={f.source} onChange={(e) => setF({ ...f, source: e.target.value })}><option value="">all sources</option><option value="engine">SentryEngine</option><option value="autosentry">Autosentry / Supersentry</option></select>
        <span className="mut">{total} alpha(s){sel.size ? `, ${sel.size} selected` : ""}</span>
      </div>
      <div className="hx-row" style={{ marginTop: 6 }}>
        <label className="fld"><span>Wait before each check (s)</span><input type="number" min={0} value={delay} onChange={(e) => setDelay(Math.max(0, Number(e.target.value) || 0))} style={{ width: 80 }} /></label>
        <label className="fld" style={{ flexDirection: "row", alignItems: "center", gap: 6 }}><input type="checkbox" checked={recheck} onChange={(e) => setRecheck(e.target.checked)} /><span>Re-check already checked</span></label>
        <button className="btn sm" disabled={run.running || !sel.size} onClick={() => check([...sel], delay)}>Check selected</button>
        <button className="btn ghost sm" disabled={!run.running} onClick={stop}>Stop</button>
        <button className="btn ghost sm" disabled={!real.length} onClick={() => setSel(new Set(real.map((r) => r.alpha_id)))}>Select shown</button>
        <button className="btn ghost sm" disabled={!sel.size} onClick={() => setSel(new Set())}>Clear</button>
      </div>
      {run.running ? <div className="hx-note">Checking {run.done}/{run.total}: {run.current}{run.waiting ? ` (waiting ${run.waiting} s)` : ""}</div>
        : run.message ? <div className="mut" style={{ fontSize: 12 }}>Last run: {run.message}</div> : null}
      <div style={{ overflowX: "auto" }}>
        <table className="hx-table"><thead><tr><th></th><th>alpha</th>{COLS.map(([k, l]) => <th key={k} onClick={() => sortBy(k)} style={{ cursor: SORTABLE.has(k) ? "pointer" : undefined }}>{l}{f.sort === k ? (f.desc ? " ▼" : " ▲") : ""}</th>)}<th></th></tr></thead>
          <tbody>{rows.map((r) => {
            const red = r.missing ? { color: "#ef4444" } : undefined;
            return (
              <tr key={r.alpha_id} style={red} title={r.missing ? "Not in Results: BRAIN made it but it was never stored" : r.expression}>
                <td><input type="checkbox" disabled={!!r.missing} checked={sel.has(r.alpha_id)} onChange={() => toggle(r.alpha_id)} /></td>
                <td>{r.alpha_id}{r.missing ? " (missing)" : ""}</td>
                {COLS.map(([k]) => k === "prod_corr" ? <React.Fragment key={k}>{prodCell(r)}</React.Fragment> :
                  <td key={k}>{["sharpe", "fitness", "turnover", "returns", "drawdown", "margin", "self_corr", "powerpool_corr"].includes(k) ? n3(r[k]) : (r[k] ?? "—")}</td>)}
                <td><button className="btn ghost sm" disabled={run.running || !!r.missing} onClick={() => check([r.alpha_id], 0)}>Check prod</button></td>
              </tr>);
          })}</tbody></table>
      </div>
    </>
  );
}

export function ResultsTab() {
  const [sub, setSub] = useState<"stats" | "missing">("stats");
  return (
    <>
      <div className="seg" style={{ marginTop: 8 }}>
        <button className={"seg-btn" + (sub === "stats" ? " on" : "")} onClick={() => setSub("stats")}>Alpha stats</button>
        <button className={"seg-btn" + (sub === "missing" ? " on" : "")} onClick={() => setSub("missing")}>Missing results</button>
      </div>
      {sub === "stats" ? <AlphaStats /> : <MissingView />}
    </>
  );
}
