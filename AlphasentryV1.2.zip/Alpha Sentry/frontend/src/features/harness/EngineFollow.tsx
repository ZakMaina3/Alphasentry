import { useEffect } from "react";
import { api } from "../../lib/api";
import { useResearch } from "../../lib/store";

// Keeps SentryEngine on the region chosen in Autosentry (the market in the top bar). Whenever that region changes, and once at start-up,
// the engine is told; with "follow" on (the default, switch in SentryEngine → Control → Queue by region) it drops every other region's
// queued simulations immediately. Renders nothing; failures are silent (the engine may simply be off).
export function EngineFollow() {
  const R: any = useResearch();
  const region = String(R.ctx?.region || "");
  useEffect(() => {
    if (!region) return;
    const t = setTimeout(() => { try { Promise.resolve(api.post("/harness_engine/focus/follow", { region })).catch(() => {}); } catch { /* ignore */ } }, 400);
    return () => clearTimeout(t);
  }, [region]);
  return null;
}
