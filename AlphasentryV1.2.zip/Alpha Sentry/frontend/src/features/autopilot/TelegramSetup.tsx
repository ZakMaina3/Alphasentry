import { useEffect, useState } from "react";
import { api } from "../../lib/api";
import { useToast } from "../../lib/toast";
import { NumberInput } from "../../lib/NumberInput";

// Telegram alerts: when the 4-hour BRAIN session expires the Autosentry pauses, sends the
// biometrics link to your phone, waits for you to finish the face scan, then resumes by itself.
export function TelegramSetup() {
  const { toast, toastErr } = useToast();
  const [open, setOpen] = useState(false);
  const [cfg, setCfg] = useState<any>(null);
  const [token, setToken] = useState("");
  const [chat, setChat] = useState("");
  const [busy, setBusy] = useState(false);
  const [headsUp, setHeadsUp] = useState(15);
  const [resend, setResend] = useState(15);
  const [autoRef, setAutoRef] = useState(0);

  async function load() {
    const c = await api.get<any>("/notify/config");
    if (c.error) return;
    setCfg(c); setChat(c.chat_id || ""); setHeadsUp(c.heads_up_min ?? 15); setResend(c.resend_min ?? 15); setAutoRef(c.auto_refresh_min ?? 0);
  }
  useEffect(() => { load(); }, []);

  async function save(patch: any, msg?: string) {
    setBusy(true);
    const r = await api.post<any>("/notify/config", patch);
    setBusy(false);
    if (r.error) { toastErr(r.error); return false; }
    setCfg(r); setChat(r.chat_id || ""); if (patch.token) setToken("");
    toast(msg || (r.bot_username ? `Saved — bot @${r.bot_username}` : "Saved."), "ok");
    return true;
  }
  async function discover() {
    setBusy(true);
    const r = await api.post<any>("/notify/discover");
    setBusy(false);
    if (r.error) return toastErr(r.error);
    setChat(r.chat_id);
    toast(`Found chat with ${r.name || "you"} — press Save.`, "ok");
  }
  async function test() {
    setBusy(true);
    const r = await api.post<any>("/notify/test");
    setBusy(false);
    r.error ? toastErr(r.error) : toast("Test message sent — check Telegram.", "ok");
  }

  const on = !!cfg?.enabled;
  return (
    <div style={{ marginTop: 12, borderTop: "1px solid var(--line, rgba(255,255,255,.08))", paddingTop: 8 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer" }} onClick={() => setOpen((v) => !v)}>
        <b style={{ fontSize: 12 }}>{open ? "▾" : "▸"} Telegram alerts</b>
        <span className={"badge" + (on && cfg?.token_set && cfg?.chat_id ? " ok" : "")}>{on && cfg?.token_set && cfg?.chat_id ? "on" : "off"}</span>
      </div>
      {open ? <div style={{ marginTop: 8 }}>
        <div className="mut" style={{ fontSize: 11, marginBottom: 8, lineHeight: 1.5 }}>
          1) In Telegram open <b>@BotFather</b> → <code>/newbot</code> → copy the token. 2) Paste it below and Save.
          3) Open your new bot and press <b>Start</b> (send it any message). 4) Press <b>Find my chat ID</b>, then Save.
          5) Send test, then switch alerts on.
        </div>
        <label className="fld"><span>Bot token {cfg?.token_set ? <span className="mut">(saved: {cfg.token_masked})</span> : null}</span>
          <input type="password" value={token} onChange={(e) => setToken(e.target.value)} placeholder={cfg?.token_set ? "leave empty to keep" : "123456:ABC-DEF…"} autoComplete="off" /></label>
        <label className="fld" style={{ marginTop: 6 }}><span>Chat ID</span>
          <input value={chat} onChange={(e) => setChat(e.target.value)} placeholder="filled by “Find my chat ID”" /></label>
        <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
          <button className="btn sm" disabled={busy} onClick={() => save({ token: token || undefined, chat_id: chat, heads_up_min: headsUp, resend_min: resend, auto_refresh_min: autoRef })}>Save</button>
          <button className="btn ghost sm" disabled={busy || !cfg?.token_set} onClick={discover}>Find my chat ID</button>
          <button className="btn ghost sm" disabled={busy || !cfg?.token_set || !cfg?.chat_id} onClick={test}>Send test</button>
        </div>
        <div className="dx-filters" style={{ marginTop: 8 }}>
          <span className={"pill" + (on ? " on" : "")} onClick={() => save({ enabled: !on }, on ? "Alerts off." : "Alerts on.")}
            title="Send the biometrics link when the BRAIN session expires and resume automatically afterwards.">
            Session alerts & auto-resume: {on ? "ON" : "OFF"}</span>
          <span className="pill on" title="Every alpha Autosentry finds is sent to this chat (not silent), as long as the bot token and chat ID are saved. This is no longer a switch.">Winner alerts: always on</span>
          <span className={"pill" + (cfg?.remote_enabled ? " on" : "")} onClick={() => save({ remote_enabled: !cfg?.remote_enabled })}
            title="Accept commands from your Telegram chat only: /status, /start, /stop, /switch, /set …, /refresh. Send /help to the bot.">
            Remote control: {cfg?.remote_enabled ? "ON" : "OFF"}</span>
        </div>
        {cfg?.remote_enabled ? <div className="mut" style={{ fontSize: 11, marginTop: 6, lineHeight: 1.5 }}>
          Send <code>/menu</code> or <code>/help</code> to your bot. It only obeys your chat, never submits anything to BRAIN,
          and works while this computer is on with the app running. A remote <code>/start</code> reuses the settings of the last run started here.</div> : null}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginTop: 8 }}>
          <label className="fld" title="0 = no warning"><span>Heads-up (min before expiry)</span>
            <NumberInput min={0} max={120} fallback={15} value={headsUp} onChange={setHeadsUp} /></label>
          <label className="fld" title="Fresh link + reminder; later reminders back off automatically."><span>First reminder after (min)</span>
            <NumberInput min={5} max={240} fallback={15} value={resend} onChange={setResend} /></label>
          <label className="fld" title="0 = off. Otherwise, when this many minutes are left, the biometrics link is sent early so the session is renewed BEFORE it ends. You can also send /refresh any time."><span>Auto-refresh when ≤ N min left (0 = off)</span>
            <NumberInput min={0} max={120} fallback={0} value={autoRef} onChange={setAutoRef} /></label>
        </div>
      </div> : null}
    </div>
  );
}
