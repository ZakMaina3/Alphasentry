import { useEffect, useMemo, useState } from "react";
import { api } from "../../lib/api";
import { usePersistentState } from "../../lib/persist";
import { useToast } from "../../lib/toast";

type Row = Record<string, any>;
const num = (v: any, d = 2) => (v == null ? "—" : (+v).toFixed(d));
const pts = (v: any) => (v == null ? "—" : Math.round(+v).toLocaleString());

// Osmosis Planner — reads every submitted alpha from BRAIN (read-only), finds the scopes with enough
// qualifying alphas, and proposes the 100,000-point allocation for each. It never writes to BRAIN:
// you enter the points yourself (inline in the Submitted table, or with Osmosis Scale).
export function Osmosis() {
  const { toast, toastErr } = useToast();
  const [plan, setPlan] = useState<Row | null>(null);
  const [busy, setBusy] = useState("");
  const [prog, setProg] = useState("");
  const [sel, setSel] = useState("");
  const [current, setCurrent] = usePersistentState<string>("osm:current", "");
  const [minAlphas, setMinAlphas] = usePersistentState<number>("osm:min", 10);
  const [corrMax, setCorrMax] = usePersistentState<number>("osm:corr", 0.7);
  const [maxMove, setMaxMove] = usePersistentState<number>("osm:move", 20000);
  const [maxDs, setMaxDs] = usePersistentState<number>("osm:ds", 0.35);
  const [topN, setTopN] = usePersistentState<number>("osm:topn", 10);
  const [consultFrom, setConsultFrom] = usePersistentState<string>("osm:consult", "");

  const [edits, setEdits] = useState<Record<string, Record<string, number>>>({});
  const [include, setInclude] = useState<Record<string, boolean>>({});
  const [report, setReport] = useState<Row | null>(null);
  const [canUndo, setCanUndo] = useState(false);
  const TOTAL = 100000;

  const parseCurrent = (): Record<string, number> => {
    const out: Record<string, number> = {};
    for (const line of current.split(/\r?\n/)) {
      const m = line.trim().match(/^([A-Za-z0-9]+)[\s,;:\t]+(\d+)/);
      if (m) out[m[1]] = parseInt(m[2], 10);
    }
    return out;
  };

  const compute = async () => {
    setBusy("plan");
    const d = await api.post<Row>("/osmosis/plan", {
      config: { min_alphas: minAlphas, corr_max: corrMax, max_move: maxMove, max_dataset_w: maxDs, top_n: topN, consultant_start: consultFrom },
      current: parseCurrent(),
    });
    setBusy("");
    if (d.error || d.detail) return toastErr(String(d.error ?? JSON.stringify(d.detail)));
    setPlan(d);
    const e: Record<string, Record<string, number>> = {}, inc: Record<string, boolean> = {};
    for (const sc of d.scopes ?? []) {
      if (!sc.eligible) continue;
      e[sc.scope] = Object.fromEntries(sc.plan.map((p: Row) => [p.id, p.points]));
      inc[sc.scope] = !!sc.allocate;
    }
    setEdits(e); setInclude(inc);
    if (d.scopes?.length && !d.scopes.some((s: Row) => s.scope === sel)) {
      setSel((d.scopes.find((s: Row) => s.allocate) ?? d.scopes[0]).scope);
    }
  };
  useEffect(() => { compute(); api.get<any>("/osmosis/journal").then((j) => setCanUndo(!!j.items?.some((x: Row) => !x.undone))); }, []);

  const total = (sc: string) => Object.values(edits[sc] ?? {}).reduce((a, b) => a + (+b || 0), 0);
  const count = (sc: string) => Object.values(edits[sc] ?? {}).filter((v) => (+v || 0) > 0).length;
  const scopeOk = (sc: string) => total(sc) === TOTAL && count(sc) >= minAlphas;
  const chosen = Object.keys(edits).filter((k) => include[k]);
  const allOk = chosen.length >= 3 && chosen.every(scopeOk);
  const setPt = (sc: string, id: string, v: string) =>
    setEdits((e) => ({ ...e, [sc]: { ...e[sc], [id]: Math.max(0, Math.round(+v || 0)) } }));
  const resetScope = (sc: string) => {
    const s0 = plan?.scopes?.find((x: Row) => x.scope === sc);
    if (s0) setEdits((e) => ({ ...e, [sc]: Object.fromEntries(s0.plan.map((p: Row) => [p.id, p.points])) }));
  };
  const balance = (sc: string) => setEdits((e) => {          // scale to exactly 100,000, keeping the proportions you set
    const cur = e[sc] ?? {}, ids = Object.keys(cur).filter((i) => cur[i] > 0), sum = ids.reduce((a, i) => a + cur[i], 0);
    if (!sum) return e;
    const raw = ids.map((i) => (cur[i] / sum) * TOTAL), pts = raw.map(Math.floor);
    let short = TOTAL - pts.reduce((a, b) => a + b, 0);
    [...raw.keys()].sort((a, b) => (raw[b] - pts[b]) - (raw[a] - pts[a])).forEach((k) => { if (short-- > 0) pts[k]++; });
    return { ...e, [sc]: { ...cur, ...Object.fromEntries(ids.map((i, k) => [i, pts[k]])) } };
  });

  const waitJob = async (id: string) => {
    let s: any = {};
    for (; ;) {
      s = await api.get(`/osmosis/jobs/${id}`);
      setProg(`${s.message ?? ""}${s.total ? ` · ${s.done}/${s.total}` : ""}`);
      if (s.status !== "running") break;
      await new Promise((r) => setTimeout(r, 1200));
    }
    return s;
  };
  const implement = async () => {
    const body: Record<string, Record<string, number>> = {};
    chosen.forEach((k) => { body[k] = edits[k]; });
    const n = chosen.reduce((a, k) => a + count(k), 0);
    if (!window.confirm(`Write these Osmosis points to BRAIN now?\n\n${chosen.length} scope(s): ${chosen.join(", ")}\n${n} alphas get points; any other alpha in those scopes that has points will be cleared.\n\nThis edits points only (no alpha is submitted). You can undo the last change afterwards.`)) return;
    setBusy("implement"); setReport(null); setProg("checking…");
    const start = await api.post<any>("/osmosis/implement", { edits: body, current: parseCurrent() });
    if (start.error || start.detail || !start.job_id) { setBusy(""); setProg(""); return toastErr(String(start.error ?? start.detail ?? "could not start")); }
    const s = await waitJob(start.job_id);
    setBusy(""); setProg("");
    if (s.status === "error") return toastErr(s.error || "implement failed");
    setReport(s.result); setCanUndo(!!s.result?.undo_available || canUndo);
    toast(`Wrote points for ${s.result?.written ?? 0} alpha(s).`, "ok");
  };
  const undo = async () => {
    if (!window.confirm("Put the points back to what they were before your last Implement?")) return;
    setBusy("undo"); setReport(null);
    const start = await api.post<any>("/osmosis/undo", {});
    if (start.error || !start.job_id) { setBusy(""); return toastErr(start.error ?? "could not start"); }
    const s = await waitJob(start.job_id);
    setBusy(""); setProg("");
    if (s.status === "error") return toastErr(s.error || "undo failed");
    setReport({ undone: s.result?.restored ?? 0, failed: s.result?.failed ?? [] });
    setCanUndo(false);
    toast("Previous points restored.", "ok");
  };

  const refresh = async (force: boolean) => {
    setBusy("refresh"); setProg("starting…");
    const start = await api.post<any>("/osmosis/refresh", { force_pnl: force });
    if (start.error || !start.job_id) { setBusy(""); return toastErr(start.error ?? "could not start"); }
    let s: any = {};
    for (; ;) {
      s = await api.get(`/osmosis/jobs/${start.job_id}`);
      setProg(`${s.message ?? ""}${s.total ? ` · ${s.done}/${s.total}` : ""}`);
      if (s.status !== "running") break;
      await new Promise((r) => setTimeout(r, 1500));
    }
    setBusy(""); setProg("");
    if (s.status === "error") return toastErr(s.error || "refresh failed");
    toast(`Read ${s.result?.alphas ?? 0} submitted alphas.`, "ok");
    compute();
  };

  const scope: Row | undefined = plan?.scopes?.find((s: Row) => s.scope === sel);
  const csv = () => {
    if (!plan?.scopes) return;
    const lines = ["scope,alpha_id,points,was"];
    for (const s of plan.scopes) if (s.allocate) for (const p of s.plan) lines.push(`${s.scope},${p.id},${p.points},${p.was}`);
    const url = URL.createObjectURL(new Blob([lines.join("\n")], { type: "text/csv" }));
    const a = document.createElement("a"); a.href = url; a.download = "osmosis_plan.csv"; a.click();
    URL.revokeObjectURL(url);
  };
  const when = useMemo(() => (plan?.fetched_at ? new Date(plan.fetched_at * 1000).toLocaleString() : "never"), [plan?.fetched_at]);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12, flex: 1, minHeight: 0, overflow: "auto" }}>
      <div className="panel" style={{ padding: 14 }}>
        <div className="dx-head"><b>Osmosis Planner</b>
          <span className="mut">read-only · last read {when}</span>
          <span style={{ marginLeft: "auto", display: "flex", gap: 6 }}>
            <button className="btn sm" onClick={() => refresh(false)} disabled={!!busy}>{busy === "refresh" ? "Reading…" : "Read my alphas from BRAIN"}</button>
            <button className="btn ghost sm" onClick={() => refresh(true)} disabled={!!busy} title="Re-download every PnL, even recent ones">Full refresh</button>
            <button className="btn ghost sm" onClick={compute} disabled={!!busy}>Recompute</button>
            <button className="btn ghost sm" onClick={csv} disabled={!plan?.valid}>Download plan (CSV)</button>
            <button className="btn sm" onClick={implement} disabled={!!busy || !allOk}
              title={allOk ? "Write these points to BRAIN" : "Every chosen scope needs exactly 100,000 points over at least 10 alphas, and at least 3 scopes must be chosen"}>
              {busy === "implement" ? "Implementing…" : "Implement on BRAIN"}</button>
            {canUndo && <button className="btn ghost sm" onClick={undo} disabled={!!busy}>Undo last</button>}
          </span>
        </div>
        {prog && <div className="mut" style={{ marginTop: 6 }}>{prog}</div>}
        <p className="mut" style={{ margin: "8px 0 0" }}>
          Edit the suggested points if you like, then press <b>Implement on BRAIN</b> to write them to your alphas (points only; no alpha is ever submitted).
          Reading your alphas is read-only. Allocations lock every Sunday 23:59 EST, and only allocated scopes count toward your daily Osmosis rank.
        </p>
      </div>

      {report && (
        <div className="panel" style={{ padding: 14 }}>
          {report.undone != null ? <b>Restored {report.undone} alpha(s).</b> : <b>Wrote {report.written} alpha(s){report.cleared ? `, cleared ${report.cleared}` : ""}.</b>}
          {report.verified && Object.entries(report.verified).map(([k, v]: [string, any]) => (
            <div key={k}>{k}: BRAIN now shows {pts(v.total)} points {v.ok ? "✓" : "— not 100,000, check this scope"}</div>))}
          {report.verified == null && report.undone == null && <div className="mut">BRAIN did not return points when re-read, so the totals could not be double-checked.</div>}
          {report.failed?.length > 0 && <div style={{ marginTop: 6 }}>Problems: {report.failed.join("; ")}</div>}
        </div>
      )}

      {plan?.empty && <div className="panel empty" style={{ padding: 18 }}>{plan.message}</div>}

      {plan && !plan.empty && (
        <div className="panel" style={{ padding: 14 }}>
          <div style={{ fontWeight: 600, color: plan.valid ? "var(--ok, #3a7)" : "var(--warn, #b80)" }}>
            {plan.valid ? "Valid allocation possible" : "No valid allocation yet"}
          </div>
          <div style={{ marginTop: 4 }}>{plan.message}</div>
          {!plan.points_read_from_brain && (
            <div className="mut" style={{ marginTop: 6 }}>
              Your current points were not returned by BRAIN, so the plan is the full target. Paste your current allocation under
              Settings below if you want the plan to move gradually from it.
            </div>
          )}
          {plan.no_pnl > 0 && <div className="mut" style={{ marginTop: 6 }}>{plan.no_pnl} alpha(s) had no PnL available; they are planned without correlation or volatility data.</div>}
        </div>
      )}

      {plan?.scopes?.length > 0 && (
        <div className="panel" style={{ padding: 14 }}>
          <b>Scopes</b>
          <div className="panel-scroll" style={{ marginTop: 8 }}>
            <table>
              <thead><tr><th></th><th>scope</th><th>alphas</th><th>qualifying</th><th>status</th><th>combo Sharpe</th><th>equal weight</th><th>holdout (plan / equal)</th></tr></thead>
              <tbody>{plan.scopes.map((s: Row) => (
                <tr key={s.scope} onClick={() => setSel(s.scope)} style={{ cursor: "pointer", background: s.scope === sel ? "var(--row-sel, rgba(120,120,120,.15))" : undefined }}>
                  <td>{s.eligible && <input type="checkbox" checked={!!include[s.scope]} onClick={(e) => e.stopPropagation()}
                    onChange={(e) => setInclude((x) => ({ ...x, [s.scope]: e.target.checked }))} title="Include this scope when implementing" />}</td>
                  <td><b>{s.scope}</b></td><td>{s.alphas}</td><td>{s.passing} / {s.needed}</td>
                  <td>{!s.eligible ? `not eligible · ${s.short_by} short` : s.allocate ? (s.weak ? "allocate (weak)" : "allocate") : "skip (weak)"}</td>
                  <td>{num(s.stats?.sharpe)}</td><td>{num(s.stats?.sharpe_equal_weight)}</td>
                  <td>{s.holdout ? `${num(s.holdout.plan)} / ${num(s.holdout.equal_weight)}` : "—"}</td>
                </tr>))}</tbody>
            </table>
          </div>
        </div>
      )}

      {scope && (
        <div className="panel" style={{ padding: 14 }}>
          <div className="dx-head"><b>{scope.scope}</b>
            <span className="mut">{scope.passing} of {scope.alphas} alphas qualify · current points {pts(scope.current_total)}</span></div>
          {scope.eligible ? (
            <>
              {scope.gradual && <div className="mut">Moving gradually toward the target (at most {pts(maxMove)} points shifted this time).</div>}
              {scope.caps_relaxed?.length > 0 && <div className="mut">Could not apply: {scope.caps_relaxed.join(", ")} — your alphas are not diverse enough for that limit.</div>}
              <div className="panel-scroll" style={{ marginTop: 8, maxHeight: 340 }}>
                <table>
                  <thead><tr><th>alpha</th><th>points (editable)</th><th>suggested</th><th>was</th><th>change</th><th>dataset</th><th>note</th></tr></thead>
                  <tbody>{scope.plan.map((p: Row) => {
                    const v = edits[scope.scope]?.[p.id] ?? p.points;
                    return (
                      <tr key={p.id}><td>{p.id}</td>
                        <td><input type="number" min={0} step={500} value={v} style={{ width: 100 }}
                          onChange={(e) => setPt(scope.scope, p.id, e.target.value)} /></td>
                        <td>{pts(p.points)}</td><td>{pts(p.was)}</td>
                        <td>{v - p.was > 0 ? "+" : ""}{pts(v - p.was)}</td><td>{p.dataset ?? "—"}</td>
                        <td>{p.verdict === "watch" ? "watch" : ""}</td></tr>);
                  })}</tbody>
                </table>
              </div>
              <div style={{ marginTop: 8, display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                <b style={{ color: scopeOk(scope.scope) ? "var(--ok, #3a7)" : "var(--warn, #b80)" }}>
                  Total {pts(total(scope.scope))} / {pts(TOTAL)} · {count(scope.scope)} alphas
                  {total(scope.scope) !== TOTAL ? ` · ${total(scope.scope) > TOTAL ? "over" : "short"} by ${pts(Math.abs(total(scope.scope) - TOTAL))}` : count(scope.scope) < minAlphas ? ` · needs ${minAlphas}+ alphas` : " ✓"}
                </b>
                <button className="btn ghost sm" onClick={() => balance(scope.scope)}>Balance to 100,000</button>
                <button className="btn ghost sm" onClick={() => resetScope(scope.scope)}>Reset to suggestion</button>
              </div>
              {scope.remove_from_allocation?.length > 0 && <div style={{ marginTop: 8 }}>Set to 0: {scope.remove_from_allocation.join(", ")}</div>}
            </>
          ) : (
            <div style={{ marginTop: 6 }}>
              Needs {scope.short_by} more qualifying alpha(s). Datasets among the qualifying alphas:{" "}
              {Object.entries(scope.datasets || {}).map(([k, v]) => `${k} ×${v}`).join(", ") || "none"}. New alphas on other datasets help most.
            </div>
          )}
          {(scope.dropped?.length > 0 || scope.pruned?.length > 0) && (
            <details style={{ marginTop: 10 }}>
              <summary>{(scope.dropped?.length || 0) + (scope.pruned?.length || 0)} alpha(s) left out and why</summary>
              <table><tbody>
                {[...(scope.dropped || []), ...(scope.pruned || [])].map((x: Row) => <tr key={x.id}><td>{x.id}</td><td>{x.reason}</td></tr>)}
              </tbody></table>
            </details>
          )}
        </div>
      )}

      <details className="panel" style={{ padding: 14 }}>
        <summary><b>Settings</b></summary>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: 10, marginTop: 10 }}>
          <label>Qualifying alphas needed per scope<input type="number" value={minAlphas} min={1} onChange={(e) => setMinAlphas(+e.target.value)} /></label>
          <label>Drop alphas correlated above<input type="number" step="0.05" value={corrMax} onChange={(e) => setCorrMax(+e.target.value)} /></label>
          <label>Most points to move per scope at once<input type="number" step="1000" value={maxMove} onChange={(e) => setMaxMove(+e.target.value)} /></label>
          <label title="Only the best N alphas of each region and delay get points (after removing highly correlated ones). 0 = no limit.">Best alphas per scope<input type="number" value={topN} min={0} onChange={(e) => setTopN(+e.target.value)} /></label>
          <label title="USA alphas submitted before this date are not compensated, so they get no Osmosis points and any points they hold are released.">Consultant since (USA alphas before this get no points)<input type="date" value={consultFrom} onChange={(e) => setConsultFrom(e.target.value)} /></label>
          <label>Most weight on one dataset<input type="number" step="0.05" value={maxDs} onChange={(e) => setMaxDs(+e.target.value)} /></label>
        </div>
        <label style={{ display: "block", marginTop: 10 }}>Your current allocation (optional, one “alpha id, points” per line)
          <textarea rows={4} value={current} onChange={(e) => setCurrent(e.target.value)} placeholder={"AbC123, 12000\nXyZ789, 8000"} style={{ width: "100%" }} />
        </label>
        <button className="btn sm" style={{ marginTop: 8 }} onClick={compute} disabled={!!busy}>Apply and recompute</button>
      </details>
    </div>
  );
}
