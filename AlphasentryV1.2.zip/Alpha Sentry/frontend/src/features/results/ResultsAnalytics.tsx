import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../../lib/api";
import { AlphaCell } from "../../lib/AlphaCell";
import { useToast } from "../../lib/toast";

const num = (v: any) => (v == null ? "—" : (+v).toFixed(3));
const pct = (v: any) => (v == null ? "—" : (v * 100).toFixed(2) + "%");
// BRAIN reports margin as a fraction (0.0012 = 12 bps). Margin is conventionally read in bps.
const bpsNum = (v: any) => (v == null ? null : v * 10000);
const bps = (v: any) => (v == null ? "—" : (v * 10000).toFixed(1) + " bps");
// A near-miss worth retrying: didn't pass, but |Sharpe| > 1 and |fitness| > 0.7.
const nearMiss = (r: any) => !r.passed && Math.abs(r.sharpe || 0) > 1 && Math.abs(r.fitness || 0) > 0.7;
const MARGIN_MIN_BPS = 5;   // "thin margin" flag: alphas earning under ~5 bps per dollar traded

interface Row {
  id?: number; alpha_id: string; expr: string; region: string; delay: number; universe: string;
  sharpe: number; fitness: number; turnover: number; returns: number; margin: number; drawdown: number;
  self_corr: number; prod_corr: number;
  powerpool_corr: number; tests_failed: number; passed: boolean; reasons: string[]; tag: string;
  submitted?: boolean;
}

// Three-state verdict. "Passed all gates" (green) requires the metric gate AND that the
// production-correlation test has actually been RUN and is below 0.70. If prod-corr was never
// run we can only say the metrics passed — never that it cleared every gate.
type Verdict = "pass" | "metrics" | "fail";
// The verdict AND a human reason, so a row is always explicitly PASSED/FAILED with a why. After
// the prod-corr check runs, the reason names the deciding factor (prod-corr over/under 0.70).
function verdictInfo(r: Row): { state: Verdict; label: string; reason: string } {
  if (!r.passed)
    return { state: "fail", label: "Failed", reason: (r.reasons || []).join(", ") || "failed the metric gate" };
  if (r.prod_corr == null)
    return { state: "metrics", label: "Metrics only", reason: "prod-corr not checked — click Verify prod-corr" };
  if (Math.abs(r.prod_corr) >= 0.7)
    return { state: "fail", label: "Failed", reason: `prod-corr ${(+r.prod_corr).toFixed(3)} ≥ 0.70` };
  return { state: "pass", label: "Passed all gates", reason: `metrics ✓ + prod-corr ${(+r.prod_corr).toFixed(3)} < 0.70` };
}
const verdict = (r: Row): Verdict => verdictInfo(r).state;
// An alpha "needs negation" when its raw metrics are negative — the signal works inverted, so
// you'd submit -1 * it. Drawdown/margin/returns of the RAW alpha are meaningless in that case.
const needsNeg = (r: Row) => r.sharpe != null && r.sharpe < 0;

// Eval red-flags — ONLY for alphas that don't need negation (for those we recommend negating
// instead, since the raw drawdown/returns/margin would be misleading).
function evalFlags(r: Row): string[] {
  if (needsNeg(r)) return [];
  const f: string[] = [];
  if (r.drawdown != null && r.returns != null && Math.abs(r.drawdown) > Math.abs(r.returns))
    f.push("drawdown > returns");
  const mbps = bpsNum(r.margin);
  if (mbps != null && Math.abs(mbps) < MARGIN_MIN_BPS)
    f.push("thin margin");
  return f;
}
interface Insight { operator: string; count: number; avg_fitness: number; }

// Results & Analytics: filter/sort/CSV over every stored simulation result with the full
// per-metric verdict, plus the operator-fitness insights that feed generation.
export function ResultsAnalytics() {
  const { toast, toastErr } = useToast();
  const nav = useNavigate();
  const [rows, setRows] = useState<Row[]>([]);
  const [busyReuse, setBusyReuse] = useState("");
  const [busySubmit, setBusySubmit] = useState("");
  const [busyVault, setBusyVault] = useState("");
  const [sel, setSel] = useState<Row | null>(null);
  const [pnl, setPnl] = useState<{ points: { date: string; pnl: number }[]; max_drawdown: number } | null>(null);
  const [yearly, setYearly] = useState<any[]>([]);
  const [pnlBusy, setPnlBusy] = useState(false);

  async function openChart(r: Row) {
    if (!r.alpha_id) return toast("This result has no alpha id (didn't simulate on BRAIN).", "warn");
    setSel(r); setPnl(null); setYearly([]); setPnlBusy(true);
    const d = await api.get<any>(`/analytics/alpha/${r.alpha_id}/pnl`);
    setPnlBusy(false);
    if (d.error) return toastErr(d.error);
    setPnl(d.pnl || { points: [], max_drawdown: 0 }); setYearly(d.yearly || []);
  }

  const [prodBusy, setProdBusy] = useState(false);
  // Run BRAIN's production-correlation test (the true submission gate) for the given alphas,
  // then reload so verdicts become authoritative.
  async function runProdCorr(alphaIds: string[]) {
    const ids = [...new Set(alphaIds.filter(Boolean))];
    if (!ids.length) return toast("No metric-passing alphas with an id to check yet.", "warn");
    setProdBusy(true);
    const start = await api.post<any>("/analytics/prodcorr", { alpha_ids: ids, threshold: 0.7 });
    if (start.error || !start.job_id) { setProdBusy(false); return toastErr(start.error || "could not start"); }
    let s: any = {};
    for (; ;) { s = await api.get(`/analytics/jobs/${start.job_id}`); if (s.status !== "running") break; await new Promise((r) => setTimeout(r, 1500)); }
    setProdBusy(false);
    if (s.status !== "done") return toastErr(s.error || s.status);
    await load();
    if (sel) { const fresh = (await api.get<any>("/analytics/results?limit=400")).results?.find((x: Row) => x.alpha_id === sel.alpha_id); if (fresh) setSel(fresh); }
    const res: any[] = s.result?.results || [];
    const passed = res.filter((x) => x.submittable).length;
    const failed = res.filter((x) => x.value != null && Math.abs(x.value) >= 0.7).length;
    const pending = res.filter((x) => x.value == null).length;   // BRAIN hasn't computed prod-corr yet
    toast(`Prod-corr checked · ${passed} passed · ${failed} failed${pending ? ` · ${pending} pending on BRAIN` : ""}.`, passed ? "ok" : "warn");
  }

  // Turn a near-miss expression back into a template ({field}/{field2}) and open it in Template
  // Studio, with the retry dataset(s) noted so the user knows which data to select.
  async function reuse(r: Row) {
    setBusyReuse(r.alpha_id || r.expr);
    const d = await api.post<any>("/generate/templatize", { expression: r.expr });   // backend strips vec_*
    setBusyReuse("");
    if (d.error) return toastErr(d.error);
    // Negative Sharpe → the NEGATED alpha is the winner: load the template negated.
    const neg = needsNeg(r);
    let tmpl: string = neg ? `-(${d.template})` : d.template;
    // Append BELOW any existing template (stack multiple reuses), replacing only an untouched example.
    const EX = ["group_zscore(ts_rank({field}, 60), subindustry)", "group_zscore(ts_regression({field}, {field2}, 120), subindustry)"];
    const prev = (() => { try { return String(JSON.parse(localStorage.getItem("ace2:tpl:text") || '""')); } catch { return ""; } })();
    const keep = prev.trim() && !EX.includes(prev.trim());
    localStorage.setItem("ace2:tpl:text", JSON.stringify(keep ? prev.replace(/\s+$/, "") + "\n" + tmpl : tmpl));
    if (!keep) localStorage.setItem("ace2:tpl:multi", JSON.stringify(!!d.multi));
    const prevDs = (() => { try { return JSON.parse(localStorage.getItem("ace2:tpl:retry") || "[]"); } catch { return []; } })();
    localStorage.setItem("ace2:tpl:retry", JSON.stringify([...new Set([...prevDs, ...(d.datasets || [])])]));
    toast(`Template appended${neg ? " (negated)" : ""}${d.datasets?.length ? ` — retry with: ${d.datasets.join(", ")}` : ""}.`, "ok");
    nav("/templates");
  }

  // Submit to BRAIN — the one irreversible action in the app. Always confirm first.
  async function submitAlpha(r: Row) {
    if (!r.alpha_id) return toast("This result has no alpha id.", "warn");
    if (!window.confirm(`Submit ${r.alpha_id} to BRAIN? This cannot be undone.`)) return;
    setBusySubmit(r.alpha_id);
    const d = await api.post<any>(`/simulate/submit/${r.alpha_id}`, {});
    setBusySubmit("");
    if (d.error) return toastErr(d.error);
    if (!d.submitted) return toastErr("BRAIN did not confirm the submission — check the alpha on BRAIN directly.");
    toast(`Submitted ${r.alpha_id}.`, "ok");
    await load();
  }

  // Park a result in the Vault for later — doesn't touch BRAIN at all.
  async function addToVault(r: Row) {
    if (r.id == null) return toast("This result can't be vaulted (no stored id).", "warn");
    setBusyVault(r.alpha_id || r.expr);
    const d = await api.post<any>("/vault/add-from-result", { sim_result_id: r.id });
    setBusyVault("");
    if (d.error) return toastErr(d.error);
    toast("Added to Vault.", "ok");
  }

  const [rate, setRate] = useState<{ passed: number; total: number; success_rate: number }>({ passed: 0, total: 0, success_rate: 0 });
  const [insights, setInsights] = useState<Insight[]>([]);
  const [q, setQ] = useState("");
  const [only, setOnly] = useState<"all" | "pass" | "fail">("all");
  const [sort, setSort] = useState("fit_desc");

  const [ledger, setLedger] = useState<any>(null);
  const load = async () => {
    const d = await api.get<any>("/analytics/results?limit=400");
    setRows(d.results || []); setRate({ passed: d.passed, total: d.total, success_rate: d.success_rate });
    const s = await api.get<any>("/analytics/summary");
    setInsights(s.operator_insights || []);
    const l = await api.get<any>("/analytics/ledger");
    if (!l.error) setLedger(l);
  };
  useEffect(() => { load(); }, []);

  const view = useMemo(() => {
    let r = rows.filter((x) => (only === "all" || (only === "pass" ? x.passed : !x.passed)));
    const ql = q.toLowerCase();
    if (ql) r = r.filter((x) => (x.expr || "").toLowerCase().includes(ql) || (x.alpha_id || "").toLowerCase().includes(ql));
    const f = (x: Row) => Math.abs(x.fitness || 0);
    r = [...r].sort(sort === "fit_asc" ? (a, b) => f(a) - f(b)
      : sort === "sharpe" ? (a, b) => Math.abs(b.sharpe || 0) - Math.abs(a.sharpe || 0)
        : (a, b) => f(b) - f(a));
    return r;
  }, [rows, only, q, sort]);

  function csv() {
    if (!view.length) return toast("Nothing to export.", "warn");
    const esc = (v: any) => { const s = String(v ?? ""); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
    const head = "alpha_id,passed,region,delay,universe,neutralization,sharpe,fitness,turnover,tests_failed,tag,expression";
    const body = view.map((r: any) => [r.alpha_id, r.passed, r.region, r.delay, r.universe, r.neutralization,
      r.sharpe, r.fitness, r.turnover, r.tests_failed, r.tag, r.expr].map(esc).join(","));
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([[head, ...body].join("\n")], { type: "text/csv" }));
    a.download = `ace_results_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a); a.click(); a.remove();
    toast(`Exported ${view.length} row(s).`, "ok");
  }

  const maxFit = Math.max(1, ...insights.map((i) => i.avg_fitness));

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12, flex: 1, minHeight: 0 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 12 }}>
        {[
          { l: "Success rate", v: `${Math.round(rate.success_rate * 100)}%` },
          { l: "Passed metrics", v: rate.passed },
          { l: "Fully verified", v: rows.filter((r) => verdict(r) === "pass").length },
          { l: "Simulated", v: rate.total },
        ].map((k) => (
          <div key={k.l} className="panel" style={{ padding: 12 }}>
            <div className="mut" style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: ".5px" }}>{k.l}</div>
            <div style={{ fontSize: 22, fontWeight: 700, color: "var(--acc)", marginTop: 4 }}>{k.v}</div>
          </div>
        ))}
      </div>

      {ledger && ledger.total_simulated > 0 ? (
        <div className="mut" style={{ fontSize: 12, background: "var(--surface-2)", borderRadius: 8, padding: "8px 12px" }}>
          <b>Experiment ledger:</b> {ledger.total_simulated} alphas simulated
          {ledger.by_region?.length ? " · " + ledger.by_region.map((r: any) => `${r.region} ${r.simulated}`).join(" · ") : ""}.
          {ledger.total_simulated >= 200 ? <span style={{ color: "var(--warn)" }}> ⚠ Wide sweep — a single winner here may be multiple-testing overfit; confirm it walks forward across regimes/regions.</span> : null}
        </div>
      ) : null}

      <div className="dx-split" style={{ flex: 1, minHeight: 0 }}>
        <div className="panel" style={{ padding: 14 }}>
          <div className="dx-head">
            <b>Results</b>
            <input placeholder="filter expression / id" value={q} onChange={(e) => setQ(e.target.value)} style={{ maxWidth: 160 }} />
            {(["all", "pass", "fail"] as const).map((o) => <span key={o} className={"pill" + (only === o ? " on" : "")} onClick={() => setOnly(o)}>{o}</span>)}
            <select value={sort} onChange={(e) => setSort(e.target.value)} style={{ width: 120, padding: "4px 6px", fontSize: 12 }}>
              <option value="fit_desc">|fitness| ↓</option><option value="fit_asc">|fitness| ↑</option><option value="sharpe">|Sharpe| ↓</option>
            </select>
            <button className="btn ghost sm" title="Run BRAIN production-correlation for EVERY metric-passing alpha (re-checks included)"
              onClick={() => runProdCorr(rows.filter((r) => r.passed && r.alpha_id).map((r) => r.alpha_id))}
              disabled={prodBusy}>{prodBusy ? <><span className="spin" /> prod-corr…</> : "Verify prod-corr"}</button>
            <button className="btn ghost sm" onClick={csv}>CSV</button>
          </div>
          <div className="panel-scroll">
            {!view.length ? <div className="empty">No results yet — Generate → Simulate.</div> :
              <table><thead><tr><th></th><th>alpha</th><th>Sharpe</th><th>Fit</th><th>Turn</th><th>flags</th><th>verdict · why</th><th>retry</th></tr></thead>
                <tbody>{view.map((r, i) => {
                  const vi = verdictInfo(r); const vd = vi.state;
                  const vc = vd === "pass" ? "var(--ok)" : vd === "metrics" ? "var(--warn)" : "var(--bad)";
                  return (
                  <tr key={i}>
                    <td title={vi.label + " — " + vi.reason}>
                      {vd === "pass" ? <span style={{ color: "var(--ok)" }}>✓</span>
                        : vd === "metrics" ? <span style={{ color: "var(--warn)" }}>◐</span>
                          : <span style={{ color: "var(--bad)" }}>✗</span>}</td>
                    <td>{r.alpha_id ? <a href={`https://platform.worldquantbrain.com/alpha/${r.alpha_id}`} target="_blank" rel="noopener"><code>{r.alpha_id}</code></a> : "—"}
                      <div style={{ fontSize: 11, marginTop: 2 }}><AlphaCell expr={r.expr} max={40} /></div></td>
                    <td>{num(r.sharpe)}</td><td>{num(r.fitness)}</td>
                    <td style={{ color: (r.turnover != null && r.turnover > 0.7) ? "var(--bad)" : undefined }}>{r.turnover == null ? "—" : (r.turnover * 100).toFixed(0) + "%"}</td>
                    <td style={{ fontSize: 10.5, whiteSpace: "nowrap" }}>
                      {needsNeg(r) ? <span className="badge" style={{ color: "var(--warn)" }} title="Metrics are negative — recommend submitting the negated signal (multiply by -1)">↔ negate</span>
                        : evalFlags(r).map((f) => <span key={f} className="badge bad" style={{ marginRight: 3 }} title="Eval red-flag">{f === "drawdown > returns" ? "DD>Ret" : "margin<5bps"}</span>)}</td>
                    <td style={{ fontSize: 11 }}><span style={{ color: vc, fontWeight: 600 }}>{vi.label}</span>
                      <div className="mut" style={{ fontSize: 10.5 }}>{vi.reason}</div></td>
                    <td style={{ whiteSpace: "nowrap" }}>
                      {r.alpha_id ? <button className="btn ghost sm" title="Equity curve & yearly stats" onClick={() => openChart(r)}>📈</button> : null}
                      {nearMiss(r) ?
                        <button className="btn ghost sm" title="Has potential — reuse as a template with the same dataset"
                          onClick={() => reuse(r)} disabled={!!busyReuse} style={{ marginLeft: 4 }}>
                          {busyReuse === (r.alpha_id || r.expr) ? <span className="spin" /> : "⟳"}</button>
                        : null}
                      {r.id != null ? (
                        <button className="btn ghost sm" title="Park in the Alpha Vault (tag/note for later)"
                          onClick={() => addToVault(r)} disabled={!!busyVault} style={{ marginLeft: 4 }}>
                          {busyVault === (r.alpha_id || r.expr) ? <span className="spin" /> : "🗄"}</button>
                      ) : null}
                      {r.alpha_id ? (
                        r.submitted ? <span className="badge ok" style={{ marginLeft: 4 }} title="Already submitted">submitted</span> :
                        <button className="btn ghost sm" title="Submit to BRAIN — cannot be undone"
                          onClick={() => submitAlpha(r)} disabled={!!busySubmit} style={{ marginLeft: 4 }}>
                          {busySubmit === r.alpha_id ? <span className="spin" /> : "Submit"}</button>
                      ) : null}</td>
                  </tr>);})}</tbody></table>}
          </div>
        </div>

        <div className="panel" style={{ padding: 14, minWidth: 420 }}>
          {sel ? (
            <>
              <div className="dx-head"><b>{sel.alpha_id}</b>
                <button className="btn ghost sm" style={{ marginLeft: "auto" }} onClick={() => setSel(null)}>← Insights</button></div>
              <div className="panel-scroll">
                {pnlBusy ? <div className="mut"><span className="spin" /> Loading equity curve…</div> :
                  !pnl?.points?.length ? <div className="empty">No PnL series available for this alpha.</div> :
                    <>
                      {(() => {
                        const pts = pnl.points, n = pts.length;
                        const ys = pts.map((p) => p.pnl), lo = Math.min(...ys), hi = Math.max(...ys), rng = hi - lo || 1;
                        const path = pts.map((p, i) => `${(i / Math.max(1, n - 1)) * 300},${60 - ((p.pnl - lo) / rng) * 56}`).join(" ");
                        return <svg viewBox="0 0 300 60" width="100%" height="90" preserveAspectRatio="none" style={{ background: "var(--surface-2)", borderRadius: 8 }}>
                          <polyline points={path} fill="none" stroke="var(--acc)" strokeWidth="1.5" vectorEffect="non-scaling-stroke" />
                        </svg>;
                      })()}
                      <div className="mut" style={{ fontSize: 11, marginTop: 4 }}>
                        Cumulative PnL · {pnl.points.length} days · max drawdown {pnl.max_drawdown.toLocaleString()}
                      </div>
                      <div className="dx-head" style={{ marginTop: 12 }}><b>Eval</b>
                        <span className="mut">ret {pct(sel.returns)} · margin {bps(sel.margin)} · maxDD {pct(sel.drawdown)}</span></div>
                      {needsNeg(sel)
                        ? <div style={{ fontSize: 12, color: "var(--warn)" }}>↔ <b>Recommend negating</b> — metrics are negative (Sharpe {num(sel.sharpe)}). Submit the inverted signal (multiply by -1); drawdown/returns/margin flags don't apply until it's negated.</div>
                        : evalFlags(sel).length
                          ? <div style={{ fontSize: 12, color: "var(--bad)" }}>⚠ {evalFlags(sel).join(" · ")} — weak risk/reward, review before submitting.</div>
                          : <div style={{ fontSize: 12, color: "var(--ok)" }}>✓ Drawdown within returns and margin healthy.</div>}

                      <div className="dx-head" style={{ marginTop: 12 }}><b>Submission readiness</b>
                        {sel.alpha_id ? <button className="btn ghost sm" style={{ marginLeft: "auto" }} onClick={() => runProdCorr([sel.alpha_id])} disabled={prodBusy}>
                          {prodBusy ? <><span className="spin" /> …</> : sel.prod_corr == null ? "Run prod-corr" : "Re-check prod-corr"}</button> : null}</div>
                      <div className="mut" style={{ fontSize: 12 }}>
                        Prod-corr: {sel.prod_corr == null ? <span style={{ color: "var(--warn)" }}>not checked</span>
                          : <b style={{ color: Math.abs(sel.prod_corr) < 0.7 ? "var(--ok)" : "var(--bad)" }}>{num(sel.prod_corr)}</b>}
                        {sel.prod_corr != null ? (Math.abs(sel.prod_corr) < 0.7 ? " — under 0.70 ✓" : " — ≥ 0.70 ✗") : ""}
                      </div>
                      {(() => {
                        const vi = verdictInfo(sel);
                        const c = vi.state === "pass" ? "var(--ok)" : vi.state === "metrics" ? "var(--warn)" : "var(--bad)";
                        const mark = vi.state === "pass" ? "✓" : vi.state === "metrics" ? "◐" : "✗";
                        return <div style={{ fontSize: 12, marginTop: 4, color: c, fontWeight: 600 }}>
                          {mark} {vi.label}<span style={{ fontWeight: 400 }}> — {vi.reason}</span>
                          {vi.state === "pass" ? <div className="mut" style={{ fontWeight: 400, fontSize: 11 }}>BRAIN takes one submission at a time — submit it there yourself.</div> : null}
                        </div>;
                      })()}
                      {yearly.length ? <>
                        <div className="dx-head" style={{ marginTop: 12 }}><b>Yearly stats</b></div>
                        <table style={{ fontSize: 11 }}><thead><tr>{Object.keys(yearly[0]).filter((k) => k !== "alpha_id").slice(0, 5).map((k) => <th key={k}>{k}</th>)}</tr></thead>
                          <tbody>{yearly.map((y, i) => <tr key={i}>{Object.keys(yearly[0]).filter((k) => k !== "alpha_id").slice(0, 5).map((k) => <td key={k}>{typeof y[k] === "number" ? (+y[k]).toFixed(2) : String(y[k])}</td>)}</tr>)}</tbody></table>
                      </> : null}
                    </>}
              </div>
            </>
          ) : (<>
          <div className="dx-head"><b>Operator insights</b><span className="mut">avg |fitness|, feeds generation</span></div>
          <div className="panel-scroll">
            {!insights.length ? <div className="empty">Not enough data yet (≥2 uses per operator).</div> :
              <table><thead><tr><th>operator</th><th>uses</th><th>avg</th></tr></thead>
                <tbody>{insights.map((o) => (
                  <tr key={o.operator}><td><code>{o.operator}</code></td><td>{o.count}</td>
                    <td><div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <div style={{ height: 6, borderRadius: 3, background: "var(--acc)", width: `${Math.round(60 * o.avg_fitness / maxFit)}px` }} />
                      <span className="mut">{o.avg_fitness}</span></div></td></tr>))}</tbody></table>}
          </div>
          </>)}
        </div>
      </div>
    </div>
  );
}
