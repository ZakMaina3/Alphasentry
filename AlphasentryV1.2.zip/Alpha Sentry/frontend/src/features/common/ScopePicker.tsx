import { useEffect, useState } from "react";
import { api } from "../../lib/api";
import { useResearch } from "../../lib/store";

// Region / Delay / Universe dropdowns shared by Autosentry, Supersentry and SentryEngine.
// The choices come from the data stored on this computer (datasets pulled in the Data Catalog, alphas already simulated,
// fields downloaded) merged with BRAIN's own option list when it is loaded, so they work offline and only list real markets.

export interface LocalRegion { region: string; delays: number[]; universes: Record<string, string[]>; local?: boolean }
let _cache: LocalRegion[] | null = null;
let _inflight: Promise<LocalRegion[]> | null = null;

function fetchLocal(force = false): Promise<LocalRegion[]> {
  if (_cache && !force) return Promise.resolve(_cache);
  if (!_inflight || force) {
    _inflight = api.get<{ regions?: LocalRegion[] }>("/catalog/local_scopes")
      .then((d) => { _cache = d.regions || []; return _cache; })
      .catch(() => _cache || [])
      .finally(() => { _inflight = null; });
  }
  return _inflight;
}

const uniq = <T,>(a: T[]) => [...new Set(a)];

export function useScopes() {
  const R = useResearch();
  const [local, setLocal] = useState<LocalRegion[]>(_cache || []);
  useEffect(() => { let on = true; fetchLocal().then((r) => { if (on) setLocal(r); }); return () => { on = false; }; }, []);
  const brain = (R.options || []).filter((o) => !o.instrument || o.instrument === "EQUITY");
  const regions = uniq([...local.map((r) => r.region), ...brain.map((o) => o.region)]);
  const delays = (region: string): number[] => {
    const d = uniq([...(local.find((r) => r.region === region)?.delays || []), ...brain.filter((o) => o.region === region).map((o) => o.delay)]);
    return (d.length ? d : [1, 0]).sort((a, b) => b - a);
  };
  const universes = (region: string, delay: number): string[] => {
    const l = local.find((r) => r.region === region)?.universes?.[String(delay)] || [];
    const b = brain.filter((o) => o.region === region && o.delay === delay).flatMap((o) => o.universes);
    return uniq([...l, ...b]);
  };
  return { regions, delays, universes, reload: () => fetchLocal(true).then(setLocal) };
}

interface Props {
  region: string; delay: number; universe?: string;
  onChange: (v: { region: string; delay: number; universe: string }) => void;
  withUniverse?: boolean;           // false = only Region and Delay (e.g. when the universe is chosen elsewhere)
  noDelay?: boolean;
}

/** Three <label className="fld"> selects, meant to sit inside an existing row. A value you already have that is not in the list is kept. */
export function ScopeFields({ region, delay, universe = "", onChange, withUniverse = true, noDelay = false }: Props) {
  const S = useScopes();
  const withCur = (list: string[], cur: string) => (cur && !list.includes(cur) ? [cur, ...list] : list);
  const regions = withCur(S.regions, region);
  const delays = S.delays(region);
  const unis = withCur(S.universes(region, delay), universe);
  const pickRegion = (r: string) => {
    const ds = S.delays(r);
    const d = ds.includes(delay) ? delay : ds[0];
    const us = S.universes(r, d);
    onChange({ region: r, delay: d, universe: us.includes(universe) ? universe : (us[0] || universe) });
  };
  const pickDelay = (d: number) => {
    const us = S.universes(region, d);
    onChange({ region, delay: d, universe: us.length && !us.includes(universe) ? us[0] : universe });
  };
  return (
    <>
      <label className="fld" title="Markets you have data for on this computer (and BRAIN's list when it is loaded).">
        <span>Region</span>
        <select value={region} onChange={(e) => pickRegion(e.target.value)}>
          {regions.map((r) => <option key={r} value={r}>{r}</option>)}
        </select>
      </label>
      {noDelay ? null : (
        <label className="fld"><span>Delay</span>
          <select value={delay} onChange={(e) => pickDelay(+e.target.value)}>
            {(delays.includes(delay) ? delays : [delay, ...delays]).map((d) => <option key={d} value={d}>{d}</option>)}
          </select>
        </label>
      )}
      {withUniverse ? (
        <label className="fld" title="Universes stored for this region and delay.">
          <span>Universe</span>
          <select value={universe} onChange={(e) => onChange({ region, delay, universe: e.target.value })}>
            {unis.length ? unis.map((u) => <option key={u} value={u}>{u}</option>) : <option value={universe}>{universe || "(none stored)"}</option>}
          </select>
        </label>
      ) : null}
    </>
  );
}
