import { useEffect, useMemo, useState } from "react";
import { api } from "../../lib/api";
import { usePersistentState } from "../../lib/persist";
import { useToast } from "../../lib/toast";

type Row = Record<string, any>;
const sk = (s: Row) => `${s.region}|${s.delay}`;

// Data Catalog — download datasets and datafields from BRAIN ONCE (by region/delay and category), keep them in the
// shared knowledge database that Autosentry, Clone and swap and SentryEngine all read, browse them, and export CSV / Excel.
export function Catalog() {
  const { toast, toastErr } = useToast();
  const [offered, setOffered] = useState<Row[]>([]);
  const [picked, setPicked] = usePersistentState<string[]>("cat:picked", []);
  const [cats, setCats] = useState<Row[]>([]);
  const [catPicked, setCatPicked] = usePersistentState<string[]>("cat:cats", []);
  const [force, setForce] = useState(false);
  const [busy, setBusy] = useState("");
  const [prog, setProg] = useState("");
  const [report, setReport] = useState<Row | null>(null);
  const [summary, setSummary] = useState<Row | null>(null);
  const [f, setF] = useState({ region: "", delay: "", type: "", category: "", dataset: "", q: "" });
  const [page, setPage] = useState(0);
  const [data, setData] = useState<Row>({ total: 0, rows: [] });
  const LIMIT = 100;

  const loadSummary = async () => { const d = await api.get<Row>("/catalog/summary"); if (!d.error && !d.detail) setSummary(d); };
  const qs = (extra: Record<string, any> = {}) => new URLSearchParams(Object.entries({ ...f, ...extra }).filter(([, v]) => v !== "" && v != null).map(([k, v]) => [k, String(v)])).toString();
  const loadRows = async () => { const d = await api.get<Row>(`/catalog/browse?${qs({ limit: LIMIT, offset: page * LIMIT })}`); if (!d.error && !d.detail) setData(d); };
  useEffect(() => { loadSummary(); }, []);
  useEffect(() => { loadRows(); }, [page, f.region, f.delay, f.type]);

  const loadScopes = async () => {
    setBusy("scopes");
    const d = await api.get<Row>("/catalog/scopes");
    setBusy("");
    if (d.error || d.detail) return toastErr(String(d.error ?? d.detail));
    setOffered(d.scopes ?? []);
  };
  const chosen = useMemo(() => offered.filter((s) => picked.includes(sk(s))).map((s) => ({ region: s.region, delay: s.delay, universe: s.universe })), [offered, picked]);
  const toggle = (k: string) => setPicked((p) => (p.includes(k) ? p.filter((x) => x !== k) : [...p, k]));

  const loadCats = async () => {
    if (!chosen.length) return toast("Pick at least one region and delay first.", "warn");
    setBusy("cats");
    const d = await api.post<Row>("/catalog/categories", { scopes: chosen });
    setBusy("");
    if (d.error || d.detail) return toastErr(String(d.error ?? d.detail));
    setCats(d.categories ?? []);
    loadSummary();
  };

  const wait = async (id: string) => {
    let s: any = {};
    for (; ;) {
      s = await api.get(`/catalog/jobs/${id}`);
      setProg(s.message ?? "");
      if (s.status !== "running") break;
      await new Promise((r) => setTimeout(r, 1500));
    }
    return s;
  };
  const download = async () => {
    if (!chosen.length) return toast("Pick at least one region and delay first.", "warn");
    const scopeTxt = chosen.map((s) => `${s.region} D${s.delay}`).join(", ");
    const catTxt = catPicked.length ? `${catPicked.length} categor${catPicked.length === 1 ? "y" : "ies"}` : "all categories";
    if (!window.confirm(`Download datafields from BRAIN now?\n\n${scopeTxt}\n${catTxt}\n\nThis is a one-time download: datasets you already have are skipped${force ? " (you ticked re-download, so they are fetched again)" : ""}. It can take a while and can be stopped and resumed.`)) return;
    setBusy("pull"); setReport(null); setProg("starting…");
    const start = await api.post<any>("/catalog/pull", { scopes: chosen, categories: catPicked, force });
    if (start.error || start.detail || !start.job_id) { setBusy(""); setProg(""); return toastErr(String(start.error ?? start.detail ?? "could not start")); }
    setJob(start.job_id);
    const s = await wait(start.job_id);
    setBusy(""); setProg(""); setJob("");
    if (s.status === "error") return toastErr(s.error || "download failed");
    setReport(s.result); loadSummary(); loadRows();
    toast(s.status === "cancelled" ? "Stopped. Run it again to resume." : `Downloaded ${s.result?.fields ?? 0} datafields.`, "ok");
  };
  const [job, setJob] = useState("");
  const stop = async () => { if (job) await api.post(`/catalog/jobs/${job}/cancel`); };

  const exportHref = (fmt: string) => `/api/catalog/export?${qs({ fmt })}`;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12, flex: 1, minHeight: 0, overflow: "auto" }}>
      <div className="panel" style={{ padding: 14 }}>
        <div className="dx-head"><b>Data Catalog</b><span className="mut">one-time download · shared by Autosentry, Clone and swap and SentryEngine</span></div>
        <p className="mut" style={{ margin: "6px 0 10px" }}>
          1) Load the regions BRAIN offers and tick the ones you want. 2) Optionally load and tick categories (none ticked = all). 3) Download.
          Datasets you already downloaded are skipped, so running it again only fetches what is missing.
        </p>
        <div className="dx-filters">
          <button className="btn sm" onClick={loadScopes} disabled={!!busy}>{busy === "scopes" ? "Loading…" : offered.length ? "Reload regions" : "Load regions"}</button>
          <button className="btn ghost sm" onClick={loadCats} disabled={!!busy || !chosen.length}>{busy === "cats" ? "Loading…" : "Load categories for selected"}</button>
        </div>
        {offered.length > 0 && (
          <div className="dx-filters" style={{ marginTop: 8 }}>
            {offered.map((s) => (
              <label key={sk(s)} style={{ display: "inline-flex", gap: 4, alignItems: "center", marginRight: 10 }}>
                <input type="checkbox" checked={picked.includes(sk(s))} onChange={() => toggle(sk(s))} />{s.region} D{s.delay}
              </label>))}
          </div>
        )}
        {cats.length > 0 && (
          <div style={{ marginTop: 8 }}>
            <b style={{ fontSize: 12 }}>Categories</b>{" "}
            <button className="btn ghost sm" onClick={() => setCatPicked(cats.map((c) => c.id))}>all</button>{" "}
            <button className="btn ghost sm" onClick={() => setCatPicked([])}>none (= all)</button>
            <div className="dx-filters" style={{ marginTop: 6 }}>
              {cats.map((c) => (
                <label key={c.id} style={{ display: "inline-flex", gap: 4, alignItems: "center", marginRight: 10 }}>
                  <input type="checkbox" checked={catPicked.includes(c.id)}
                    onChange={() => setCatPicked((p) => (p.includes(c.id) ? p.filter((x) => x !== c.id) : [...p, c.id]))} />{c.name} <span className="mut">({c.count})</span>
                </label>))}
            </div>
          </div>
        )}
        <div className="dx-filters" style={{ marginTop: 10 }}>
          <button className="btn" onClick={download} disabled={!!busy || !chosen.length}>{busy === "pull" ? "Downloading…" : "Download from BRAIN"}</button>
          {busy === "pull" && <button className="btn ghost" onClick={stop}>Stop</button>}
          <label style={{ display: "inline-flex", gap: 4, alignItems: "center" }}>
            <input type="checkbox" checked={force} onChange={(e) => setForce(e.target.checked)} />download again even if already downloaded</label>
        </div>
        {prog && <div className="mut" style={{ marginTop: 6 }}>{prog}</div>}
        {report && (
          <div style={{ marginTop: 8 }}>
            <b>Downloaded {report.fields} datafields.</b>
            {report.scopes?.map((s: Row) => <div key={s.scope}>{s.scope.replace(/\|/g, " · ")}: {s.fields} fields from {s.datasets - s.skipped} dataset(s){s.skipped ? `, ${s.skipped} already had` : ""}</div>)}
            {report.errors?.length > 0 && <div style={{ marginTop: 4 }}>Problems: {report.errors.slice(0, 5).join("; ")}{report.errors.length > 5 ? ` … and ${report.errors.length - 5} more (run again to retry them)` : ""}</div>}
          </div>
        )}
      </div>

      {summary?.scopes?.length > 0 && (
        <div className="panel" style={{ padding: 14 }}>
          <b>What you have</b>
          <div className="panel-scroll" style={{ marginTop: 8, maxHeight: 220 }}>
            <table><thead><tr><th>region</th><th>delay</th><th>datasets</th><th>datafields</th><th>last downloaded</th></tr></thead>
              <tbody>{summary.scopes.map((s: Row) => (
                <tr key={sk(s)}><td>{s.region}</td><td>D{s.delay}</td><td>{s.datasets}</td><td>{s.fields.toLocaleString()}</td>
                  <td>{s.pulled_at ? new Date(s.pulled_at * 1000).toLocaleString() : "shipped with the app"}</td></tr>))}</tbody></table>
          </div>
        </div>
      )}

      <div className="panel" style={{ padding: 14 }}>
        <div className="dx-head"><b>Browse and export</b><span className="mut">{(data.total ?? 0).toLocaleString()} datafields match</span>
          <span style={{ marginLeft: "auto", display: "flex", gap: 6 }}>
            <a className="btn ghost sm" href={exportHref("csv")}>Export CSV</a>
            <a className="btn ghost sm" href={exportHref("xlsx")}>Export Excel</a>
          </span></div>
        <div className="dx-filters" style={{ margin: "8px 0" }}>
          <select value={f.region} onChange={(e) => { setF({ ...f, region: e.target.value }); setPage(0); }}>
            <option value="">all regions</option>{[...new Set((summary?.scopes ?? []).map((s: Row) => s.region))].map((r: any) => <option key={r} value={r}>{r}</option>)}</select>
          <select value={f.delay} onChange={(e) => { setF({ ...f, delay: e.target.value }); setPage(0); }}>
            <option value="">any delay</option><option value="0">D0</option><option value="1">D1</option></select>
          <select value={f.type} onChange={(e) => { setF({ ...f, type: e.target.value }); setPage(0); }}>
            <option value="">any type</option><option value="MATRIX">MATRIX</option><option value="VECTOR">VECTOR</option></select>
          <input placeholder="category" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} style={{ width: 120 }} />
          <input placeholder="dataset" value={f.dataset} onChange={(e) => setF({ ...f, dataset: e.target.value })} style={{ width: 120 }} />
          <input placeholder="search id / description" value={f.q} onChange={(e) => setF({ ...f, q: e.target.value })} style={{ width: 200 }}
            onKeyDown={(e) => { if (e.key === "Enter") { setPage(0); loadRows(); } }} />
          <button className="btn ghost sm" onClick={() => { setPage(0); loadRows(); }}>Search</button>
        </div>
        <div className="panel-scroll" style={{ maxHeight: 420 }}>
          <table><thead><tr><th>datafield</th><th>dataset</th><th>category</th><th>scope</th><th>type</th><th>alphas</th><th>description</th></tr></thead>
            <tbody>{(data.rows ?? []).map((r: Row) => (
              <tr key={`${r.region}${r.delay}${r.field_id}`}><td>{r.field_id}</td><td title={r.dataset_name}>{r.dataset_id}</td><td>{r.category}</td>
                <td>{r.region} D{r.delay}</td><td>{r.type}</td><td>{r.alpha_count}</td><td title={r.description}>{String(r.description).slice(0, 90)}</td></tr>))}</tbody></table>
        </div>
        <div className="dx-filters" style={{ marginTop: 8 }}>
          <button className="btn ghost sm" disabled={page === 0} onClick={() => setPage(page - 1)}>‹ Prev</button>
          <span className="mut">page {page + 1} of {Math.max(1, Math.ceil((data.total ?? 0) / LIMIT))}</span>
          <button className="btn ghost sm" disabled={(page + 1) * LIMIT >= (data.total ?? 0)} onClick={() => setPage(page + 1)}>Next ›</button>
        </div>
      </div>
    </div>
  );
}
