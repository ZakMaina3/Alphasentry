import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../../lib/api";
import { useResearch } from "../../lib/store";
import { usePersistentState } from "../../lib/persist";
import { NumberInput } from "../../lib/NumberInput";
import { useToast } from "../../lib/toast";
import "./templates.css";

interface Op { name: string; params: string[]; }
const lines = (s: string) => s.split("\n").map((x) => x.trim()).filter(Boolean);

// Fuzzy match: every letter of the query appears IN ORDER in the operator name (underscores in
// both are ignored), so "tsrnk" or "trank" both find "ts_rank".
function subseq(needle: string, hay: string): boolean {
  const n = needle.replace(/_/g, ""), h = hay.replace(/_/g, "");
  let i = 0;
  for (const c of h) if (i < n.length && c === n[i]) i++;
  return i === n.length;
}

// Unwrap vec_*( … ) → its inner expression (templates must not carry vec_*; it's re-applied at
// expansion). Balanced-paren, repeated until none remain.
function stripVec(s: string): string {
  const re = /vec_[a-z0-9_]+\s*\(/i;
  let m: RegExpExecArray | null;
  while ((m = re.exec(s))) {
    const start = m.index, open = m.index + m[0].length - 1;
    let depth = 0, close = -1;
    for (let i = open; i < s.length; i++) {
      if (s[i] === "(") depth++;
      else if (s[i] === ")") { depth--; if (depth === 0) { close = i; break; } }
    }
    if (close === -1) break;
    s = s.slice(0, start) + s.slice(open + 1, close) + s.slice(close + 1);
  }
  return s;
}

// The starting example switches with the mode so the placeholders always match: one {field}
// for single-field, {field} + {field2} for multi-field.
const SINGLE_EX = "group_zscore(ts_rank({field}, 60), subindustry)";
const MULTI_EX = "group_zscore(ts_regression({field}, {field2}, 120), subindustry)";

// Structural check (not a full parser): unbalanced brackets, empty call, dangling comma,
// missing {field} slot.
function checkExpr(e: string): string[] {
  const iss: string[] = []; let depth = 0;
  for (const ch of e) { if (ch === "(") depth++; else if (ch === ")") { depth--; if (depth < 0) { iss.push("A ')' has no matching '('"); break; } } }
  if (depth > 0) iss.push(depth + " unclosed '('");
  if (/\(\s*\)/.test(e)) iss.push("Empty ( ) — missing input");
  if (/,\s*\)/.test(e) || /\(\s*,/.test(e) || /,\s*,/.test(e)) iss.push("Stray comma");
  if (!/\{field\d*(:\w+)?\}/.test(e)) iss.push("No {field} slot");
  return iss;
}

export function TemplateStudio() {
  const R = useResearch();
  const nav = useNavigate();
  const { toast, toastErr } = useToast();

  // Persisted so leaving and returning (or a reload) keeps the template, mode and results.
  const [tmpl, setTmpl] = usePersistentState("tpl:text", SINGLE_EX);
  const [vecOps, setVecOps] = usePersistentState<string[]>("tpl:vecops", ["vec_avg", "vec_max", "vec_min", "vec_norm"]);
  const [multi, setMulti] = usePersistentState("tpl:multi", false);
  const [maxOps, setMaxOps] = usePersistentState("tpl:maxops", 4);
  const [field2Src, setField2Src] = usePersistentState("tpl:field2src", "same");   // same | <datasetId> | custom
  const [customFields, setCustomFields] = usePersistentState("tpl:customfields", "");
  const [maxCombos, setMaxCombos] = usePersistentState("tpl:maxcombos", 0);   // 0 = all combinations
  const [maxFields, setMaxFields] = usePersistentState("tpl:maxfields", 0);   // 0 = use every selected field
  const [out, setOut] = usePersistentState<any | null>("tpl:out", null);

  const [ops, setOps] = useState<Op[]>([]);
  const [busy, setBusy] = useState(false);       // Preview & validate
  const [busyS, setBusyS] = useState(false);     // Suggest from data
  const [busyP, setBusyP] = useState(false);     // LLM field picks
  const [picks, setPicks] = usePersistentState<any[]>("tpl:picks", []);
  const [pickN, setPickN] = usePersistentState("tpl:pickn", 6);
  const [suggestN, setSuggestN] = usePersistentState("tpl:suggestn", 8);   // how many templates to suggest
  // Datasets to retry with, set when a near-miss result is reused as a template.
  const [retryDs, setRetryDs] = useState<string[]>(() => { try { return JSON.parse(localStorage.getItem("ace2:tpl:retry") || "[]"); } catch { return []; } });
  const taRef = useRef<HTMLTextAreaElement>(null);

  // ── operator autocomplete ────────────────────────────────────────────────────────
  const [ac, setAc] = useState<{ open: boolean; matches: Op[]; idx: number; start: number; end: number }>(
    { open: false, matches: [], idx: 0, start: 0, end: 0 });

  useEffect(() => { api.get<{ operators: Op[] }>("/generate/operators").then((d) => setOps(d.operators || [])); }, []);
  const VEC = ["vec_avg", "vec_max", "vec_min", "vec_norm", "vec_sum", "vec_count", "vec_stddev", "vec_range"];

  const selFields = R.fields.filter((f) => R.selFields.includes(f.id));
  const dsById = Object.fromEntries(R.datasets.map((d) => [d.id, d]));
  const fieldCats: Record<string, string> = {};
  selFields.forEach((f) => { const c = f.dataset_id && dsById[f.dataset_id]?.category_id; if (c) fieldCats[f.id] = c; });
  const nVec = selFields.filter((f) => String(f.type).toUpperCase() === "VECTOR").length;

  // {field2} pool: the same selected fields, a specific selected dataset's fields, or the user's own field ids.
  const selectedDatasets = R.datasets.filter((d) => R.selDatasets.includes(d.id));
  const customList = customFields.split(/[\s,]+/).map((s) => s.trim()).filter(Boolean);
  const field2Ids =
    field2Src === "custom" ? customList :
    field2Src === "same" ? selFields.map((f) => f.id) :
    selFields.filter((f) => f.dataset_id === field2Src).map((f) => f.id);
  // All fields the validator must know (selected + any custom, typed MATRIX by default).
  const allFieldsPayload = [
    ...selFields.map((f) => ({ id: f.id, type: f.type })),
    ...customList.map((id) => ({ id, type: "MATRIX" })),
  ];

  const syntax = useMemo(() => {
    const ls = lines(tmpl); let bad = 0; const detail: string[] = [];
    ls.forEach((e, i) => { const is = checkExpr(e); if (is.length) { bad++; if (detail.length < 2) detail.push(`Line ${i + 1}: ${is[0]}`); } });
    return { bad, total: ls.length, detail };
  }, [tmpl]);

  // Rank matches: exact-prefix, then contains, then FUZZY subsequence (letters in order, underscores
  // ignored) — so you never need to type the operator exactly to get suggestions.
  function computeMatches(token: string): Op[] {
    const t = token.toLowerCase();
    const pre = ops.filter((o) => o.name.toLowerCase().startsWith(t));
    const mid = ops.filter((o) => !o.name.toLowerCase().startsWith(t) && o.name.toLowerCase().includes(t));
    const seen = new Set([...pre, ...mid].map((o) => o.name));
    const fuzzy = ops.filter((o) => !seen.has(o.name) && subseq(t, o.name.toLowerCase()));
    pre.sort((a, b) => a.name.length - b.name.length || a.name.localeCompare(b.name));
    mid.sort((a, b) => a.name.localeCompare(b.name));
    fuzzy.sort((a, b) => a.name.length - b.name.length || a.name.localeCompare(b.name));
    return [...pre, ...mid, ...fuzzy].slice(0, 40);
  }

  // After any edit / caret move, recompute the token under the caret and the suggestion list.
  function refreshAc(ta: HTMLTextAreaElement) {
    const pos = ta.selectionStart;
    if (pos !== ta.selectionEnd) return setAc((a) => ({ ...a, open: false }));
    const m = ta.value.slice(0, pos).match(/([A-Za-z_][A-Za-z0-9_]*)$/);
    if (!m) return setAc((a) => ({ ...a, open: false }));
    const token = m[1], start = pos - token.length;
    const matches = computeMatches(token);
    setAc({ open: matches.length > 0, matches, idx: 0, start, end: pos });
  }

  function insertOp(op: Op) {
    const ta = taRef.current; if (!ta) return;
    // Insert `op()` and drop the caret INSIDE the parens — you type the field/args yourself; the
    // suggestion no longer fills in a {field} placeholder for you.
    const ins = op.name + "()";
    const v = tmpl.slice(0, ac.start) + ins + tmpl.slice(ac.end);
    setTmpl(v);
    const caret = ac.start + op.name.length + 1;   // just after "("
    setAc((a) => ({ ...a, open: false }));
    requestAnimationFrame(() => { ta.focus(); ta.selectionStart = ta.selectionEnd = caret; });
  }

  function onKeyDown(ev: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (!ac.open) {
      if (ev.key === "Tab" && !ev.shiftKey) { const ta = ev.currentTarget; refreshAc(ta); }
      return;
    }
    if (ev.key === "ArrowDown") { ev.preventDefault(); setAc((a) => ({ ...a, idx: (a.idx + 1) % a.matches.length })); }
    else if (ev.key === "ArrowUp") { ev.preventDefault(); setAc((a) => ({ ...a, idx: (a.idx - 1 + a.matches.length) % a.matches.length })); }
    else if (ev.key === "Enter" || ev.key === "Tab") { ev.preventDefault(); insertOp(ac.matches[ac.idx]); }
    else if (ev.key === "Escape") { ev.preventDefault(); setAc((a) => ({ ...a, open: false })); }
  }

  // Switching the mode swaps in the matching example (only if the text is still an untouched
  // example, so a user's own work is never overwritten).
  function toggleMulti() {
    setMulti((was) => {
      const now = !was;
      setTmpl((cur) => (cur.trim() === SINGLE_EX || cur.trim() === MULTI_EX || !cur.trim())
        ? (now ? MULTI_EX : SINGLE_EX) : cur);
      return now;
    });
  }

  async function expand() {
    if (!selFields.length) return toast("Select datafields in the Data Explorer first.", "warn");
    if (syntax.bad) return toast(`Fix the template first — ${syntax.detail[0]}.`, "warn");
    // "Fields to use" (0 = all) trims the {field} pool at the source, so the user controls how big
    // the sweep gets. When {field2} is the same selected fields, it follows the same trim.
    const lim = (arr: string[]) => (maxFields > 0 ? arr.slice(0, maxFields) : arr);
    const fieldIds = lim(selFields.map((f) => f.id));
    const f2 = field2Src === "same" ? lim(field2Ids) : field2Ids;
    setBusy(true);
    const d = await api.post<any>("/generate/templates/expand", {
      templates: lines(tmpl), field_ids: fieldIds,
      field2_ids: multi ? f2 : [],
      fields: allFieldsPayload, vec_ops: vecOps,
      max_operators: maxOps, multi_field: multi,
      max_combos: maxCombos,   // 0 = all possible combinations
    });
    setBusy(false);
    if (d.error) return toastErr(d.error);
    setOut(d);
    toast(`${d.report.valid} valid of ${d.report.total} expansions.`);
  }

  async function pickFields() {
    if (!selFields.length) return toast("Select some datafields first — the LLM picks from them.", "warn");
    setBusyP(true); setPicks([]);
    const start = await api.post<any>("/generate/fields/suggest", {
      region: R.ctx.region, delay: R.ctx.delay, instrument: R.ctx.instrument, universe: R.ctx.universe,
      dataset_names: R.datasets.filter((d) => R.selDatasets.includes(d.id)).map((d) => d.name || d.id),
      fields: selFields.map((f) => ({ id: f.id, type: f.type, description: f.description, dataset_id: f.dataset_id })),
      categories: fieldCats, max_operators: maxOps, n: pickN, multi_field: multi,
    });
    if (start.error || !start.job_id) { setBusyP(false); return toastErr(start.error || "Could not start."); }
    let s: any = {};
    for (; ;) { s = await api.get(`/generate/jobs/${start.job_id}`); if (s.status !== "running") break; await new Promise((r) => setTimeout(r, 1400)); }
    setBusyP(false);
    if (s.status !== "done") return toastErr(s.error || s.status);
    const p = s.result?.picks || [];
    setPicks(p);
    toast(p.length ? `${p.length} field ideas via ${s.result.provider} — pick the ones to use.` : "No field ideas returned.", p.length ? "ok" : "warn");
  }
  function usePick(p: any) {
    if (p.fields?.length) R.setSelFields([...new Set([...R.selFields, ...p.fields])]);
    if (p.template) {
      const t = stripVec(p.template);   // never carry a vec_* into the template box
      setTmpl((cur) => {
        // Append below what's there (unless it's empty or the untouched starter example).
        const keep = cur && cur.trim() && cur.trim() !== SINGLE_EX && cur.trim() !== MULTI_EX;
        return (keep ? cur.replace(/\s+$/, "") + "\n" : "") + t;
      });
    }
    toast(`Added ${(p.fields || []).join(", ")} — template appended. Preview to expand.`, "ok");
  }

  async function suggest() {
    if (!selFields.length) return toast("Select datafields first.", "warn");
    setBusyS(true);
    const start = await api.post<any>("/generate/templates/suggest", {
      region: R.ctx.region, delay: R.ctx.delay, instrument: R.ctx.instrument, universe: R.ctx.universe,
      dataset_names: R.datasets.filter((d) => R.selDatasets.includes(d.id)).map((d) => d.name || d.id),
      fields: selFields.map((f) => ({ id: f.id, type: f.type, description: f.description })),
      categories: fieldCats, max_operators: maxOps, n: suggestN, multi_field: multi,
    });
    if (start.error || !start.job_id) { setBusyS(false); return toastErr(start.error || "Could not start."); }
    let s: any = {};
    for (; ;) { s = await api.get(`/generate/jobs/${start.job_id}`); if (s.status !== "running") break; await new Promise((r) => setTimeout(r, 1400)); }
    setBusyS(false);
    if (s.status !== "done") return toastErr(s.error || s.status);
    const t = (s.result?.templates || []);
    if (t.length) { setTmpl(t.join("\n")); toast(`${t.length} templates suggested via ${s.result.provider}.`); }
    else toast("No templates returned.", "warn");
  }

  const valid = (out?.results || []).filter((r: any) => r.ok).map((r: any) => r.expr);

  return (
    <div className="dx-split" style={{ flex: 1, minHeight: 0 }}>
      {/* ── editor ── */}
      <div className="panel tpl-panel">
        <div className="dx-head">
          <b>Template</b>
          <span className="tpl-tag">{"{field}"} single · {"{field2}"} multi · type an operator, Tab / ↑↓ + Enter</span>
        </div>
        <div className="tpl-body">
          {retryDs.length ? (
            <div className="mut" style={{ fontSize: 12, color: "var(--acc)", background: "var(--acc-weak)", padding: "8px 10px", borderRadius: 8, marginBottom: 8 }}>
              ⟳ Reused from a near-miss. Retry with dataset id(s): <b>{retryDs.join(", ")}</b> — fetch them in the Data Explorer and select their fields, then Preview.
              <span className="pill sm" style={{ marginLeft: 8 }} onClick={() => { localStorage.removeItem("ace2:tpl:retry"); setRetryDs([]); }}>dismiss</span>
            </div>
          ) : null}
          <div className="tpl-editor">
            <textarea
              ref={taRef} value={tmpl} spellCheck={false}
              onChange={(e) => { setTmpl(e.target.value); refreshAc(e.currentTarget); }}
              onKeyDown={onKeyDown}
              onKeyUp={(e) => { if (["ArrowLeft", "ArrowRight", "Home", "End"].includes(e.key)) refreshAc(e.currentTarget); }}
              onBlur={() => setTimeout(() => setAc((a) => ({ ...a, open: false })), 120)}
            />
            {ac.open ? (
              <div className="tpl-ac">
                {ac.matches.map((o, i) => (
                  <div key={o.name} className={"tpl-ac-item" + (i === ac.idx ? " on" : "")}
                    onMouseEnter={() => setAc((a) => ({ ...a, idx: i }))}
                    onMouseDown={(e) => { e.preventDefault(); insertOp(o); }}>
                    <span>{o.name}</span>
                    <span className="sig">({(o.params || []).join(", ")})</span>
                  </div>
                ))}
                <div className="tpl-ac-hint">↑↓ to move · Enter / Tab to insert · Esc to dismiss</div>
              </div>
            ) : null}
          </div>

          <div style={{ fontSize: 12, marginTop: 6, color: syntax.bad ? "var(--bad)" : "var(--ok)" }}>
            {syntax.bad ? `⚠ ${syntax.bad} of ${syntax.total} need a fix — ${syntax.detail.join("; ")}` : `✓ ${syntax.total} template(s) look OK`}
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 10, alignItems: "end", marginTop: 12,
            padding: "10px 12px", border: "1px solid var(--line)", borderRadius: "var(--radius-sm)", background: "var(--surface-2)" }}>
            <div>
              <div className="mut" style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: ".5px", marginBottom: 4 }}>Mode</div>
              <div className="dx-filters">
                <span className={"pill" + (!multi ? " on" : "")} onClick={() => multi && toggleMulti()}>Single {"{field}"}</span>
                <span className={"pill" + (multi ? " on" : "")} onClick={() => !multi && toggleMulti()}>Multi {"{field}"} + {"{field2}"}</span>
              </div>
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <label className="fld" style={{ width: 88 }}><span>Max Ops</span>
                <NumberInput min={1} fallback={4} value={maxOps} onChange={setMaxOps} /></label>
              <label className="fld" style={{ width: 100 }}
                title="How many of your selected fields to feed into the sweep. 0 = use them all.">
                <span>Fields to use</span>
                <NumberInput min={0} fallback={0} value={maxFields} onChange={setMaxFields} placeholder="all" /></label>
            </div>

            {multi ? <div style={{ gridColumn: "1 / -1" }}>
              <label className="fld"><span>{"{field2}"} source</span>
                <select value={field2Src} onChange={(e) => setField2Src(e.target.value)}>
                  <option value="same">Same selected fields</option>
                  {selectedDatasets.map((d) => <option key={d.id} value={d.id}>Dataset · {d.name || d.id}</option>)}
                  <option value="custom">My own field ids…</option>
                </select></label>
              {field2Src === "custom" ?
                <label className="fld" style={{ marginTop: 6 }}><span>Your field ids (comma / space separated)</span>
                  <input value={customFields} onChange={(e) => setCustomFields(e.target.value)} placeholder="anl4_xxx, fnd6_yyy" /></label> : null}
              <label className="fld" style={{ marginTop: 6, width: 160 }}
                title="Cap the number of {field}×{field2} combinations produced. 0 = every possible combination.">
                <span>Max combinations</span>
                <NumberInput min={0} fallback={0} value={maxCombos} onChange={setMaxCombos} placeholder="all" /></label>
              <div className="mut" style={{ fontSize: 11, marginTop: 4 }}>
                {"{field}"} uses {maxFields > 0 ? `the first ${maxFields} of ` : ""}your selected fields ·
                {" "}{"{field2}"} draws from {(field2Src === "same" && maxFields > 0 ? Math.min(maxFields, field2Ids.length) : field2Ids.length)} field(s) ·
                {" "}{maxCombos > 0 ? `capped at ${maxCombos} combos` : "all possible combinations"}.
              </div>
            </div> : null}
          </div>

          <div className="mut" style={{ fontSize: 11, marginTop: 10, marginBottom: 4 }}>
            Vector operators — VECTOR fields ({nVec} selected) are wrapped in one of these
          </div>
          <div className="dx-filters wrap">
            {VEC.map((v) => <span key={v} className={"pill" + (vecOps.includes(v) ? " on" : "")}
              onClick={() => setVecOps((x) => x.includes(v) ? x.filter((y) => y !== v) : [...x, v])}>{v}</span>)}
          </div>

          <div className="dx-filters" style={{ marginTop: 12, alignItems: "center" }}>
            <button className="btn" onClick={expand} disabled={busy || busyS || busyP}>
              {busy ? <><span className="spin" /> Expanding…</> : "Preview & Validate"}</button>
            <button className="btn ghost" onClick={suggest} disabled={busy || busyS || busyP}>
              {busyS ? <><span className="spin" /> Suggesting…</> : "✦ Suggest From Data"}</button>
            <span className="mut" style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 12 }}>
              how many
              <span style={{ width: 60 }}><NumberInput min={1} max={50} fallback={8} value={suggestN} onChange={setSuggestN} /></span>
            </span>
          </div>

          {/* LLM picks the datafields (from their descriptions) + a template, to shrink the search. */}
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 10, flexWrap: "wrap" }}>
            <button className="btn ghost sm" onClick={pickFields} disabled={busy || busyS || busyP}
              title="The LLM reads your selected fields' descriptions and proposes concrete field + template ideas that make economic sense — pick the ones to use.">
              {busyP ? <><span className="spin" /> Choosing…</> : "🎯 Let the LLM pick fields"}</button>
            <span className="mut" style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 12 }}>
              how many
              <span style={{ width: 60 }}><NumberInput min={1} max={20} fallback={6} value={pickN} onChange={setPickN} /></span>
            </span>
          </div>
          {picks.length ? <div style={{ marginTop: 6 }}>
            {picks.map((p, i) => (
              <div key={i} style={{ border: "1px solid var(--line)", borderRadius: 8, padding: "8px 10px", marginBottom: 6 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <b style={{ fontSize: 12 }}>{(p.fields || []).join(" + ")}</b>
                  <button className="btn sm" style={{ marginLeft: "auto" }} onClick={() => usePick(p)}>Use</button>
                </div>
                <code style={{ display: "block", fontSize: 12, marginTop: 3, wordBreak: "break-all" }}>{p.template}</code>
                {p.reason ? <div className="mut" style={{ fontSize: 11, marginTop: 2 }}>{p.reason}</div> : null}
              </div>))}
          </div> : null}
        </div>
      </div>

      {/* ── expansions (header sticks; only the table scrolls) ── */}
      <div className="panel tpl-panel">
        <div className="dx-head">
          <b>Expansions</b>
          {out ? <span className="mut">{out.report.valid} valid · {out.report.rejected} rejected</span> : null}
          {valid.length ? <button className="btn sm" style={{ marginLeft: "auto" }}
            onClick={() => { R.setPending(valid); nav("/simulate"); }}>Send {valid.length} To Simulate →</button> : null}
        </div>
        <div className="tpl-body flush">
          {!out ? <div className="empty">Select fields, write a template, and Preview. VECTOR fields fan out across your vec_* choices; multi-field takes a bounded product.</div> :
            <table><thead><tr><th></th><th>Expansion</th><th>Issues</th></tr></thead>
              <tbody>{out.results.map((r: any, i: number) => (
                <tr key={i}><td><span className={"badge " + (r.ok ? "ok" : "bad")}>{r.ok ? "ok" : "rej"}</span></td>
                  <td><code style={{ fontSize: 11 }}>{r.expr}</code></td>
                  <td className="mut" style={{ fontSize: 11 }}>{(r.issues || []).join(", ")}</td></tr>))}</tbody></table>}
        </div>
      </div>
    </div>
  );
}
