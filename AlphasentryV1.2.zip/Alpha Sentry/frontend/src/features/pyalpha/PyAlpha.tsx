import { useMemo, useState } from "react";
import { api } from "../../lib/api";
import { useResearch } from "../../lib/store";
import { usePersistentState } from "../../lib/persist";
import { NumberInput } from "../../lib/NumberInput";
import { useToast } from "../../lib/toast";

const num = (v: any, d = 3) => (v == null ? "—" : (+v).toFixed(d));

// Alpha Translation — Fast Expression → Python Alpha (following YOUR guideline, edited here),
// then simulate the Python alpha and the original Fast Expression side by side.
export function PyAlpha() {
  const R = useResearch();
  const { toast, toastErr } = useToast();

  const [expr, setExpr] = usePersistentState("py:expr", "");
  const [code, setCode] = usePersistentState("py:code", "");
  const [notes, setNotes] = usePersistentState("py:notes", "");
  const [neut, setNeut] = usePersistentState("py:neut", "MARKET");
  const [decay, setDecay] = usePersistentState("py:decay", 0);
  const [trunc, setTrunc] = usePersistentState("py:trunc", 0.08);
  const [lookback, setLookback] = usePersistentState("py:lookback", 0);
  const [nanOn, setNanOn] = usePersistentState("py:nan", true);
  const [pyRes, setPyRes] = usePersistentState<any>("py:pyres", null);
  const [fxRes, setFxRes] = usePersistentState<any>("py:fxres", null);
  const [meta, setMeta] = useState<any>(null);
  const [busy, setBusy] = useState<string>("");
  const [guide, setGuide] = useState<string>("");
  const [guideBuiltin, setGuideBuiltin] = useState<boolean>(true);
  const [showGuide, setShowGuide] = useState(false);

  const neutOpts = useMemo(() => {
    const recs = (R.options || []).filter((o) => o.instrument === R.ctx.instrument && o.region === R.ctx.region);
    return [...new Set(recs.flatMap((o) => o.neutralizations))];
  }, [R.options, R.ctx]);

  const settings = () => ({
    region: R.ctx.region, universe: R.ctx.universe, delay: R.ctx.delay, neutralization: neut, decay, truncation: trunc,
    lookback: lookback > 0 ? lookback : "", nan_handling: nanOn ? "ON" : "OFF", pasteurization: "ON",
  });

  async function loadGuide() {
    const g = await api.get<any>("/pyalpha/guideline");
    if (g.error) return toastErr(g.error);
    setGuide(g.text); setGuideBuiltin(!!g.builtin); setShowGuide(true);
  }
  async function saveGuide() {
    const g = await api.post<any>("/pyalpha/guideline", { text: guide });
    if (g.error) return toastErr(g.error);
    setGuideBuiltin(!!g.builtin);
    toast(g.builtin ? "Built-in guidelines in use." : "Custom guideline saved.", "ok");
  }
  async function resetGuide() {
    const g = await api.post<any>("/pyalpha/guideline/reset", {});
    if (g.error) return toastErr(g.error);
    setGuide(g.text); setGuideBuiltin(true);
    toast("Built-in guidelines restored.", "ok");
  }

  async function job(path: string, body: any, label: string): Promise<any | null> {
    setBusy(label);
    const start = await api.post<any>(path, body);
    if (start.error || !start.job_id) { setBusy(""); toastErr(start.error || "Could not start."); return null; }
    let s: any = {};
    for (; ;) {
      s = await api.get(`/pyalpha/jobs/${start.job_id}`);
      if (s.status !== "running") break;
      await new Promise((r) => setTimeout(r, 1800));
    }
    setBusy("");
    if (s.status === "error") { toastErr(s.error); return null; }
    return s.result ?? null;
  }

  async function translate(fix = false) {
    if (!expr.trim()) return toast("Paste a Fast Expression first.", "warn");
    const r = await job("/pyalpha/translate", {
      expression: expr, settings: settings(), notes,
      prior_code: fix ? code : "", error: fix ? (pyRes?.error || (pyRes?.reasons || []).join("; ")) : "",
    }, fix ? "fixing" : "translating");
    if (!r) return;
    setCode(r.code); setPyRes(null); setMeta(r);
    if (r.syntax_error) toast(`Translated, but Python still has a syntax error (${r.syntax_error}).`, "warn");
    else toast(`Translated by ${r.provider} in ${r.seconds}s.`, "ok");
  }
  async function simPy() {
    if (!code.trim()) return toast("Nothing to simulate — translate first or paste code.", "warn");
    const r = await job("/pyalpha/simulate", { code, settings: settings() }, "simpy");
    if (r) { setPyRes(r); toast(r.ok ? (r.passed ? "Python alpha passed the gate." : "Simulated — see the verdict.") : "Simulation failed — see the error.", r.ok && r.passed ? "ok" : "warn"); }
  }
  async function simFx() {
    if (!expr.trim()) return toast("Paste a Fast Expression first.", "warn");
    const r = await job("/pyalpha/simulate-fast", { expression: expr, settings: settings() }, "simfx");
    if (r) setFxRes(r);
  }

  const rows: [string, string][] = [["Sharpe", "sharpe"], ["Fitness", "fitness"], ["Turnover", "turnover"], ["Returns", "returns"], ["Drawdown", "drawdown"], ["Margin", "margin"]];
  const delta = (k: string) => (pyRes?.ok && fxRes?.ok && pyRes[k] != null && fxRes[k] != null) ? (pyRes[k] - fxRes[k]) : null;

  return (
    <div className="dx-split" style={{ flex: 1, minHeight: 0 }}>
      <div className="panel" style={{ padding: 14 }}>
        <div className="dx-head"><b>Alpha Translation</b>
          <span className="mut">{R.ctx.region} · D{R.ctx.delay} · {R.ctx.universe}</span>
          {busy ? <span className="badge ok" style={{ marginLeft: "auto" }}>{busy}…</span> : null}</div>
        <div className="panel-scroll">
          <label className="fld"><span>Fast Expression</span>
            <textarea value={expr} onChange={(e) => setExpr(e.target.value)} style={{ minHeight: 84, fontFamily: "monospace" }} spellCheck={false}
              placeholder="ts_backfill(ts_decay_linear(rank(field_a),150)*rank(field_b),5)" /></label>
          <label className="fld"><span>Extra notes for this translation (optional)</span>
            <input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="e.g. field_b is a VECTOR field" /></label>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8, marginTop: 8 }}>
            <label className="fld"><span>Neutralization</span>
              <select value={neut} onChange={(e) => setNeut(e.target.value)}>
                {[...new Set([neut, ...neutOpts])].map((n) => <option key={n}>{n}</option>)}</select></label>
            <label className="fld"><span>Decay</span><NumberInput min={0} fallback={0} value={decay} onChange={setDecay} /></label>
            <label className="fld"><span>Truncation</span><NumberInput step="0.01" min={0} fallback={0.08} value={trunc} onChange={setTrunc} /></label>
            <label className="fld" title="Python alphas take a lookback window (0 = leave unset)"><span>Lookback</span><NumberInput min={0} fallback={0} value={lookback} onChange={setLookback} /></label>
            <div className="dx-filters" style={{ alignSelf: "end" }}>
              <span className={"pill" + (nanOn ? " on" : "")} onClick={() => setNanOn((v) => !v)}
                title="Python alphas require NaN handling ON on the platform.">NaN handling: {nanOn ? "ON" : "OFF"}</span></div>
          </div>

          <div style={{ display: "flex", gap: 8, marginTop: 12, flexWrap: "wrap" }}>
            <button className="btn" onClick={() => translate(false)} disabled={!!busy}>{busy === "translating" ? <><span className="spin" /> Translating…</> : "⇄ Translate to Python"}</button>
            <button className="btn ghost" onClick={simPy} disabled={!!busy}>{busy === "simpy" ? <><span className="spin" /> Simulating…</> : "▶ Simulate Python"}</button>
            <button className="btn ghost" onClick={simFx} disabled={!!busy}>{busy === "simfx" ? <><span className="spin" /> Simulating…</> : "▶ Simulate Fast Expr (baseline)"}</button>
          </div>

          <div className="section" style={{ fontSize: 11, color: "var(--mut)", textTransform: "uppercase", letterSpacing: ".5px", marginTop: 14 }}>Translation guideline</div>
          {!showGuide ? <button className="btn ghost sm" onClick={loadGuide}>View / edit guideline</button> : <>
            <div className="mut" style={{ fontSize: 12, marginBottom: 4 }}>
              {guideBuiltin ? <span style={{ color: "var(--ok)" }}>Built-in guidelines in use — translation works in one click.</span>
                : <span style={{ color: "var(--warn)" }}>Custom guideline in use (overrides the built-in).</span>}</div>
            <textarea value={guide} onChange={(e) => setGuide(e.target.value)} style={{ minHeight: 260, width: "100%", fontFamily: "monospace", fontSize: 12 }} spellCheck={false} />
            <div style={{ display: "flex", gap: 8, marginTop: 6 }}>
              <button className="btn sm" onClick={saveGuide}>Save guideline</button>
              <button className="btn ghost sm" onClick={resetGuide} disabled={guideBuiltin}>Restore built-in</button>
              <button className="btn ghost sm" onClick={() => setShowGuide(false)}>Close</button></div></>}
        </div>
      </div>

      <div className="panel" style={{ padding: 14 }}>
        <div className="dx-head"><b>Python Alpha</b>
          {meta ? <span className="mut">{meta.provider} · {meta.model}</span> : null}
          <button className="btn ghost sm" style={{ marginLeft: "auto" }} onClick={() => { navigator.clipboard?.writeText(code); toast("Copied."); }} disabled={!code}>Copy</button></div>
        <div className="panel-scroll">
          <textarea value={code} onChange={(e) => setCode(e.target.value)} spellCheck={false}
            style={{ width: "100%", minHeight: 300, fontFamily: "monospace", fontSize: 12, whiteSpace: "pre", overflow: "auto" }}
            placeholder="The translated Python alpha appears here — you can edit it before simulating." />
          {meta?.syntax_error ? <div style={{ fontSize: 12, color: "var(--bad)", marginTop: 4 }}>Syntax error: {meta.syntax_error}</div> : null}
          {meta && (meta.checks?.length || meta.checklist) ? <div style={{ fontSize: 12, marginTop: 8 }}>
            <div className="section" style={{ fontSize: 11, color: "var(--mut)", textTransform: "uppercase", letterSpacing: ".5px" }}>Port checklist{meta.coldStartDays ? ` · cold start ≈ ${meta.coldStartDays} days` : ""}</div>
            {(meta.checks || []).length ? <ul style={{ margin: "4px 0 4px 16px", padding: 0 }}>{meta.checks.map((c: string, i: number) => <li key={i}>{c}</li>)}</ul> : null}
            {meta.checklist ? <div className="mut" style={{ whiteSpace: "pre-wrap" }}>{meta.checklist}</div> : null}</div> : null}

          <div className="section" style={{ fontSize: 11, color: "var(--mut)", textTransform: "uppercase", letterSpacing: ".5px", marginTop: 14 }}>Simulation</div>
          {!pyRes && !fxRes ? <div className="empty">Simulate the Python alpha and the Fast Expression baseline to compare them.</div> : <>
            {pyRes && !pyRes.ok ? <div style={{ fontSize: 12, color: "var(--bad)", background: "var(--bad-weak)", borderRadius: 6, padding: "6px 9px", marginBottom: 8, whiteSpace: "pre-wrap" }}>
              <b>Python simulation failed.</b> {pyRes.error}
              <div style={{ marginTop: 6 }}><button className="btn sm" onClick={() => translate(true)} disabled={!!busy}>Send error back to the LLM to fix</button></div></div> : null}
            {fxRes && !fxRes.ok ? <div style={{ fontSize: 12, color: "var(--bad)", marginBottom: 8 }}>Fast Expression simulation failed: {fxRes.error}</div> : null}
            <table><thead><tr><th>Metric</th><th>Python</th><th>Fast Expr</th><th>Δ</th></tr></thead>
              <tbody>
                {rows.map(([label, k]) => (
                  <tr key={k}><td>{label}</td>
                    <td>{pyRes?.ok ? (k === "turnover" && pyRes[k] != null ? (pyRes[k] * 100).toFixed(1) + "%" : num(pyRes[k])) : "—"}</td>
                    <td>{fxRes?.ok ? (k === "turnover" && fxRes[k] != null ? (fxRes[k] * 100).toFixed(1) + "%" : num(fxRes[k])) : "—"}</td>
                    <td className="mut">{delta(k) == null ? "—" : (delta(k)! >= 0 ? "+" : "") + (k === "turnover" ? (delta(k)! * 100).toFixed(1) + "pp" : delta(k)!.toFixed(3))}</td></tr>))}
                <tr><td>Gate</td>
                  <td>{pyRes?.ok ? (pyRes.passed ? <span style={{ color: "var(--ok)" }}>✓ pass</span> : <span style={{ color: "var(--bad)" }}>✗ {(pyRes.reasons || []).join(", ")}</span>) : "—"}</td>
                  <td>{fxRes?.ok ? (fxRes.passed ? <span style={{ color: "var(--ok)" }}>✓ pass</span> : <span style={{ color: "var(--bad)" }}>✗ {(fxRes.reasons || []).join(", ")}</span>) : "—"}</td><td /></tr>
                <tr><td>Alpha</td>
                  <td>{pyRes?.alpha_id ? <a href={`https://platform.worldquantbrain.com/alpha/${pyRes.alpha_id}`} target="_blank" rel="noopener"><code>{pyRes.alpha_id}</code></a> : "—"}</td>
                  <td>{fxRes?.alpha_id ? <a href={`https://platform.worldquantbrain.com/alpha/${fxRes.alpha_id}`} target="_blank" rel="noopener"><code>{fxRes.alpha_id}</code></a> : "—"}</td><td /></tr>
              </tbody></table>
            {pyRes?.ok && fxRes?.ok ? <div className="mut" style={{ fontSize: 12, marginTop: 6 }}>
              A faithful translation should land close to the baseline — a large Sharpe/turnover gap usually means a NaN, rank-tie or decay-window difference to fix.</div> : null}
          </>}
        </div>
      </div>
    </div>
  );
}
