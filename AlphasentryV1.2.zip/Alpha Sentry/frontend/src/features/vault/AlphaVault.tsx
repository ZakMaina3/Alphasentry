import { useEffect, useMemo, useState } from "react";
import { api } from "../../lib/api";
import { AlphaCell } from "../../lib/AlphaCell";
import { useToast } from "../../lib/toast";

interface VaultItem {
  id: number; created_at: number; updated_at: number; alpha_id: string; expression: string;
  region: string; delay: number; universe: string; neutralization: string;
  sharpe: number | null; fitness: number | null; turnover: number | null;
  status: "parked" | "reviewing" | "archived" | "submitted"; note: string; tags: string[];
  source_sim_result_id: number;
}

const num = (v: any) => (v == null ? "—" : (+v).toFixed(3));
const STATUSES: VaultItem["status"][] = ["parked", "reviewing", "archived", "submitted"];

// Alpha Vault: a parking spot for alphas worth keeping but not submitted yet — separate
// from the raw Results log, with your own notes/tags/status, and a Submit action that
// reuses the exact same code path Results & Analytics uses.
export function AlphaVault() {
  const { toast, toastErr } = useToast();
  const [items, setItems] = useState<VaultItem[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [q, setQ] = useState("");
  const [sel, setSel] = useState<VaultItem | null>(null);
  const [noteDraft, setNoteDraft] = useState("");
  const [tagsDraft, setTagsDraft] = useState("");
  const [busy, setBusy] = useState("");

  const load = async () => {
    const d = await api.get<any>(`/vault${statusFilter ? `?status=${statusFilter}` : ""}`);
    if (d.error) return toastErr(d.error);
    setItems(d.items || []);
  };
  useEffect(() => { load(); }, [statusFilter]);

  useEffect(() => {
    setNoteDraft(sel?.note || "");
    setTagsDraft((sel?.tags || []).join(", "));
  }, [sel?.id]);

  const view = useMemo(() => items.filter((it) =>
    !q || it.expression.toLowerCase().includes(q.toLowerCase()) ||
    it.alpha_id.toLowerCase().includes(q.toLowerCase()) ||
    (it.tags || []).some((t) => t.toLowerCase().includes(q.toLowerCase()))), [items, q]);

  async function saveNote() {
    if (!sel) return;
    setBusy("save");
    const tags = tagsDraft.split(",").map((t) => t.trim()).filter(Boolean);
    const d = await api.patch<any>(`/vault/${sel.id}`, { note: noteDraft, tags });
    setBusy("");
    if (d.error) return toastErr(d.error);
    toast("Saved.", "ok");
    setSel(d); load();
  }

  async function setStatus(it: VaultItem, status: VaultItem["status"]) {
    const d = await api.patch<any>(`/vault/${it.id}`, { status });
    if (d.error) return toastErr(d.error);
    if (sel?.id === it.id) setSel(d);
    load();
  }

  async function remove(it: VaultItem) {
    if (!window.confirm(`Remove this vault entry? (${it.alpha_id || it.expression.slice(0, 40)})`)) return;
    const d = await api.delete<any>(`/vault/${it.id}`);
    if (d.error) return toastErr(d.error);
    if (sel?.id === it.id) setSel(null);
    load();
  }

  async function submit(it: VaultItem) {
    if (!it.alpha_id) return toast("This entry has no alpha id — it can't be submitted.", "warn");
    if (!window.confirm(`Submit ${it.alpha_id} to BRAIN? This cannot be undone.`)) return;
    setBusy(`submit-${it.id}`);
    const d = await api.post<any>(`/vault/${it.id}/submit`, {});
    setBusy("");
    if (d.error) return toastErr(d.error);
    if (!d.submitted) return toastErr("BRAIN did not confirm the submission.");
    toast(`Submitted ${it.alpha_id}.`, "ok");
    load();
  }

  return (
    <div className="dx-split" style={{ flex: 1, minHeight: 0 }}>
      <div className="panel" style={{ padding: 14 }}>
        <div className="dx-head"><b>Alpha Vault</b><span className="mut">{items.length}</span>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} style={{ marginLeft: "auto" }}>
            <option value="">all statuses</option>
            {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
          <button className="btn ghost sm" onClick={load}>Refresh</button>
        </div>
        <input placeholder="filter by expression / alpha id / tag" value={q} onChange={(e) => setQ(e.target.value)} style={{ marginBottom: 8 }} />
        <div className="panel-scroll">
          {!view.length ? <div className="empty">Nothing parked yet — add results from Results & Analytics (🗄).</div> :
            <table><thead><tr><th>alpha</th><th>Sharpe</th><th>Fit</th><th>status</th><th>tags</th><th></th></tr></thead>
              <tbody>{view.map((it) => (
                <tr key={it.id} onClick={() => setSel(it)}
                  style={{ cursor: "pointer", background: sel?.id === it.id ? "var(--surface-2)" : undefined }}>
                  <td>{it.alpha_id ? <code>{it.alpha_id}</code> : <span className="mut">no id</span>}
                    <div style={{ fontSize: 11, marginTop: 2 }}><AlphaCell expr={it.expression} max={36} /></div></td>
                  <td>{num(it.sharpe)}</td><td>{num(it.fitness)}</td>
                  <td>
                    <select value={it.status} onClick={(e) => e.stopPropagation()}
                      onChange={(e) => setStatus(it, e.target.value as VaultItem["status"])}>
                      {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select></td>
                  <td style={{ fontSize: 11 }}>{(it.tags || []).map((t) => <span key={t} className="badge" style={{ marginRight: 3 }}>{t}</span>)}</td>
                  <td style={{ whiteSpace: "nowrap" }} onClick={(e) => e.stopPropagation()}>
                    {it.alpha_id && it.status !== "submitted" ? (
                      <button className="btn ghost sm" onClick={() => submit(it)} disabled={!!busy}>
                        {busy === `submit-${it.id}` ? <span className="spin" /> : "Submit"}</button>
                    ) : null}
                    <button className="btn ghost sm" style={{ marginLeft: 4 }} onClick={() => remove(it)}>✕</button>
                  </td>
                </tr>
              ))}</tbody></table>}
        </div>
      </div>

      <div className="panel" style={{ padding: 14, minWidth: 360 }}>
        {!sel ? <div className="empty">Select a vault entry to view/edit its note and tags.</div> : (
          <>
            <div className="dx-head"><b>{sel.alpha_id || "unsubmitted"}</b>
              <span className="mut" style={{ marginLeft: 8 }}>{sel.region} · delay {sel.delay} · {sel.universe}</span></div>
            <div style={{ fontSize: 12, margin: "8px 0" }}><AlphaCell expr={sel.expression} max={200} /></div>
            <label className="fld"><span>Note</span>
              <textarea rows={6} value={noteDraft} onChange={(e) => setNoteDraft(e.target.value)}
                placeholder="Why you're keeping this, what to try next, correlation concerns, etc." /></label>
            <label className="fld" style={{ marginTop: 8 }}><span>Tags (comma-separated)</span>
              <input value={tagsDraft} onChange={(e) => setTagsDraft(e.target.value)} placeholder="momentum, retry-decay, needs-negation" /></label>
            <button className="btn sm" style={{ marginTop: 10 }} onClick={saveNote} disabled={busy === "save"}>
              {busy === "save" ? <span className="spin" /> : "Save note & tags"}</button>
          </>
        )}
      </div>
    </div>
  );
}
