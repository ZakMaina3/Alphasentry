import { useState } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { useResearch } from "../../lib/store";
import { useTheme } from "../../lib/useTheme";
import { icon } from "../../lib/icons";
import { HeaderJobs } from "../HeaderJobs";
import { HEADER_NAV_PATHS, type NavGroup, type NavItem } from "../types";

export function Header({ nav }: { nav: NavGroup[] }) {
  const { pathname } = useLocation();
  const nav2 = useNavigate();
  const { ctx } = useResearch();
  const { theme, setTheme } = useTheme();

  // Primary pipeline promoted to the header rail, ordered as HEADER_NAV_PATHS lists them.
  const byPath = new Map(nav.flatMap((g) => g.items).map((it) => [it.path, it]));
  const rail: NavItem[] = HEADER_NAV_PATHS.map((p) => byPath.get(p)).filter(Boolean) as NavItem[];

  // Auto-update-from-upstream is disabled in this fork (updated manually by its owner only).
  const [upd] = useState<{ available?: boolean; latest?: string }>({});

  return (
    <header className="header">
      <nav className="hnav" aria-label="Primary">
        {rail.map((it) => (
          <NavLink key={it.id} to={it.path} end={it.path === "/"} title={it.label}
            className={({ isActive }) => "hnav-link" + (isActive ? " active" : "")}>
            <span className="hnav-ico">{icon(it.icon)}</span>
            <span className="hnav-lbl"><span>{it.label}</span></span>
          </NavLink>
        ))}
      </nav>
      <div className="spacer" />
      {/* Live research context (edit it on the Data Explorer). */}
      <span className="ctx-chip">{ctx.region} · {ctx.universe} · <b>D{ctx.delay}</b> · {ctx.instrument}</span>
      {upd.available ? (
        <button className="ctx-chip" onClick={() => nav2("/settings")}
          title="A new version is available — open Settings → Updates to install it"
          style={{ cursor: "pointer", borderColor: "var(--acc)", color: "var(--acc)" }}>
          ⬆ Update {upd.latest}
        </button>
      ) : null}
      <HeaderJobs />
      <button className="icon-btn" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
        title={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"} aria-label="Toggle theme">
        {theme === "dark" ?
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></svg> :
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" /></svg>}
      </button>
      <button className={"icon-btn" + (pathname === "/settings" ? " active" : "")} onClick={() => nav2("/settings")}
        title="Settings" aria-label="Settings">
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="3" />
          <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" /></svg>
      </button>
    </header>
  );
}
