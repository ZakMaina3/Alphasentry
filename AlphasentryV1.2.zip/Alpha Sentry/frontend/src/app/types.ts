export interface NavItem {
  id: string;
  path: string;
  label: string;
  icon: string;
  ready: boolean;
}
export interface NavGroup {
  group: string;
  items: NavItem[];
}

// The core workflow pipeline promoted to the header's quick-nav rail (icon buttons whose label
// slides open on hover / when active). Everything else stays in the sidebar — Header and Sidebar
// import this so they partition the same nav identically. Order here is the rail's left→right order.
export const HEADER_NAV_PATHS: string[] = [
  "/", "/data", "/generate", "/templates", "/simulate", "/results", "/portfolio",
];
