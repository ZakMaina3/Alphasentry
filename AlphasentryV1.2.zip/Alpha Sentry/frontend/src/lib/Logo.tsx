// Alpha Sentry logo family: one shield/hex language, brand amber gradient. Source of truth for the PNG/SVG files: tools/make_logos.py.
const SHIELD = "M16 2.8 L27.2 6.8 V15 C27.2 21.8 22.4 26.8 16 29.4 C9.6 26.8 4.8 21.8 4.8 15 V6.8 Z";
type P = { size?: number };

function Frame({ size, label, id, children }: { size: number; label: string; id: string; children: React.ReactNode }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" aria-label={label}>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="var(--acc-2)" /><stop offset="1" stopColor="var(--acc)" /></linearGradient>
      </defs>
      <rect width="32" height="32" rx="8" fill="var(--acc-fg)" />
      {children}
    </svg>
  );
}
const ink = { fill: "none", stroke: "var(--acc-fg)", strokeLinecap: "round", strokeLinejoin: "round" } as const;

export function LogoMark({ size = 26 }: P) {   // Alpha Sentry
  return <Frame size={size} label="Alpha Sentry" id="as-g"><path d={SHIELD} fill="url(#as-g)" />
    <path d="M9.5 20 L14 14 L17.5 17.2 L22.6 10.4" {...ink} strokeWidth={2.3} /><circle cx="22.6" cy="10.4" r="2" fill="var(--acc-fg)" /></Frame>;
}
export function AutosentryMark({ size = 22 }: P) {
  return <Frame size={size} label="Autosentry" id="au-g"><path d={SHIELD} fill="url(#au-g)" />
    <path d="M21.2 13.2 A6 6 0 1 0 22 17.6" {...ink} strokeWidth={2.2} /><path d="M18.3 12.6 L21.6 13.2 L22.6 9.9" {...ink} strokeWidth={2.2} />
    <circle cx="16" cy="16" r="1.9" fill="var(--acc-fg)" /></Frame>;
}
export function SupersentryMark({ size = 22 }: P) {
  return <Frame size={size} label="Supersentry" id="su-g"><path d={SHIELD} fill="url(#su-g)" />
    <path d="M10.8 20 L16 15.2 L21.2 20" {...ink} strokeWidth={2.3} /><path d="M10.8 15.4 L16 10.6 L21.2 15.4" {...ink} strokeWidth={2.3} opacity={0.6} />
    <circle cx="16" cy="7.4" r="1.2" fill="var(--acc-fg)" /></Frame>;
}
export function SentryEngineMark({ size = 22 }: P) {
  return <Frame size={size} label="SentryEngine" id="se-g"><path d="M16 2.6 L27.6 9.3 V22.7 L16 29.4 L4.4 22.7 V9.3 Z" fill="url(#se-g)" />
    <path d="M16 8.8 L21.6 10.9 V16 C21.6 19.6 19.2 22 16 23.4 C12.8 22 10.4 19.6 10.4 16 V10.9 Z" {...ink} strokeWidth={2} /><circle cx="16" cy="15.6" r="1.9" fill="var(--acc-fg)" /></Frame>;
}

export function Wordmark() {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 9 }}>
      <img src="/alpha-sentry.png" alt="Alpha Sentry" width={28} height={28}
        style={{ height: 28, width: 28, objectFit: "contain", borderRadius: 7, display: "block", flex: "0 0 auto" }} />
      <span style={{
        fontFamily: "'Bahnschrift', 'Century Gothic', 'Trebuchet MS', 'Segoe UI Semibold', system-ui, sans-serif",
        fontVariantCaps: "all-small-caps", fontWeight: 800, fontSize: 22, letterSpacing: "1.4px", lineHeight: "28px",
      }}>Alpha <span style={{ color: "var(--acc)" }}>Sentry</span></span>
    </span>
  );
}
