# ============================================================================
#  Alpha Sentry - desktop launcher (Windows)
#
#  What it does when you double-click the "Alpha Sentry" shortcut:
#    1. If the app is not running: makes sure Python / Node / packages are installed
#       (it hands that to  run.bat --setup-only , which shows a normal console window ONLY when
#       something actually has to be installed).
#    2. Builds the frontend once (frontend\dist) - and again only when the source changed.
#    3. Starts the backend HIDDEN (no console windows, no file-watching reloader, one port: 8766).
#    4. Opens the app in its own window (Edge/Chrome "app mode": no tabs, no address bar).
#
#  Clicking the shortcut again while it runs just opens another window. Closing the window does
#  NOT stop the backend (an Autosentry keeps running); use the "Stop Alpha Sentry" shortcut for that.
#  Logs: logs\launcher.log, logs\backend.log, logs\backend.err.log, logs\build.log
# ============================================================================
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root
$Port = 8766
$Url  = "http://127.0.0.1:$Port"
$LogDir = Join-Path $Root 'logs'
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$LogFile = Join-Path $LogDir 'launcher.log'
$PidFile = Join-Path $Root '.ace.pid'

# A freshly installed Python/Node only updates PATH in the registry - reload it into this process.
$env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User') + ';' + $env:Path
$env:PYTHONUNBUFFERED = '1'

# ---- tiny helpers ----------------------------------------------------------------------
$script:Splash = $null
try { Add-Type -AssemblyName System.Windows.Forms, System.Drawing } catch { }

function Log([string]$m) {
    try { Add-Content -Path $LogFile -Value ("{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m) } catch { }
}

function Pump([int]$ms) {            # keep the splash window responsive while waiting
    $end = (Get-Date).AddMilliseconds($ms)
    while ((Get-Date) -lt $end) {
        try { [System.Windows.Forms.Application]::DoEvents() } catch { }
        Start-Sleep -Milliseconds 50
    }
}

function New-Splash {
    try {
        $f = New-Object System.Windows.Forms.Form
        $f.FormBorderStyle = 'None'; $f.StartPosition = 'CenterScreen'; $f.TopMost = $true; $f.ShowInTaskbar = $false
        $f.Size = New-Object System.Drawing.Size(420, 110)
        $f.BackColor = [System.Drawing.Color]::FromArgb(24, 26, 32)
        $l = New-Object System.Windows.Forms.Label
        $l.Dock = 'Fill'; $l.TextAlign = 'MiddleCenter'; $l.ForeColor = [System.Drawing.Color]::White
        $l.Font = New-Object System.Drawing.Font('Segoe UI', 12)
        $f.Controls.Add($l)
        $f.Show(); [System.Windows.Forms.Application]::DoEvents()
        return @{ Form = $f; Label = $l }
    } catch { return $null }
}

function Set-Status([string]$t) {
    Log $t
    if ($script:Splash) { try { $script:Splash.Label.Text = $t; [System.Windows.Forms.Application]::DoEvents() } catch { } }
}

function Fail([string]$msg) {
    Log "FAILED: $msg"
    if ($script:Splash) { try { $script:Splash.Form.Close() } catch { } }
    try { [System.Windows.Forms.MessageBox]::Show($msg + "`r`n`r`nLogs: $LogDir", 'Alpha Sentry', 'OK', 'Error') | Out-Null } catch { }
    exit 1
}

function Test-Backend {
    try { Invoke-WebRequest -UseBasicParsing "$Url/api" -TimeoutSec 2 | Out-Null; return $true } catch { return $false }
}

# Run a process and wait for it WITHOUT freezing the splash window. Returns the exit code.
function Wait-Proc($proc) {
    $null = $proc.Handle              # cache the handle so ExitCode is reliable in Windows PowerShell 5.1
    while (-not $proc.HasExited) { Pump 200 }
    return $proc.ExitCode
}

function Dist-Stale {
    $idx = Join-Path $Root 'frontend\dist\index.html'
    if (-not (Test-Path $idx)) { return $true }
    $t = (Get-Item $idx).LastWriteTime
    foreach ($p in @('frontend\src', 'frontend\public', 'frontend\index.html', 'frontend\package.json',
                     'frontend\vite.config.ts', 'frontend\tsconfig.json')) {
        $full = Join-Path $Root $p
        if (-not (Test-Path $full)) { continue }
        $newer = Get-ChildItem -Path $full -Recurse -File -ErrorAction SilentlyContinue |
                 Where-Object { $_.LastWriteTime -gt $t } | Select-Object -First 1
        if ($newer) { return $true }
    }
    return $false
}

function Needs-Setup {
    if (-not (Test-Path (Join-Path $Root 'backend\.venv\Scripts\python.exe'))) { return $true }
    if (-not (Test-Path (Join-Path $Root 'frontend\node_modules\.bin\vite.cmd'))) { return $true }
    # requirements.txt / package.json unchanged since the last install?  (run.bat stores copies)
    $pairs = @(@('backend\requirements.txt', 'backend\.venv\requirements.lock'),
               @('frontend\package.json', 'frontend\node_modules\.ace_pkg.lock'))
    foreach ($pr in $pairs) {
        $a = Join-Path $Root $pr[0]; $b = Join-Path $Root $pr[1]
        if (-not (Test-Path $b)) { return $true }
        if ((Get-FileHash $a).Hash -ne (Get-FileHash $b).Hash) { return $true }
    }
    return $false
}

function Find-Browser {
    $cands = @()
    foreach ($k in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe',
                     'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe',
                     'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe',
                     'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe')) {
        try { $v = (Get-ItemProperty -Path $k -ErrorAction Stop).'(default)'; if ($v) { $cands += $v } } catch { }
    }
    $cands += @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
                "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
                "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
                "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
                "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")
    foreach ($c in $cands) { if ($c -and (Test-Path $c)) { return $c } }
    return $null
}

function Open-Window {
    $b = Find-Browser
    if ($b) {
        Log "opening app window with $b"
        Start-Process -FilePath $b -ArgumentList "--app=$Url"
    } else {
        Log 'no Edge/Chrome found - opening the default browser'
        Start-Process $Url
    }
}

# ---- one launcher at a time ------------------------------------------------------------
$created = $false
$mutex = New-Object System.Threading.Mutex($true, 'Local\ACEStudioLauncher', [ref]$created)
if (-not $created) { exit 0 }

try {
    Log '--- launch ---'
    $script:Splash = New-Splash
    Set-Status 'Starting Alpha Sentry...'

    $alreadyUp = Test-Backend
    if ($alreadyUp) {
        Log 'backend already running'
        if (-not (Test-Path (Join-Path $Root 'frontend\dist\index.html'))) {
            Fail ("Alpha Sentry's backend is already running without a built frontend (it was probably started with run.bat).`r`n" +
                  "Close its 'Alpha Sentry backend' window (or use the Stop Alpha Sentry shortcut) and launch again.")
        }
    } else {
        # ---- 1. install / verify ----
        if (Needs-Setup) {
            Set-Status 'First-time setup - a setup window will open...'
            if ($script:Splash) { $script:Splash.Form.Hide() }
            $p = Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', '""run.bat" --setup-only"' -WorkingDirectory $Root -PassThru
            $code = Wait-Proc $p
            if ($script:Splash) { $script:Splash.Form.Show() }
            if ($code -ne 0) { Fail 'Setup did not finish. Open run.bat once to see what went wrong.' }
        }

        # ---- 2. build the frontend (first run, or after the source changed) ----
        if (Dist-Stale) {
            Set-Status 'Building the interface (about a minute, first time only)...'
            $buildLog = Join-Path $LogDir 'build.log'
            $fe = Join-Path $Root 'frontend'
            $p = Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', ('npm run build > "' + $buildLog + '" 2>&1') `
                               -WorkingDirectory $fe -WindowStyle Hidden -PassThru
            $code = Wait-Proc $p
            if ($code -ne 0) {
                # "npm run build" also type-checks (tsc); fall back to a plain vite build if only types failed.
                Log "npm run build failed ($code) - retrying with vite build only"
                $p = Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', ('npx vite build >> "' + $buildLog + '" 2>&1') `
                                   -WorkingDirectory $fe -WindowStyle Hidden -PassThru
                $code = Wait-Proc $p
            }
            if ($code -ne 0 -or -not (Test-Path (Join-Path $fe 'dist\index.html'))) {
                Fail 'Could not build the interface. See logs\build.log.'
            }
        }

        # ---- 3. start the backend, hidden ----
        Set-Status 'Starting the backend...'
        $py = Join-Path $Root 'backend\.venv\Scripts\python.exe'
        foreach ($n in @('backend.log', 'backend.err.log')) {          # keep logs from growing forever
            $f = Join-Path $LogDir $n
            if ((Test-Path $f) -and ((Get-Item $f).Length -gt 5MB)) { Move-Item -Force $f ($f + '.old') }
        }
        $proc = Start-Process -FilePath $py -WorkingDirectory $Root -WindowStyle Hidden -PassThru `
                  -RedirectStandardOutput (Join-Path $LogDir 'backend.log') `
                  -RedirectStandardError  (Join-Path $LogDir 'backend.err.log') `
                  -ArgumentList '-m', 'uvicorn', 'app.main:app', '--app-dir', 'backend',
                                '--host', '127.0.0.1', '--port', "$Port"
        Set-Content -Path $PidFile -Value $proc.Id
        Log "backend started, pid $($proc.Id)"

        $deadline = (Get-Date).AddSeconds(120)
        $up = $false
        while ((Get-Date) -lt $deadline) {
            if ($proc.HasExited) { Fail 'The backend stopped right after starting. See logs\backend.err.log.' }
            if (Test-Backend) { $up = $true; break }
            Pump 700
        }
        if (-not $up) { Fail 'The backend did not answer within 2 minutes. See logs\backend.err.log.' }
    }

    # ---- 4. open the window ----
    Set-Status 'Opening Alpha Sentry...'
    Open-Window
    Pump 1200
    if ($script:Splash) { try { $script:Splash.Form.Close() } catch { } }
    Log 'done'
} catch {
    Fail ("Unexpected error: " + $_.Exception.Message)
} finally {
    try { $mutex.ReleaseMutex() } catch { }
}
