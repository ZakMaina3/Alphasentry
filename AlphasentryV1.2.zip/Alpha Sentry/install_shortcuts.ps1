# Creates the "Alpha Sentry" and "Stop Alpha Sentry" shortcuts on your Desktop (and "Alpha Sentry" in the
# Start menu so you can also press Win and type "Alpha Sentry"). Safe to run again; re-run it if you move the folder.
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Icon = Join-Path $Root 'build\alpha-sentry.ico'
$sh = New-Object -ComObject WScript.Shell

function Make-Link([string]$dir, [string]$name, [string]$vbs, [string]$desc) {
    $lnk = $sh.CreateShortcut((Join-Path $dir ($name + '.lnk')))
    $lnk.TargetPath       = Join-Path $env:WINDIR 'System32\wscript.exe'
    $lnk.Arguments        = '"' + (Join-Path $Root $vbs) + '"'
    $lnk.WorkingDirectory = $Root
    $lnk.IconLocation     = $Icon + ',0'
    $lnk.Description      = $desc
    $lnk.Save()
    Write-Host ("  created: " + (Join-Path $dir ($name + '.lnk')))
}

$desktop = [Environment]::GetFolderPath('Desktop')        # follows OneDrive-redirected desktops
$start   = [Environment]::GetFolderPath('Programs')
Make-Link $desktop 'Alpha Sentry'      'Alpha Sentry.vbs'      'Open Alpha Sentry (starts it in the background if needed)'
Make-Link $desktop 'Stop Alpha Sentry' 'Stop Alpha Sentry.vbs' 'Stop the Alpha Sentry background backend'
Make-Link $start   'Alpha Sentry'      'Alpha Sentry.vbs'      'Open Alpha Sentry'
Write-Host ''
Write-Host 'Done. Double-click "Alpha Sentry" on your Desktop.'
