# HANDOFF — continue the SentryEngine → Alpha Sentry port in a NEW chat

## 1. Start the new chat like this
Upload these 3 files, then paste the prompt below.
- `ACE-Studio-harness-port-checkpoint.zip`  (this project, the work so far — it contains this file)
- `alpha-harness-main.zip`                   (the SOURCE being ported; needed for everything still to do)
- `Alpha_Harness_to_ACE_Studio_Blueprint.docx` (the original plan)

> **Prompt to paste:**
> I'm continuing a port of SentryEngine into my Alpha Sentry fork. Unzip `ACE-Studio-harness-port-checkpoint.zip`, read
> `HANDOFF.md` then `PORT_STATUS.md` inside it, and continue from "NEXT". Rules: additive only (existing Alpha Sentry functions
> unchanged), every new lab is preview + queue-only with NO submit path, flags default OFF, plain `sqlite3` (no SQLAlchemy)
> in the harness, tests first (`python tests/run_all.py` must stay green), and checkpoint a fresh zip + update
> `PORT_STATUS.md` after every phase so I can resume if my limit runs out. Don't build anything until I type "continue".
> If I've already tested the build, my results are: <paste what worked / what failed / any log lines>.

## 2. State in one paragraph
Built and unit-tested (153 tests incl. D1-D4 planning core; run offline; includes the Optuna-free optimizer layer, template language and task scheduler — endpoints for tasks exist but have no UI yet): geo gate + log forwarding removed; batch engine (packer, dedup, shared slot lease,
crash-safe journal/orphan adoption, dry-run); six labs (Relocate, Repair, Harden, Harvest, Diversify, Pair) plus Template sweep, Power Pool, Deepen and Evolution (fragment B), plus the LLM adapter, daily budget and Invent lab (fragment C); returns vault +
mixing + mix queueing; scorer that writes finished lab alphas into Alpha Sentry's Results and feeds Alpha Sentry's operator/template learning;
skeleton ledger; yield book; Autosentry routing (flag-gated, regular Autosentry only); sqlite3 gateway replacing SQLAlchemy;
a "SentryEngine" screen (Control / Labs / Mixing). **Never run against real BRAIN or a real Alpha Sentry DB** — that is the first thing to do.

## 3. What remains — see FRAGMENTS.md (small, independent pieces with ids, sizes and test gates)
Tell the new chat: "Do fragment A1 from FRAGMENTS.md" (or any id). The older summary below is kept for context.

### Older summary
A. **User testing results** (no code): follow `HARNESS_TESTING.md`; fix whatever real BRAIN / the real DB shows. Highest value.
B. **(DONE: optimizer interface + built-in samplers + task scheduler; Optuna optional)** Original note: needs an environment where `pip install optuna` works (check the numpy 1.26.4 pin first). Port from
   `alpha-harness-main/backend/src/alpha_harness/`: `labs/tasks.py` (scheduler: start_waiting/advance/ask_points over Study/Trial),
   `optimize/{study,samplers,objectives}.py` (~70 KB), `labs/registry.py`, then labs `search.py` → `template.py` → `ga.py`
   (Evolution) → `power_pool.py` (19 KB) → `deepen.py` (builds a YAML template; `yaml` is available). Plan: new tables
   `harness_task`/`harness_trial` in `harness/store.py` DDL; a sync scheduler thread that asks Optuna for points, enqueues them on
   the existing tracker/engine (so slots, dedup, scoring, yield all come for free), and feeds scored results back as trial values.
C. **Planning**: `plan/{day,dispatch,advisor,pm}.py` + `llm/{budget,keys}.py`. They orchestrate the Optuna labs, so do them after B.
   Alpha Sentry has its own LLM key handling (look at `backend/app/modules/research` and `prompts`) — adapt to it rather than porting AH's
   `llm/service.py` + vault. Flag: `harness_planning` (already exists; currently only gates the skeleton ledger).
D. **Invent lab** (`labs/invent.py`, 24 KB, LLM-driven) — needs the LLM adapter from C.
E. **Frontend**: tabs for Tasks/queue list, skeleton ledger view, plan/budget; run a real `npm run build` (never done in the
   sandbox: no node_modules). The existing screen was only type-checked against stub types.
F. **Optional**: put Supersentry / SuperAlpha (`backend/app/super/service.py` ~line 405, type SUPER, single sims) on the shared
   slot lease only (no batching). Not routed today.

## 4. Architecture rules (keep following them)
- Everything lives in `backend/app/harness/` + modules `backend/app/modules/harness_engine`, `harness_vault` (registered in
  `modules/__init__.py` ENABLED) + `frontend/src/features/harness/`. Existing Alpha Sentry code is touched in exactly these places:
  `simulation/service.py` (+9 lines: routing hook in `run_simulation`), `autopilot/service.py` (+2 lines: `engine_routing()`), `super/service.py` (+~9 lines: lease routing in `run_simulation`), `superpilot/service.py` (+2 lines: `engine_routing()`),
  `modules/__init__.py` (2 names), `modules/meta/__init__.py` (nav entry), `app/App.tsx` (route), `Header.tsx` + build/script files
  (support removal), `_ace_entry.py` (geo removal). Verified with `diff -w` against the original upload.
- DB: plain `sqlite3` via `harness/store.py` (`Store`, `default_store()`, `ensure_tables`, `check_ace_schema`). Add new tables in the
  `DDL` list there. Alpha Sentry's own tables (`sim_results`, `datasets`, `fields`) are read; the scorer inserts into `sim_results` using
  only columns that exist. No SQLAlchemy anywhere in the harness.
- ONE payload builder: `harness/payload.py` (`Scope`, `make_settings`, `make_payload`). ONE alpha query: `labs/ace_sources.scoped_alphas`.
  `brain_port.py` is the ONLY place `ace_lib` is touched (lazy imports). Shared API bits in `api_common.py` (`ScopeBase`, `need_flag`).
- Lab pattern: pure logic module (data injected as callables, so it's unit-testable) + a function in `ace_sources.py` that supplies Alpha Sentry
  data + `/<lab>/preview` (free) and `/<lab>/run` (queue only) endpoints + a tab in `Harness.tsx`. Results flow:
  tracker queue → BatchEngine → BRAIN → scorer → `sim_results` (tag `harness`) → Alpha Sentry screens + yield book.
- Flags (`harness/flags.py`, file `data/harness/flags.json`, all default OFF): `harness_engine`, `harness_vault`, `harness_planning`,
  `autopilot_via_engine`.
- Port AH code with: `async`→sync, `structlog`→`logging`, Python-3.14 `except A, B:` → `except (A, B):`, `Tuple4`/`SimulationRequest` →
  `Scope` + dict payloads, DuckDB catalog → `ace_sources` (Alpha Sentry's knowledge DB; coverage is per DATASET, no universe per field).
- Every behaviour has a test in `tests/test_harness_engine.py`; `tests/ace_db.py` builds a throwaway DB shaped like Alpha Sentry's tables.

## 5. Sandbox limits to expect (the previous chat had these)
Python 3.12, no network, no SQLAlchemy/FastAPI/pydantic/optuna/node_modules. So: FastAPI module endpoints are compile-checked only; the
React screen was type-checked with stub types (`tsc` + a stub for `react`); anything touching real BRAIN is untested. `python
tests/run_all.py` needs only the standard library + pandas.

## 6. Known gaps / weaker spots
- Alpha Sentry has no per-field coverage or per-universe fields → Harvest/Pair/Relocate use dataset coverage and region+delay.
- "Submittable" = passed Alpha Sentry's gate (`passed_gate`), a proxy for AH's all-checks rule (ledger + yield book use it).
- Dry-run records become `dryrun` and are NOT counted as duplicates (so they can be re-queued).
- Autosentry's routed records are `external` (counted as duplicates + in yields as lab "autopilot"); a crash is rescued only when the
  harness engine is started (orphan adoption), and rescued alphas are scored with tag `harness`.

## 7. File map (lines)
```
backend/app/harness/
  __init__ 7 · api_common 26 · autopilot_route 174 · brain_port 116 · flags 52 · payload 40 · scoring 139 · store 125
  engine/   batch 194 · dedup 29 · match 32 · packer 210 · slots 71 · tracker 156
  harvest/  patterns 106 · seeds 113
  labs/     ace_sources 251 · checks 43 · diversify 46 · exprtools 34 · harden 147 · pair 238 · relocate 96 · repair 507
  plan/     skeletons 88 · yields 98
  vault/    ace_vault 100 · combine 426 · mixing 418 · mixrun 68 · store 63
backend/app/modules/harness_engine/__init__ 358 · harness_vault/__init__ 131
frontend/src/features/harness/Harness.tsx 339 · harness.css 12
tests/ test_harness_engine.py 835 · ace_db.py 59 · run_all.py 44
```
