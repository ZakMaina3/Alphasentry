"""Make (or refresh) the seed that ships with every version of Alpha Sentry.

    python tools/make_seed.py                      # from your live ACE database (data/ace_studio_v2.db)
    python tools/make_seed.py path/to/ace_studio_v2.db

Writes seed/ace_studio_v2.seed.db: only the public catalogue (datasets, fields, operator reference), never anyone's results, vault alphas, library, lessons, tasks, flags or keys
(add --with-history to include past results and vault alphas for private use). The source is opened read-only. Run it before zipping a new version, and
every ACE install that unpacks that version gets your history merged in (insert-only, once per seed file; see backend/app/harness/seed.py).
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

from app.harness import seed  # noqa: E402


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    src = Path(args[0]) if args else ROOT / "data" / "ace_studio_v2.db"
    if not src.exists():
        print(f"No database at {src}. Pass the path to your ace_studio_v2.db.")
        return 1
    out = ROOT / "seed" / seed.SEED_NAME
    counts = seed.build_seed(src, out, None if "--with-history" in sys.argv else seed.SHIPPED)   # default: public catalogue only
    print(f"Wrote {out} ({out.stat().st_size // 1024} KB, sha256 {seed.sha_of(out)[:12]})")
    for t, n in counts.items():
        print(f"  {t:22s} {n:6d} rows")
    return 0


if __name__ == "__main__":
    sys.exit(main())
