"""Draws the Alpha Sentry logo family (SVG -> PNG/ICO). Run: python tools/make_logos.py  (needs playwright+chromium and Pillow).
Writes frontend/public/{alpha-sentry,autosentry,supersentry,sentryengine}.{svg,png} and build/alpha-sentry.ico."""
import asyncio, io, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
A, A2, FG = "#5fb3b3", "#8fcfcf", "#0f1a1a"
SHIELD = "M16 2.8 L27.2 6.8 V15 C27.2 21.8 22.4 26.8 16 29.4 C9.6 26.8 4.8 21.8 4.8 15 V6.8 Z"

def svg(body: str, bg: bool = True) -> str:
    grad = f'<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{A2}"/><stop offset="1" stop-color="{A}"/></linearGradient></defs>'
    plate = f'<rect width="32" height="32" rx="8" fill="#0f1a1a"/>' if bg else ""
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="256" height="256">{grad}{plate}{body}</svg>'

MARKS = {
    # shield + rising alpha curve ending in a "sighted" dot
    "alpha-sentry": f'<path d="{SHIELD}" fill="url(#g)"/><path d="M9.5 20 L14 14 L17.5 17.2 L22.6 10.4" fill="none" stroke="{FG}" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"/><circle cx="22.6" cy="10.4" r="2" fill="{FG}"/>',
    # shield + closed loop (runs by itself) around a core
    "autosentry": f'<path d="{SHIELD}" fill="url(#g)"/><path d="M21.2 13.2 A6 6 0 1 0 22 17.6" fill="none" stroke="{FG}" stroke-width="2.2" stroke-linecap="round"/><path d="M18.3 12.6 L21.6 13.2 L22.6 9.9" fill="none" stroke="{FG}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="16" cy="16" r="1.9" fill="{FG}"/>',
    # shield + double chevron up + crown star
    "supersentry": f'<path d="{SHIELD}" fill="url(#g)"/><path d="M10.8 20 L16 15.2 L21.2 20" fill="none" stroke="{FG}" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M10.8 15.4 L16 10.6 L21.2 15.4" fill="none" stroke="{FG}" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round" opacity=".6"/><circle cx="16" cy="7.4" r="1.2" fill="{FG}"/>',
    # hexagon engine block with a shield core and three cooling ticks
    "sentryengine": f'<path d="M16 2.6 L27.6 9.3 V22.7 L16 29.4 L4.4 22.7 V9.3 Z" fill="url(#g)"/><path d="M16 8.8 L21.6 10.9 V16 C21.6 19.6 19.2 22 16 23.4 C12.8 22 10.4 19.6 10.4 16 V10.9 Z" fill="none" stroke="{FG}" stroke-width="2" stroke-linejoin="round"/><circle cx="16" cy="15.6" r="1.9" fill="{FG}"/>',
}

async def main():
    from playwright.async_api import async_playwright
    pub = ROOT / "frontend" / "public"; pub.mkdir(parents=True, exist_ok=True)
    pngs = {}
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={"width": 256, "height": 256}, device_scale_factor=1)
        for name, body in MARKS.items():
            s = svg(body)
            (pub / f"{name}.svg").write_text(s, encoding="utf-8")
            await pg.set_content(f'<body style="margin:0;background:transparent">{s}</body>')
            pngs[name] = await pg.screenshot(omit_background=True, clip={"x": 0, "y": 0, "width": 256, "height": 256})
            (pub / f"{name}.png").write_bytes(pngs[name])
        await b.close()
    from PIL import Image
    im = Image.open(io.BytesIO(pngs["alpha-sentry"])).convert("RGBA")
    (ROOT / "build").mkdir(exist_ok=True)
    im.save(ROOT / "build" / "alpha-sentry.ico", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    print("logos written")

if __name__ == "__main__":
    asyncio.run(main())
