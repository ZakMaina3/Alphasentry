@echo off
REM  Creates the "Alpha Sentry" desktop icon (and a Stop icon). Run once; re-run if you move this folder.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_shortcuts.ps1"
if errorlevel 1 (echo [error] could not create the shortcuts.) 
pause
