"""Nuitka entry point — serves Alpha Sentry (backend API + built React frontend) from a single
standalone executable, so recipients need NOTHING installed (no Python, no Node).

Uses the app OBJECT (not the "app.main:app" import string) so there is no dynamic import for
Nuitka to miss, and no reload machinery. The built frontend lives in ./frontend/dist next to
the .exe; writable state (the SQLite db, caches, logs) is created in ./data next to the .exe.
"""

from __future__ import annotations

import os
import threading
import time
import webbrowser


def _open_browser(host: str, port: int) -> None:
    time.sleep(2.0)
    try:
        webbrowser.open(f"http://{host}:{port}/")
    except Exception:
        pass


def _set_window_title() -> None:
    """Name the console window 'Alpha Sentry' so the taskbar hover / thumbnail reads nicely."""
    try:
        if os.name == "nt":
            import ctypes
            ctypes.windll.kernel32.SetConsoleTitleW("Alpha Sentry")
    except Exception:
        pass


def main() -> None:
    _set_window_title()
    from app.main import app  # noqa: E402  — pulls in the whole backend + vendored engine
    import uvicorn

    host = os.environ.get("ACE_HOST", "127.0.0.1")
    port = int(os.environ.get("ACE_PORT", "8766"))
    print(f"\n  Alpha Sentry -> http://{host}:{port}/   (close this window to stop)\n")
    threading.Thread(target=_open_browser, args=(host, port), daemon=True).start()
    uvicorn.run(app, host=host, port=port, log_level="warning")


if __name__ == "__main__":
    main()
