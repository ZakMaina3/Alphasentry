"""BRAIN LLM-prompt submissions: prompt builder, form validation and sample-output checker.

BRAIN asks for: Prompt Name, Model, Model Version, Update Frequency, Prompt Weight (0-1, up to
2 decimals), Prompt (max 10,000 chars) and the exact Sample Prompt Output (JSON). The checker mirrors
the contract in the prompt itself: a JSON array of objects with exactly 7 non-blank fields.
"""

from __future__ import annotations

import json
import re
import time

from sqlalchemy import select

from app.db import models as M
from app.db.base import SessionLocal

MAX_PROMPT_CHARS = 10000
FIELDS = ["company_name", "ticker", "isin", "mic", "confidence_score", "investment_horizon", "return_prediction"]
_BLANK = {"", "n/a", "na", "null", "none", "nan", "-", "unknown", "tbd"}


# ── validators ───────────────────────────────────────────────────────────────────────

def isin_ok(isin: str) -> bool:
    """12 chars: 2-letter country + 9 alphanumerics + a Luhn check digit (letters -> 10..35)."""
    if not re.fullmatch(r"[A-Z]{2}[A-Z0-9]{9}[0-9]", isin or ""):
        return False
    digits = "".join(str(int(c, 36)) for c in isin)
    total = 0
    for i, ch in enumerate(reversed(digits)):
        d = int(ch)
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


def check_form(f: dict) -> dict:
    """Field-level problems for the BRAIN form → {field: message}."""
    err: dict = {}
    for k, label in (("name", "Prompt name"), ("model", "Model"), ("model_version", "Model version"),
                     ("update_frequency", "Update frequency")):
        if not str(f.get(k) or "").strip():
            err[k] = f"{label} is required."
    w = str(f.get("weight") or "").strip()
    if not w:
        err["weight"] = "Prompt weight is required."
    elif not re.fullmatch(r"(0(\.\d{1,2})?|1(\.0{1,2})?|\.\d{1,2})", w):
        err["weight"] = "Weight must be a number between 0 and 1 with up to 2 decimal places."
    p = f.get("prompt") or ""
    if not p.strip():
        err["prompt"] = "Prompt is required."
    elif len(p) > MAX_PROMPT_CHARS:
        err["prompt"] = f"Prompt is {len(p)} characters — the limit is {MAX_PROMPT_CHARS}."
    if not str(f.get("sample_output") or "").strip():
        err["sample_output"] = "Paste the exact response your prompt generated."
    return err


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def validate_output(text: str, expect_n: int = 50) -> dict:
    """Check a pasted model response against the 7-field contract."""
    errors, warnings = [], []
    raw = (text or "").strip()
    if not raw:
        return {"ok": False, "errors": [{"row": 0, "field": "", "msg": "Nothing to check."}],
                "warnings": [], "summary": {}}
    data = None
    try:
        data = json.loads(raw)
    except Exception:
        m = re.search(r"(\[.*\])", raw, re.S)
        if m:
            try:
                data = json.loads(m.group(1))
                warnings.append("The response has text around the JSON (prose or markdown fences). BRAIN needs the "
                                "exact response, so make the prompt require JSON only.")
            except Exception:
                data = None
    if data is None:
        return {"ok": False, "errors": [{"row": 0, "field": "", "msg": "Not valid JSON."}], "warnings": warnings,
                "summary": {}}
    if isinstance(data, dict):
        lists = [v for v in data.values() if isinstance(v, list)]
        if len(lists) == 1:
            warnings.append("The response is an object wrapping the list; the prompt asks for a bare JSON array.")
            data = lists[0]
        else:
            return {"ok": False, "errors": [{"row": 0, "field": "", "msg": "Expected a JSON array of instruments."}],
                    "warnings": warnings, "summary": {}}
    if not isinstance(data, list) or not data:
        return {"ok": False, "errors": [{"row": 0, "field": "", "msg": "The array is empty."}],
                "warnings": warnings, "summary": {}}

    seen_pair, seen_isin = {}, {}
    horizons, confs = set(), []
    for i, rec in enumerate(data, 1):
        def bad(field, msg):
            errors.append({"row": i, "field": field, "msg": msg})
        if not isinstance(rec, dict):
            bad("", "Not an object.")
            continue
        keys = set(rec)
        if keys - set(FIELDS):
            bad("", f"Unexpected field(s): {', '.join(sorted(keys - set(FIELDS)))}.")
        for f in FIELDS:
            if f not in rec:
                bad(f, "Missing.")
            elif rec[f] is None or (isinstance(rec[f], str) and rec[f].strip().lower() in _BLANK):
                bad(f, "Blank / null / N/A.")
        for f in ("company_name", "ticker", "isin", "mic"):
            if f in rec and rec[f] is not None and not isinstance(rec[f], str):
                bad(f, "Must be a string.")
        isin = str(rec.get("isin") or "").strip()
        if isin and isin.lower() not in _BLANK and not isin_ok(isin):
            bad("isin", f"{isin!r} is not a valid ISIN (12 characters with a correct check digit).")
        mic = str(rec.get("mic") or "").strip()
        if mic and mic.lower() not in _BLANK and not re.fullmatch(r"[A-Z0-9]{4}", mic):
            bad("mic", f"{mic!r} is not a 4-character MIC.")
        c = rec.get("confidence_score")
        if "confidence_score" in rec and c is not None:
            if not _num(c):
                bad("confidence_score", "Must be a number.")
            elif not -1.0 <= c <= 1.0:
                bad("confidence_score", f"{c} is outside -1.0…1.0.")
            else:
                confs.append(float(c))
                if c == 0:
                    warnings.append(f"Row {i}: confidence 0 is neither long nor short.")
        h = rec.get("investment_horizon")
        if h is not None and "investment_horizon" in rec:
            if isinstance(h, bool) or not isinstance(h, int):
                bad("investment_horizon", "Must be a whole number of trading days.")
            elif h <= 0:
                bad("investment_horizon", "Must be positive.")
            else:
                horizons.add(h)
        r = rec.get("return_prediction")
        if r is not None and "return_prediction" in rec:
            if not _num(r):
                bad("return_prediction", "Must be a number.")
            elif r < 0:
                bad("return_prediction", "Must be >= 0 (direction lives in the confidence sign).")
        pair = (str(rec.get("ticker") or "").strip().upper(), mic)
        if all(pair):
            if pair in seen_pair:
                bad("ticker", f"Duplicate ticker+MIC {pair[0]}/{pair[1]} (also row {seen_pair[pair]}).")
            seen_pair.setdefault(pair, i)
        if isin:
            if isin in seen_isin:
                bad("isin", f"Duplicate ISIN (also row {seen_isin[isin]}).")
            seen_isin.setdefault(isin, i)

    n = len(data)
    if len(horizons) > 1:
        warnings.append(f"Mixed horizons {sorted(horizons)} — use one horizon across the batch.")
    if expect_n and (n < expect_n * 0.5 or n > expect_n * 2):
        warnings.append(f"{n} instruments — about {expect_n} works best (more context per name); use several "
                        "prompts for broader coverage.")
    longs = sum(1 for c in confs if c > 0)
    shorts = sum(1 for c in confs if c < 0)
    if confs and (longs == 0 or shorts == 0):
        warnings.append("All positions point the same way (no longs or no shorts) — fine if intended.")
    summary = {"instruments": n, "long": longs, "short": shorts,
               "avg_abs_confidence": round(sum(abs(c) for c in confs) / len(confs), 3) if confs else None,
               "horizons": sorted(horizons)}
    return {"ok": not errors, "errors": errors[:200], "warnings": list(dict.fromkeys(warnings))[:20], "summary": summary}


# ── prompt builder ───────────────────────────────────────────────────────────────────

PRESETS = {
    "persona": {"label": "Investor persona",
                "role": "You are a portfolio manager who invests exactly in the style of {persona}.",
                "task": "Using current web research, select and rank stocks that this investor would buy (long) or avoid/short, "
                        "applying their documented criteria, position sizing and time horizon.",
                "universe": "Large and mid-cap listed equities across major global exchanges."},
    "fundamental": {"label": "Fundamental analyst",
                    "role": "You are a senior equity research analyst running a bottom-up fundamental workflow.",
                    "task": "For each company, read the latest results, guidance and filings, assess revenue and margin trends, balance "
                            "sheet strength and valuation versus peers, and form a directional view over the horizon.",
                    "universe": "Listed companies in a single sector of your choice across North America, Europe and Asia-Pacific."},
    "macro": {"label": "Macro idea",
              "role": "You are a global macro strategist who translates macro regimes into equity positioning.",
              "task": "Identify the current macro drivers (rates, inflation, FX, commodities, growth) from fresh sources and pick the "
                      "listed equities that benefit (long) or suffer (short) most over the horizon.",
              "universe": "Liquid listed equities with clear exposure to the chosen macro driver, across regions."},
    "sector": {"label": "Sector specific",
               "role": "You are a sector specialist who knows the key value drivers of this industry.",
               "task": "Score each company on the sector's key factors (for example capex cycle, pricing power, order backlog, "
                       "regulation) using the latest verified information, then rank them long to short.",
               "universe": "Publicly listed companies across the whole value chain of the sector, multiple regions."},
    "country": {"label": "Country specific",
                "role": "You are a country strategist covering one national equity market in depth.",
                "task": "Using recent news, policy and earnings data for the country, choose the stocks best and worst placed "
                        "to outperform over the horizon.",
                "universe": "The most liquid listed companies of that country, across sectors."},
    "news": {"label": "News based",
             "role": "You are a news-driven equity analyst who trades on fresh information flow.",
             "task": "Search the last days of financial news, identify companies with material, still-unpriced news, and "
                     "decide direction and conviction from the evidence.",
             "universe": "Listed equities with notable news flow in the last 1-2 weeks, across major exchanges."},
    "event": {"label": "Event based",
              "role": "You are an event-driven analyst (earnings, M&A, spin-offs, index changes, regulatory decisions).",
              "task": "Find upcoming or just-occurred catalysts through verified sources and position for the likely "
                      "price reaction over the horizon.",
              "universe": "Listed equities with a dated catalyst within the next 30 days, across regions."},
}


def build_prompt(p: dict) -> str:
    n = int(p.get("n") or 50)
    horizon = int(p.get("horizon") or 21)
    days = int(p.get("window_days") or 90)
    role = (p.get("role") or "").strip() or "You are a senior equity research analyst."
    task = (p.get("task") or "").strip() or ("Using current, up-to-date web search, evaluate listed companies and form a "
                                             "directional view for each.")
    universe = (p.get("universe") or "").strip() or "Listed equities across major global exchanges."
    lang = (p.get("language") or "").strip()
    extra = (p.get("extra") or "").strip()
    lang_line = (f"\nLANGUAGE\nWrite your internal reasoning in {lang}; keep the JSON keys exactly as specified (English).\n"
                 if lang and lang.lower() not in ("english", "en") else "")
    text = f"""ROLE
{role}

TASK
{task}
Cover approximately {n} instruments.

REQUIREMENTS — WEB VERIFICATION
- Search the web for each company's current ticker, exchange listing and most recent price action before finalizing any prediction. Do not rely on internal recall alone for facts that may be stale (recent earnings, guidance changes, M&A, regulatory actions).
- Verify ISIN and MIC codes against a reliable source (exchange listing pages, OpenFIGI or official investor-relations pages) rather than generating them from memory. If a verified ISIN cannot be confirmed, exclude that instrument rather than guessing.
- Prioritize information from the last {max(7, days // 3)}-{days} days so the view reflects current market conditions.

EQUITY UNIVERSE
{universe}
{lang_line}
OUTPUT FORMAT
Return ONLY a JSON array. No prose, no markdown, no commentary before or after. Each element must be an object with exactly these 7 fields, all mandatory, none blank/null/"N/A":

[
  {{
    "company_name": "<str>",
    "ticker": "<str>",
    "isin": "<str>",
    "mic": "<str>",
    "confidence_score": <float>,
    "investment_horizon": <int>,
    "return_prediction": <float>
  }}
]

FIELD DEFINITIONS
- company_name: full legal/trading name, web-verified.
- ticker: primary listing exchange ticker, web-verified.
- isin: valid 12-character ISIN, web-verified. Exclude the instrument if this cannot be confirmed.
- mic: 4-character ISO 10383 MIC of the primary listing venue, web-verified.
- confidence_score: float between -1.0 and 1.0. POSITIVE = long. NEGATIVE = short. Magnitude reflects conviction based on the strength and recency of verified evidence.
- investment_horizon: integer number of trading days the view is intended to hold. Use {horizon} for every instrument.
- return_prediction: non-negative float (>= 0.0), the magnitude of the expected return over the horizon. Direction is carried only by the sign of confidence_score; never make this negative.

CONSISTENCY CHECK (apply before finalizing each record)
1. Were ticker, ISIN and MIC verified via web search this session, not recalled from memory?
2. Are all 7 fields populated with a real, verified value?
3. Is return_prediction >= 0.0 in every record?
4. Is the thesis for each score traceable to a specific recent ({days} days or less) piece of information found via search?

SCOPE DISCIPLINE
- Target approximately {n} instruments; do not pad the list with out-of-universe names.
- No duplicate ticker+MIC pairs.
- Exclude any instrument whose ISIN/MIC cannot be verified rather than guessing.
{('- ' + extra) if extra else ''}
Begin by searching for current news and price data relevant to this universe, then generate the JSON array."""
    return re.sub(r"\n{3,}", "\n\n", text).strip()


# ── persistence ──────────────────────────────────────────────────────────────────────

_COLS = ("name", "model", "model_version", "update_frequency", "weight", "prompt", "sample_output",
         "thesis", "status", "notes")


def _d(r: M.BrainPrompt) -> dict:
    return {"id": r.id, "created_at": r.created_at, "updated_at": r.updated_at,
            **{k: getattr(r, k) for k in _COLS}, "chars": len(r.prompt or "")}


def list_prompts() -> list:
    with SessionLocal() as db:
        return [_d(r) for r in db.scalars(select(M.BrainPrompt).order_by(M.BrainPrompt.updated_at.desc())).all()]


def get_prompt(pid: int) -> dict | None:
    with SessionLocal() as db:
        r = db.get(M.BrainPrompt, pid)
        return _d(r) if r else None


def save_prompt(data: dict, pid: int | None = None) -> dict:
    with SessionLocal() as db:
        r = db.get(M.BrainPrompt, pid) if pid else None
        if pid and not r:
            return {"error": "not found"}
        if not r:
            r = M.BrainPrompt()
            db.add(r)
        for k in _COLS:
            if data.get(k) is not None:
                setattr(r, k, str(data[k]))
        r.updated_at = time.time()
        db.commit()
        return _d(r)


def delete_prompt(pid: int) -> dict:
    with SessionLocal() as db:
        r = db.get(M.BrainPrompt, pid)
        if r:
            db.delete(r)
            db.commit()
    return {"ok": True}
