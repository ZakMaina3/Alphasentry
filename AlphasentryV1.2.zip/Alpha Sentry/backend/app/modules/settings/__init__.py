"""Settings module — API keys, LLM provider/model choice + live key test, and BRAIN login.

Reuses the studio key store (keys) and session manager (session_manager) via the brain
adapter, so v2 shares the exact same secrets file and session the user already has.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.brain import engine  # noqa: F401 — loads the vendored engine + keys into env

import keys as keymgr          # noqa: E402
import session_manager as sm   # noqa: E402
import llm_providers as L      # noqa: E402

PREFIX = "/api/settings"
router = APIRouter()


# ── API keys ─────────────────────────────────────────────────────────────────────────

@router.get("/keys")
def get_keys():
    return {"status": keymgr.status()}


class KeysReq(BaseModel):
    updates: dict


@router.post("/keys")
def set_keys(req: KeysReq):
    return {"status": keymgr.set_keys(req.updates)}


@router.post("/keys/clear")
def clear_keys():
    return {"status": keymgr.set_keys({name: keymgr.CLEAR for name in keymgr.PROVIDERS})}


@router.post("/keys/{provider}/delete")
def delete_key(provider: str):
    """Delete a single provider's stored API key."""
    return {"status": keymgr.set_keys({provider: keymgr.CLEAR})}


# ── providers / models ───────────────────────────────────────────────────────────────

@router.get("/providers")
def providers():
    pref = keymgr.get_preferred()
    return {"available": [p.name for p in L.all_available()], "preferred": pref,
            "used": [p.name for p in L.default_chain(pref)]}


class PreferReq(BaseModel):
    preferred: str = ""


@router.post("/providers")
def set_provider(req: PreferReq):
    keymgr.set_preferred(req.preferred)
    pref = keymgr.get_preferred()
    return {"available": [p.name for p in L.all_available()], "preferred": pref,
            "used": [p.name for p in L.default_chain(pref)]}


@router.get("/providers/{provider}/models")
def provider_models(provider: str):
    if not L.is_known_provider(provider):
        raise HTTPException(404, f"unknown provider {provider!r}")
    return {"provider": provider, "models": L.list_models(provider),
            "current": L.provider_model(provider), "default": L.provider_default(provider)}


class ModelReq(BaseModel):
    model: str = ""


@router.post("/providers/{provider}/model")
def set_provider_model(provider: str, req: ModelReq):
    if not L.is_known_provider(provider):
        raise HTTPException(404, f"unknown provider {provider!r}")
    if provider not in L.PROVIDER_KEY_ENV:
        keymgr.custom_set_model(provider, req.model)
    else:
        keymgr.set_provider_model(provider, req.model)
    return {"provider": provider, "current": L.provider_model(provider)}


@router.post("/providers/{provider}/test")
def provider_test(provider: str):
    return L.test_provider(provider)


# ── ready-made providers, base-URL overrides and your own OpenAI-compatible providers ───────────

@router.get("/provider_catalog")
def provider_catalog():
    """Every ready-made provider (label, free-tier hint, local?, key optional?, key saved?, current base URL) and your own."""
    import provider_presets as PP
    st = keymgr.status()
    cat = PP.catalog(st)
    for c in cat:
        c["base_url"] = PP.base_url(c["name"])
        c["default_base_url"] = PP.PRESETS[c["name"]]["base_url"]
        c["overridden"] = bool(keymgr.get_base_url(c["name"]))
        c["hint"] = (st.get(c["name"]) or {}).get("hint", "")
    return {"presets": cat, "custom": keymgr.custom_list(), "account_set": bool((st.get("cloudflare_account") or {}).get("set"))}


class BaseUrlReq(BaseModel):
    url: str = ""


@router.post("/providers/{provider}/base_url")
def set_base_url(provider: str, req: BaseUrlReq):
    try:
        keymgr.set_base_url(provider, req.url)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"provider": provider, "base_url": keymgr.get_base_url(provider)}


class CustomReq(BaseModel):
    label: str
    base_url: str
    key: str = ""
    model: str = ""


@router.post("/custom")
def custom_add(req: CustomReq):
    try:
        r = keymgr.custom_set(req.label, req.base_url, req.key, req.model)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {**r, "custom": keymgr.custom_list()}


@router.post("/custom/{name}/delete")
def custom_remove(name: str):
    if keymgr.get_preferred() == name:
        keymgr.set_preferred("")
    return {"deleted": keymgr.custom_delete(name), "custom": keymgr.custom_list()}


# ── BRAIN login (biometrics, two steps) ──────────────────────────────────────────────

class LoginReq(BaseModel):
    email: str | None = None
    password: str | None = None
    force: bool = False


@router.post("/login/begin")
def login_begin(req: LoginReq):
    # Guard against the classic footgun: re-logging in gives you a NEW BRAIN session and CANCELS the
    # current one, so any running simulation instantly starts failing with 401 "Incorrect
    # authentication credentials". Refuse while a task is running unless the caller forces it.
    if not req.force:
        from app.core.jobs import jobs
        running = [j for j in jobs.list_recent(200) if j.get("status") == "running"]
        if running:
            kinds = ", ".join(sorted({str(j.get("kind", "task")) for j in running}))
            return {"error": f"A background task is running ({len(running)}: {kinds}). Re-logging in now "
                             "starts a fresh BRAIN session and cancels this one, so the running task would "
                             "fail with authentication errors. Wait for it to finish (or stop it), then log "
                             "in. Use “Log in anyway” only if you accept losing the running task.",
                    "job_running": len(running)}
    return sm.begin_login(req.email, req.password)


@router.post("/login/complete")
def login_complete():
    return sm.complete_login()
