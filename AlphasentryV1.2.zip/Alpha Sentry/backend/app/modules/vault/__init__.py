"""Vault module — park, tag, and revisit alphas you're not submitting yet, separate from
the raw sim_results log. Submitting from here calls the same submit_alpha() the Simulate
screen uses, so there's still one submission code path in the app."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.vault import service
from app.simulation import service as sim

PREFIX = "/api/vault"
router = APIRouter()


class AddFromResultReq(BaseModel):
    sim_result_id: int
    note: str = ""
    tags: list[str] = []


@router.post("/add-from-result")
def add_from_result(req: AddFromResultReq):
    try:
        return service.add_from_result(req.sim_result_id, req.note, req.tags)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, str(e))


class AddManualReq(BaseModel):
    alpha_id: str = ""
    expression: str = ""
    region: str = ""
    delay: int = 1
    universe: str = ""
    neutralization: str = ""
    sharpe: float | None = None
    fitness: float | None = None
    turnover: float | None = None
    note: str = ""
    tags: list[str] = []


@router.post("/add")
def add_manual(req: AddManualReq):
    return service.add_manual(**req.model_dump())


@router.get("")
def list_vault(status: str | None = None, region: str | None = None, limit: int = 300):
    return service.list_vault(status, region, limit)


class UpdateReq(BaseModel):
    note: str | None = None
    tags: list[str] | None = None
    status: str | None = None   # parked|reviewing|archived


@router.patch("/{vault_id}")
def update(vault_id: int, req: UpdateReq):
    try:
        return service.update(vault_id, note=req.note, tags=req.tags, status=req.status)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, str(e))


@router.delete("/{vault_id}")
def delete(vault_id: int):
    return service.delete(vault_id)


@router.post("/{vault_id}/submit")
def submit(vault_id: int):
    """Submit this vault entry's alpha to BRAIN — not reversible on BRAIN's side. The
    frontend must confirm with the user before calling this."""
    items = service.list_vault(limit=100000)["items"]
    row = next((x for x in items if x["id"] == vault_id), None)
    if not row:
        raise HTTPException(404, "no such vault entry")
    if not row.get("alpha_id"):
        raise HTTPException(400, "This vault entry has no alpha_id — it can't be submitted.")
    try:
        return sim.submit_alpha(row["alpha_id"])
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, str(e))
