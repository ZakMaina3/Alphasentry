"""SentryEngine returns vault + mixing. Gated by the `harness_vault` flag (default OFF). Read-only analysis and
free previews; a "run" of a mix only queues the combined expression on the harness engine. No submit path."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

import logging

from app.core.jobs import jobs
from app.harness import flags
from app.harness.api_common import ScopeBase, need_flag
from app.harness.store import check_ace_schema, default_store, ensure_tables

PREFIX = "/api/harness_vault"
router = APIRouter()


def on_startup() -> None:
    ensure_tables(default_store())
    for problem in check_ace_schema(default_store()):
        logging.getLogger(__name__).warning("harness: %s", problem)


class ScopeReq(ScopeBase):
    neutralization: str | None = None
    min_sharpe: float = 0.7
    limit: int = 200


class MixReq(ScopeReq):
    sizes: list[int] = [2]
    max_correlation: float = 0.5
    min_uplift: float | None = 0.0
    population: int = 120
    include_submitted: bool = True
    check_self_correlation: bool = True


class CombineReq(BaseModel):
    expressions: list[str]
    strategy: str | None = None


@router.post("/backfill")
def backfill_start(req: ScopeReq):
    """Fetch daily returns for this scope's alphas that have none (one BRAIN read per alpha; no sim quota)."""
    need_flag("harness_vault")
    from app.harness.vault import ace_vault as v
    jid = jobs.submit("harness_returns_backfill", lambda progress, cancelled: v.backfill_scope(
        req.region, req.delay, req.universe, req.min_sharpe, req.limit, progress, cancelled))
    return {"job_id": jid}


@router.post("/matrix")
def matrix(req: ScopeReq):
    need_flag("harness_vault")
    from app.harness.vault import ace_vault as v
    return v.mixer.correlation_matrix(region=req.region, delay=req.delay, universe=req.universe,
                                      instrument_type=req.instrument_type, neutralization=req.neutralization,
                                      min_sharpe=req.min_sharpe, limit=min(req.limit, 60))


@router.post("/mix/candidates")
def mix_candidates(req: MixReq):
    """Groups worth mixing, ranked by uplift over their best member, with a predicted self-correlation verdict.
    Free: computed from stored series, nothing is simulated."""
    need_flag("harness_vault")
    from app.harness.vault import ace_vault as v
    return v.mixer.candidates(region=req.region, delay=req.delay, universe=req.universe,
                              instrument_type=req.instrument_type, neutralization=req.neutralization,
                              sizes=req.sizes, min_sharpe=req.min_sharpe, max_correlation=req.max_correlation,
                              min_uplift=req.min_uplift, population=req.population, limit=40,
                              include_submitted=req.include_submitted,
                              check_self_correlation=req.check_self_correlation)


@router.post("/combine")
def combine(req: CombineReq):
    need_flag("harness_vault")
    from app.harness.vault.combine import Strategy, build, recommend
    try:
        rec = recommend(req.expressions)
        chosen = Strategy(req.strategy) if req.strategy else rec.strategy
        return {"recommendation": rec.to_dict(), "expression": build(req.expressions, strategy=chosen)}
    except ValueError as e:
        raise HTTPException(400, str(e))


class MixPreview(BaseModel):
    members: list[str]
    strategy: str | None = None
    weights: list[float] | None = None


class MixRun(BaseModel):
    groups: list[list[str]]
    strategy: str | None = None
    dry_run: bool = False


@router.post("/mix/preview")
def mix_preview(req: MixPreview):
    """The expression a group would produce, and why it is put together that way. Free."""
    need_flag("harness_vault")
    from app.harness.vault import ace_vault as v, mixrun
    lookup = v.by_ids(req.members)
    missing = [m for m in req.members if m not in lookup]
    if missing:
        raise HTTPException(404, f"Not found in Alpha Sentry results: {', '.join(missing)}.")
    try:
        return mixrun.preview([lookup[m] for m in req.members], req.strategy, req.weights)
    except ValueError as e:
        raise HTTPException(422, str(e))


@router.post("/mix/run")
def mix_run(req: MixRun):
    """Combine each group into one new alpha and queue it on the harness engine (deduplicated). Needs both
    the `harness_vault` and `harness_engine` flags. Queue-only: nothing is submitted."""
    need_flag("harness_vault")
    from app.harness.vault import ace_vault as v, mixrun
    requests, built, problems = mixrun.build_requests(
        req.groups, v.by_ids(sorted({m for g in req.groups for m in g})), req.strategy)
    if req.dry_run or not requests:
        return {"built": built, "problems": problems, "queued": 0, "dryRun": True}
    if not flags.enabled("harness_engine"):
        raise HTTPException(409, "Queueing needs the 'harness_engine' flag too. Use dry_run to preview.")
    from app.modules.harness_engine import _get_engine
    out = _get_engine().tracker.enqueue_many("mix", requests)
    return {"built": built, "problems": problems, "queued": out["queued"], "duplicates": out["duplicates"]}
