"""Notify module — Telegram setup for Autosentry alerts (session re-auth, winners)."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.notify import telegram as T

PREFIX = "/api/notify"
router = APIRouter()


class ConfigReq(BaseModel):
    token: str | None = None
    chat_id: str | None = None
    enabled: bool | None = None
    heads_up_min: int | None = None
    resend_min: int | None = None
    notify_winners: bool | None = None
    remote_enabled: bool | None = None
    auto_refresh_min: int | None = None


@router.get("/config")
def get_config():
    return T.public_config()


@router.post("/config")
def set_config(req: ConfigReq):
    if req.token:
        try:
            info = T.bot_info(req.token.strip())
        except Exception as e:  # noqa: BLE001
            raise HTTPException(400, f"That bot token was rejected by Telegram ({e}).")
    else:
        info = None
    out = T.save_config(req.model_dump())
    if info:
        out["bot_username"] = info.get("username", "")
    return out


@router.post("/discover")
def discover():
    try:
        return T.discover_chat_id()
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, str(e))


@router.post("/test")
def test():
    c = T.config()
    if not (c["token"] and str(c["chat_id"]).strip()):
        raise HTTPException(400, "Save the bot token and chat ID first.")
    ok = T.send("✅ Alpha Sentry Autosentry can reach you here.\nWhen your BRAIN session expires I'll send the "
                "biometrics link in this chat.", cfg=c)
    if not ok:
        raise HTTPException(400, "Telegram rejected the message — check the token and chat ID.")
    return {"ok": True}
