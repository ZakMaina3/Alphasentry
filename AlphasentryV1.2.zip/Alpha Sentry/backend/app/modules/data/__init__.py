"""Data module — the research context's options, datasets, and datafields.

Thin HTTP over `brain.engine`. Datafields carry the VECTOR/MATRIX split and a computed
`prefix` (the field-family first 3 letters) so the Data Explorer can facet without
re-deriving it client-side. A clean 409 is returned when there is no session, so the UI
can prompt for login instead of failing deep in the API.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.brain import engine
from app.knowledge import service as knowledge

PREFIX = "/api/data"
router = APIRouter()


def _learn(fn, *a, **k):
    """Feed the knowledge DB without ever failing the user-facing request."""
    try:
        fn(*a, **k)
    except Exception as e:  # noqa: BLE001
        print(f"[knowledge] ingest skipped: {e}")


def field_prefix(fid: str) -> str:
    """Field family = everything up to the first underscore (nws18_acb -> 'nws18'). Fields
    with no underscore are grouped under a single general bucket."""
    fid = str(fid or "")
    return fid.split("_", 1)[0].lower() if "_" in fid else "general"


def _guard(fn, *a, **k):
    try:
        return fn(*a, **k)
    except engine.SessionExpired as e:
        raise HTTPException(409, str(e))


@router.get("/options")
def options(refresh: bool = False):
    return _guard(engine.get_options, refresh)


@router.get("/datasets")
def datasets(region: str = "USA", universe: str = "TOP3000", delay: int = 1,
             instrument_type: str = "EQUITY", theme: bool = False,
             coverage_min: float = 0.0, value_min: float = 0.0, category: str = ""):
    rows = _guard(engine.get_datasets, region=region, universe=universe, delay=delay,
                  instrument_type=instrument_type, theme=theme, coverage_min=coverage_min,
                  value_min=value_min, category=category)
    _learn(knowledge.ingest_datasets, region, delay, instrument_type, universe, rows)
    return {"count": len(rows), "datasets": rows}


class FieldsReq(BaseModel):
    dataset_ids: list[str]
    region: str = "USA"
    universe: str = "TOP3000"
    delay: int = 1
    instrument_type: str = "EQUITY"
    data_type: str = "ALL"
    search: str = ""
    limit: int = 2000


@router.post("/datafields")
def datafields(req: FieldsReq):
    df, raw = _guard(engine.fetch_fields, req.dataset_ids, region=req.region,
                     universe=req.universe, delay=req.delay,
                     instrument_type=req.instrument_type, data_type=req.data_type,
                     search=req.search)
    if df is None or getattr(df, "empty", True):
        return {"count": 0, "fetched": raw, "duplicates": 0, "vector": 0, "matrix": 0, "fields": []}

    cols = [c for c in ["id", "description", "type", "alphaCount", "dateCoverage",
                        "coverage", "is_virgin", "dataset_id"] if c in df.columns]
    out = df[cols].head(req.limit).to_dict(orient="records")
    for row in out:
        row["prefix"] = field_prefix(row.get("id", ""))
    n_vec = int((df["type"].astype(str).str.upper() == "VECTOR").sum()) if "type" in df.columns else 0
    n_mat = int((df["type"].astype(str).str.upper() == "MATRIX").sum()) if "type" in df.columns else 0
    _learn(knowledge.ingest_fields, req.region, req.delay, req.dataset_ids, out)
    return engine._json_safe({
        "count": len(df), "fetched": raw, "duplicates": max(0, raw - len(df)),
        "vector": n_vec, "matrix": n_mat, "fields": out,
    })
