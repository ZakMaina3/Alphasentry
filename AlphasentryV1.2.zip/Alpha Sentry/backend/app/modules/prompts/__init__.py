"""BRAIN Prompts module — build, validate and keep LLM-prompt submissions for WorldQuant BRAIN."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.prompts import service as P

PREFIX = "/api/brain-prompts"
router = APIRouter()


class PromptReq(BaseModel):
    name: str | None = None
    model: str | None = None
    model_version: str | None = None
    update_frequency: str | None = None
    weight: str | None = None
    prompt: str | None = None
    sample_output: str | None = None
    thesis: str | None = None
    status: str | None = None
    notes: str | None = None


class BuildReq(BaseModel):
    role: str = ""
    task: str = ""
    universe: str = ""
    n: int = 50
    horizon: int = 21
    window_days: int = 90
    language: str = ""
    extra: str = ""


class CheckReq(BaseModel):
    sample_output: str = ""
    expect_n: int = 50
    form: dict | None = None


class DraftReq(BaseModel):
    thesis: str
    idea: str = ""


@router.get("/presets")
def presets():
    return {"presets": P.PRESETS, "max_chars": P.MAX_PROMPT_CHARS}


@router.get("")
def list_all():
    return {"items": P.list_prompts()}


@router.post("")
def create(req: PromptReq):
    return P.save_prompt(req.model_dump())


@router.patch("/{pid}")
def update(pid: int, req: PromptReq):
    r = P.save_prompt(req.model_dump(), pid)
    if r.get("error"):
        raise HTTPException(404, r["error"])
    return r


@router.delete("/{pid}")
def remove(pid: int):
    return P.delete_prompt(pid)


@router.post("/build")
def build(req: BuildReq):
    text = P.build_prompt(req.model_dump())
    return {"prompt": text, "chars": len(text), "too_long": len(text) > P.MAX_PROMPT_CHARS}


@router.post("/check")
def check(req: CheckReq):
    out = {"output": P.validate_output(req.sample_output, req.expect_n)}
    if req.form is not None:
        out["form"] = P.check_form(req.form)
    return out


@router.post("/draft")
def draft(req: DraftReq):
    """Best effort: let the LLM draft ROLE / TASK / UNIVERSE from a one-line thesis."""
    try:
        from app.autopilot import service as A
        res = A._llm(
            "Write three short parts of an LLM prompt for a global equity long/short idea. Thesis: "
            f"{req.thesis}\nStyle hint: {req.idea or 'none'}\nReturn ONLY a JSON array of exactly 3 strings: "
            "[ROLE (1-2 sentences, 'You are ...'), TASK (2-4 sentences: what to search, assess and decide), "
            "UNIVERSE (1-2 sentences: which listed equities, regions, sectors)].", 3)
        parts = [str(x).strip() for x in res.expressions if str(x).strip()]
        if len(parts) < 3:
            raise RuntimeError("the model returned fewer than 3 parts")
        return {"role": parts[0], "task": parts[1], "universe": parts[2]}
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, f"Could not draft with the LLM ({str(e)[:160]}). Fill the three boxes by hand "
                                 "or pick a preset.")
