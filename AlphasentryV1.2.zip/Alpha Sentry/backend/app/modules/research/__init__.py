"""Research module — the Research Lab's backend.

Runs LLM research as a background job (survives a refresh), ingests research papers
(paste or PDF upload with a page range), saves sessions, and pushes chosen ideas to a
saved prompt for later generation. Separate from generation by design.
"""

from __future__ import annotations

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from pydantic import BaseModel

from app.core.jobs import jobs
from app.research import service

PREFIX = "/api/research"
router = APIRouter()


@router.get("/providers")
def providers():
    return service.providers()


class RunReq(BaseModel):
    category: str = ""
    region: str = "USA"
    delay: int = 1
    instrument: str = "EQUITY"
    dataset_names: list[str] = []
    fields: list[dict] = []
    categories: dict = {}                 # field_id -> category (for two-category mode)
    goal: str = ""
    paper_text: str = ""
    paper_name: str = ""
    paper_is_community: bool = False      # WorldQuant community paper → stricter grounding
    n: int = 6
    # single (default) | multi_single_dataset | multi_two_categories — multi only when chosen
    mode: str = "single"
    max_operators: int = 6
    economic_review: bool = True          # drop hypotheses whose expression makes no economic sense


@router.post("/run")
def run(req: RunReq):
    if not req.fields:
        raise HTTPException(400, "Select some datafields first so the research is grounded in your data.")
    if req.paper_is_community and req.paper_text and not req.fields:
        raise HTTPException(400, "For a WorldQuant community paper, first select the datasets/fields it "
                                 "suggests so the research maps to the right data.")

    def task(progress, should_cancel):
        out = service.run_research(
            category=req.category, region=req.region, delay=req.delay, instrument=req.instrument,
            dataset_names=req.dataset_names, fields=req.fields, categories=req.categories, goal=req.goal,
            paper_text=req.paper_text, paper_is_community=req.paper_is_community,
            mode=req.mode, max_operators=req.max_operators, n=req.n,
            economic_review=req.economic_review, progress=progress)
        sid = service.save_session({**req.model_dump(), **out})
        out["session_id"] = sid
        return out

    return {"job_id": jobs.submit("research", task)}


@router.post("/goal")
def goal(req: RunReq):
    """Auto-generate a research goal from the selected data — or from the uploaded paper if present."""
    try:
        g = service.suggest_goal(
            region=req.region, delay=req.delay, instrument=req.instrument,
            dataset_names=req.dataset_names, fields=req.fields, categories=req.categories,
            paper_text=req.paper_text)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, str(e))
    return {"goal": g}


@router.get("/jobs/{jid}")
def job(jid: str):
    j = jobs.get(jid)
    if not j:
        raise HTTPException(404, "no such job")
    return j


@router.post("/paper")
async def paper(file: UploadFile = File(...), pages: str = Form("")):
    """Extract text from an uploaded PDF (optionally a page range like '1-3,5')."""
    data = await file.read()
    try:
        text = service.extract_pdf_text(data, pages)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, f"Could not read that PDF ({e}).")
    if not text:
        raise HTTPException(400, "No selectable text found in that PDF (is it a scan?).")
    return {"name": file.filename, "chars": len(text), "text": text[:80000]}


@router.get("/sessions")
def sessions(limit: int = 30):
    return {"sessions": service.list_sessions(limit)}


class PushReq(BaseModel):
    name: str = ""
    scope: str = "generate"      # generate | template
    category: str = ""
    region: str = ""
    body: str
    dataset_names: list[str] = []
    research_id: int = 0
    compose: bool = True         # AI-rewrite into a structured prompt with a nice name
    source: str = "research"     # research | strategy


@router.post("/push")
def push(req: PushReq):
    def task(progress, should_cancel):
        progress(message="naming and saving the prompt…")
        # Save the RAW notes as-is (no restructuring) with a nice name. The user can auto-rewrite
        # into a full master prompt on demand in Generation.
        name = (req.name or "").strip() or service.nice_name(req.body, req.category, req.region, req.source)
        saved = service.save_prompt(name=name, scope=req.scope, category=req.category,
                                    region=req.region, body=req.body, dataset_names=req.dataset_names,
                                    research_id=req.research_id)
        return {"ok": True, "prompt_id": saved["id"], "name": saved["name"], "duplicate": saved["duplicate"]}
    return {"job_id": jobs.submit("push-prompt", task)}


# ── hypothesis-FIRST workflow: idea -> keywords -> datafields (reverse of /run above) ──

class BrainstormReq(BaseModel):
    category: str = ""
    region: str = "USA"
    delay: int = 1
    instrument: str = "EQUITY"
    goal: str = ""
    n: int = 6


@router.post("/brainstorm")
def brainstorm(req: BrainstormReq):
    """STEP 1 of the hypothesis-first flow: propose hypotheses with NO datafield catalogue
    in hand yet. Each one carries search keywords — feed those to /fields-for-hypothesis to
    get an actual datafield shortlist, then run the normal /run (grounded research) or
    Generation against just those fields. Never repeats the same idea more than twice."""
    def task(progress, should_cancel):
        progress(message="brainstorming hypotheses…")
        return service.brainstorm_hypotheses(category=req.category, region=req.region, delay=req.delay,
                                             instrument=req.instrument, goal=req.goal, n=req.n)
    return {"job_id": jobs.submit("brainstorm", task)}


class FieldsForHypothesisReq(BaseModel):
    region: str = "USA"
    delay: int = 1
    instrument: str = "EQUITY"
    universe: str = "TOP3000"
    keywords: list[str]
    live: bool = True
    limit: int = 25


@router.post("/fields-for-hypothesis")
def fields_for_hypothesis(req: FieldsForHypothesisReq):
    """STEP 2: turn a hypothesis's search keywords into an actual datafield shortlist —
    live against BRAIN first, falling back to the local knowledge cache."""
    try:
        return service.fields_for_hypothesis(region=req.region, delay=req.delay, instrument=req.instrument,
                                             universe=req.universe, keywords=req.keywords,
                                             live=req.live, limit=req.limit)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, str(e))
