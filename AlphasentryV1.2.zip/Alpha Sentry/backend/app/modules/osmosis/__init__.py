"""Osmosis Planner module — review every submitted alpha, find the scopes that qualify and propose
the 100,000-point allocation; Implement writes the (edited) points to BRAIN on request. No alpha is submitted."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.core.jobs import jobs
from app.osmosis import planner as P
from app.osmosis import service

PREFIX = "/api/osmosis"
router = APIRouter()


class RefreshReq(BaseModel):
    force_pnl: bool = False


class PlanReq(BaseModel):
    config: dict = {}
    current: dict[str, int] = {}          # optional: your current points per alpha id


@router.post("/refresh")
def refresh(req: RefreshReq):
    def task(progress, should_cancel):
        return service.refresh(progress, should_cancel, req.force_pnl)
    return {"job_id": jobs.submit("osmosis-refresh", task)}


@router.get("/jobs/{jid}")
def job(jid: str):
    j = jobs.get(jid)
    if not j:
        raise HTTPException(404, "no such job")
    return j


@router.post("/plan")
def plan(req: PlanReq):
    allowed = {k: v for k, v in req.config.items() if k in P.DEFAULTS}
    return service.make_plan(allowed, req.current)


@router.get("/defaults")
def defaults():
    return P.DEFAULTS


class ImplementReq(BaseModel):
    edits: dict[str, dict[str, int]]      # {scope: {alpha_id: points}}  (0 = no points)
    current: dict[str, int] = {}
    dry_run: bool = False


@router.post("/implement")
def implement(req: ImplementReq):
    """Write the (edited) allocation to BRAIN as Osmosis points. This edits points only: it never
    submits an alpha. The whole allocation is validated first; the first write is read back."""
    if req.dry_run:
        try:
            return service.implement(req.edits, req.current, lambda **k: None, lambda: False, True)
        except ValueError as e:
            raise HTTPException(400, str(e))

    def task(progress, should_cancel):
        return service.implement(req.edits, req.current, progress, should_cancel)
    try:
        from app.osmosis import apply as A
        d = A.validate_and_diff(service.load_snapshot().get("alphas", []), req.edits, None, req.current)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, str(e))
    if not d["ok"]:
        raise HTTPException(400, "; ".join(d["errors"]))
    return {"job_id": jobs.submit("osmosis-implement", task)}


@router.post("/undo")
def undo():
    def task(progress, should_cancel):
        return service.undo(progress, should_cancel)
    return {"job_id": jobs.submit("osmosis-undo", task)}


@router.get("/journal")
def journal():
    return {"items": service.journal()}
