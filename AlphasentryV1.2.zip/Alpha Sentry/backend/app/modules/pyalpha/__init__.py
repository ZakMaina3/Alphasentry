"""Alpha Translation module — Fast Expression → Python Alpha + simulation + built-in, editable guideline."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.core.jobs import jobs
from app.pyalpha import service

PREFIX = "/api/pyalpha"
router = APIRouter()


class GuideReq(BaseModel):
    text: str


@router.get("/guideline")
def guideline():
    return service.get_guideline()


@router.post("/guideline")
def save_guideline(req: GuideReq):
    return service.save_guideline(req.text)


@router.post("/guideline/reset")
def reset_guideline():
    """Back to the built-in guidelines (removes your override)."""
    return service.reset_guideline()


class TranslateReq(BaseModel):
    expression: str
    settings: dict = {}
    notes: str = ""
    prior_code: str = ""      # set when asking for a fix
    error: str = ""


@router.post("/translate")
def translate(req: TranslateReq):
    if not req.expression.strip():
        raise HTTPException(400, "Paste a Fast Expression first.")

    def task(progress, should_cancel):
        progress(message="translating…")
        return service.translate(expression=req.expression, settings=req.settings, notes=req.notes,
                                 prior_code=req.prior_code, error=req.error, progress=progress)
    return {"job_id": jobs.submit("pyalpha-translate", task)}


class SimReq(BaseModel):
    code: str = ""
    expression: str = ""
    settings: dict = {}


@router.post("/simulate")
def simulate(req: SimReq):
    if not req.code.strip():
        raise HTTPException(400, "No Python alpha code to simulate.")

    def task(progress, should_cancel):
        return service.simulate_python(code=req.code, settings=req.settings,
                                       progress=progress, should_cancel=should_cancel)
    return {"job_id": jobs.submit("pyalpha-simulate", task)}


@router.post("/simulate-fast")
def simulate_fast(req: SimReq):
    if not req.expression.strip():
        raise HTTPException(400, "No Fast Expression to simulate.")

    def task(progress, should_cancel):
        return service.simulate_fast(expression=req.expression, settings=req.settings,
                                     progress=progress, should_cancel=should_cancel)
    return {"job_id": jobs.submit("pyalpha-simulate-fast", task)}


@router.get("/jobs/{jid}")
def job(jid: str):
    j = jobs.get(jid)
    if not j:
        raise HTTPException(404, "no such job")
    return j


@router.post("/jobs/{jid}/cancel")
def cancel(jid: str):
    return {"cancelled": jobs.cancel(jid)}
