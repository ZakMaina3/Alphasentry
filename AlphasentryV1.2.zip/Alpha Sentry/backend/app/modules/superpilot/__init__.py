"""Supersentry module — start/stop/inspect the autonomous SuperAlpha engine."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.core.jobs import jobs
from app.superpilot import service

PREFIX = "/api/superpilot"
router = APIRouter()


class StartReq(BaseModel):
    region: str = "USA"
    delay: int = 1
    instrument: str = "EQUITY"
    universe: str = "ILLIQUID_MINVOL1M"
    neutralizations: list[str] = ["FAST"]
    decay: int = 10
    truncation: float = 0.08
    selection_limit: int = 1000
    selection_handling: str = "POSITIVE"
    own: bool = True                    # selections start with `own &&` (only your own alphas)
    min_components: int = 11            # a selection must pick MORE THAN 10 alphas
    per_round: int = 6                  # SuperAlphas simulated per round (BRAIN runs 3 at once)
    n_selections: int = 6               # selections the LLM writes per round
    n_combos: int = 6                   # combos the LLM writes per round
    goal: str = ""
    tag: str = ""
    winner_tag: str = ""
    min_sharpe: float | None = None
    min_fitness: float | None = None
    max_turnover: float = 0.70
    max_corr: float = 0.70
    max_rounds: int = 0                 # 0 = run forever
    max_winners: int = 0                # 0 = run forever
    pause_between_rounds: int = 5
    use_library: bool = True
    flip: bool = True                   # retry negative results with the combo reversed
    flip_min_sharpe: float = 0.5
    decorrelate: bool = True            # low-correlation rebuilds, other neutralizations, operator swaps


@router.post("/start")
def start(req: StartReq):
    try:
        return service.start(req.model_dump())
    except RuntimeError as e:
        raise HTTPException(400, str(e))


@router.post("/stop")
def stop():
    jid = service._LIVE.get("job_id")
    return {"cancelled": bool(jid and jobs.cancel(jid))}


@router.get("/status")
def status():
    return service.status()


@router.post("/reset")
def reset():
    return service.reset_state()


class VerifyReq(BaseModel):
    selections: list[str]
    region: str = "USA"
    delay: int = 1
    instrument: str = "EQUITY"
    selection_limit: int = 1000
    selection_handling: str = "POSITIVE"
    min_components: int = 11


@router.post("/verify")
def verify(req: VerifyReq):
    """Count the alphas picked by selection expressions (ad-hoc check from the screen)."""
    cfg = {"region": req.region, "delay": req.delay, "instrument": req.instrument,
           "selection_limit": req.selection_limit, "selection_handling": req.selection_handling,
           "min_components": req.min_components}
    try:
        return {"results": service.verify_selections(cfg, [e.strip() for e in req.selections if e.strip()],
                                                     lambda **k: None, lambda: False)}
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, str(e)[:200])
