"""update — in-app self-update for the packaged build.

/check reports whether a newer signed release exists; /apply downloads + verifies it and swaps
on relaunch. No-ops safely when running from source.
"""

from __future__ import annotations

from fastapi import APIRouter

from app.update import service

PREFIX = "/api/update"
router = APIRouter()


@router.get("/check")
def check():
    return service.check()


@router.post("/apply")
def apply():
    return service.apply(progress=lambda **_: None)
