"""Data Catalog module: one-time download of datasets/datafields from BRAIN by region and category, browse, export."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel

from app.brain import engine
from app.catalog import service
from app.core.jobs import jobs

PREFIX = "/api/catalog"
router = APIRouter()


def _guard(fn, *a, **k):
    try:
        return fn(*a, **k)
    except engine.SessionExpired as e:
        raise HTTPException(409, str(e))


@router.get("/local_scopes")
def local_scopes():
    """Regions, delays and universes known from the data stored on this computer (feeds the Region / Universe dropdowns everywhere)."""
    from app.catalog import scopes
    from app.harness.store import default_store
    return scopes.local_scopes(default_store())


class Scope(BaseModel):
    region: str
    delay: int
    universe: str = ""


class CatReq(BaseModel):
    scopes: list[Scope]


class PullReq(BaseModel):
    scopes: list[Scope]
    categories: list[str] = []
    force: bool = False


@router.get("/scopes")
def scopes():
    return {"scopes": _guard(service.scopes_offered)}


@router.post("/categories")
def categories(req: CatReq):
    return {"categories": _guard(service.list_categories, [s.model_dump() for s in req.scopes])}


@router.post("/pull")
def pull(req: PullReq):
    if not req.scopes:
        raise HTTPException(400, "Pick at least one region and delay.")
    sc = [s.model_dump() for s in req.scopes]

    def task(progress, should_cancel):
        return service.pull(sc, req.categories, req.force, progress, should_cancel)
    return {"job_id": jobs.submit("catalog-pull", task)}


@router.get("/jobs/{jid}")
def job(jid: str):
    j = jobs.get(jid)
    if not j:
        raise HTTPException(404, "no such job")
    return j


@router.post("/jobs/{jid}/cancel")
def cancel(jid: str):
    return {"cancelled": jobs.cancel(jid)}


@router.get("/summary")
def summary():
    return service.summary()


@router.get("/browse")
def browse(region: str = "", delay: str = "", q: str = "", type: str = "", category: str = "", dataset: str = "",
           limit: int = 200, offset: int = 0):
    return service.browse(limit, offset, region=region, delay=delay or None, q=q, type_=type, category=category, dataset=dataset)


@router.get("/export")
def export(fmt: str = "csv", region: str = "", delay: str = "", q: str = "", type: str = "", category: str = "", dataset: str = ""):
    data, name, mime = service.export("xlsx" if fmt == "xlsx" else "csv", region=region, delay=delay or None, q=q,
                                      type_=type, category=category, dataset=dataset)
    return Response(content=data, media_type=mime, headers={"Content-Disposition": f'attachment; filename="{name}"'})
