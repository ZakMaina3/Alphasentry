"""Osmosis Planner: reviews every submitted alpha, finds the scopes that qualify and proposes a
100,000-point allocation per scope. Reading is read-only; the only thing ever written to BRAIN is the
Osmosis points on alphas, and only when the user presses Implement. No alpha is ever submitted."""
