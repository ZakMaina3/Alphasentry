"""Osmosis Planner service: pull every submitted alpha (and its daily PnL) from BRAIN, cache a
snapshot, and run the planner on it. Reading uses GET only. `implement` / `undo` PATCH the Osmosis points
of alphas (and nothing else) and only run when the user asks; no alpha is ever submitted."""
from __future__ import annotations

import json
import time
from concurrent.futures import ThreadPoolExecutor

from app.brain import engine
from app.core.config import get_settings
from app.osmosis import extract as X
from app.osmosis import planner as P

import ace_lib as ace          # noqa: E402

_FILE = get_settings().data_dir / "osmosis_snapshot.json"
PNL_FRESH_SECONDS = 20 * 3600


def load_snapshot() -> dict:
    try:
        return json.loads(_FILE.read_text())
    except Exception:
        return {"fetched_at": None, "alphas": [], "errors": []}


def _save(snap: dict) -> None:
    tmp = _FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(snap))
    tmp.replace(_FILE)


def _list_submitted(s, progress, should_cancel) -> list:
    """Page through /users/self/alphas. Submitted alphas are status ACTIVE (stage OS)."""
    def pages(params):
        out, offset = [], 0
        while not should_cancel():
            r = s.get(ace.brain_api_url + "/users/self/alphas",
                      params={**params, "limit": 100, "offset": offset}, timeout=60)
            if "retry-after" in r.headers:
                time.sleep(float(r.headers["Retry-After"])); continue
            if r.status_code // 100 != 2:
                raise RuntimeError(f"BRAIN answered {r.status_code} when listing alphas")
            d = r.json()
            rows = d.get("results") or []
            out += rows
            progress(message=f"listing alphas… {len(out)}")
            offset += len(rows)
            if not rows or offset >= int(d.get("count") or 0):
                break
        return out
    rows = pages({"status": "ACTIVE"})
    if not rows:                                   # fall back: list everything, keep the submitted ones
        rows = pages({})
    return [r for r in rows if X.is_submitted(r)]


def _daily_pnl(s, alpha_id: str) -> dict | None:
    try:
        df = engine.brain_call("alpha daily PnL", ace.get_alpha_daily_pnl, s, alpha_id)
    except Exception:
        return None
    if df is None or getattr(df, "empty", True):
        return None
    col = next((c for c in df.columns if str(c).lower() == "pnl"), None)
    if col is None:
        col = next((c for c in df.columns if "pnl" in str(c).lower()), None)
    if col is None:
        return None
    return {str(i)[:10]: float(v) for i, v in df[col].items() if v == v}


def refresh(progress, should_cancel, force_pnl: bool = False) -> dict:
    s = engine.require_session()
    raws = _list_submitted(s, progress, should_cancel)
    old = {a["id"]: a for a in load_snapshot().get("alphas", [])}
    now = time.time()
    alphas = [a for a in (X.normalise(r) for r in raws) if a]
    need = []
    for a in alphas:
        prev = old.get(a["id"])
        if prev and prev.get("pnl") and not force_pnl and now - prev.get("pnl_at", 0) < PNL_FRESH_SECONDS:
            a["pnl"], a["pnl_at"] = prev["pnl"], prev["pnl_at"]
        else:
            need.append(a)
    progress(message=f"{len(alphas)} submitted alphas · fetching PnL for {len(need)}…", total=len(need), done=0)
    errors, done = [], 0

    def one(a):
        a["pnl"] = _daily_pnl(s, a["id"]); a["pnl_at"] = time.time()
        if a["pnl"] is None:
            errors.append(a["id"])

    with ThreadPoolExecutor(max_workers=4) as ex:
        futs = [ex.submit(one, a) for a in need]
        for f in futs:
            if should_cancel():
                break
            f.result()
            done += 1
            progress(done=done, message=f"PnL {done}/{len(need)}")
    snap = {"fetched_at": now, "alphas": alphas, "errors": errors}
    _save(snap)
    return {"alphas": len(alphas), "no_pnl": len(errors),
            "scopes": sorted({a["scope"] for a in alphas})}


def list_submitted_light(progress=None, should_cancel=lambda: False) -> list:
    """Submitted alphas (normalised) WITHOUT downloading their PnL: used by Clone and swap when no snapshot exists."""
    s = engine.require_session()
    raws = _list_submitted(s, progress or (lambda **k: None), should_cancel)
    return [a for a in (X.normalise(r) for r in raws) if a]


def make_plan(cfg: dict | None = None, current: dict | None = None) -> dict:
    snap = load_snapshot()
    alphas = snap.get("alphas", [])
    if not alphas:
        return {"empty": True, "message": "No snapshot yet. Press Refresh to read your submitted alphas from BRAIN.",
                "fetched_at": None}
    if current:
        alphas = [{**a, "points": int(current.get(a["id"], 0))} for a in alphas]
    res = P.plan_account(alphas, cfg)
    res["fetched_at"] = snap.get("fetched_at")
    res["no_pnl"] = len(snap.get("errors", []))
    res["points_read_from_brain"] = any(int(a.get("points") or 0) > 0 for a in snap.get("alphas", []))
    # light per-scope tags for the UI
    for sc in res["scopes"]:
        sc["types"] = dict(_count(a["type"] for a in alphas if a["scope"] == sc["scope"]))
    return res


def _count(it):
    d: dict = {}
    for x in it:
        d[x] = d.get(x, 0) + 1
    return d.items()


# ── implement (write the points to BRAIN) ────────────────────────────────────────────

_JOURNAL = get_settings().data_dir / "osmosis_journal.json"


def _journal() -> list:
    try:
        return json.loads(_JOURNAL.read_text())
    except Exception:
        return []


def _save_journal(j: list) -> None:
    _JOURNAL.write_text(json.dumps(j[-30:]))


def journal() -> list:
    return [{"id": e["id"], "t": e["t"], "writes": len(e["changes"]), "undone": e.get("undone", False),
             "scopes": e.get("scopes", [])} for e in reversed(_journal())]


def _set_points(s, alpha_id: str, points: int | None):
    """PATCH one alpha's Osmosis points (None clears them). Waits out a 429."""
    for _ in range(6):
        r = ace.set_alpha_properties(s, alpha_id, osmosis_points=points)
        if r.status_code == 429:
            time.sleep(float(r.headers.get("Retry-After", 3))); continue
        return r
    return r


def _read_points(s, alpha_id: str) -> int:
    r = s.get(ace.brain_api_url + "/alphas/" + alpha_id, timeout=30)
    if r.status_code // 100 != 2:
        raise RuntimeError(f"could not read {alpha_id} back (BRAIN answered {r.status_code})")
    return X.points_of(r.json())


def _apply_changes(s, changes: list, progress, should_cancel) -> tuple[list, list]:
    """changes = [{id, new, old}] with new/old as ints (0 = none). The first one is a canary: it
    is read back, and if BRAIN did not take the value we stop before touching anything else."""
    done, failed = [], []
    for n, c in enumerate(changes):
        if should_cancel():
            break
        target = c["new"] if c["new"] > 0 else None
        r = _set_points(s, c["id"], target)
        if r.status_code // 100 != 2:
            msg = f"{c['id']}: BRAIN answered {r.status_code} {str(getattr(r, 'text', ''))[:120]}"
            failed.append(msg)
            if n == 0:
                raise RuntimeError("The first write was refused, so nothing else was changed. " + msg)
            continue
        if n == 0:
            got = _read_points(s, c["id"])
            if got != c["new"]:
                raise RuntimeError(f"BRAIN accepted the first write but did not keep it ({c['id']} reads back {got}, "
                                   f"expected {c['new']}). Nothing else was changed; "
                                   "the Osmosis points field may work differently on your account.")
        done.append(c)
        progress(done=len(done), message=f"wrote {len(done)}/{len(changes)}")
        time.sleep(0.25)
    return done, failed


def implement(edits: dict, current: dict | None, progress, should_cancel, dry_run: bool = False) -> dict:
    from app.osmosis import apply as A
    snap = load_snapshot()
    alphas = snap.get("alphas", [])
    d = A.validate_and_diff(alphas, edits, None, current)
    if not d["ok"]:
        raise ValueError("; ".join(d["errors"]))
    changes = [{"id": w["id"], "scope": w["scope"], "old": w["old"], "new": w["new"]} for w in d["writes"]] + \
              [{"id": c["id"], "scope": c["scope"], "old": c["old"], "new": 0} for c in d["clears"]]
    if dry_run:
        return {"dry_run": True, "writes": len(d["writes"]), "clears": len(d["clears"]),
                "unchanged": d["unchanged"], "scopes": d["scopes"]}
    if not changes:
        return {"written": 0, "cleared": 0, "failed": [], "message": "BRAIN already has exactly these points."}
    s = engine.require_session()
    progress(total=len(changes), done=0, message="writing points to BRAIN…")
    done, failed = _apply_changes(s, changes, progress, should_cancel)
    if done:
        j = _journal()
        j.append({"id": f"{int(time.time())}", "t": time.time(), "scopes": d["scopes"], "changes": done})
        _save_journal(j)
    # verify: list everything again and check each scope's total
    verified = None
    try:
        rows = [a for a in (X.normalise(r) for r in _list_submitted(s, lambda **k: None, should_cancel)) if a]
        pts = {a["id"]: a["points"] for a in rows}
        if any(pts.values()):
            verified = {}
            for sc in d["scopes"]:
                tot = sum(p for i, p in pts.items() if next((a for a in rows if a["id"] == i), {}).get("scope") == sc)
                verified[sc] = {"total": tot, "ok": tot == P.DEFAULTS["total"]}
        snap2 = load_snapshot()
        for a in snap2.get("alphas", []):
            if a["id"] in pts:
                a["points"] = pts[a["id"]]
        _save(snap2)
    except Exception as e:  # noqa: BLE001
        failed.append(f"could not re-read points to verify: {str(e)[:120]}")
    return {"written": sum(1 for c in done if c["new"] > 0), "cleared": sum(1 for c in done if c["new"] == 0),
            "failed": failed, "verified": verified, "undo_available": bool(done)}


def undo(progress, should_cancel) -> dict:
    j = _journal()
    entry = next((e for e in reversed(j) if not e.get("undone")), None)
    if not entry:
        raise ValueError("Nothing to undo.")
    s = engine.require_session()
    back = [{"id": c["id"], "old": c["new"], "new": c["old"]} for c in entry["changes"]]
    progress(total=len(back), done=0, message="restoring previous points…")
    done, failed = _apply_changes(s, back, progress, should_cancel)
    if len(done) == len(back):
        entry["undone"] = True
        _save_journal(j)
    return {"restored": len(done), "failed": failed}
