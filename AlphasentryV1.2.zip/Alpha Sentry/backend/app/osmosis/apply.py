"""Validate an (edited) allocation and work out exactly which alphas must be written. Pure."""
from __future__ import annotations

from app.osmosis.planner import DEFAULTS


def validate_and_diff(alphas: list, edits: dict, cfg: dict | None = None, current: dict | None = None) -> dict:
    """alphas: snapshot list (id, scope, points). edits: {scope: {alpha_id: points}}.
    current: optional {alpha_id: points} that overrides what the snapshot knows.
    Returns {ok, errors, writes:[{id,scope,old,new}], clears:[{id,scope,old}], scopes:[...], unchanged}."""
    cfg = {**DEFAULTS, **(cfg or {})}
    by_id = {a["id"]: a for a in alphas}
    cur = {a["id"]: int((current or {}).get(a["id"], a.get("points") or 0)) for a in alphas}
    errors, writes, clears, scopes, unchanged = [], [], [], [], 0
    for scope, pts in sorted((edits or {}).items()):
        want: dict = {}
        for aid, v in (pts or {}).items():
            a = by_id.get(aid)
            if a is None:
                errors.append(f"{scope}: {aid} is not one of your submitted alphas"); continue
            if a["scope"] != scope:
                errors.append(f"{scope}: {aid} belongs to {a['scope']}"); continue
            try:
                n = int(v)
            except (TypeError, ValueError):
                errors.append(f"{scope}: points for {aid} is not a whole number"); continue
            if n < 0 or n > cfg["total"]:
                errors.append(f"{scope}: points for {aid} must be between 0 and {cfg['total']:,}"); continue
            if n > 0:
                want[aid] = n
        total = sum(want.values())
        if len(want) < cfg["min_alphas"]:
            errors.append(f"{scope}: needs at least {cfg['min_alphas']} alphas with points (has {len(want)})")
        if total != cfg["total"]:
            errors.append(f"{scope}: points add up to {total:,}, they must be exactly {cfg['total']:,} "
                          f"({'over' if total > cfg['total'] else 'short'} by {abs(total - cfg['total']):,})")
        scopes.append(scope)
        for aid, n in want.items():
            if cur.get(aid, 0) == n:
                unchanged += 1
            else:
                writes.append({"id": aid, "scope": scope, "old": cur.get(aid, 0), "new": n})
        for a in alphas:
            if a["scope"] == scope and a["id"] not in want and cur.get(a["id"], 0) > 0:
                clears.append({"id": a["id"], "scope": scope, "old": cur[a["id"]]})
    if len(scopes) < cfg["min_scopes"]:
        errors.append(f"BRAIN needs at least {cfg['min_scopes']} scopes allocated; this has {len(scopes)}")
    return {"ok": not errors, "errors": errors, "writes": writes, "clears": clears,
            "scopes": scopes, "unchanged": unchanged}
