"""Turn a raw BRAIN alpha record into the planner's alpha dict. Pure, defensive: BRAIN's fields
vary by alpha type and over time, so every lookup tolerates a missing value."""
from __future__ import annotations

import re

from app.osmosis.planner import scope_of

_PRICE_FIELDS = {"open", "high", "low", "close", "volume", "vwap", "returns", "adv20", "cap", "sharesout",
                 "dividend", "split"}
_WORDS = {"industry", "subindustry", "sector", "market", "country", "exchange", "currency", "true", "false",
          "std", "k", "lag", "dense", "rettype", "driver", "sigma", "range", "filter", "mode", "scale",
          "rate", "constant", "nan", "inf"}
_POINT_KEYS = ("osmosisPoints", "osmosis_points", "osmosisPoint", "points")


def _get(d, *path):
    for k in path:
        if not isinstance(d, dict):
            return None
        d = d.get(k)
    return d


def _num(v):
    try:
        f = float(v)
        return None if f != f else f
    except (TypeError, ValueError):
        return None


def expression_of(raw: dict) -> str:
    for path in (("regular", "code"), ("combo", "code"), ("selection", "code"), ("code",)):
        v = _get(raw, *path)
        if isinstance(v, str) and v.strip():
            return v
    return ""


def operators_in(expr: str) -> list:
    return sorted({m.lower() for m in re.findall(r"([A-Za-z_][A-Za-z0-9_]*)\s*\(", expr or "")})


def fields_in(expr: str) -> list:
    """Identifiers that are not operators, group names or keyword names: the datafields."""
    ops = {o for o in re.findall(r"([A-Za-z_][A-Za-z0-9_]*)\s*\(", expr or "")}
    out = []
    for m in re.finditer(r"(?<![A-Za-z0-9_.])([A-Za-z_][A-Za-z0-9_]*)(?!\s*[(=A-Za-z0-9_])", expr or ""):
        t = m.group(1)
        if t in ops or t.lower() in _WORDS:
            continue
        if t not in out:
            out.append(t)
    return out


def dataset_of(expr: str) -> str | None:
    """Best guess at the dataset from the first datafield (BRAIN ids start with the dataset code,
    e.g. oth143_..., anl4_..., fnd6_...). Plain price/volume fields group as 'pv'."""
    fl = fields_in(expr)
    if not fl:
        return None
    f = fl[0]
    if f.lower() in _PRICE_FIELDS:
        return "pv"
    return f.split("_")[0].lower() if "_" in f else f.lower()


def category_of(raw: dict) -> str | None:
    c = raw.get("category")
    if isinstance(c, dict):
        return c.get("name") or c.get("id")
    if isinstance(c, str):
        return c
    for x in raw.get("classifications") or []:
        if isinstance(x, dict) and "CATEGORY" in str(x.get("id", "")).upper():
            return x.get("name") or x.get("id")
    return None


def points_of(raw: dict) -> int:
    for k in _POINT_KEYS:
        v = _num(raw.get(k))
        if v is not None:
            return int(v)
    v = _num(_get(raw, "osmosis", "points"))
    return int(v) if v is not None else 0


def is_submitted(raw: dict) -> bool:
    return (str(raw.get("stage", "")).upper() == "OS" or str(raw.get("status", "")).upper() == "ACTIVE"
            or bool(raw.get("dateSubmitted")))


def normalise(raw: dict) -> dict | None:
    st = raw.get("settings") or {}
    if not raw.get("id") or not st.get("region"):
        return None
    expr = expression_of(raw)
    inv = _get(raw, "is", "investabilityConstrained")
    return {
        "id": raw["id"], "type": raw.get("type") or "REGULAR", "language": str(st.get("language") or "").upper(),
        "scope": scope_of(st.get("region"), st.get("delay")),
        "region": st.get("region"), "delay": st.get("delay"),
        "sharpe": _num(_get(raw, "is", "sharpe")), "fitness": _num(_get(raw, "is", "fitness")),
        "turnover": _num(_get(raw, "is", "turnover")),
        "inv_sharpe": _num(inv.get("sharpe")) if isinstance(inv, dict) else None,
        "neutralization": st.get("neutralization"),
        "dataset": dataset_of(expr), "category": category_of(raw),
        "ops": operators_in(expr), "expr": expr[:4000],
        "tags": raw.get("tags") or [], "points": points_of(raw),
        "date_submitted": raw.get("dateSubmitted"),
    }
