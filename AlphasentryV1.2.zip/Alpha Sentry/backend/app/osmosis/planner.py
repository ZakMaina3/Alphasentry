"""Pure planning logic (no network, no database).

An *alpha* is a dict:
  id, scope ("USA D1"), sharpe, turnover, inv_sharpe (investability-constrained Sharpe or None),
  neutralization, dataset, category, ops (list of operator names), pnl ({date: daily pnl} or None),
  points (current Osmosis points, int, may be 0).

Rules come from BRAIN's Osmosis article: >=10 alphas per scope, exactly 100,000 points per scope,
>=3 scopes, drop alphas that lose ~60% of Sharpe under investability constraints (unless unique),
avoid turnover above 20% unless robust, prune highly correlated alphas, diversify datasets /
categories / operators / neutralizations, move gradually.
"""
from __future__ import annotations

import math
from collections import Counter

import numpy as np

DEFAULTS = {
    "min_alphas": 10,          # qualifying alphas needed for a scope to be planned
    "min_scopes": 3,           # BRAIN needs allocations in at least this many scopes
    "total": 100_000,          # points per scope, exactly
    "corr_max": 0.70,          # prune an alpha this correlated with a better one already chosen
    "inv_drop": 0.60,          # drop if Sharpe falls this much (or more) under investability constraints
    "inv_ok": 1.0,             # investability-constrained Sharpe that counts as "robust"
    "turnover_hi": 0.20,
    "recent_days": 252,
    "min_overlap": 60,         # days two alphas must share before their correlation is trusted
    "max_alpha_w": 0.20,       # share caps inside a scope
    "max_dataset_w": 0.35,
    "max_category_w": 0.50,
    "max_neut_w": 0.60,
    "max_hi_turn_w": 0.20,
    "max_op_w": 0.70,          # for signature operators (ones most alphas do not all share)
    "max_move": 20_000,        # most points moved per scope in one change (gradual changes)
    "min_scope_sharpe": 1.0,   # a scope whose combo is weaker than this is flagged weak
    "top_n": 10,               # only the best N (after de-correlation) of each scope get points; 0 = no limit
    "consultant_start": "",    # YYYY-MM-DD: USA alphas submitted before this date are not compensated and get no points ("" = rule off)
    "uncompensated_region": "USA",
}


def is_uncompensated(a: dict, cfg: dict) -> bool:
    """A USA alpha submitted before you became a consultant earns nothing, so it must not hold Osmosis points."""
    start = str(cfg.get("consultant_start") or "").strip()[:10]
    when = str(a.get("date_submitted") or "").strip()[:10]
    region = str(a.get("region") or str(a.get("scope", "")).split(" ")[0]).upper()
    return bool(start and when and region == str(cfg.get("uncompensated_region") or "USA").upper() and when < start)


# ── helpers ──────────────────────────────────────────────────────────────────────────

def scope_of(region: str, delay) -> str:
    return f"{str(region or '?').upper()} D{int(delay) if delay is not None else '?'}"


def _sharpe(x: np.ndarray) -> float | None:
    if x.size < 20:
        return None
    sd = float(np.std(x, ddof=1))
    return None if sd <= 0 else float(np.mean(x) / sd * math.sqrt(252))


def _series(a: dict) -> dict:
    return a.get("pnl") or {}


def _matrix(alphas: list, dates: list | None = None):
    """Aligned daily-PnL matrix (rows = dates, cols = alphas); missing days are NaN."""
    if dates is None:
        ds = set()
        for a in alphas:
            ds.update(_series(a))
        dates = sorted(ds)
    idx = {d: i for i, d in enumerate(dates)}
    m = np.full((len(dates), len(alphas)), np.nan)
    for j, a in enumerate(alphas):
        for d, v in _series(a).items():
            i = idx.get(d)
            if i is not None and v is not None:
                m[i, j] = float(v)
    return dates, m


def corr(x: np.ndarray, y: np.ndarray, min_overlap: int) -> float | None:
    ok = ~(np.isnan(x) | np.isnan(y))
    if ok.sum() < min_overlap:
        return None
    a, b = x[ok], y[ok]
    if np.std(a) == 0 or np.std(b) == 0:
        return None
    return float(np.corrcoef(a, b)[0, 1])


# ── 1. screen each alpha ─────────────────────────────────────────────────────────────

def screen(alphas: list, cfg: dict) -> dict:
    """alpha id -> {verdict: keep|watch|drop, reasons: [...], quality, recent_sharpe}."""
    ds_count = Counter(a.get("dataset") for a in alphas if a.get("dataset"))
    out = {}
    for a in alphas:
        reasons, verdict = [], "keep"
        if is_uncompensated(a, cfg):
            out[a["id"]] = {"verdict": "drop", "quality": 0.0, "recent_sharpe": None,
                            "reasons": [f"uncompensated: submitted {str(a.get('date_submitted'))[:10]}, before you became a consultant ({cfg['consultant_start']})"]}
            continue
        sh = a.get("sharpe")
        inv = a.get("inv_sharpe")
        tu = a.get("turnover")
        series = _series(a)
        recent = None
        if series:
            ds = sorted(series)[-cfg["recent_days"]:]
            recent = _sharpe(np.array([series[d] for d in ds if series[d] is not None], dtype=float))

        if sh is None or sh <= 0:
            verdict = "drop"; reasons.append("Sharpe is not positive")
        if verdict != "drop" and inv is not None and sh and (1 - inv / sh) >= cfg["inv_drop"]:
            unique = a.get("dataset") and ds_count[a["dataset"]] == 1
            if unique:
                verdict = "watch"
                reasons.append(f"loses {100 * (1 - inv / sh):.0f}% of Sharpe under investability constraints, kept: only alpha on its dataset")
            else:
                verdict = "drop"
                reasons.append(f"loses {100 * (1 - inv / sh):.0f}% of Sharpe under investability constraints")
        if verdict != "drop" and tu is not None and tu > cfg["turnover_hi"]:
            if inv is not None and inv < cfg["inv_ok"]:
                verdict = "drop"; reasons.append(f"turnover {tu:.0%} and constrained Sharpe {inv:.2f} is not robust")
            elif inv is None:
                verdict = "watch"; reasons.append(f"turnover {tu:.0%} and no investability-constrained Sharpe to confirm it")
        if verdict != "drop" and recent is not None and recent < 0:
            verdict = "watch"; reasons.append(f"recent PnL is negative (Sharpe {recent:.2f})")
        base = inv if (inv is not None and inv > 0) else (sh or 0.0)
        q = max(0.01, float(base)) * (0.7 if verdict == "watch" else 1.0)
        out[a["id"]] = {"verdict": verdict, "reasons": reasons, "quality": round(q, 4),
                        "recent_sharpe": None if recent is None else round(recent, 3)}
    return out


# ── 2. choose a diversified, de-correlated set ───────────────────────────────────────

def select(alphas: list, scr: dict, cfg: dict) -> tuple[list, list]:
    """Greedy by quality, skipping any alpha too correlated with one already chosen.
    Returns (selected alphas, pruned [{id, reason}])."""
    cand = sorted((a for a in alphas if scr[a["id"]]["verdict"] != "drop"),
                  key=lambda a: -scr[a["id"]]["quality"])
    _, m = _matrix(cand)
    chosen_idx, pruned = [], []
    for j, a in enumerate(cand):
        worst, who = None, None
        for k in chosen_idx:
            c = corr(m[:, j], m[:, k], cfg["min_overlap"])
            if c is not None and (worst is None or c > worst):
                worst, who = c, cand[k]["id"]
        if worst is not None and worst > cfg["corr_max"]:
            pruned.append({"id": a["id"], "reason": f"correlation {worst:.2f} with {who}"})
        elif int(cfg.get("top_n") or 0) > 0 and len(chosen_idx) >= int(cfg["top_n"]):
            pruned.append({"id": a["id"], "reason": f"not among the best {int(cfg['top_n'])} in this scope"})
        else:
            chosen_idx.append(j)
    return [cand[j] for j in chosen_idx], pruned


# ── 3. weights ───────────────────────────────────────────────────────────────────────

def _solve(w: np.ndarray, caps: list) -> tuple[np.ndarray, bool]:
    w = np.asarray(w, dtype=float)
    w = w / w.sum()
    frozen = np.zeros(len(w), dtype=bool)
    for _ in range(200):
        violated = False
        for idx, cap, _l in caps:
            s = w[idx].sum()
            if s > cap + 1e-9:
                w[idx] *= cap / s
                frozen[idx] = True
                violated = True
        resid = 1.0 - w.sum()
        free = ~frozen
        if abs(resid) < 1e-12 or not free.any() or w[free].sum() <= 0:
            break
        w[free] += resid * w[free] / w[free].sum()
        if not violated:
            break
    ok = abs(1 - w.sum()) < 1e-6 and all(w[idx].sum() <= cap + 1e-6 for idx, cap, _l in caps)
    if abs(1 - w.sum()) > 1e-9:
        w = w / w.sum()
    return w, ok


def apply_caps(w: np.ndarray, caps: list) -> tuple[np.ndarray, list]:
    """Scale groups down to their caps and hand the excess to everything else, repeatedly.
    caps = [(index array, cap share, label)]. A cap that cannot be met (for example every alpha
    shares one neutralization) is set aside, most-violated first, and reported instead of
    spoiling the others. Returns (weights summing to 1, labels of caps that had to be relaxed)."""
    caps = [c if len(c) == 3 else (c[0], c[1], "") for c in caps]
    relaxed: list = []
    while True:
        w2, ok = _solve(w, caps)
        if ok:
            return w2, relaxed
        multi = [c for c in caps if len(c[0]) > 1 and w2[c[0]].sum() > c[1] + 1e-6]
        if not multi:                                  # only per-alpha caps left (too few alphas)
            return w2, relaxed + ["per-alpha cap"]
        worst = max(multi, key=lambda c: w2[c[0]].sum() - c[1])
        relaxed.append(worst[2])
        caps = [c for c in caps if c is not worst]


def _caps_for(sel: list, cfg: dict) -> list:
    n = len(sel)
    caps = [(np.array([i]), cfg["max_alpha_w"], "alpha") for i in range(n)]

    def group(key, cap, skip_empty=True):
        d: dict = {}
        for i, a in enumerate(sel):
            v = a.get(key)
            if v:
                d.setdefault(v, []).append(i)
        for name, ids in d.items():
            caps.append((np.array(ids), cap, f"{key} {name}"))

    group("dataset", cfg["max_dataset_w"])
    group("category", cfg["max_category_w"])
    group("neutralization", cfg["max_neut_w"])
    hi = [i for i, a in enumerate(sel) if (a.get("turnover") or 0) > cfg["turnover_hi"]]
    if hi:
        caps.append((np.array(hi), cfg["max_hi_turn_w"], "turnover above 20%"))
    ops: dict = {}
    for i, a in enumerate(sel):
        for o in set(a.get("ops") or []):
            ops.setdefault(o, []).append(i)
    for o, ids in ops.items():
        if len(ids) < 0.8 * n:               # ubiquitous operators (rank, ...) cannot be avoided
            caps.append((np.array(ids), cfg["max_op_w"], f"operator {o}"))
    return caps


def raw_weights(sel: list, scr: dict, m: np.ndarray) -> np.ndarray:
    """Inverse volatility (equal if there is no PnL), tilted gently by sqrt(quality)."""
    vol = np.array([np.nanstd(m[:, j], ddof=1) if np.sum(~np.isnan(m[:, j])) > 20 else np.nan
                    for j in range(len(sel))])
    if np.all(np.isnan(vol)) or np.nanmin(vol) <= 0:
        inv = np.ones(len(sel))
    else:
        vol = np.where(np.isnan(vol), np.nanmedian(vol), vol)
        inv = 1.0 / vol
    q = np.array([max(scr[a["id"]]["quality"], 0.01) for a in sel])
    return inv * np.sqrt(q)


def build_weights(sel: list, scr: dict, cfg: dict, m: np.ndarray | None = None):
    if m is None:
        _, m = _matrix(sel)
    return apply_caps(raw_weights(sel, scr, m), _caps_for(sel, cfg))


def round_points(w, total: int) -> list:
    """Whole points that sum to exactly `total` (largest remainder)."""
    w = np.asarray(w, dtype=float)
    raw = w / w.sum() * total
    pts = np.floor(raw).astype(int)
    short = int(total - pts.sum())
    order = np.argsort(-(raw - pts))
    for i in order[:short]:
        pts[i] += 1
    return [int(x) for x in pts]


def move_towards(current: dict, target: dict, max_move: int, total: int) -> dict:
    """Step from the current allocation toward the target, moving at most `max_move` points.
    Both sum to `total`, so the result does too."""
    ids = set(current) | set(target)
    cur = {i: current.get(i, 0) for i in ids}
    tgt = {i: target.get(i, 0) for i in ids}
    moved = sum(max(0, tgt[i] - cur[i]) for i in ids)
    if moved <= max_move or moved == 0:
        return {i: v for i, v in tgt.items() if v}
    t = max_move / moved
    raw = {i: cur[i] + t * (tgt[i] - cur[i]) for i in ids}
    pts = round_points(np.array([raw[i] for i in ids]), total)
    return {i: p for i, p in zip(ids, pts) if p}


# ── 4. how good is a combo ───────────────────────────────────────────────────────────

def combo_stats(sel: list, w: np.ndarray) -> dict:
    dates, m = _matrix(sel)
    if not dates:
        return {"sharpe": None, "max_drawdown_vs_equal": None}
    mm = np.nan_to_num(m)
    have = (~np.isnan(m)).any(axis=1)
    mm, d = mm[have], np.array(dates)[have]
    if len(mm) < 20:
        return {"sharpe": None, "max_drawdown_vs_equal": None}

    def stats(weights):
        p = mm @ weights
        cum = np.cumsum(p)
        dd = float(np.max(np.maximum.accumulate(cum) - cum))
        return _sharpe(p), dd
    sh, dd = stats(np.asarray(w))
    sh_eq, dd_eq = stats(np.ones(len(sel)) / len(sel))
    return {"sharpe": None if sh is None else round(sh, 3),
            "sharpe_equal_weight": None if sh_eq is None else round(sh_eq, 3),
            "max_drawdown_vs_equal": None if dd_eq <= 0 else round(dd / dd_eq, 3),
            "days": int(len(mm))}


def holdout(sel: list, scr: dict, cfg: dict, frac: float = 0.25) -> dict | None:
    """Fit the weights on the older part of the history and judge them on the newer part."""
    dates, m = _matrix(sel)
    if len(dates) < 120:
        return None
    cut = int(len(dates) * (1 - frac))
    train, test = np.nan_to_num(m[:cut]), np.nan_to_num(m[cut:])
    w, _ = apply_caps(raw_weights(sel, scr, np.where(np.isnan(m[:cut]), np.nan, m[:cut])), _caps_for(sel, cfg))
    eq = np.ones(len(sel)) / len(sel)
    a, b = _sharpe(test @ w), _sharpe(test @ eq)
    if a is None or b is None:
        return None
    return {"plan": round(a, 3), "equal_weight": round(b, 3), "days": int(len(test))}


# ── 5. plan a scope / the whole account ──────────────────────────────────────────────

def plan_scope(scope: str, alphas: list, cfg: dict) -> dict:
    scr = screen(alphas, cfg)
    sel, pruned = select(alphas, scr, cfg)
    dropped = [{"id": a["id"], "reason": "; ".join(scr[a["id"]]["reasons"])} for a in alphas
               if scr[a["id"]]["verdict"] == "drop"]
    rows = [{"id": a["id"], "verdict": scr[a["id"]]["verdict"], "reasons": scr[a["id"]]["reasons"],
             "recent_sharpe": scr[a["id"]]["recent_sharpe"], "sharpe": a.get("sharpe"),
             "turnover": a.get("turnover"), "dataset": a.get("dataset"), "category": a.get("category"),
             "points_now": int(a.get("points") or 0)} for a in alphas]
    n_uncomp = sum(1 for a in alphas if is_uncompensated(a, cfg))
    res = {"scope": scope, "uncompensated": n_uncomp, "alphas": len(alphas), "passing": len(sel), "needed": cfg["min_alphas"],
           "eligible": len(sel) >= cfg["min_alphas"], "dropped": dropped, "pruned": pruned,
           "datasets": dict(Counter(a.get("dataset") or "unknown" for a in sel)), "rows": rows,
           "current_total": int(sum(int(a.get("points") or 0) for a in alphas))}
    if not res["eligible"]:
        res["short_by"] = cfg["min_alphas"] - len(sel)
        res["plan"] = []
        return res
    w, relaxed = build_weights(sel, scr, cfg)
    target = dict(zip([a["id"] for a in sel], round_points(w, cfg["total"])))
    cur = {a["id"]: int(a.get("points") or 0) for a in alphas if int(a.get("points") or 0) > 0}
    holds_uncomp = any(is_uncompensated(a, cfg) for a in alphas if int(a.get("points") or 0) > 0)
    # points sitting on uncompensated alphas earn nothing, so they are released at once instead of being moved gradually
    anchored = sum(cur.values()) == cfg["total"] and not holds_uncomp
    final = move_towards(cur, target, cfg["max_move"], cfg["total"]) if anchored else target
    by_id = {a["id"]: a for a in alphas}
    plan_w = np.array([final.get(a["id"], 0) for a in sel], dtype=float)
    stats = combo_stats(sel, plan_w / max(plan_w.sum(), 1))
    res.update({
        "released_uncompensated": holds_uncomp, "caps_relaxed": relaxed, "gradual": anchored and final != target,
        "plan": sorted(({"id": i, "points": p, "was": cur.get(i, 0),
                         "dataset": by_id[i].get("dataset"), "verdict": scr[i]["verdict"] if i in scr else "keep"}
                        for i, p in final.items() if i in by_id), key=lambda r: -r["points"]),
        "target": [{"id": i, "points": p} for i, p in sorted(target.items(), key=lambda kv: -kv[1])],
        "stats": stats, "holdout": holdout(sel, scr, cfg),
        "weak": stats["sharpe"] is not None and stats["sharpe"] < cfg["min_scope_sharpe"],
    })
    res["remove_from_allocation"] = [i for i in cur if i not in final]
    return res


def plan_account(alphas: list, cfg: dict | None = None) -> dict:
    cfg = {**DEFAULTS, **(cfg or {})}
    groups: dict = {}
    for a in alphas:
        groups.setdefault(a["scope"], []).append(a)
    scopes = [plan_scope(s, groups[s], cfg) for s in sorted(groups)]
    elig = [s for s in scopes if s["eligible"]]
    good = [s for s in elig if not s["weak"]]
    chosen = list(good)
    topped = []
    if len(chosen) < cfg["min_scopes"]:
        rest = sorted((s for s in elig if s["weak"]), key=lambda s: -(s["stats"]["sharpe"] or -9))
        for s in rest[: cfg["min_scopes"] - len(chosen)]:
            chosen.append(s); topped.append(s["scope"])
    for s in scopes:
        s["allocate"] = s in chosen
    valid = len(chosen) >= cfg["min_scopes"]
    note = ""
    if not str(cfg.get("consultant_start") or "").strip():
        note = " (Consultant start date not set: USA alphas from before it are NOT excluded yet.)"
    if valid:
        msg = f"Allocate {len(chosen)} scope(s): " + ", ".join(s["scope"] for s in chosen) + "."
        if topped:
            msg += f" {', '.join(topped)} added only to reach the {cfg['min_scopes']}-scope minimum (its combo is weak)."
        weak_left = [s["scope"] for s in elig if s["weak"] and s["scope"] not in topped]
        if weak_left:
            msg += f" Left out as weak: {', '.join(weak_left)} (only allocated scopes count toward your daily rank)."
    else:
        msg = (f"No valid allocation yet: {len(elig)} scope(s) have {cfg['min_alphas']}+ qualifying alphas, "
               f"BRAIN needs {cfg['min_scopes']}. Closest: " +
               ", ".join(f"{s['scope']} (needs {s['short_by']} more)" for s in
                         sorted((s for s in scopes if not s["eligible"]), key=lambda s: s["short_by"])[:4]) + ".")
    msg += note
    return {"valid": valid, "message": msg, "min_scopes": cfg["min_scopes"], "scopes": scopes,
            "config": cfg, "alphas": len(alphas)}
