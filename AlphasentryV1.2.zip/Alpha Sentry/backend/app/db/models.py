"""ORM models for the knowledge database.

Kept intentionally small but expressive: datasets and fields are stored per (id, region,
delay) so the same concept seen in different regions accumulates as separate rows the
similarity layer can link. JSON columns hold flexible payloads (selected ids, hypotheses)
without a table per shape.
"""

from __future__ import annotations

import time

from sqlalchemy import Boolean, Float, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


def _now() -> float:
    return time.time()


class Dataset(Base):
    __tablename__ = "datasets"
    __table_args__ = (UniqueConstraint("dataset_id", "region", "delay", name="uq_dataset_region_delay"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    dataset_id: Mapped[str] = mapped_column(String, index=True)
    region: Mapped[str] = mapped_column(String, index=True)
    delay: Mapped[int] = mapped_column(Integer, index=True)
    instrument: Mapped[str] = mapped_column(String, default="EQUITY")
    universe: Mapped[str] = mapped_column(String, default="")
    category: Mapped[str] = mapped_column(String, default="", index=True)
    name: Mapped[str] = mapped_column(String, default="")
    description: Mapped[str] = mapped_column(Text, default="")
    coverage: Mapped[float] = mapped_column(Float, default=0.0)
    value_score: Mapped[float] = mapped_column(Float, default=0.0)
    alpha_count: Mapped[int] = mapped_column(Integer, default=0)
    fetch_count: Mapped[int] = mapped_column(Integer, default=1)
    first_seen: Mapped[float] = mapped_column(Float, default=_now)
    last_seen: Mapped[float] = mapped_column(Float, default=_now)


class Field(Base):
    __tablename__ = "fields"
    __table_args__ = (UniqueConstraint("field_id", "region", "delay", name="uq_field_region_delay"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    field_id: Mapped[str] = mapped_column(String, index=True)
    dataset_id: Mapped[str] = mapped_column(String, index=True)
    region: Mapped[str] = mapped_column(String, index=True)
    delay: Mapped[int] = mapped_column(Integer, index=True)
    type: Mapped[str] = mapped_column(String, default="MATRIX")
    prefix: Mapped[str] = mapped_column(String, default="", index=True)
    description: Mapped[str] = mapped_column(Text, default="")
    alpha_count: Mapped[int] = mapped_column(Integer, default=0)
    is_virgin: Mapped[bool] = mapped_column(Boolean, default=False)
    first_seen: Mapped[float] = mapped_column(Float, default=_now)
    last_seen: Mapped[float] = mapped_column(Float, default=_now)


class Usage(Base):
    """Per-user usage counters (operators / fields / categories / datasets / regions), the
    substrate for the diversity engine. Populated as generation and simulation land."""
    __tablename__ = "usage"
    __table_args__ = (UniqueConstraint("kind", "key", "region", name="uq_usage"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    kind: Mapped[str] = mapped_column(String, index=True)     # operator|field|category|dataset|region
    key: Mapped[str] = mapped_column(String, index=True)
    region: Mapped[str] = mapped_column(String, default="", index=True)
    count: Mapped[int] = mapped_column(Integer, default=0)
    sum_abs_fitness: Mapped[float] = mapped_column(Float, default=0.0)
    last_at: Mapped[float] = mapped_column(Float, default=_now)


class ResearchSession(Base):
    __tablename__ = "research_sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[float] = mapped_column(Float, default=_now, index=True)
    category: Mapped[str] = mapped_column(String, default="")
    region: Mapped[str] = mapped_column(String, default="")
    delay: Mapped[int] = mapped_column(Integer, default=1)
    goal: Mapped[str] = mapped_column(Text, default="")
    datasets_json: Mapped[str] = mapped_column(Text, default="[]")
    fields_json: Mapped[str] = mapped_column(Text, default="[]")
    provider: Mapped[str] = mapped_column(String, default="")
    model: Mapped[str] = mapped_column(String, default="")
    paper_name: Mapped[str] = mapped_column(String, default="")
    hypotheses_json: Mapped[str] = mapped_column(Text, default="[]")
    expressions_json: Mapped[str] = mapped_column(Text, default="[]")
    templates_json: Mapped[str] = mapped_column(Text, default="[]")


class SimResult(Base):
    """A simulated alpha and its verdict against the success gate. `passed_gate` and
    `gate_reasons` capture exactly which metrics passed/failed, so the success-rate engine
    and the donation trigger can reason over real, per-metric outcomes."""
    __tablename__ = "sim_results"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[float] = mapped_column(Float, default=_now, index=True)
    alpha_id: Mapped[str] = mapped_column(String, default="", index=True)
    expression: Mapped[str] = mapped_column(Text, default="")
    region: Mapped[str] = mapped_column(String, default="", index=True)
    delay: Mapped[int] = mapped_column(Integer, default=1)
    universe: Mapped[str] = mapped_column(String, default="")
    neutralization: Mapped[str] = mapped_column(String, default="")
    sharpe: Mapped[float] = mapped_column(Float, nullable=True)
    fitness: Mapped[float] = mapped_column(Float, nullable=True)
    turnover: Mapped[float] = mapped_column(Float, nullable=True)
    returns: Mapped[float] = mapped_column(Float, nullable=True)
    margin: Mapped[float] = mapped_column(Float, nullable=True)
    drawdown: Mapped[float] = mapped_column(Float, nullable=True)
    self_corr: Mapped[float] = mapped_column(Float, nullable=True)
    prod_corr: Mapped[float] = mapped_column(Float, nullable=True)
    powerpool_corr: Mapped[float] = mapped_column(Float, nullable=True)
    tests_failed: Mapped[int] = mapped_column(Integer, default=0)
    passed_gate: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    gate_reasons: Mapped[str] = mapped_column(Text, default="[]")
    n_ops: Mapped[int] = mapped_column(Integer, default=0)
    tagged: Mapped[str] = mapped_column(String, default="")
    submitted: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    submitted_at: Mapped[float] = mapped_column(Float, nullable=True)


class OperatorRef(Base):
    """The Operator Lab's single source of truth for how each operator is used correctly:
    signature, parameter kinds (positional vs keyword), a canonical example the LLM copies,
    and notes. Seeded from the account's operator definitions + curated examples; the user can
    edit any row (user_edited=True protects it from re-seeding)."""
    __tablename__ = "operator_ref"

    # Composite key: the same operator name (add, multiply, …) exists under REGULAR/SELECTION/COMBO.
    name: Mapped[str] = mapped_column(String, primary_key=True)
    scope: Mapped[str] = mapped_column(String, primary_key=True, default="REGULAR")   # REGULAR|SELECTION|COMBO
    signature: Mapped[str] = mapped_column(String, default="")
    params_json: Mapped[str] = mapped_column(Text, default="[]")   # [{name, kind, required, default}]
    example: Mapped[str] = mapped_column(Text, default="")
    notes: Mapped[str] = mapped_column(Text, default="")
    user_edited: Mapped[bool] = mapped_column(Boolean, default=False)
    updated_at: Mapped[float] = mapped_column(Float, default=_now)


class Prompt(Base):
    __tablename__ = "prompts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[float] = mapped_column(Float, default=_now, index=True)
    name: Mapped[str] = mapped_column(String, default="")
    scope: Mapped[str] = mapped_column(String, default="generate")   # generate|template
    category: Mapped[str] = mapped_column(String, default="")
    region: Mapped[str] = mapped_column(String, default="")
    body: Mapped[str] = mapped_column(Text, default="")
    datasets_json: Mapped[str] = mapped_column(Text, default="[]")
    source_research_id: Mapped[int] = mapped_column(Integer, default=0)


class VaultAlpha(Base):
    """The Alpha Vault: a parking spot for alphas that passed simulation (or are just worth
    keeping) but aren't submitted yet — with your own notes/tags/status, separate from the
    raw sim_results log so it doesn't get buried among failed runs."""
    __tablename__ = "vault_alphas"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[float] = mapped_column(Float, default=_now, index=True)
    updated_at: Mapped[float] = mapped_column(Float, default=_now)
    alpha_id: Mapped[str] = mapped_column(String, default="", index=True)
    expression: Mapped[str] = mapped_column(Text, default="")
    region: Mapped[str] = mapped_column(String, default="", index=True)
    delay: Mapped[int] = mapped_column(Integer, default=1)
    universe: Mapped[str] = mapped_column(String, default="")
    neutralization: Mapped[str] = mapped_column(String, default="")
    sharpe: Mapped[float] = mapped_column(Float, nullable=True)
    fitness: Mapped[float] = mapped_column(Float, nullable=True)
    turnover: Mapped[float] = mapped_column(Float, nullable=True)
    status: Mapped[str] = mapped_column(String, default="parked", index=True)  # parked|reviewing|archived|submitted
    note: Mapped[str] = mapped_column(Text, default="")
    tags_json: Mapped[str] = mapped_column(Text, default="[]")
    source_sim_result_id: Mapped[int] = mapped_column(Integer, default=0)


class TemplateStat(Base):
    """API-learning memory for template SKELETONS (the expression with its field names
    stripped out, so `ts_rank(close, 20)` and `ts_rank(volume, 20)` count as the same
    template). Every simulated alpha updates the skeleton it came from, so generation/
    templates can be steered toward what has actually worked and away from what hasn't."""
    __tablename__ = "template_stats"
    __table_args__ = (UniqueConstraint("skeleton", "region", name="uq_template_region"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    skeleton: Mapped[str] = mapped_column(Text, index=True)
    region: Mapped[str] = mapped_column(String, default="", index=True)
    category: Mapped[str] = mapped_column(String, default="", index=True)
    pass_count: Mapped[int] = mapped_column(Integer, default=0)
    fail_count: Mapped[int] = mapped_column(Integer, default=0)
    best_fitness: Mapped[float] = mapped_column(Float, default=0.0)
    best_sharpe: Mapped[float] = mapped_column(Float, default=0.0)
    example_expression: Mapped[str] = mapped_column(Text, default="")
    last_used_at: Mapped[float] = mapped_column(Float, default=_now)
    blocked: Mapped[bool] = mapped_column(Boolean, default=False)  # manually banned by the user


class HypothesisLog(Base):
    """Tracks how many times each distinct hypothesis (fingerprinted by its normalized idea
    text) has been suggested, per category/region, so the research engine can enforce
    'never suggest the same hypothesis more than twice'."""
    __tablename__ = "hypothesis_log"
    __table_args__ = (UniqueConstraint("fingerprint", "category", "region", name="uq_hypothesis"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    fingerprint: Mapped[str] = mapped_column(String, index=True)
    category: Mapped[str] = mapped_column(String, default="", index=True)
    region: Mapped[str] = mapped_column(String, default="", index=True)
    idea: Mapped[str] = mapped_column(Text, default="")
    times_suggested: Mapped[int] = mapped_column(Integer, default=0)
    first_suggested_at: Mapped[float] = mapped_column(Float, default=_now)
    last_suggested_at: Mapped[float] = mapped_column(Float, default=_now)


class AutopilotAsset(Base):
    """The Autosentry Library: everything the user feeds the engine so it can research from it —
    working alphas, templates, papers (text + distilled digest), boosters and free-form notes.
    `uses`/`wins` are updated after every hypothesis so the engine can favour what pays off.
    kind: alpha | template | paper | booster | note
      - alpha:    a concrete, working FastExpr the engine mutates / re-simulates
      - template: an abstract expression with {field} / {field2} placeholders
      - booster:  a wrapper containing {alpha}, e.g. `group_neutralize({alpha}, industry)`
      - paper:    extracted text (`body`) + LLM digest (`digest`)"""
    __tablename__ = "autopilot_assets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[float] = mapped_column(Float, default=_now, index=True)
    updated_at: Mapped[float] = mapped_column(Float, default=_now)
    kind: Mapped[str] = mapped_column(String, index=True)
    name: Mapped[str] = mapped_column(String, default="")
    body: Mapped[str] = mapped_column(Text, default="")
    digest: Mapped[str] = mapped_column(Text, default="")
    meta_json: Mapped[str] = mapped_column(Text, default="{}")
    source: Mapped[str] = mapped_column(String, default="user")      # user | autopilot
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    uses: Mapped[int] = mapped_column(Integer, default=0)
    wins: Mapped[int] = mapped_column(Integer, default=0)
    fingerprint: Mapped[str] = mapped_column(String, default="", index=True)
    last_used_at: Mapped[float] = mapped_column(Float, default=0.0)


class AutopilotLesson(Base):
    """Durable memory of what worked / failed. Repeated lessons are reinforced (`weight`+1)
    instead of duplicated, and the heaviest + most recent ones are fed back into the
    hypothesis and template prompts of every future run."""
    __tablename__ = "autopilot_lessons"
    __table_args__ = (UniqueConstraint("fingerprint", "region", name="uq_ap_lesson"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[float] = mapped_column(Float, default=_now, index=True)
    last_at: Mapped[float] = mapped_column(Float, default=_now)
    kind: Mapped[str] = mapped_column(String, default="insight", index=True)   # success|failure|insight|booster
    region: Mapped[str] = mapped_column(String, default="", index=True)
    text: Mapped[str] = mapped_column(Text, default="")
    fingerprint: Mapped[str] = mapped_column(String, default="", index=True)
    weight: Mapped[int] = mapped_column(Integer, default=1)
    source: Mapped[str] = mapped_column(String, default="autopilot")           # autopilot | user | llm
    pinned: Mapped[bool] = mapped_column(Boolean, default=False)


class BrainPrompt(Base):
    """A BRAIN 'LLM prompt' submission draft: exactly the fields of the BRAIN form plus the thesis
    it was built from. Drafts may be incomplete; validation is reported, never enforced on save."""
    __tablename__ = "brain_prompts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[float] = mapped_column(Float, default=_now, index=True)
    updated_at: Mapped[float] = mapped_column(Float, default=_now)
    name: Mapped[str] = mapped_column(String, default="")
    model: Mapped[str] = mapped_column(String, default="")
    model_version: Mapped[str] = mapped_column(String, default="")
    update_frequency: Mapped[str] = mapped_column(String, default="")
    weight: Mapped[str] = mapped_column(String, default="")          # kept as text so "0.10" stays "0.10"
    prompt: Mapped[str] = mapped_column(Text, default="")
    sample_output: Mapped[str] = mapped_column(Text, default="")
    thesis: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String, default="draft")     # draft | ready | submitted
    notes: Mapped[str] = mapped_column(Text, default="")
