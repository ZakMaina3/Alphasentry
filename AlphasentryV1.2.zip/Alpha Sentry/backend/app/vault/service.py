"""Alpha Vault — a parking spot for alphas you're keeping but not submitting yet.

Separate from the raw sim_results log (which fills with every attempt, pass or fail) so
alphas worth revisiting don't get buried. You can push a result into the vault, tag/note
it, change its status (parked / reviewing / archived / submitted), or submit it straight
from here — which reuses the same submit_alpha() the Simulate screen uses, so there is
still only one submission code path in the whole app.
"""

from __future__ import annotations

import json
import time

from sqlalchemy import select, desc

from app.db.base import SessionLocal
from app.db import models as M


def _row_to_dict(r: M.VaultAlpha) -> dict:
    return {
        "id": r.id, "created_at": r.created_at, "updated_at": r.updated_at,
        "alpha_id": r.alpha_id, "expression": r.expression, "region": r.region,
        "delay": r.delay, "universe": r.universe, "neutralization": r.neutralization,
        "sharpe": r.sharpe, "fitness": r.fitness, "turnover": r.turnover,
        "status": r.status, "note": r.note, "tags": json.loads(r.tags_json or "[]"),
        "source_sim_result_id": r.source_sim_result_id,
    }


def add_from_result(sim_result_id: int, note: str = "", tags: list | None = None) -> dict:
    with SessionLocal() as db:
        sr = db.get(M.SimResult, sim_result_id)
        if not sr:
            raise RuntimeError(f"No stored result with id {sim_result_id}.")
        row = M.VaultAlpha(
            alpha_id=sr.alpha_id, expression=sr.expression, region=sr.region, delay=sr.delay,
            universe=sr.universe, neutralization=sr.neutralization, sharpe=sr.sharpe,
            fitness=sr.fitness, turnover=sr.turnover, note=note or "",
            tags_json=json.dumps(tags or []), source_sim_result_id=sim_result_id)
        db.add(row)
        db.commit()
        db.refresh(row)
        return _row_to_dict(row)


def add_manual(*, alpha_id="", expression="", region="", delay=1, universe="", neutralization="",
               sharpe=None, fitness=None, turnover=None, note="", tags=None) -> dict:
    with SessionLocal() as db:
        row = M.VaultAlpha(alpha_id=alpha_id, expression=expression, region=region, delay=delay,
                           universe=universe, neutralization=neutralization, sharpe=sharpe,
                           fitness=fitness, turnover=turnover, note=note or "",
                           tags_json=json.dumps(tags or []))
        db.add(row)
        db.commit()
        db.refresh(row)
        return _row_to_dict(row)


def list_vault(status: str | None = None, region: str | None = None, limit: int = 300) -> dict:
    with SessionLocal() as db:
        q = select(M.VaultAlpha)
        if status:
            q = q.where(M.VaultAlpha.status == status)
        if region:
            q = q.where(M.VaultAlpha.region == region)
        rows = db.scalars(q.order_by(desc(M.VaultAlpha.updated_at)).limit(limit)).all()
        return {"items": [_row_to_dict(r) for r in rows], "total": len(rows)}


def update(vault_id: int, *, note: str | None = None, tags: list | None = None,
          status: str | None = None) -> dict:
    with SessionLocal() as db:
        row = db.get(M.VaultAlpha, vault_id)
        if not row:
            raise RuntimeError(f"No vault entry with id {vault_id}.")
        if note is not None:
            row.note = note
        if tags is not None:
            row.tags_json = json.dumps(tags)
        if status is not None:
            row.status = status
        row.updated_at = time.time()
        db.commit()
        db.refresh(row)
        return _row_to_dict(row)


def delete(vault_id: int) -> dict:
    with SessionLocal() as db:
        row = db.get(M.VaultAlpha, vault_id)
        if not row:
            return {"deleted": False}
        db.delete(row)
        db.commit()
        return {"deleted": True}
