"""Autosentry follow-ups: reversing and boosting WITHOUT extra simulation rounds.

The rule (set by the user after testing):
  * REVERSE an alpha only when its Sharpe is below -1 (`flip_min_sharpe`, default 1.0).
  * BOOST every alpha whose Sharpe is above 1 (`booster_trigger`) and that does not already pass everything, with each eligible booster.
    A reversed alpha that then shows Sharpe above 1 is boosted too (reverse, then boost).
  * Nothing runs on its own: follow-ups wait in a queue and ride in the NEXT standard batch (10 per batch, `parallel` batches per round),
    together with that round's new expressions, so no simulation slot is spent on a half-empty batch.

Pure functions (no database, no BRAIN): the engine passes in its own helpers, so this is tested without the app.
An item is (expression, base_row, kind, booster, extra) with kind in "flip" | "boost" | "flip+boost" | "nudge"; extra = {"hyp": n}."""
from __future__ import annotations

from typing import Any, Callable, Iterable

Item = tuple  # (expr, base_row, kind, booster | None)


def plan(rows: Iterable[dict], *, flip_on: bool, flip_at: float, trigger: float, max_turnover: float, boosters: list[dict],
         eligible: Callable[[dict, dict, float], bool], apply_booster: Callable[[str, dict], str], flip_expr: Callable[[str], str],
         norm: Callable[[str], str], seen: set, queued: set, pick: Callable[[dict], list] | None = None,
         hyp_no: int = 0, max_depth: int = 2, min_gain: float = 0.1, include_passed: bool = False,
         nudge: Callable[[str], list] | None = None, floor: float | None = None,
         report: dict | None = None) -> list[Item]:
    """Follow-ups wanted after a batch. `queued` holds the normalised expressions already waiting; both sets stop duplicates.
    pick(row) chooses which boosters to try on a row (default: every eligible one). A boosted row may be boosted once more
    (up to `max_depth`) when the first boost gained at least `min_gain` Sharpe. `nudge(expr)` lists window variants;
    `floor` lowers the trigger for near-misses; `report` (a dict) receives counts for logging."""
    out: list[Item] = []
    claimed = set(queued)
    rep = report if report is not None else {}
    rep.update({"candidates": 0, "duplicates": 0, "reverse": 0, "boost": 0, "nudge": 0})
    low = trigger if floor is None else min(trigger, floor)

    def add(expr: str, base: dict, kind: str, b: dict | None) -> bool:
        n = norm(expr)
        if n in seen or n in claimed:
            rep["duplicates"] += 1
            return False
        claimed.add(n)
        out.append((expr, base, kind, b, {"hyp": hyp_no}))
        return True

    for r in sorted(rows, key=lambda x: -abs(x.get("sharpe") or 0)):
        sh, expr, kind = r.get("sharpe"), r.get("expr"), r.get("_kind") or ""
        if sh is None or not expr:
            continue
        tu = r.get("turnover")
        if flip_on and not kind and sh < -flip_at and not (tu is not None and tu > max_turnover):
            add(flip_expr(expr), r, "flip", None)
        depth = int(r.get("_depth") or 0)
        again = kind in ("boost", "flip+boost") and depth < max_depth and (r.get("_gain") or 0) >= min_gain
        if sh > low and (include_passed or not r.get("passed")) and (kind in ("", "flip") or again):
            rep["candidates"] += 1
            applied = set(r.get("_applied") or [])
            chosen = pick(r) if pick else [b for b in boosters if eligible(r, b, low) and b.get("name") not in applied]
            for b in chosen:
                if add(apply_booster(expr, b), r, "flip+boost" if kind == "flip" else "boost", b):
                    rep["boost"] += 1
            if nudge and kind == "" and sh > trigger:
                for e2 in nudge(expr)[:2]:
                    if add(e2, r, "nudge", None):
                        rep["nudge"] += 1
    rep["reverse"] = sum(1 for i in out if i[2] == "flip")
    return out


def compose(carry: list[Item], new_exprs: list[str], cap: int, reserve_frac: float | None = None) -> tuple[list[str], dict[int, Item], list[str]]:
    """The next batch: queued follow-ups first, then new expressions up to `cap`. A few slots stay for new expressions
    (a quarter of the batch, at least 2) so research never starves; follow-ups that do not fit wait for the batch after.
    Takes the used items out of `carry`. Returns (expressions, {position: follow-up item}, new expressions actually used)."""
    keep_for_new = cap // 4 if reserve_frac is None else int(round(cap * reserve_frac))
    reserve = min(len(new_exprs), max(2, keep_for_new)) if new_exprs else 0
    take = carry[:max(0, cap - reserve)]
    del carry[:len(take)]
    used_new = list(new_exprs[:cap - len(take)])
    exprs = [t[0] for t in take] + used_new
    return exprs, {i: t for i, t in enumerate(take)}, used_new
