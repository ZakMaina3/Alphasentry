"""Autosentry supervision, pure: has a step stalled, and what to tell you when it did (no BRAIN, no Telegram, no threads)."""
from __future__ import annotations

import time


def stalled(beat: float, now: float, minutes: float) -> bool:
    """True when nothing has happened for `minutes` (0 or less = never)."""
    try:
        m = float(minutes or 0)
    except (TypeError, ValueError):
        return False
    return m > 0 and (now - float(beat)) > m * 60


def _ago(sec: float) -> str:
    sec = int(max(0, sec))
    return f"{sec // 3600}h {sec % 3600 // 60}m" if sec >= 3600 else f"{sec // 60}m {sec % 60}s"


def stall_message(now: float, beat: float, live: dict, events: list[dict], minutes: float, batches: list[dict] | None = None) -> str:
    """The Telegram text: what it was doing, for how long, the last events and the batches that were abandoned."""
    hyp = live.get("hypothesis") or {}
    idea = str(hyp.get("idea") or "—")[:160] if isinstance(hyp, dict) else "—"
    lines = [f"🛑 Autosentry was stuck for {_ago(now - beat)} (limit {int(minutes)} min) and has been stopped.",
             f"Step: {live.get('phase') or '—'}" + (f" · {str(live.get('wait'))[:120]}" if live.get("wait") else ""),
             f"Hypothesis: {idea}",
             f"Cycle {live.get('cycle', '—')} · round {live.get('round', '—')}"]
    if batches:
        lines.append("Abandoned at BRAIN: " + "; ".join(f"{b.get('region', '?')} D{b.get('delay', '?')} × {b.get('size', '?')} sims, "
                                                          f"{_ago(now - float(b.get('since') or now))}" for b in batches[:5]))
    last = [e for e in (events or []) if isinstance(e, dict)][-6:]
    if last:
        lines.append("Last events:")
        for e in last:
            lines.append(f"  {time.strftime('%H:%M:%S', time.localtime(e.get('t') or now))} {str(e.get('msg', ''))[:140]}")
    lines.append("Nothing was submitted. Press Start to run again.")
    return "\n".join(lines)
