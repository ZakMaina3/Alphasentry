"""Autosentry — the autonomous alpha engine.

What it does, forever (until you press Stop):

  1. HYPOTHESIZE  — the LLM (your own API key) reads the selected datafields and proposes
                    testable hypotheses, each pinned to the few fields that express it.
  2. TEMPLATIZE   — for the current hypothesis it designs {field}/{field2} templates.
  3. SIMULATE     — expands the templates over the hypothesis' fields, validates them and
                    simulates ONE BATCH OF 10 (configurable) through the normal simulation
                    service (so every result lands in Results & Analytics + template learning).
  4. REVIEW       — every gate-passing alpha gets the full BRAIN submission check
                    (self / prod / power-pool correlation + every IS test). Near-misses get the
                    same check so the LLM can see WHICH tests failed.
  5. REFINE       — the LLM reads the batch results (metrics + failing tests per template) and
                    rewrites the templates. Go to 3.
  …until the hypothesis yields an alpha that passes EVERYTHING, then it parks the winner in the
  Alpha Vault, tags it, and moves to the next hypothesis. If a hypothesis stalls (max rounds) it
  is abandoned and the failure is fed to the next ones so the engine doesn't repeat itself.

LIBRARY & LEARNING (see app/autopilot/library.py): the user can upload working alphas, templates,
papers, boosters and notes. They are fed to the LLM at the hypothesis + template stages. Boosters
(wrappers around `{alpha}`) are applied to EVERY alpha whose Sharpe is above the booster trigger (1.0) that does not yet
pass everything, and an alpha is REVERSED only when its Sharpe is below -1. Those follow-ups never get a simulation of their
own: they wait in a queue and ride in the next standard batch of 10 (see followups.py). Every batch, win and stall is written back as a lesson, winners
join the library as new working alphas, and the lessons steer every later run.

It NEVER submits anything to BRAIN: submission is irreversible, so it stays a manual click.
"""

from __future__ import annotations

import json
import random
from concurrent.futures import ThreadPoolExecutor
import re
import threading
import time
import traceback

from sqlalchemy import select

from app.brain import engine
from app.core.config import get_settings
from app.core.jobs import jobs
from app.autopilot import boosting as BO
from app.autopilot import clone as CL
from app.autopilot import followups as FU
from app.autopilot import library as K
from app.autopilot import pacing as PC
from app.autopilot import supervisor as SUP
from app.autopilot import winners as WN
from app.db import models as M
from app.db.base import SessionLocal
from app.generation import service as G
from app.notify import telegram as TG
from app.simulation import service as S

import ace_lib as ace          # noqa: E402
import llm_providers as L      # noqa: E402
import keys as keymgr          # noqa: E402

DELIM = "|||"
_LOCK = threading.Lock()
_FILE = get_settings().data_dir / "autopilot_state.json"

# ── persisted state (winners + hypothesis history survive a restart) ─────────────────

_DEFAULT_STATE = {"cycles": 0, "simulated": 0, "winners": [], "hypotheses": [], "started_at": None}


def _load_state() -> dict:
    try:
        d = json.loads(_FILE.read_text())
        return {**_DEFAULT_STATE, **d}
    except Exception:
        return json.loads(json.dumps(_DEFAULT_STATE))


def _save_state(st: dict) -> None:
    try:
        st["hypotheses"] = st["hypotheses"][-300:]
        _FILE.write_text(json.dumps(st))
    except Exception:
        pass


def reset_state() -> dict:
    with _LOCK:
        _save_state(json.loads(json.dumps(_DEFAULT_STATE)))
    return {"ok": True}


# ── live state (what the UI polls) ───────────────────────────────────────────────────

_LIVE: dict = {"job_id": None, "phase": "idle", "wait": "", "hypothesis": None, "round": 0,
               "max_rounds": 0, "templates": [], "last_batch": [], "events": [], "cycle": 0}


# Another engine (the Supersentry) can route this module's event/live output (session waits, Telegram
# re-login) into its OWN panel by installing hooks while it runs.
_HOOKS: dict = {"event": None, "live": None}
_BEAT = {"t": time.time()}                 # last sign of life of a running Autosentry (any event or phase change); the stall watchdog reads it
_HALT = {"lock": threading.Lock(), "resuming": False, "stop": threading.Event(), "gen": 0}


class _Halted(BaseException):
    """Raised inside the run when the session ended: the run unwinds completely (not caught by `except Exception`)."""


def _event(msg: str, progress=None) -> None:
    _BEAT["t"] = time.time()
    if _HOOKS["event"]:
        return _HOOKS["event"](msg, progress)
    with _LOCK:
        _LIVE["events"].append({"t": time.time(), "msg": str(msg)[:400]})
        del _LIVE["events"][:-300]
    if progress:
        try:
            progress(log=msg)
        except Exception:
            pass


def _live(**kw) -> None:
    _BEAT["t"] = time.time()
    if _HOOKS["live"]:
        return _HOOKS["live"](**kw)
    with _LOCK:
        _LIVE.update(kw)


def status() -> dict:
    jid = _LIVE.get("job_id")
    running = bool(jid and jobs.get(jid).get("status") == "running")
    with _LOCK:
        live = json.loads(json.dumps(_LIVE, default=str))
    st = _load_state()
    live["running"] = running
    live["run"] = dict(_RUN)
    live["resuming"] = bool(_HALT["resuming"])
    if not running and not _HALT["resuming"] and live["phase"] not in ("idle", "stopped"):
        live["phase"] = "stopped"
    live["state"] = {"cycles": st["cycles"], "simulated": st["simulated"],
                     "winners": st["winners"][-50:], "hypotheses": st["hypotheses"][-40:]}
    return live


# ── small helpers ────────────────────────────────────────────────────────────────────

def _sleep(sec: float, should_cancel) -> None:
    end = time.time() + sec
    while time.time() < end and not should_cancel():
        _BEAT["t"] = time.time()            # a deliberate wait (cool-down, prod-check delay, back-off) is not a stall
        time.sleep(1)


def _norm(e: str) -> str:
    return re.sub(r"\s+", "", str(e)).lower()


def _fp(idea: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", idea.lower()).strip()[:90]


def _chain():
    chain = L.default_chain(keymgr.get_preferred())
    if not chain:
        raise RuntimeError("No LLM providers set up. Add an API key in Settings.")
    return chain


def _llm(prompt: str, n: int):
    return L.MultiLLM(_chain()).generate_list(prompt, n=n)


def _seen_expressions(region: str) -> set:
    with SessionLocal() as db:
        rows = db.scalars(select(M.SimResult.expression).where(M.SimResult.region == region)).all()
    return {_norm(r) for r in rows if r}


# ── BRAIN session: ask for biometrics on Telegram when it expires, resume automatically ──

_CTX: dict = {"progress": None, "cancel": lambda: False}


def _interval(cfgn: dict, sent: int) -> float:
    """Gap before re-sending the link: base, 2x base, then hourly (no spam if you're asleep)."""
    base = max(5, int(cfgn.get("resend_min") or 15)) * 60
    return base if sent <= 1 else base * 2 if sent == 2 else max(base * 2, 3600)


_REAUTH_LOCK = threading.Lock()          # only ONE re-login flow at a time (watchdog or main thread)
_EXP = {"epoch": 0.0}                    # when BRAIN last told us the session ends (local clock)
_LIVE_OK = {"t": 0.0}                    # last time a protected call succeeded


def _session_check() -> str:
    """'live' | 'dead' | 'unknown' — decided by a REAL authenticated call, not by BRAIN's
    /authentication probe. That probe answers "UNKNOWN (network?)" for a dead token, which made the
    old logic think everything was fine and never ask for a login.
      dead    = no session at all, or BRAIN says 401/403, or the session's end time has passed and the
                call did not succeed
      unknown = BRAIN unreachable / transient error (never triggers a login)"""
    now = time.time()
    if now - _LIVE_OK["t"] < 20:
        return "live"
    try:
        s = engine.sm._state.get("session") or engine.sm._load_pkl()
    except Exception:
        s = None
    if s is None:
        return "dead"                                   # no session -> a link must be sent
    try:
        r = s.get(ace.brain_api_url + "/users/self/alphas", params={"limit": 1}, timeout=20)
        code = r.status_code
    except Exception:
        return "unknown"
    if code // 100 == 2:
        _LIVE_OK["t"] = now
        return "live"
    if code in (401, 403):
        return "dead"
    past_end = bool(_EXP["epoch"]) and now > _EXP["epoch"] + 20
    return "dead" if past_end else "unknown"


def _reauth_flow(cancel=None, progress=None) -> None:
    """The session is dead: start a login, send the biometrics link to Telegram, poll for the face scan,
    re-send reminders with back-off, and return once a session works again. Without Telegram it waits
    for a manual login in Settings."""
    if cancel is None:
        cancel, progress = _CTX["cancel"], _CTX["progress"]
    while not _REAUTH_LOCK.acquire(timeout=2):
        if cancel():
            return
    try:
        sent, next_send, notified, err_sent = 0, 0.0, False, False
        while not cancel():
            if _session_check() != "dead":
                if notified:
                    _event("BRAIN session verified — restarting Autosentry.", progress)
                    TG.send("✅ BRAIN session verified — restarting Autosentry.", silent=True)
                _live(wait="")
                return
            c = TG.config()
            if not TG.ready(c):
                _live(phase="waiting", wait="BRAIN session expired or missing — log in from Settings "
                                            "(or set up Telegram alerts); resuming automatically.")
                _sleep(30, cancel)
                continue
            now = time.time()
            if now >= next_send:
                try:
                    r = engine.sm.begin_login()
                except Exception as e:  # noqa: BLE001
                    r = {"state": "error", "message": str(e)}
                st = r.get("state")
                if st == "biometrics":
                    sent += 1
                    notified = True
                    next_send = float("inf")        # ONE link only: a second begin_login would invalidate the link you already verified
                    TG.send(("🔐 BRAIN session expired — Autosentry is paused.\nTap the button and complete the "
                             "face scan; I'll resume by myself once you verify." if sent == 1 else
                             "🔐 The previous BRAIN link stopped working. Autosentry is still paused — use this new link."),
                            url=r["url"], button="Complete biometrics", cfg=c)
                    _event(f"session expired — biometrics link sent to Telegram (#{sent})", progress)
                elif st == "done":
                    _LIVE_OK["t"] = 0.0
                    continue                    # logged in straight away; the check at the top confirms
                else:
                    msg = str(r.get("message") or "login failed")[:200]
                    if not err_sent:
                        TG.send(f"⚠ Autosentry couldn't start a BRAIN login: {msg}", cfg=c)
                        err_sent = True
                    _event(f"⚠ login attempt failed: {msg}", progress)
                    next_send = now + 300
            elif notified:
                try:
                    cr = engine.sm.complete_login()  # 201 once the face scan is finished
                    _LIVE_OK["t"] = 0.0
                    if (cr or {}).get("state") == "error" and "No login in progress" in str(cr.get("message")):
                        next_send = 0.0              # the pending login was lost (restart / reset): only then send a fresh link
                except Exception:
                    pass
            _live(phase="waiting", wait="BRAIN session expired — biometrics link sent to your Telegram; "
                                        "waiting for the face scan…" if notified else
                  "BRAIN session expired — starting login…")
            _sleep(10, cancel)
    finally:
        _REAUTH_LOCK.release()


def _ensure_session() -> None:
    """Call before any BRAIN work: returns at once when the session works; otherwise runs the re-login."""
    if _session_check() == "dead":
        _session_halt()
        raise _Halted()


def _abandon_everything(reason: str) -> list:
    """Stop the run NOW and let go of everything in flight: cancel the job (even when its thread is stuck), cancel Autosentry's
    running simulations in the engine journal and give its slots back. Returns the batches that were abandoned."""
    batches: list = []
    jid = _LIVE.get("job_id")
    if jid:
        jobs.cancel(jid)
        jobs.force_end(jid, "cancelled", reason)
    try:
        from app.harness.engine.slots import shared_lease
        from app.modules.harness_engine import _tracker
        tr = _tracker()
        batches = [b for b in tr.running_batches() if b.get("task") == "autopilot"]
        for b in batches:
            tr.abandon_batch(b["batch_id"])
        held = shared_lease.held_by("autopilot")
        if held:
            shared_lease.release("autopilot", held)
    except Exception:  # noqa: BLE001      engine routing is optional; never block the stop on it
        pass
    _live(phase="stopped", wait=reason)
    return batches


def _session_halt() -> None:
    """The BRAIN session ended: stop Autosentry completely, send ONE verification link, restart by itself once you have verified."""
    with _HALT["lock"]:
        if _HALT["resuming"]:
            return
        _HALT["resuming"] = True
        _HALT["stop"].clear()
    cfg_in = _ACTIVE.get("cfg_in")
    _event("BRAIN session ended — Autosentry stopped completely. It restarts by itself once you verify.", _CTX["progress"])
    _abandon_everything("BRAIN session ended — waiting for verification")
    threading.Thread(target=_resume_after_login, args=(cfg_in,), daemon=True, name="autosentry-resume").start()


def _resume_after_login(cfg_in: dict | None) -> None:
    cancel = _HALT["stop"].is_set
    try:
        _live(phase="waiting", wait="BRAIN session ended — Autosentry stopped; waiting for you to verify.")
        _reauth_flow(cancel=cancel, progress=None)
        if cancel():
            _event("Restart cancelled (you pressed Stop).", None)
            return
        if not cfg_in:
            _event("Session verified, but there are no saved settings to restart with — press Start.", None)
            return
        _HALT["resuming"] = False
        start(cfg_in)
        _event("Autosentry restarted after verification.", None)
        TG.send("▶ Autosentry restarted.", silent=True)
    except Exception as e:  # noqa: BLE001
        _event(f"⚠ could not restart Autosentry: {type(e).__name__}: {str(e)[:160]}", None)
        TG.send(f"⚠ Session verified but Autosentry could not restart: {str(e)[:200]}. Press Start.")
    finally:
        _HALT["resuming"] = False


def stop() -> bool:
    """Stop Autosentry (and cancel a pending restart after a session expiry)."""
    _HALT["stop"].set()
    jid = _LIVE.get("job_id")
    ok = bool(jid and jobs.cancel(jid))
    if _HALT["resuming"]:
        _live(phase="stopped", wait="")
        return True
    return ok


def _stall_halt(minutes: float) -> None:
    """A step has made no progress for `minutes`: stop, abandon everything and tell you on Telegram what it was doing."""
    now = time.time()
    with _LOCK:
        live = json.loads(json.dumps(_LIVE, default=str))
    batches = _abandon_everything(f"stuck for {int(minutes)} min — stopped")
    msg = SUP.stall_message(now, _BEAT["t"], live, live.get("events") or [], minutes, batches)
    _event(f"⚠ no progress for {int(minutes)} minutes — Autosentry stopped and its simulations abandoned.", _CTX["progress"])
    TG.send(msg, silent=False)


def _heads_up_loop(stop: threading.Event, gen: int = 0) -> None:
    """Watchdog (runs beside the Autosentry, even while a simulation is in flight):
      - remembers when the session ends,
      - when it is running low: warns on Telegram with a "Refresh session now" button — or, if
        auto-refresh is on, sends the biometrics link right away so the session is renewed BEFORE it ends,
      - the moment the session is dead (or missing) it sends the biometrics link — it does NOT wait
        for the main loop to reach its next BRAIN call,
      - tells you once if BRAIN has been unreachable for ~10 minutes."""
    warned, auto_done, unknown_n, unknown_sent = False, False, 0, False
    while not stop.wait(45):
        if _HALT["gen"] != gen:
            return                                       # a newer run owns the watchdog now
        mins = float(((_ACTIVE.get("cfg") or {}).get("stall_minutes")) or 0)
        if not _HALT["resuming"] and SUP.stalled(_BEAT["t"], time.time(), mins):
            _stall_halt(mins)
            return
        c = TG.config()
        ready = TG.ready(c)
        try:
            rem = engine.sm.remaining_seconds()
        except Exception:
            rem = 0
        if rem > 0:
            _EXP["epoch"] = time.time() + rem
        st = _session_check()
        if st == "dead":
            unknown_n, unknown_sent, warned, auto_done = 0, False, False, False
            _session_halt()                              # stop completely; one link; restart after verification (also without Telegram: log in from Settings)
            return
        if st == "unknown":
            unknown_n += 1
            if unknown_n >= 13 and not unknown_sent and ready:
                unknown_sent = True
                TG.send("⚠ Autosentry can't reach BRAIN to check the session (network down?). It will keep "
                        "retrying and sends the biometrics link as soon as it can confirm the session ended.",
                        silent=True, cfg=c)
        else:
            unknown_n, unknown_sent = 0, False
        if not ready:
            continue
        lead = int(c.get("heads_up_min") or 0) * 60
        auto = int(c.get("auto_refresh_min") or 0) * 60
        if rem > max(lead, auto):
            warned, auto_done = False, False
        if auto > 0 and 0 < rem <= auto and not auto_done:
            auto_done = warned = True
            try:
                from app.notify import remote as _RC
                threading.Thread(target=_RC.refresh_session, kwargs={"auto": True, "rem": rem}, daemon=True).start()
            except Exception:
                pass
        elif lead > 0 and 0 < rem <= lead and not warned:
            warned = True
            btn = [[{"text": "🔄 Refresh session now", "cb": "cmd:refresh"}]] if c.get("remote_enabled") else None
            TG.send(f"⏳ BRAIN session expires in ~{max(1, rem // 60)} min. When it does I'll pause and send "
                    "you the biometrics link here." + ("\nOr refresh it now:" if btn else ""),
                    silent=True, cfg=c, buttons=btn)


# ── 1. hypotheses ────────────────────────────────────────────────────────────────────

_HYP_WHY: dict = {}


def _as_revisit(item: dict, prior: list, valid_ids: set) -> dict:
    """An idea that was tried before is allowed again, but as an IMPROVEMENT pass: remember how it
    did, and make sure it is not run on exactly the same fields as last time."""
    best = max((float(h.get("best_fitness") or 0) for h in prior), default=0.0)
    used = {f for h in prior for f in (h.get("fields") or [])}
    fields = list(item["fields"])
    if set(fields) <= used:                    # nothing new -> bring in up to 2 unused selected fields
        extra = [f for f in sorted(valid_ids) if f not in used][:2]
        fields = (fields + extra)[:8]
    return {**item, "fields": fields, "revisit": True,
            "prior": {"times": len(prior), "best_fitness": best, "fields": sorted(used)[:8],
                      "status": prior[-1].get("status", "stalled")}}


def _gap_text(cfg: dict) -> str:
    """If the Osmosis Planner has read your account, tell the LLM where this scope is short of alphas."""
    try:
        from app.osmosis import planner as OP, service as OS
        alphas = OS.load_snapshot().get("alphas") or []
        sc = OP.scope_of(cfg["region"], cfg["delay"])
        mine = [a for a in alphas if a["scope"] == sc]
        if not alphas:
            return ""
        r = OP.plan_scope(sc, mine, {**OP.DEFAULTS})
        ds = ", ".join(f"{k} x{v}" for k, v in sorted(r["datasets"].items(), key=lambda kv: -kv[1])[:8]) or "none"
        if r["eligible"]:
            return f"Account context: {sc} already has {r['passing']} qualifying submitted alphas (datasets: {ds}). Prefer ideas on other datasets when equally good.\n"
        return (f"Account context: {sc} has only {r['passing']} qualifying submitted alphas and Osmosis needs {r['needed']}; "
                f"datasets already used: {ds}. Prefer ideas on OTHER datasets and mechanisms to fill the gap.\n")
    except Exception:  # noqa: BLE001
        return ""


def _new_hypotheses(cfg: dict, fields: list, categories: dict, history: list, n: int = 5,
                    ctx: dict | None = None) -> list:
    ids = {f["id"] for f in fields}
    done = [h["idea"] for h in history[-40:]]
    avoid = ""
    if done:
        lines = []
        for h in history[-25:]:
            tag = "WORKED" if h.get("status") == "won" else "stalled"
            bf = h.get("best_fitness") or 0
            lines.append(f"- [{tag}, best fitness {bf:.2f}, fields: {', '.join((h.get('fields') or [])[:4])}] {h['idea']}")
        avoid = ("\nPREVIOUS HYPOTHESES (new ideas are welcome, but you MAY also return an earlier idea that "
                 "stalled if you can improve it: keep its core mechanism and choose DIFFERENT or additional "
                 "datafields that would represent it better. Build on ones that WORKED):\n"
                 + "\n".join(lines) + "\n")
    goal = f"User goal: {cfg['goal']}\n" if cfg.get("goal") else ""
    goal += (cfg.get("_gap") or "")
    meta = (
        "You are a senior quantitative researcher for the WorldQuant BRAIN platform. "
        f"Region {cfg['region']}, universe {cfg['universe']}, delay {cfg['delay']}, {cfg['instrument']}.\n"
        + goal + avoid + (K.context_text(ctx, "papers", "alphas", "notes", "lessons") if ctx else "") +
        f"Propose {n} DISTINCT, testable stock-return hypotheses, each grounded in the DATAFIELDS below "
        "(read their descriptions), each exploiting a DIFFERENT economic mechanism.\n"
        f"Return ONLY a JSON array of exactly {n} strings in this exact form:\n"
        f"  idea {DELIM} mechanism (why it predicts returns) {DELIM} expected sign {DELIM} "
        "1-6 datafield ids copied EXACTLY from the catalogue below, comma-separated\n"
        f"=== DATAFIELDS ===\n{G._field_summary(fields, categories, 200)}\n")
    idmap = {i.lower(): i for i in ids}
    prior_by_fp: dict = {}
    for h in history:
        prior_by_fp.setdefault(_fp(h["idea"]), []).append(h)
    batch_seen: set = set()
    out: list = []
    why = {"returned": 0, "malformed": 0, "unknown_fields": 0, "repeats": 0}
    rejected_ideas: list = []
    for attempt in range(2):
        prompt = meta
        if attempt and rejected_ideas:
            prompt += ("\nYour previous answer was rejected (repeats, or fields not in the catalogue). "
                       "Do NOT reuse these ideas; propose genuinely different mechanisms and copy datafield "
                       "ids EXACTLY:\n" + "\n".join(f"- {x}" for x in rejected_ideas[:10]) + "\n")
        res = _llm(prompt, n)
        for s in res.expressions:
            why["returned"] += 1
            raw = str(s).strip()
            parts = [p.strip() for p in re.split(r"\|\|\||\s\|\s", raw)]
            if len(parts) < 4:
                why["malformed"] += 1
                continue
            toks = re.split(r"[,\s;]+", parts[3])
            fids = []
            for x in toks:
                x = x.strip("`'\"()[]{}.")
                fid = idmap.get(x.lower())
                if fid and fid not in fids:
                    fids.append(fid)
            if not fids:
                why["unknown_fields"] += 1
                rejected_ideas.append(parts[0][:120])
                continue
            fp = _fp(parts[0])
            if fp in batch_seen:
                continue                       # same idea twice in ONE answer
            batch_seen.add(fp)
            item = {"idea": parts[0], "mechanism": parts[1], "sign": parts[2], "fields": fids[:8]}
            if fp in prior_by_fp:
                why["repeats"] += 1
                item = _as_revisit(item, prior_by_fp[fp], ids)
            out.append(item)
        if out:
            break
    _HYP_WHY.clear()
    _HYP_WHY.update(why)
    return out


# ── 2. templates ─────────────────────────────────────────────────────────────────────

_BANNED = re.compile(r"\bbucket\s*\(|\bvec_[A-Za-z0-9_]*\s*\(", re.I)
_FILLER = re.compile(r"([*/+\-]\s*[01](?![.\d])|(?<![.\d])[01]\s*[*/])")


def _clean_templates(raw: list, field_ids: set) -> list:
    out = []
    for t in raw:
        t = str(t).strip()
        if "{field}" not in t or _BANNED.search(t) or _FILLER.search(t):
            continue
        if set(re.findall(r"[A-Za-z_][A-Za-z0-9_]*", t)) & field_ids:
            continue          # a concrete field leaked into the template
        out.append(t)
    seen, uniq = set(), []
    for t in out:
        if _norm(t) not in seen:
            seen.add(_norm(t)); uniq.append(t)
    return uniq


def _propose_templates(cfg: dict, hyp: dict, fields: list, categories: dict, feedback: str,
                       current: list, ctx: dict | None = None) -> list:
    n = int(cfg["templates_per_round"])
    n_ops = G._clamp_ops(cfg["max_operators"])
    hyp_fields = [f for f in fields if f["id"] in set(hyp["fields"])] or fields[:8]
    try:
        from app.operators import service as opsvc
        op_examples = opsvc.reference_block("REGULAR")
        atlas = opsvc.atlas_block("REGULAR", skip_prefixes=("vec_",), skip_names={"bucket"}) if cfg.get("use_atlas", True) else ""
    except Exception:
        op_examples, atlas = "", ""
    if atlas:
        op_examples = ("=== OPERATOR ATLAS (every operator you may use, with the correct form; prefer a varied mix over the usual rank/ts_mean) ===\n"
                       + atlas + op_examples)
    hints = ""
    for fn in (G.template_learning_hint, ):
        try:
            hints += fn(cfg["region"]) or ""
        except Exception:
            pass
    two = ("You may use {field2} for a second, different datafield (ratio, spread, correlation, "
           "conditioning) in about half of the templates; the rest use {field} only.\n"
           if cfg.get("allow_two_field") else
           "Every template MUST contain {field} exactly once and MUST NOT contain {field2}.\n")
    fb = ""
    if feedback:
        fb = ("=== LAST ROUND — LEARN FROM THIS ===\n" + feedback +
              "\nKeep the structures that scored best, FIX the failing ones for the reason shown, and "
              "add new variants. Do not resubmit a template unchanged.\n")
    cur = ("=== CURRENT TEMPLATES ===\n" + "\n".join(current) + "\n") if current else ""
    meta = (
        "Design reusable WorldQuant FastExpr alpha TEMPLATES that express ONE hypothesis.\n"
        f"Region {cfg['region']}, universe {cfg['universe']}, delay {cfg['delay']}, {cfg['instrument']}.\n"
        f"HYPOTHESIS: {hyp['idea']}\nMECHANISM: {hyp['mechanism']}\nEXPECTED SIGN: {hyp['sign']}\n"
        f"Propose {n} templates. {two}Use EXACTLY {n_ops} operators per template (at most).\n"
        "A template is abstract: use ONLY the literal placeholders {field}"
        + (" / {field2}" if cfg.get("allow_two_field") else "") +
        " where a datafield goes — NEVER write a real field id or dataset name.\n"
        "NO FILLER ARITHMETIC ('* 1', '+ 0', '/ 1', ...). Every arithmetic operator must change the signal.\n"
        "Pass named parameters as keywords; windows/groups positional; groups are identifiers "
        "(industry/sector/subindustry/market), never numbers.\n"
        "NEVER use bucket() or any vec_* operator (vector reduction is applied at expansion time).\n"
        "Aim for low turnover and neutral exposure: wrap in rank()/group_rank()/group_neutralize() where it "
        "makes economic sense, and use ts_decay_linear/ts_mean to smooth noisy signals.\n"
        + hints + (K.context_text(ctx, "templates", "alphas", "papers", "notes", "lessons") if ctx else "")
        + fb + cur +
        f"=== OPERATORS ===\n{G.operator_summary()}\n{op_examples}"
        f"=== THE HYPOTHESIS' DATAFIELDS (context only — never put these ids in a template) ===\n"
        f"{G._field_summary(hyp_fields, categories, 40)}\n"
        "Return ONLY a JSON array of template strings.")
    res = _llm(meta, n)
    return _clean_templates(res.expressions, {f["id"] for f in fields})[:max(2, n * 2)]


# ── 3. expansion (round-robin across templates so a batch of 10 is diverse) ──────────

def _expand(cfg: dict, templates: list, hyp: dict, fields: list, seen: set) -> list:
    ids = list(hyp["fields"]) or [f["id"] for f in fields[:8]]
    groups = {"one": [t for t in templates if "{field2}" not in t],
              "two": [t for t in templates if "{field2}" in t]}
    by_template: list[list] = []
    for key, tl in groups.items():
        if not tl:
            continue
        multi = key == "two" and len(ids) >= 2
        if key == "two" and not multi:
            continue
        r = G.expand_templates(tl, ids, fields, ["vec_avg", "vec_max", "vec_min", "vec_norm"],
                               cfg["max_operators"], multi, max_combos=40 * cfg.get("parallel", 1))
        per: dict = {}
        for row in r["results"]:
            if row["ok"] and _norm(row["expr"]) not in seen:
                per.setdefault(_skeleton(row["expr"]), []).append(row["expr"])
        for lst in per.values():
            random.shuffle(lst)
            by_template.append(lst)
    batch, depth = [], 0
    cap = cfg["batch_size"] * cfg.get("parallel", 1)
    while len(batch) < cap and any(depth < len(l) for l in by_template):
        for lst in by_template:
            if depth < len(lst) and len(batch) < cap:
                batch.append(lst[depth])
        depth += 1
    return batch


def _skeleton(expr: str) -> str:
    try:
        return G.templatize(expr).get("template") or expr
    except Exception:
        return expr


# ── 4. review (deep BRAIN check) ─────────────────────────────────────────────────────

def _deep_check(s, alpha_id: str, max_corr: float, attempts: int = 4) -> dict:
    """Full BRAIN check for one alpha → {ok, failed:[names], pending, self_corr, prod_corr, pool_corr}."""
    df = None
    for attempt in range(attempts):
        try:
            df = ace.get_check_submission(s, alpha_id)
        except Exception:
            df = None
        if df is not None and not getattr(df, "empty", True) and "result" in df.columns:
            if not (df["result"] == "PENDING").any():
                break
        if attempt < attempts - 1:
            time.sleep(2 + 1.5 * attempt)          # was 4,8,12,16s
    if df is None or getattr(df, "empty", True) or "result" not in df.columns:
        return {"ok": False, "failed": ["check unavailable"], "pending": True,
                "self_corr": None, "prod_corr": None, "pool_corr": None}
    failed = [str(r.get("name")) for _, r in df.iterrows() if r.get("result") == "FAIL"]
    pending = bool((df["result"] == "PENDING").any())
    self_c = S._corr_from_submission(df, "self")
    prod_c = S._corr_from_submission(df, "prod")
    pool_c = S._corr_from_submission(df, "pool") or S._corr_from_submission(df, "power")
    for label, v in (("SELF_CORR>=max", self_c), ("PROD_CORR>=max", prod_c), ("POWERPOOL_CORR>=max", pool_c)):
        if v is not None and abs(v) >= max_corr and label not in failed:
            failed.append(label)
    return {"ok": not failed and not pending, "failed": failed, "pending": pending,
            "self_corr": self_c, "prod_corr": prod_c, "pool_corr": pool_c}


def _store_deep(alpha_id: str, chk: dict) -> None:
    try:
        with SessionLocal() as db:
            row = db.scalar(select(M.SimResult).where(M.SimResult.alpha_id == alpha_id))
            if not row:
                return
            row.self_corr, row.prod_corr, row.powerpool_corr = chk["self_corr"], chk["prod_corr"], chk["pool_corr"]
            if not chk["ok"]:
                row.passed_gate = False
                reasons = json.loads(row.gate_reasons or "[]")
                reasons += [f"check: {x}" for x in chk["failed"] if f"check: {x}" not in reasons]
                row.gate_reasons = json.dumps(reasons)
            db.commit()
    except Exception:
        pass


def _near_miss_score(r: dict) -> float:
    return abs(r.get("fitness") or 0) + 0.3 * abs(r.get("sharpe") or 0)


def _feedback(rows: list, checks: dict, thr: dict) -> str:
    """Compact, template-level summary of a batch for the refinement prompt."""
    per: dict = {}
    for r in rows:
        per.setdefault(_skeleton(r["expr"]), []).append(r)
    lines = [f"Gate: |Sharpe|>={thr['sharpe']}, |Fitness|>={thr['fitness']}, turnover<{thr['turnover']:.0%}, "
             "no failing IS test, correlations<0.7."]
    for tmpl, lst in sorted(per.items(), key=lambda kv: -max(_near_miss_score(x) for x in kv[1]))[:12]:
        best = max(lst, key=_near_miss_score)
        why = list(best.get("reasons") or [])
        if best.get("alpha_id") in checks:
            why += checks[best["alpha_id"]]["failed"]
        sh = best.get("sharpe"); fi = best.get("fitness"); tu = best.get("turnover")
        lines.append(f"- {tmpl}\n    best: Sharpe {sh if sh is None else round(sh, 2)}, Fitness "
                     f"{fi if fi is None else round(fi, 2)}, turnover {tu if tu is None else round(tu, 2)}"
                     f" · fails: {'; '.join(dict.fromkeys(why)) or 'none'}")
    sign_flip = [r for r in rows if (r.get("sharpe") or 0) < -0.8]
    if len(sign_flip) >= max(3, len(rows) // 2):
        lines.append("NOTE: most alphas have a strongly NEGATIVE Sharpe — the signal direction is probably "
                     "inverted; flip the sign (multiply by -1 / swap operands).")
    return "\n".join(lines)


# ── the main loop ────────────────────────────────────────────────────────────────────

DEFAULTS = dict(
    region="USA", delay=1, instrument="EQUITY", universe="TOP3000",
    neutralizations=["INDUSTRY"], decay=4, truncation=0.08,
    batch_size=10, max_rounds=4, templates_per_round=6, max_operators=4, allow_two_field=True,
    winners_per_hypothesis=1, concurrency=1,   # 1 = one batch of 10 per round
    prod_rescue_max=0.74,         # do not try to bring prod correlation down when it is above this (almost never works)
    use_atlas=True,               # give the idea-to-template step every operator of the Operator Atlas (with your edits and notes)
    stall_minutes=30,             # a step with no progress for this long: stop, abandon everything in flight, tell you on Telegram (0 = off)
    prod_check_delay=60,          # seconds to wait before each production-correlation check (0 = no wait, up to 4 checks at once)
    goal="", tag="", winner_tag="",
    min_sharpe=None, min_fitness=None, max_turnover=0.70, max_corr=0.70,
    max_cycles=0, max_winners=0, pause_between_cycles=5,
    fields=[], categories={},
    use_library=True, seed_run=True, boost=True, booster_trigger=1.0,
    flip=True, flip_min_sharpe=1.0,
    builtin_boosters=True,        # use the built-in starter boosters when your library has none for the region
    booster_own_limit=False,      # False: one threshold (booster_trigger); True: a booster's own Sharpe limit also applies
    boost_top=3,                  # boosters tried per alpha (+1 exploratory)
    boost_near_miss=0.0,          # also boost alphas this far BELOW the trigger (0 = off)
    boost_winners=False,          # also try boosting alphas that already pass everything
    nudge=True,                   # also try shorter/longer windows on promising alphas
    queue_cap=30,                 # most follow-ups waiting at once (best first, old ones dropped)
    triage=True, triage_rounds=1, triage_sharpe=0.5,   # drop an idea after its first batch if nothing reaches this |Sharpe|
    hypotheses_per_call=8,
    method="explore",             # "explore" (LLM ideas) | "clone" (old alphas with similar datafields swapped in)
    clone_sources=["submitted", "vault"], clone_min_sharpe=1.0, clone_similarity=0.5,
    clone_per_alpha=10, clone_max_sources=30, clone_ids=[],
    clone_pasted="",              # your own working alphas, pasted as text (one per line); cloned first, no Sharpe/region filter
    decorrelate=True, decorr_rounds=2, decorr_max_neuts=6,
)


_ACTIVE: dict = {"cfg": None, "cfg_in": None}      # the running engine's cfg dict (the Telegram remote edits it in place)


def live_cfg():
    """The running engine's settings dict, or None when it is not running."""
    jid = _LIVE.get("job_id")
    return _ACTIVE["cfg"] if (jid and jobs.get(jid).get("status") == "running") else None


def start(cfg_in: dict) -> dict:
    jid = _LIVE.get("job_id")
    if jid and jobs.get(jid).get("status") == "running":
        return {"job_id": jid, "already_running": True}
    try:
        from app.superpilot import service as _SP
        if _SP.is_running():
            raise RuntimeError("The Supersentry is running — stop it first (they share BRAIN's simulation slots and session).")
    except ImportError:
        pass
    cfg = {**DEFAULTS, **{k: v for k, v in cfg_in.items() if v is not None}}
    if not cfg["fields"] and cfg.get("method") != "clone":
        raise RuntimeError("Select datafields first — the engine builds hypotheses around them.")
    cfg["batch_size"] = max(2, min(10, int(cfg["batch_size"])))
    _CARRY.clear()                      # follow-ups waiting from an earlier run are stale
    _RUN.clear(); _RUN.update(BO.new_run()); _WARNED["none"] = False
    cfg["universes"] = [cfg["universe"]]
    # SPEED: a round simulates batch_size x parallel alphas as `parallel` multi-simulations that run
    # side by side (previously one batch of <=10 = one multi-sim = nothing ran in parallel).
    cfg["parallel"] = max(1, min(3, int(cfg.get("concurrency") or 1)))
    try:   # SentryEngine: with engine routing on, a round may run more batches side by side (harness/speed.py); off = the line above
        from app.harness import flags as _hf, speed as _hs
        if _hf.enabled("autopilot_via_engine"):
            cfg["parallel"] = _hs.effective_parallel(True, int(cfg.get("concurrency") or 1))
    except Exception:  # noqa: BLE001
        pass
    with _LOCK:
        _PROD_FLAGGED.clear()
        _LIVE.update({"phase": "starting", "wait": "", "hypothesis": None, "round": 0, "templates": [],
                      "last_batch": [], "events": [], "cycle": 0, "max_rounds": cfg["max_rounds"]})
    st = _load_state()
    st["started_at"] = time.time()
    _save_state(st)

    def task(progress, should_cancel):
        return _run(cfg, progress, should_cancel)

    _ACTIVE["cfg"] = cfg
    _ACTIVE["cfg_in"] = dict(cfg_in)
    _HALT["gen"] += 1
    _HALT["stop"].clear()
    _BEAT["t"] = time.time()
    try:
        from app.notify import remote as _RC
        _RC.remember_start("regular", cfg_in)
    except Exception:
        pass
    jid = jobs.submit("autopilot", task)
    _live(job_id=jid)
    return {"job_id": jid}


def _run(cfg: dict, progress, should_cancel) -> dict:
    try:
        return _run_inner(cfg, progress, should_cancel)
    except _Halted:
        return {"halted": True}


def _run_inner(cfg: dict, progress, should_cancel) -> dict:
    fields, categories = cfg["fields"], cfg.get("categories") or {}
    thr = S.gate_thresholds(cfg["delay"])
    thr = {"sharpe": cfg["min_sharpe"] or thr["sharpe"], "fitness": cfg["min_fitness"] or thr["fitness"],
           "turnover": cfg["max_turnover"]}
    queue: list = []
    fails = 0
    won_total = 0
    _CTX.update({"progress": progress, "cancel": should_cancel})
    _stop_hu = threading.Event()
    threading.Thread(target=_heads_up_loop, args=(_stop_hu, _HALT["gen"]), daemon=True).start()
    _event(f"Autosentry started · {cfg['region']}/{cfg['universe']}/delay {cfg['delay']} · "
           f"{len(fields)} fields · batches of {cfg['batch_size']}", progress)

    cfg["_gap"] = _gap_text(cfg)
    try:
        bl, bsrc = _boosters(cfg)
        _live(boost_info={"count": len(bl), "source": bsrc, "on": bool(cfg.get("boost"))})
        _event(f"Boosters: {len(bl)} from {bsrc} · boost above Sharpe {cfg.get('booster_trigger')} · reverse below -{cfg.get('flip_min_sharpe')} · "
               f"batches of {cfg['batch_size']} x {cfg.get('parallel', 1)} · idea dropped after {cfg.get('triage_rounds')} batch if best |Sharpe| < {cfg.get('triage_sharpe')}"
               if cfg.get("triage") else f"Boosters: {len(bl)} from {bsrc}", progress)
    except Exception:  # noqa: BLE001
        pass

    if cfg.get("method") == "clone":
        try:
            won_total += _clone_run(cfg, thr, progress, should_cancel)
        except Exception as e:  # noqa: BLE001
            _event(f"⚠ Clone and swap stopped: {str(e)[:220]}", progress)
            traceback.print_exc()
        _stop_hu.set()
        _live(phase="stopped", wait="")
        try:
            _event("Run summary: " + BO.run_summary(_RUN, _bstats()), progress)
        except Exception:  # noqa: BLE001
            pass
        _event("Autosentry stopped.", progress)
        return {"winners": won_total}

    if cfg.get("use_library") and cfg.get("seed_run"):
        try:
            won_total += _seed_run(cfg, thr, progress, should_cancel)
        except Exception as e:  # noqa: BLE001
            _event(f"⚠ seed run failed: {str(e)[:160]}", progress)
            traceback.print_exc()

    while not should_cancel():
        cycle_no = _load_state()["cycles"] + 1
        try:
            # session gate — wait for the user to log back in rather than dying
            _ensure_session()
            if should_cancel():
                break
            _live(wait="")

            # 1. hypothesis
            ctx = K.build_context(cfg["region"]) if cfg.get("use_library") else None
            if not queue:
                _live(phase="hypothesizing", hypothesis=None, templates=[], last_batch=[], round=0)
                _event("asking the LLM for fresh hypotheses…" + (" (using your library + lessons)" if ctx and ctx["ids"] else ""), progress)
                queue = _new_hypotheses(cfg, fields, categories, _load_state()["hypotheses"],
                                        n=max(3, min(12, int(cfg.get("hypotheses_per_call") or 8))), ctx=ctx)
                if not queue:
                    w = _HYP_WHY
                    raise RuntimeError(
                        "the LLM returned no usable hypotheses "
                        f"(of {w.get('returned', 0)} ideas: {w.get('malformed', 0)} not in the "
                        f"idea ||| mechanism ||| sign ||| fields format, {w.get('unknown_fields', 0)} used "
                        f"fields outside your selection)")
            hyp = queue.pop(0)
            _RUN["hyps"] += 1
            cfg["_hyp_no"] = _RUN["hyps"]
            hyp = {**hyp, "status": "active", "rounds": 0, "winners": [], "best_fitness": 0.0}
            _live(hypothesis=hyp, cycle=cycle_no, templates=[], last_batch=[])
            _event(f"▶ hypothesis: {hyp['idea']}  [{', '.join(hyp['fields'][:4])}]", progress)

            outcome = _work_hypothesis(cfg, hyp, fields, categories, thr, progress, should_cancel, ctx)
            _learn_from_hypothesis(cfg, hyp, outcome, ctx, progress)
            hyp.update(outcome)
            won_total += len(hyp["winners"])
            st = _load_state()
            st["cycles"] += 1
            st["hypotheses"].append({k: hyp[k] for k in ("idea", "mechanism", "status", "rounds", "winners",
                                                         "best_fitness", "fields")} | {"t": time.time()})
            _save_state(st)
            fails = 0
            if cfg["max_winners"] and won_total >= cfg["max_winners"]:
                _event(f"reached the winner target ({won_total}) — stopping.", progress); break
            if cfg["max_cycles"] and st["cycles"] >= cfg["max_cycles"]:
                _event("reached the cycle limit — stopping.", progress); break
            _live(phase="cooldown")
            _sleep(cfg["pause_between_cycles"], should_cancel)
        except Exception as e:  # noqa: BLE001 — never let one bad cycle kill an unattended run
            fails += 1
            msg = (str(e).strip().splitlines() or [type(e).__name__])[0][:220]
            back = min(900, 20 * (2 ** min(fails, 6)))
            _event(f"⚠ cycle error ({fails}): {msg} — retrying in {back}s", progress)
            if fails == 3:
                try:
                    TG.send_async(f"⚠ Autosentry has failed 3 cycles in a row.\nLast error: {msg}\nIt keeps retrying (every {back}s).")
                except Exception:  # noqa: BLE001
                    pass
            traceback.print_exc()
            _live(phase="waiting", wait=f"error: {msg} · retrying in {back}s")
            _sleep(back, should_cancel)
    _stop_hu.set()
    _live(phase="stopped", wait="")
    try:
        _event("Run summary: " + BO.run_summary(_RUN, _bstats()), progress)
    except Exception:  # noqa: BLE001
        pass
    _event("Autosentry stopped.", progress)
    return {"winners": won_total}


def _work_hypothesis(cfg, hyp, fields, categories, thr, progress, should_cancel, ctx=None) -> dict:
    templates: list = []
    feedback = ""
    seen = _seen_expressions(cfg["region"])
    winners, best = [], 0.0
    status = "stalled"
    rounds = 0
    empty_rounds = 0
    if hyp.get("revisit"):
        pr = hyp.get("prior") or {}
        feedback = (
            f"IMPROVEMENT PASS: this idea was already tried {pr.get('times', 1)} time(s) and {pr.get('status', 'stalled')} "
            f"(best fitness {pr.get('best_fitness', 0):.2f}) using fields {', '.join(pr.get('fields') or [])}. "
            "Do NOT repeat the same operator structures. Represent the idea better: change the operator mix "
            "(different smoothing/decay windows, ts_ vs group_ operators, rank vs zscore, neutralisation level, "
            "ratios or conditioning with {field2}), and use the new fields offered now where they fit.")
        _event(f"↻ improving an earlier idea (best fitness was {pr.get('best_fitness', 0):.2f}): new operators / fields", progress)
    for rnd in range(1, cfg["max_rounds"] + 1):
        if should_cancel():
            status = "cancelled"; break
        rounds = rnd
        _live(round=rnd, phase="templating")
        templates = _propose_templates(cfg, hyp, fields, categories, feedback, templates, ctx) or templates
        if rnd == 1 and ctx and ctx.get("seed_templates"):
            mine = _clean_templates(ctx["seed_templates"], {f["id"] for f in fields})
            templates = list(dict.fromkeys(mine + templates))
            if mine:
                _event(f"round 1 includes {len(mine)} of your library template(s)", progress)
        if not templates:
            _event("no valid templates this round — retrying", progress); continue
        _live(templates=templates)
        _event(f"round {rnd}: {len(templates)} templates", progress)

        batch = _expand(cfg, templates, hyp, fields, seen)
        if not batch and not _CARRY:
            empty_rounds += 1
            feedback = "Every expansion of the current templates was already simulated or invalid. Produce STRUCTURALLY NEW templates."
            if empty_rounds >= 3:
                _event("template space exhausted — abandoning hypothesis", progress); break
            continue
        exprs, meta, used_new = FU.compose(_CARRY, batch, cfg["batch_size"] * cfg.get("parallel", 1),
                                           BO.reserve_fraction(_CARRY))
        for e in exprs:
            seen.add(_norm(e))

        _live(phase="simulating")
        _event(f"simulating batch of {len(exprs)}" + (f" ({len(used_new)} new + {len(meta)} reversed/boosted)" if meta else "") + "…", progress)
        res = _simulate(cfg, exprs, thr, should_cancel)
        rows = res.get("results") or []
        st = _load_state(); st["simulated"] += len(rows); _save_state(st)
        if not rows:
            errs = "; ".join(res.get("errors") or [])[:200]
            _event(f"batch produced no results{(' — ' + errs) if errs else ''}", progress)
            feedback = f"The last batch failed to simulate ({errs}). Simplify the templates."
            continue

        # review: deep-check every gate-passer + the 3 best near-misses
        _live(phase="reviewing")
        checks = _review(cfg, rows)
        follow = _absorb_follow_ups(cfg, rows, meta, thr, progress)
        _live(last_batch=[{"expr": r["expr"], "alpha_id": r.get("alpha_id"), "sharpe": r.get("sharpe"),
                           "fitness": r.get("fitness"), "turnover": r.get("turnover"),
                           "passed": r["passed"],
                           "reasons": ([_KIND_TAG[r["_kind"]]] if r.get("_kind") else []) + (r.get("reasons") or [])
                           + (checks.get(r.get("alpha_id"), {}).get("failed") or [])}
                          for r in rows])
        for r in rows:
            if r.get("fitness") is not None:
                best = max(best, abs(r["fitness"]))
        gate_passed = [r for r in rows if r["passed"]]
        n_pass = len(gate_passed)
        _event(f"round {rnd}: {len(rows)} simulated · {n_pass} passed EVERYTHING · best |fitness| {best:.2f}", progress)

        base_rows = [r for r in rows if not r.get("_kind")]
        if cfg.get("use_library"):
            K.learn_from_batch(cfg["region"], hyp, base_rows, _skeleton)

        flip_note = follow
        if (cfg.get("flip") or cfg.get("boost")) and not should_cancel():
            _queue_follow_ups(cfg, rows, seen, progress)

        if not should_cancel():
            for dr, dchk in _decorr_pending(cfg, thr, seen, progress, should_cancel):
                checks[dr["alpha_id"]] = dchk
                gate_passed.append(dr)
                best = max(best, abs(dr.get("fitness") or 0))

        for r in gate_passed:
            winners.append(_bank_winner(cfg, hyp, r, checks.get(r["alpha_id"]), progress))
        if len(winners) >= cfg["winners_per_hypothesis"]:
            status = "won"; break
        if cfg.get("triage"):
            stop, bsh = BO.triage_stop(rows, rnd, int(cfg.get("triage_rounds") or 1), float(cfg.get("triage_sharpe") or 0.5), len(winners))
            if stop:
                _RUN["abandoned"] += 1
                _event(f"↯ not promising after {rnd} batch (best |Sharpe| {bsh:.2f} < {cfg.get('triage_sharpe')}) — next idea", progress)
                break
        feedback = _feedback(base_rows, checks, thr) + (("\n" + flip_note) if flip_note else "")
    return {"status": status, "rounds": rounds, "winners": [w["alpha_id"] for w in winners],
            "best_fitness": best, "feedback": feedback}


def _simulate(cfg: dict, batch: list, thr: dict, should_cancel, neuts: list | None = None) -> dict:
    _ensure_session()
    from app.harness.autopilot_route import engine_routing   # SentryEngine: opt-in engine routing (flag-gated)
    with engine_routing():
        return S.run_simulation(
            expressions=batch, region=cfg["region"], delay=cfg["delay"], instrument=cfg["instrument"],
            universes=cfg["universes"], neutralizations=neuts or cfg["neutralizations"], decay=cfg["decay"],
            truncation=cfg["truncation"], test_period="P0Y0M0D", pasteurization="ON", unit_handling="VERIFY",
            nan_handling="OFF", max_trade="OFF", visualization=False, concurrency=cfg["concurrency"],
            limit_of_multi=10, max_turnover=cfg["max_turnover"], min_sharpe=thr["sharpe"],
            min_fitness=thr["fitness"], max_corr=cfg["max_corr"], tag=cfg["tag"], winner_tag="",
            winner_color="GREEN", tag_winners_above=99.0, check_submission=False, get_pnl=False,
            get_stats=False, progress=lambda **k: None, should_cancel=should_cancel)


def _checks_parallel(cfg: dict, s, items: list, full_ids: set, cancel=None) -> dict:
    """BRAIN submission checks (incl. PROD / self correlation) for `items`, up to 4 AT A TIME (as in v7).
    Items not yet started when the run is cancelled are skipped (they are simply absent from the result)."""
    cancel = cancel or _CTX["cancel"]
    if not items:
        return {}

    def one(r):
        if cancel():
            return None
        return r["alpha_id"], _deep_check(s, r["alpha_id"], cfg["max_corr"], 4 if id(r) in full_ids else 1)

    got = PC.run_checks(items, one, float(cfg.get("prod_check_delay") or 0), lambda sec: _sleep(sec, cancel), cancel,
                        say=lambda m: _event(m, _CTX["progress"]))
    return {aid: chk for aid, chk in got if chk is not None}


def _review(cfg: dict, rows: list) -> dict:
    """Deep BRAIN check for every gate-passer + the 2 best near-misses, IN PARALLEL (up to 4).
    Mutates r["passed"]; flags alphas whose ONLY failure is prod correlation."""
    _ensure_session()
    s = engine.require_session()
    passers = [r for r in rows if r["passed"] and r.get("alpha_id")]
    misses = sorted([r for r in rows if not r["passed"] and r.get("alpha_id")],
                    key=_near_miss_score, reverse=True)[:2]
    full_ids = {id(r) for r in passers}
    checks = _checks_parallel(cfg, s, passers + misses, full_ids)
    for r in passers:
        if r["alpha_id"] not in checks:          # cancelled before this one was checked
            r["passed"] = False

    for r in misses:
        c = checks.get(r["alpha_id"])
        if c and c.get("pending"):
            c["failed"] = [x for x in c["failed"] if x != "check unavailable"]
    for r in passers:
        chk = checks.get(r["alpha_id"])
        if chk is None:
            continue
        _store_deep(r["alpha_id"], chk)
        r["passed"] = chk["ok"]
        if _prod_only(chk):
            r["prod_only"] = True
            with _LOCK:
                _PROD_FLAGGED.append((r, chk))
    return checks


def _unwrap(e: str, pat: str) -> str | None:
    m = re.fullmatch(pat, e.strip(), re.S)
    if m and K._balanced(m.group(1)):
        return m.group(1).strip()
    return None


def flip_expr(expr: str) -> str:
    """Reverse an alpha's sign. Already-negated expressions are un-negated instead of double-wrapped."""
    e = expr.strip()
    for pat in (r"-\s*1\s*\*\s*\((.*)\)", r"reverse\((.*)\)", r"-\s*\((.*)\)"):
        inner = _unwrap(e, pat)
        if inner:
            return inner
    return f"-1 * ({e})"


def _append_batch(new_rows: list) -> None:
    with _LOCK:
        _LIVE["last_batch"] = (list(_LIVE.get("last_batch") or []) + new_rows)[-60:]


_CARRY: list = []          # follow-ups waiting for the next batch: (expression, base row, kind, booster, {"hyp": n})
_KIND_TAG = {"flip": "sign reversed", "boost": "boosted", "flip+boost": "reversed+boosted", "nudge": "window nudged"}
_RUN: dict = BO.new_run()
_BSTATS_FILE = get_settings().data_dir / "boost_stats.json"
_WARNED: dict = {"none": False}


def _bstats() -> dict:
    try:
        return json.loads(_BSTATS_FILE.read_text())
    except Exception:
        return {}


def _bstats_save(st: dict) -> None:
    try:
        _BSTATS_FILE.write_text(json.dumps(st))
    except Exception:
        pass


def _boosters(cfg: dict) -> tuple[list, str]:
    """Boosters to use: your enabled library boosters for this region; else the built-in starters (if allowed)."""
    if not cfg.get("boost"):
        return [], "off"
    lib = K.active_boosters(cfg.get("region") or "")
    if lib:
        return lib, "your library"
    if cfg.get("builtin_boosters", True):
        return [dict(b) for b in BO.STARTERS], "built-in starters"
    return [], "none"


def _queue_follow_ups(cfg: dict, rows: list, seen: set, progress) -> None:
    """After a batch: queue what should be reversed (Sharpe below -1), boosted (Sharpe above 1) or window-nudged.
    They run in the NEXT batch. Always says what it did, or why it did nothing."""
    boosters, source = _boosters(cfg)
    if cfg.get("boost") and not boosters and not _WARNED["none"]:
        _WARNED["none"] = True
        _event(f"⚠ Boosters are ON but none is enabled for {cfg.get('region')} and the built-in starters are off — nothing can be boosted. "
               "Add boosters in Library, or turn the starters on.", progress)
    trig = float(cfg.get("booster_trigger") or 1.0)
    stats = _bstats()
    own = bool(cfg.get("booster_own_limit"))
    rep: dict = {}
    near = float(cfg.get("boost_near_miss") or 0)
    eff = trig - near if near > 0 else trig          # the lowest Sharpe that may be boosted
    items = FU.plan(rows, flip_on=bool(cfg.get("flip")), flip_at=float(cfg.get("flip_min_sharpe") or 1.0),
                    trigger=trig, max_turnover=cfg["max_turnover"], boosters=boosters,
                    eligible=lambda r, b, t: BO.eligible(r, b, t, own), apply_booster=K.apply_booster, flip_expr=flip_expr,
                    norm=_norm, seen=seen, queued={_norm(i[0]) for i in _CARRY},
                    pick=(lambda r: BO.pick(r, boosters, stats, eff, own, int(cfg.get("boost_top") or 3), set(r.get("_applied") or [])))
                    if boosters else None,
                    hyp_no=int(cfg.get("_hyp_no") or 0), include_passed=bool(cfg.get("boost_winners")),
                    nudge=BO.nudges if cfg.get("nudge") else None, floor=(trig - near) if near > 0 else None, report=rep)
    dropped = 0
    if items:
        _CARRY.extend(items)
        dropped = BO.trim(_CARRY, int(cfg.get("queue_cap") or 30), int(cfg.get("_hyp_no") or 0))
    if cfg.get("boost") or cfg.get("flip"):
        _event("follow-ups: " + BO.queue_line(rep, len(boosters), trig, source, dropped, len(_CARRY)), progress)


def _absorb_follow_ups(cfg: dict, rows: list, meta: dict, thr: dict, progress) -> str:
    """Results of the reversed/boosted/nudged variants that rode in this batch: tag them, learn from them. Returns a note for the LLM."""
    if not meta:
        return ""
    stats = _bstats()
    evs = BO.absorb(rows, meta, stats, _RUN, _norm, thr["sharpe"] * 0.6)
    _bstats_save(stats)
    improved = nflip = 0
    for ev in evs:
        r, base, kind, b = ev["row"], ev["base"], ev["kind"], ev["booster"]
        if kind == "flip":
            nflip += 1
            if ev["promising"]:
                improved += 1
                if cfg.get("use_library"):
                    K.add_lesson(f"Direction matters: {_skeleton(base['expr'])[:150]} has its edge with the sign "
                                 f"REVERSED (Sharpe {base['sharpe']:.2f} -> {r['sharpe']:.2f}). "
                                 "Build this mechanism with the opposite sign from the start.",
                                 "insight", cfg["region"])
        elif b is not None and base.get("sharpe") is not None:
            if not b.get("builtin"):
                K.learn_booster(cfg["region"], b, base["sharpe"], r["sharpe"])
            if (b.get("id") or 0) > 0:
                K.record_outcome([b["id"]], bool(r["passed"]))
        if r["passed"] and r.get("alpha_id"):
            nm = b["name"] if b else ""
            r["via"] = {"flip": "sign reversed", "nudge": "window nudged", "boost": "boosted (" + nm + ")"}.get(
                kind, "sign reversed + boosted (" + nm + ")")
    _event(f"follow-ups in this batch: {len(meta)} · {improved} reversed ones became promising · "
           f"boosts helped {_RUN['boost_helped']}/{_RUN['boosts']} so far", progress)
    return (f"Sign-reversed retries: {improved} of {nflip} became promising (those mechanisms work in the "
            "OPPOSITE direction — use that sign in the new templates).") if nflip else ""


# ── prod-correlation rescue: cross-neutralization → re-check → sister/brother operator swaps ──

_PROD_FLAGGED: list = []      # (row, check) for alphas whose ONLY failure is production correlation


def _prod_only(chk: dict) -> bool:
    failed = chk.get("failed") or []
    return bool(failed) and not chk.get("pending") and all("PROD" in str(f).upper() for f in failed)


def _prod_val(chk: dict) -> float:
    v = chk.get("prod_corr")
    return abs(v) if v is not None else 9.0


def _check_variants(cfg: dict, rows: list, should_cancel, limit: int = 5) -> list:
    """Full BRAIN check for the best metric-passing variants → [(row, check)]."""
    _ensure_session()
    s = engine.require_session()
    cand = sorted([r for r in rows if r.get("passed") and r.get("alpha_id")],
                  key=lambda r: -abs(r.get("fitness") or 0))[:limit]
    if not cand or should_cancel():
        return []
    got = _checks_parallel(cfg, s, cand, {id(r) for r in cand}, should_cancel)
    out = []
    for r in cand:
        chk = got.get(r["alpha_id"])
        if chk is None:
            continue
        _store_deep(r["alpha_id"], chk)
        r["passed"] = chk["ok"]
        out.append((r, chk))
    return out


def _op_mutants(expr: str, groups: list, known: set, limit: int, validate=None) -> list:
    """Swap ONE operator at a time for a sister/brother from its group → [(new_expr, 'a->b')]."""
    out, seen = [], {_norm(expr)}
    for grp in groups:
        grp = [g for g in grp if not known or g in known]
        for op in grp:
            for m in re.finditer(rf"\b{re.escape(op)}\s*\(", expr):
                for alt in grp:
                    if alt == op:
                        continue
                    e = expr[:m.start()] + alt + "(" + expr[m.end():]
                    if _norm(e) in seen:
                        continue
                    try:
                        if validate is not None:
                            if not validate(e):
                                continue
                        elif not G.sandbox_validate(e).get("ok"):
                            continue
                    except Exception:
                        pass
                    seen.add(_norm(e))
                    out.append((e, f"{op}->{alt}"))
    random.shuffle(out)
    return out[:limit]


def _decorrelate(cfg: dict, base: dict, base_chk: dict, thr: dict, seen: set, progress, should_cancel):
    """An alpha passed every metric but its PROD correlation is too high. Stage A re-simulates the
    same expression under the other neutralizations and re-checks prod; stage B (if still high)
    swaps operators for their sister/brother operators, one at a time, and re-checks prod.
    Returns (row, check) for the first variant that passes EVERYTHING, else None."""
    start = base_chk.get("prod_corr")
    _live(phase="decorrelating")
    _event(f"prod-corr {start if start is None else round(start, 2)} ≥ {cfg['max_corr']} on {base.get('alpha_id')} — "
           "trying cross-neutralization first…", progress)
    best_row, best_chk, best_val = base, base_chk, _prod_val(base_chk)
    expr, neut = base["expr"], base.get("neutralization")

    def consider(rows, tag):
        nonlocal best_row, best_chk, best_val
        for r, chk in _check_variants(cfg, rows, should_cancel):
            r["via"] = tag(r)
            if chk["ok"]:
                return r, chk
            if _prod_only(chk) and _prod_val(chk) < best_val:
                best_row, best_chk, best_val = r, chk, _prod_val(chk)
        return None

    # ── stage A: cross-neutralization ──
    try:
        valid = engine.valid_neutralizations(cfg["instrument"], cfg["region"]) or {
            "MARKET", "SECTOR", "INDUSTRY", "SUBINDUSTRY"}
        others = [n for n in sorted(valid) if n != neut][:max(1, int(cfg.get("decorr_max_neuts") or 6))]
        if others and not should_cancel():
            _event(f"cross-neutralization: {len(others)} option(s) ({', '.join(others)})", progress)
            res = _simulate(cfg, [expr], thr, should_cancel, neuts=others)
            hit = consider(res.get("results") or [], lambda r: f"cross-neutralization {r.get('neutralization')}")
            if hit:
                _event(f"✓ cross-neutralization fixed prod-corr ({hit[1].get('prod_corr')}) → {hit[0].get('neutralization')}", progress)
                _decorr_lesson(cfg, base, f"cross-neutralization to {hit[0].get('neutralization')}", start, hit[1])
                return hit
    except Exception as e:  # noqa: BLE001
        _event(f"⚠ cross-neutralization failed: {str(e)[:140]}", progress)

    # ── stage B: sister / brother operators on the least-correlated variant so far ──
    try:
        groups = K.active_opgroups()
        try:
            known = {o["name"] for o in G.operators_list()}
        except Exception:
            known = set()
        for rnd in range(1, max(1, int(cfg.get("decorr_rounds") or 2)) + 1):
            if should_cancel():
                break
            muts = [(e, d) for e, d in _op_mutants(best_row["expr"], groups, known, cfg["batch_size"] * 2)
                    if _norm(e) not in seen][:cfg["batch_size"]]
            if not muts:
                _event("no sister/brother operator swaps left to try", progress)
                break
            for e, _ in muts:
                seen.add(_norm(e))
            _event(f"sister/brother operators · round {rnd}: {len(muts)} variant(s), prod now {best_val:.2f}…", progress)
            by = {_norm(e): d for e, d in muts}
            nn = [best_row.get("neutralization")] if best_row.get("neutralization") else None
            res = _simulate(cfg, [e for e, _ in muts], thr, should_cancel, neuts=nn)
            hit = consider(res.get("results") or [], lambda r: f"operator swap {by.get(_norm(r['expr']), '?')}")
            if hit:
                _event(f"✓ {hit[0]['via']} fixed prod-corr ({hit[1].get('prod_corr')})", progress)
                _decorr_lesson(cfg, base, hit[0]["via"], start, hit[1])
                return hit
    except Exception as e:  # noqa: BLE001
        _event(f"⚠ operator-swap stage failed: {str(e)[:140]}", progress)
        traceback.print_exc()

    _event(f"prod-corr stayed high ({best_val:.2f}) — gave up on {base.get('alpha_id')}", progress)
    if cfg.get("use_library"):
        K.add_lesson(f"Prod correlation stayed ≥{cfg['max_corr']} even after cross-neutralization and operator "
                     f"swaps for: {_skeleton(expr)[:160]} — this structure is too similar to production alphas; "
                     "avoid it.", "failure", cfg["region"])
    return None


def _decorr_lesson(cfg: dict, base: dict, how: str, before, chk: dict) -> None:
    if cfg.get("use_library"):
        a = "?" if before is None else f"{before:.2f}"
        b = chk.get("prod_corr")
        K.add_lesson(f"Prod-corr rescue worked via {how} (prod {a} -> {b if b is None else round(b, 2)}) on: "
                     f"{_skeleton(base['expr'])[:150]}", "success", cfg["region"])


def _decorr_pending(cfg: dict, thr: dict, seen: set, progress, should_cancel) -> list:
    """Process alphas flagged by _review as 'only prod-corr failed'. Returns [(row, check)] winners."""
    with _LOCK:
        items = list(_PROD_FLAGGED)
        _PROD_FLAGGED.clear()
    if not cfg.get("decorrelate") or not items:
        return []
    uniq = {r.get("alpha_id"): (r, c) for r, c in items if r.get("alpha_id")}
    limit = float(cfg.get("prod_rescue_max") if cfg.get("prod_rescue_max") is not None else 0.74)
    for aid, (r, c) in list(uniq.items()):
        if not WN.worth_rescuing(c.get("prod_corr"), limit):
            _event(f"prod-corr {round(abs(c.get('prod_corr')), 2)} on {aid} is above {limit} — too high to fix, not trying", progress)
            del uniq[aid]
    items = sorted(uniq.values(), key=lambda rc: -abs(rc[0].get("fitness") or 0))[:3]
    wins = []
    for r, chk in items:
        if should_cancel():
            break
        hit = _decorrelate(cfg, r, chk, thr, seen, progress, should_cancel)
        if hit:
            wins.append(hit)
    return wins


def _seed_run(cfg: dict, thr: dict, progress, should_cancel) -> int:
    """Simulate the user's library alphas once under THIS run's settings (and flip/boost them), so
    the working alphas that already exist are re-checked/improved before new research starts."""
    ctx = K.build_context(cfg["region"])
    alphas = list(dict.fromkeys(ctx.get("seed_alphas") or []))
    if not alphas:
        return 0
    seen = _seen_expressions(cfg["region"])
    todo = [a for a in alphas if _norm(a) not in seen][:30]
    if not todo:
        _event("seed run: every library alpha was already simulated in this region", progress)
        return 0
    hyp = {"idea": "Library alpha (seed run)", "mechanism": "user-provided working alpha", "sign": "", "fields": []}
    n_won = 0
    step = cfg["batch_size"] * cfg.get("parallel", 1)
    for i in range(0, len(todo), step):
        if should_cancel():
            break
        exprs, meta, used_new = FU.compose(_CARRY, todo[i:i + step], step, BO.reserve_fraction(_CARRY))
        for e in exprs:
            seen.add(_norm(e))
        _live(phase="simulating", hypothesis=hyp)
        _event(f"seed run: simulating {len(used_new)} of your library alphas" + (f" + {len(meta)} reversed/boosted" if meta else "") + "…", progress)
        res = _simulate(cfg, exprs, thr, should_cancel)
        rows = res.get("results") or []
        if not rows:
            continue
        _live(phase="reviewing")
        checks = _review(cfg, rows)
        _absorb_follow_ups(cfg, rows, meta, thr, progress)
        passed = [r for r in rows if r["passed"]]
        if cfg.get("flip") or cfg.get("boost"):
            _queue_follow_ups(cfg, rows, seen, progress)
        for dr, dchk in _decorr_pending(cfg, thr, seen, progress, should_cancel):
            checks[dr["alpha_id"]] = dchk
            passed.append(dr)
        for r in passed:
            _bank_winner(cfg, hyp, r, checks.get(r["alpha_id"]), progress)
            n_won += 1
    return n_won


def _balanced_expr(e: str) -> bool:
    return bool(e) and e.count("(") == e.count(")")


_CLONE_SKIP: dict = {"python": 0}      # how many Python alphas the last _clone_sources call left out


def _clone_sources(cfg: dict) -> list:
    """Old alphas to clone: your submitted alphas and/or your vault, in this run's region and delay, best Sharpe first."""
    want = set(cfg.get("clone_sources") or [])
    ids = {str(x).strip() for x in (cfg.get("clone_ids") or []) if str(x).strip()}
    minsh = float(cfg.get("clone_min_sharpe") or 0)
    out: dict = {}
    _CLONE_SKIP["python"] = 0

    def add(aid, expr, sh, language=""):
        expr = (expr or "").strip()
        if CL.is_python_alpha({"language": language}, expr):
            _CLONE_SKIP["python"] += 1                       # Python alphas cannot be cloned by swapping datafield names
            return
        if not _balanced_expr(expr) or (ids and aid not in ids):
            return
        if sh is None or sh < minsh:
            return
        out.setdefault(_norm(expr), {"id": aid, "expr": expr, "sharpe": sh})

    if "submitted" in want:
        try:
            from app.osmosis import service as OS
            alphas = OS.load_snapshot().get("alphas") or OS.list_submitted_light()
        except Exception as e:  # noqa: BLE001
            alphas = []
            _event(f"could not read your submitted alphas: {str(e)[:120]}", None)
        for a in alphas:
            if a.get("region") == cfg["region"] and int(a.get("delay") or 0) == int(cfg["delay"]):
                add(a["id"], a.get("expr"), a.get("sharpe"), a.get("language") or "")
    if "vault" in want:
        with SessionLocal() as db:
            for v in db.scalars(select(M.VaultAlpha).where(M.VaultAlpha.region == cfg["region"],
                                                           M.VaultAlpha.delay == int(cfg["delay"]))).all():
                add(v.alpha_id or f"vault{v.id}", v.expression, v.sharpe)
    rows = sorted(out.values(), key=lambda r: -(r["sharpe"] or 0))
    rows = rows[:max(1, int(cfg.get("clone_max_sources") or 30))]
    # your own pasted alphas: you said they work, so no Sharpe / region / id filter and no cap; they go first
    mine, seen_n = [], set()
    for a in CL.parse_pasted(cfg.get("clone_pasted") or ""):
        if CL.is_python_alpha(code=a["expr"]):
            _CLONE_SKIP["python"] += 1
            continue
        if _balanced_expr(a["expr"]) and _norm(a["expr"]) not in seen_n:
            seen_n.add(_norm(a["expr"]))
            mine.append({"id": a["id"], "expr": a["expr"], "sharpe": None, "pasted": True})
    return mine + [r for r in rows if _norm(r["expr"]) not in seen_n]


def _catalog_rows(cfg: dict) -> list:
    with SessionLocal() as db:
        fs = db.scalars(select(M.Field).where(M.Field.region == cfg["region"], M.Field.delay == int(cfg["delay"]))).all()
        return [{"field_id": f.field_id, "dataset_id": f.dataset_id, "type": f.type, "description": f.description} for f in fs]


def _clone_run(cfg: dict, thr: dict, progress, should_cancel) -> int:
    """Clone and swap: each old alpha keeps its shape and gets SIMILAR datafields from the Data Catalog swapped in.
    Batches of 10, then the usual follow-ups (reverse, boost, nudge) and the full BRAIN check incl. prod correlation."""
    sources = _clone_sources(cfg)
    if _CLONE_SKIP["python"]:
        _event(f"Clone and swap: skipped {_CLONE_SKIP['python']} Python alpha(s); only fast-expression alphas are cloned.", progress)
    if not sources:
        _event(f"Clone and swap: no source alphas for {cfg['region']} delay {cfg['delay']} with Sharpe ≥ {cfg.get('clone_min_sharpe')}. "
               "Check the sources and the minimum Sharpe, or paste your own alphas.", progress)
        return 0
    catalog = _catalog_rows(cfg)
    if not catalog:
        raise RuntimeError(f"The Data Catalog has no datafields for {cfg['region']} delay {cfg['delay']}. Open Data Catalog and download them first.")
    seen = _seen_expressions(cfg["region"])
    slider = float(cfg.get("clone_similarity") if cfg.get("clone_similarity") is not None else 0.5)
    per = int(cfg.get("clone_per_alpha") or 10)
    stats: dict = {}
    plan = CL.plan_swaps(sources, catalog, slider, per, seen, _norm, stats=stats)
    if not plan and stats.get("with_fields"):
        # Do not just stop: widen the search once (more swaps per alpha, any similarity above zero) before giving up.
        _event(f"Clone and swap: no new swaps at the chosen settings ({CL.why_empty(stats, cfg['region'], cfg['delay'])}) Widening the search once…", progress)
        stats = {}
        plan = CL.plan_swaps(sources, catalog, slider, max(per * 3, 30), seen, _norm, min_sim=0.0, stats=stats)
    lineage = {_norm(p["expr"]): p for p in plan}
    _own = sum(1 for x in sources if x.get("pasted"))
    _event(f"Clone and swap: {len(sources)} source alpha(s)" + (f" ({_own} pasted by you)" if _own else "") + f" · {len(catalog)} catalogue fields · {len(plan)} swaps planned "
           f"(similarity {cfg.get('clone_similarity')}: 0 = same dataset, 1 = other datasets)", progress)
    if not plan:
        _event("Nothing to swap. " + CL.why_empty(stats, cfg["region"], cfg["delay"]), progress)
        return 0
    hyp = {"idea": "Clone and swap", "mechanism": "an old alpha with a similar datafield", "sign": "", "fields": []}
    _live(phase="simulating", hypothesis=hyp, cycle=1)
    queue = [p["expr"] for p in plan]
    step = cfg["batch_size"] * cfg.get("parallel", 1)
    n_won, tested, rnd = 0, 0, 0
    while (queue or _CARRY) and not should_cancel():
        rnd += 1
        _ensure_session()
        exprs, meta, used_new = FU.compose(_CARRY, queue[:step], step, BO.reserve_fraction(_CARRY))
        del queue[:len(used_new)]
        if not exprs:
            break
        for e in exprs:
            seen.add(_norm(e))
        _live(phase="simulating", round=rnd)
        _event(f"clone batch {rnd}: {len(used_new)} swap(s)" + (f" + {len(meta)} reversed/boosted" if meta else "") + f" · {len(queue)} still queued…", progress)
        res = _simulate(cfg, exprs, thr, should_cancel)
        rows = res.get("results") or []
        st = _load_state(); st["simulated"] += len(rows); _save_state(st)
        if not rows:
            errs = "; ".join(res.get("errors") or [])[:200]
            _event(f"batch produced no results{(' — ' + errs) if errs else ''}", progress)
            continue
        tested += len(rows)
        _live(phase="reviewing")
        checks = _review(cfg, rows)
        _absorb_follow_ups(cfg, rows, meta, thr, progress)
        for r in rows:
            p = lineage.get(_norm(r.get("expr") or ""))
            if p is not None and not r.get("_kind"):
                r["via"] = f"cloned from {p['source_id']}: {p['old']} -> {p['new']}"
        _live(last_batch=[{"expr": r["expr"], "alpha_id": r.get("alpha_id"), "sharpe": r.get("sharpe"), "fitness": r.get("fitness"),
                           "turnover": r.get("turnover"), "passed": r["passed"],
                           "reasons": ([_KIND_TAG[r["_kind"]]] if r.get("_kind") else []) + (r.get("reasons") or [])
                           + (checks.get(r.get("alpha_id"), {}).get("failed") or [])} for r in rows])
        passed = [r for r in rows if r["passed"]]
        _event(f"clone batch {rnd}: {len(rows)} simulated · {len(passed)} passed EVERYTHING (incl. prod correlation)", progress)
        if cfg.get("flip") or cfg.get("boost"):
            _queue_follow_ups(cfg, rows, seen, progress)
        for dr, dchk in _decorr_pending(cfg, thr, seen, progress, should_cancel):
            checks[dr["alpha_id"]] = dchk
            passed.append(dr)
        for r in passed:
            _bank_winner(cfg, hyp, r, checks.get(r["alpha_id"]), progress)
            n_won += 1
        _RUN["hyps"] = 1
        if cfg["max_winners"] and n_won >= cfg["max_winners"]:
            _event(f"reached the winner target ({n_won}) — stopping.", progress)
            break
    _event(f"Clone and swap finished: {tested} simulated, {n_won} winner(s).", progress)
    return n_won


def _learn_from_hypothesis(cfg: dict, hyp: dict, outcome: dict, ctx: dict | None, progress) -> None:
    """Write the result back: asset win/use counters + one distilled LLM lesson per hypothesis."""
    if not cfg.get("use_library"):
        return
    won = outcome.get("status") == "won"
    try:
        K.record_outcome((ctx or {}).get("ids") or [], won)
    except Exception:
        pass
    if won:
        return          # successes were already recorded structurally in _bank_winner
    try:
        res = _llm(
            "A WorldQuant BRAIN research run just STALLED. Hypothesis: "
            f"{hyp['idea']}\nMechanism: {hyp.get('mechanism','')}\nRounds tried: {outcome.get('rounds')}, "
            f"best |fitness| {outcome.get('best_fitness', 0):.2f}.\n"
            f"Last round summary:\n{outcome.get('feedback', '')[:1800]}\n"
            "Write 1-2 SHORT, concrete, reusable lessons (what to avoid or change next time, max 30 words "
            "each). Return ONLY a JSON array of strings.", 2)
        for t in res.expressions[:2]:
            K.add_lesson(str(t), "failure", cfg["region"], source="llm")
    except Exception:
        pass


def _bank_winner(cfg, hyp, r, chk, progress) -> dict:
    """Record a winner, ALWAYS: tag it in BRAIN, put it in the vault, keep it in the run's winner list and the library, and send the
    notification. Every step is tried on its own, so one failing never stops the others, and a failing step is written to the log
    instead of being swallowed."""
    aid = r["alpha_id"]
    w = {"alpha_id": aid, "expr": r["expr"], "sharpe": r.get("sharpe"), "fitness": r.get("fitness"),
         "turnover": r.get("turnover"), "self_corr": (chk or {}).get("self_corr"),
         "prod_corr": (chk or {}).get("prod_corr"), "hypothesis": hyp["idea"], "via": r.get("via", ""),
         "neutralization": r.get("neutralization"), "t": time.time()}
    st = _load_state(); st["winners"].append(w); _save_state(st)            # first: the winner is on record whatever happens next

    def step(label, fn):
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            _event(f"  (could not {label} for {aid}: {type(e).__name__}: {str(e)[:120]})", progress)

    def tag():
        s = engine.require_session()
        ace.set_alpha_properties(s, aid, color="GREEN", tags=[t for t in [cfg["winner_tag"] or cfg["tag"]] if t])

    def vault_save():
        from app.vault import service as vault
        note = f"Autosentry · {hyp['idea']}" + (f" · {r['via']}" if r.get("via") else "")
        tags = ["autopilot"] + (["cloned"] if str(r.get("via", "")).startswith("cloned") else ["decorrelated"] if r.get("via") else [])
        with SessionLocal() as db:
            sr = db.scalar(select(M.SimResult).where(M.SimResult.alpha_id == aid))
            sid = sr.id if sr else 0
        if sid:
            vault.add_from_result(sid, note=note, tags=tags)
        else:                                                                # not in the results table: save it from what we have
            vault.add_manual(alpha_id=aid, expression=r["expr"], region=cfg["region"], delay=cfg["delay"], universe=cfg["universe"],
                             neutralization=r.get("neutralization") or "", sharpe=r.get("sharpe"), fitness=r.get("fitness"),
                             turnover=r.get("turnover"), note=note, tags=tags)

    def library():
        if cfg.get("use_library"):
            K.add_asset("alpha", r["expr"], name=f"Autosentry winner {aid}", source="autopilot",
                        meta={"sharpe": r.get("sharpe"), "fitness": r.get("fitness"), "alpha_id": aid, "found_in": cfg["region"]})
            K.add_lesson(f"Winning idea: {hyp['idea'][:120]} -> {_skeleton(r['expr'])[:160]}", "success", cfg["region"])

    def notify():
        c = TG.config()
        if c.get("token") and str(c.get("chat_id", "")).strip():              # always, whenever a bot token and chat are saved
            if not TG.send(WN.winner_text(w, cfg["region"], cfg.get("delay")), silent=False):
                _event(f"  (Telegram did not accept the notification for {aid})", progress)
        else:
            _event("  (no Telegram notification: set up and enable Telegram in Autosentry to get one)", progress)

    step("tag it in BRAIN", tag)
    step("save it to the vault", vault_save)
    step("add it to the library", library)
    step("send the notification", notify)
    _event(f"★ WINNER {aid}: Sharpe {WN._f(w['sharpe'])} · Fitness {WN._f(w['fitness'])} · {r['expr'][:120]}", progress)
    return w
