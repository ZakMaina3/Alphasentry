"""Small pure helpers for winners and the prod-correlation rescue (no database, no BRAIN, no network)."""
from __future__ import annotations


def worth_rescuing(prod_corr, limit: float) -> bool:
    """Is a prod-correlation of this size worth trying to bring down? Above `limit` (default 0.74) it almost never works and wastes
    simulations, so the alpha is skipped. An unknown value is given the benefit of the doubt."""
    if prod_corr is None:
        return True
    try:
        return abs(float(prod_corr)) <= float(limit)
    except (TypeError, ValueError):
        return True


def _f(v, nd: int = 2) -> str:
    try:
        return f"{float(v):.{nd}f}"
    except (TypeError, ValueError):
        return "n/a"


def winner_text(w: dict, region: str = "", delay=None) -> str:
    """The notification for a winner. Never raises, whatever is missing (a None Sharpe used to make the old message fail silently)."""
    where = f" · {region}" + (f" D{delay}" if delay is not None else "") if region else ""
    lines = [f"★ Autosentry found an alpha: {w.get('alpha_id') or '?'}{where}",
             f"Sharpe {_f(w.get('sharpe'))} · Fitness {_f(w.get('fitness'))} · Turnover {_f(w.get('turnover'))}",
             f"Prod corr {_f(w.get('prod_corr'))} · Self corr {_f(w.get('self_corr'))}"]
    if w.get("neutralization"):
        lines.append(f"Neutralization {w['neutralization']}")
    if w.get("via"):
        lines.append(str(w["via"])[:200])
    lines.append(str(w.get("expr") or "")[:300])
    return "\n".join(lines)
