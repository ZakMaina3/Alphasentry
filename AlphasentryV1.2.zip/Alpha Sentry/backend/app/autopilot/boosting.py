"""Boosting helpers (pure: no database, no BRAIN).

* STARTERS: a few built-in booster wrappers used ONLY when the user's library has no enabled booster for the
  region (they live in code, never in the user's library, so every user's library stays their own).
* One threshold: an alpha is boosted when Sharpe > the trigger; a booster's own limit only counts when asked.
* Smart choice: boosters are ranked by what they have actually added before, matched to the check the alpha failed,
  with one slot kept for exploring a booster that has little history. Boosters that keep hurting are retired.
* Window nudges, queue trimming, and the "is this idea worth another batch" triage.
"""
from __future__ import annotations

import re

STARTERS: list[dict] = [
    {"id": -1, "name": "starter: neutralize industry", "body": "group_neutralize({alpha}, industry)", "family": "neutral"},
    {"id": -2, "name": "starter: neutralize subindustry", "body": "group_neutralize({alpha}, subindustry)", "family": "neutral"},
    {"id": -3, "name": "starter: neutralize sector", "body": "group_neutralize({alpha}, sector)", "family": "neutral"},
    {"id": -4, "name": "starter: decay 5", "body": "ts_decay_linear({alpha}, 5)", "family": "smooth"},
    {"id": -5, "name": "starter: decay 10", "body": "ts_decay_linear({alpha}, 10)", "family": "smooth"},
    {"id": -6, "name": "starter: rank", "body": "rank({alpha})", "family": "rank"},
    {"id": -7, "name": "starter: zscore", "body": "zscore({alpha})", "family": "rank"},
    {"id": -8, "name": "starter: liquid days only", "body": "trade_when(volume > adv20, {alpha}, -1)", "family": "cond"},
]
for _s in STARTERS:
    _s.setdefault("min_sharpe", None)
    _s.setdefault("max_turnover", None)
    _s["builtin"] = True

# which kinds of booster tend to fix which failed check (words found in the failure reasons)
FIXES = {"turnover": ("smooth", "cond"), "corr": ("neutral",), "fitness": ("rank", "cond", "smooth"),
         "sub": ("neutral",), "universe": ("neutral",), "sharpe": ("neutral", "rank")}
DEFAULT_PRIOR = 0.15          # assumed Sharpe gain for a booster with no history


def family_of(b: dict) -> str:
    if b.get("family"):
        return b["family"]
    body = (b.get("body") or "").lower()
    if "group_neutralize" in body or "group_" in body:
        return "neutral"
    if "decay" in body or "ts_mean" in body:
        return "smooth"
    if "trade_when" in body:
        return "cond"
    if "rank" in body or "zscore" in body or "scale" in body:
        return "rank"
    return "other"


def key_of(b: dict) -> str:
    return str(b.get("name") or b.get("body"))


# ── eligibility: ONE threshold ───────────────────────────────────────────────────────

def eligible(row: dict, b: dict, trigger: float, own_limit: bool = False) -> bool:
    sh = row.get("sharpe")
    if sh is None or sh < trigger:
        return False
    if own_limit and b.get("min_sharpe") and sh < float(b["min_sharpe"]):
        return False
    mt, tu = b.get("max_turnover"), row.get("turnover")
    return not (mt and tu is not None and tu > float(mt))


# ── learning what each booster is worth ──────────────────────────────────────────────

def record(stats: dict, b: dict, gain: float) -> None:
    s = stats.setdefault(key_of(b), {"n": 0, "gain": 0.0, "hurt": 0})
    s["n"] += 1
    s["gain"] += float(gain)
    if gain < -0.05:
        s["hurt"] += 1


def mean_gain(stats: dict, b: dict) -> float | None:
    s = stats.get(key_of(b))
    return None if not s or not s["n"] else s["gain"] / s["n"]


def retired(stats: dict, b: dict, min_n: int = 5, floor: float = -0.1) -> bool:
    m = mean_gain(stats, b)
    return m is not None and stats[key_of(b)]["n"] >= min_n and m < floor


def pick(row: dict, boosters: list, stats: dict, trigger: float, own_limit: bool = False,
         top: int = 3, applied: set | None = None) -> list:
    """The boosters to try on this alpha: the best `top` by expected gain (history + a bonus when the booster's
    family fixes a check this alpha failed), plus one with little history so new boosters still get tested."""
    applied = applied or set()
    cand = [b for b in boosters if eligible(row, b, trigger, own_limit) and key_of(b) not in applied
            and not retired(stats, b)]
    if len(cand) <= top:
        return cand
    why = " ".join(str(x) for x in (row.get("reasons") or [])).lower()
    want = {f for word, fams in FIXES.items() if word in why for f in fams}

    def score(b):
        m = mean_gain(stats, b)
        return (DEFAULT_PRIOR if m is None else m) + (0.25 if family_of(b) in want else 0.0)

    ranked = sorted(cand, key=lambda b: -score(b))
    chosen = ranked[:top]
    rest = [b for b in ranked[top:]]
    if rest:                                          # explore: the one we know least about
        chosen.append(min(rest, key=lambda b: (stats.get(key_of(b), {}).get("n", 0), -score(b))))
    return chosen


def best_booster(stats: dict) -> tuple | None:
    ranked = [(k, v["gain"] / v["n"], v["n"]) for k, v in stats.items() if v["n"] >= 2]
    return max(ranked, key=lambda x: x[1]) if ranked else None


# ── parameter nudges ─────────────────────────────────────────────────────────────────

_WIN = re.compile(r"(ts_[a-z_0-9]+\(\s*[^(),]+,\s*)(\d+)(\s*[,)])")


def nudges(expr: str, scales: tuple = (0.6, 1.6)) -> list:
    """Up to two variants with the first plain ts_* window changed (shorter / longer)."""
    m = _WIN.search(expr or "")
    if not m:
        return []
    w, out = int(m.group(2)), []
    for sc in scales:
        n = max(2, min(252, round(w * sc)))
        if n != w and n not in (int(x[1]) for x in out):
            out.append((expr[:m.start(2)] + str(n) + expr[m.end(2):], n))
    return [e for e, _ in out]


# ── queue care ───────────────────────────────────────────────────────────────────────

def item_score(item: tuple) -> float:
    base = item[1] or {}
    return abs(base.get("sharpe") or 0.0) + (0.0 if item[2] != "flip" else -0.2)


def trim(carry: list, cap: int, hyp_no: int, max_age: int = 2) -> int:
    """Drop follow-ups from ideas more than `max_age` hypotheses old, then keep only the best `cap`. Returns dropped."""
    before = len(carry)
    keep = [i for i in carry if hyp_no - ((i[4] or {}).get("hyp", hyp_no) if len(i) > 4 else hyp_no) <= max_age]
    keep.sort(key=item_score, reverse=True)
    keep = keep[:cap]
    carry[:] = keep
    return before - len(keep)


def reserve_fraction(carry: list, strong_at: float = 1.5) -> float:
    """Share of a batch kept for new ideas: less when strong candidates are waiting, more when nothing is promising."""
    strong = sum(1 for i in carry if abs((i[1] or {}).get("sharpe") or 0) >= strong_at)
    return 0.2 if strong else 0.4


# ── triage: is this idea worth another batch? ────────────────────────────────────────

def triage_stop(rows: list, rnd: int, triage_rounds: int, triage_sharpe: float, winners: int = 0) -> tuple[bool, float]:
    """After the first batch(es), an idea whose best alpha is weak is dropped so the next idea can be tested.
    A strongly negative alpha counts (it can be reversed). Returns (stop, best |Sharpe|)."""
    best = max((abs(r.get("sharpe") or 0.0) for r in rows if not r.get("_kind")), default=0.0)
    return (rnd <= triage_rounds and winners == 0 and best < triage_sharpe), best


# ── bookkeeping after a batch ────────────────────────────────────────────────────────

def new_run() -> dict:
    return {"hyps": 0, "abandoned": 0, "boosts": 0, "boost_helped": 0, "flips": 0, "flip_helped": 0,
            "nudges": 0, "nudge_helped": 0}


def absorb(rows: list, meta: dict, stats: dict, run: dict, norm, promising_sharpe: float, helped_gain: float = 0.05) -> list:
    """Tag the follow-up variants that rode in this batch (kind, depth, gain, boosters already applied), update the
    per-booster stats and the run counters. Returns the events for the caller's side effects:
    [{kind, base, row, booster, gain, promising}]."""
    by = {norm(it[0]): it for it in meta.values()}
    out = []
    for r in rows:
        it = by.get(norm(r.get("expr") or ""))
        if it is None:
            continue
        _, base, kind, b = it[:4]
        r["_kind"] = kind
        sh, bs = r.get("sharpe"), base.get("sharpe")
        if sh is None:
            continue
        gain = sh - (bs if bs is not None else sh)
        r["_gain"] = gain
        r["_depth"] = int(base.get("_depth") or 0) + (1 if kind in ("boost", "flip+boost") else 0)
        r["_applied"] = list(base.get("_applied") or []) + ([key_of(b)] if b else [])
        promising = False
        if kind == "flip":
            run["flips"] += 1
            promising = sh >= promising_sharpe
            run["flip_helped"] += 1 if promising else 0
        elif kind == "nudge":
            run["nudges"] += 1
            run["nudge_helped"] += 1 if gain >= helped_gain else 0
        elif b is not None:
            run["boosts"] += 1
            run["boost_helped"] += 1 if gain >= helped_gain else 0
            record(stats, b, gain)
        out.append({"kind": kind, "base": base, "row": r, "booster": b, "gain": gain, "promising": promising})
    return out


def queue_line(rep: dict, n_boosters: int, trigger: float, source: str, dropped: int, waiting: int) -> str:
    """One readable log line about what the follow-up step did (or why it did nothing)."""
    parts = [f"{rep.get('candidates', 0)} alpha(s) above Sharpe {trigger:g}"]
    parts.append(f"{n_boosters} booster(s) ({source})")
    parts.append(f"queued: {rep.get('reverse', 0)} reversal(s) · {rep.get('boost', 0)} boost(s) · {rep.get('nudge', 0)} window nudge(s)")
    if rep.get("duplicates"):
        parts.append(f"{rep['duplicates']} already tried")
    if dropped:
        parts.append(f"{dropped} old/low-ranked dropped")
    parts.append(f"{waiting} waiting")
    return " · ".join(parts)


def run_summary(run: dict, stats: dict) -> str:
    b = best_booster(stats)
    s = (f"{run['hyps']} idea(s) tested ({run['abandoned']} dropped early) · boosts {run['boost_helped']}/{run['boosts']} helped · "
         f"reversals {run['flip_helped']}/{run['flips']} became promising · window nudges {run['nudge_helped']}/{run['nudges']} helped")
    if b:
        s += f" · best booster: {b[0]} (+{b[1]:.2f} avg over {b[2]})"
    return s
