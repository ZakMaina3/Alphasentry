"""Which regions a library item (alpha, booster) applies to.

Stored in the item's existing `meta` as `regions`: a list of region codes, e.g. ["USA", "EUR"].
  * no `regions` key (every item made before this existed) = applies to ALL regions, as before
  * a list = only those regions; an empty list = none (the item is parked everywhere)
Supersentry's memory uses a "<region>:super" key; the suffix is ignored here.
Pure functions, no database, so they are cheap to test.
"""
from __future__ import annotations

import re
from typing import Any, Iterable

_CODE = re.compile(r"^[A-Z0-9]{2,8}$")


def base(region: str | None) -> str:
    return str(region or "").split(":", 1)[0].strip().upper()


def clean(regions: Any) -> list[str] | None:
    """A tidy, de-duplicated, upper-case list of region codes; None when `regions` is not a list (= all regions)."""
    if regions is None or not isinstance(regions, (list, tuple, set)):
        return None
    out: list[str] = []
    for r in regions:
        c = base(str(r))
        if _CODE.match(c) and c not in out:
            out.append(c)
    return out


def applies(meta: dict | None, region: str | None) -> bool:
    """Does an item with this meta apply to `region`? An empty `region` (no filter asked for) always applies."""
    regs = clean((meta or {}).get("regions"))
    if regs is None or not base(region):
        return True
    return base(region) in regs


def normalize(regions: Iterable[str], known: Iterable[str] = ()) -> list[str] | None:
    """The list to store: None (= all regions, the key is removed) when every known region is ticked, else the sorted list."""
    got = clean(list(regions)) or []
    known_c = clean(list(known)) or []
    if known_c and set(known_c) <= set(got):
        return None
    return sorted(got)


def toggled(meta: dict | None, region: str, on: bool, known: Iterable[str]) -> dict:
    """A copy of `meta` with `region` ticked or unticked. Untouched keys (min_sharpe, ...) are kept."""
    known_c = clean(list(known)) or []
    cur = clean((meta or {}).get("regions"))
    cur_set = set(known_c) if cur is None else set(cur)
    r = base(region)
    if not _CODE.match(r):
        raise ValueError(f"{region!r} is not a region code")
    (cur_set.add if on else cur_set.discard)(r)
    new = normalize(cur_set, known_c)
    out = dict(meta or {})
    if new is None:
        out.pop("regions", None)
    else:
        out["regions"] = new
    return out
