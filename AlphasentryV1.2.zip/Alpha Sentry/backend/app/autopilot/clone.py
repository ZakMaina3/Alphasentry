"""Clone and swap (pure): take an old alpha, keep its shape (operators, windows), and swap its datafield for SIMILAR
datafields from the catalogue. No database, no network, no LLM: similarity is a TF-IDF cosine over the field id and
description, plus a bonus that the 'similarity slider' steers toward the same dataset or toward other datasets.

catalogue row: {field_id, dataset_id, description, type, dataset_name?, alpha_count?}"""
from __future__ import annotations

import math
import re
from collections import Counter

from app.osmosis.extract import fields_in

_STOP = {"the", "a", "an", "of", "and", "or", "for", "to", "in", "on", "by", "with", "data", "dataset", "value", "field",
         "based", "is", "are", "this", "that", "from", "as", "at", "per", "its", "it"}
SAME_BONUS = 0.35


def tokens(row: dict) -> Counter:
    """Bag of words from the id (weighted 2: its parts, with trailing digits dropped as well) and the description."""
    c: Counter = Counter()
    fid = str(row.get("field_id") or "")
    for part in re.split(r"[_\W]+", fid.lower()):
        if len(part) > 1 and part not in _STOP:
            c[part] += 2
            base = re.sub(r"\d+$", "", part)
            if base and base != part and len(base) > 1:
                c[base] += 2
    for t in re.findall(r"[a-z0-9]+", str(row.get("description") or "").lower()):
        if len(t) > 1 and t not in _STOP:
            c[t] += 1
    return c


class Index:
    """TF-IDF vectors for one scope's catalogue."""

    def __init__(self, catalog: list):
        self.rows = {r["field_id"]: r for r in catalog if r.get("field_id")}
        bags = {fid: tokens(r) for fid, r in self.rows.items()}
        df: Counter = Counter()
        for b in bags.values():
            df.update(b.keys())
        n = max(1, len(bags))
        self.idf = {t: math.log((1 + n) / (1 + d)) + 1.0 for t, d in df.items()}
        self.vec, self.norm = {}, {}
        for fid, b in bags.items():
            v = {t: w * self.idf[t] for t, w in b.items()}
            self.vec[fid] = v
            self.norm[fid] = math.sqrt(sum(x * x for x in v.values())) or 1.0

    def cosine(self, a: str, b: str) -> float:
        va, vb = self.vec[a], self.vec[b]
        if len(va) > len(vb):
            va, vb = vb, va
        return sum(w * vb.get(t, 0.0) for t, w in va.items()) / (self.norm[a] * self.norm[b])


def similar(index: Index, field_id: str, slider: float = 0.5, top: int = 10, exclude: set | None = None,
            min_sim: float = 0.08) -> list:
    """Most similar fields to `field_id` of the SAME type (so vec_* wrappers stay valid).
    slider 0 = only fields from the same dataset, 1 = only fields from other datasets, in between = a bonus either way.
    Returns [(field_id, score)] best first."""
    if field_id not in index.rows:
        return []
    me = index.rows[field_id]
    exclude = set(exclude or ()) | {field_id}
    out = []
    for fid, r in index.rows.items():
        if fid in exclude or str(r.get("type", "MATRIX")).upper() != str(me.get("type", "MATRIX")).upper():
            continue
        same = bool(me.get("dataset_id")) and r.get("dataset_id") == me.get("dataset_id")
        if slider <= 0.0 and not same:
            continue
        if slider >= 1.0 and same:
            continue
        sim = index.cosine(field_id, fid)
        if sim < min_sim:
            continue
        out.append((fid, sim + (SAME_BONUS * (1 - slider) if same else SAME_BONUS * slider)))
    out.sort(key=lambda x: (-x[1], x[0]))
    return out[:top]


_PY_HINT = re.compile(r"(^|\n)\s*(def\s+\w+\s*\(|import\s+\w+|from\s+\w+\s+import\s|class\s+\w+|return\b|@\w+)|\bnp\.|\bpd\.|\bself\.|:\s*\n\s+\S")


def is_python_alpha(alpha: dict | None = None, code: str | None = None) -> bool:
    """True for a Python alpha (BRAIN language PYTHON) or code that looks like Python rather than a fast expression. Such alphas are
    left out of Clone and swap: a datafield cannot be swapped in them by name, and they cannot be simulated as fast expressions."""
    if alpha and str(alpha.get("language") or "").upper() == "PYTHON":
        return True
    text = code if code is not None else str((alpha or {}).get("expr") or "")
    return bool(text and _PY_HINT.search(text))


def swap_expression(expr: str, old: str, new: str) -> str:
    return re.sub(rf"(?<![A-Za-z0-9_.]){re.escape(old)}(?![A-Za-z0-9_])", new, expr)


def catalogue_fields_in(expr: str, index: Index) -> list:
    """Datafields of the expression that the catalogue knows, as written in the expression (matching ignores upper/lower case)."""
    lower = {k.lower(): k for k in index.rows}
    out = []
    for f in fields_in(expr):
        k = f if f in index.rows else lower.get(f.lower())
        if k is not None:
            out.append((f, k))
    return out


def plan_swaps(sources: list, catalog: list, slider: float, per_alpha: int, seen: set, norm, min_sim: float = 0.08,
               stats: dict | None = None) -> list:
    """Candidate expressions, round-robin across the source alphas so every batch mixes sources.
    sources: [{id, expr, sharpe?}]. Returns [{expr, source_id, source_expr, old, new, score}].
    `stats` (optional dict) is filled with why a plan came out short: sources without catalogue fields, field ids the catalogue lacks,
    swaps found, and swaps dropped because they were simulated before."""
    index = Index(catalog)
    st = stats if stats is not None else {}
    st.update({"sources": len(sources), "with_fields": 0, "no_fields": [], "missing": [], "found": 0, "already_seen": 0, "no_neighbour": 0})
    per_source: list = []
    claimed = set(seen)
    for s in sources:
        expr = s.get("expr") or ""
        used = set(fields_in(expr))
        known = catalogue_fields_in(expr, index)
        if known:
            st["with_fields"] += 1
        else:
            if len(st["no_fields"]) < 5:
                st["no_fields"].append(s.get("id"))
            for f in fields_in(expr):
                if f not in st["missing"] and len(st["missing"]) < 8:
                    st["missing"].append(f)
        cands = []
        for old, key in known:
            near = similar(index, key, slider, per_alpha, exclude=used | {key}, min_sim=min_sim)
            if not near:
                st["no_neighbour"] += 1
            for new, score in near:
                e2 = swap_expression(expr, old, new)
                if e2 == expr:
                    continue
                st["found"] += 1
                if norm(e2) in claimed:
                    st["already_seen"] += 1
                    continue
                cands.append({"expr": e2, "source_id": s.get("id"), "source_expr": expr, "old": old, "new": new,
                              "score": round(score, 4)})
        cands.sort(key=lambda c: -c["score"])
        uniq, take = set(), []
        for c in cands:
            n = norm(c["expr"])
            if n in uniq:
                continue
            uniq.add(n); take.append(c)
            if len(take) >= per_alpha:
                break
        claimed |= uniq
        per_source.append(take)
    out, depth = [], 0
    while any(depth < len(p) for p in per_source):
        for p in per_source:
            if depth < len(p):
                out.append(p[depth])
        depth += 1
    return out


def why_empty(st: dict, region: str, delay: int) -> str:
    """One plain sentence on why no swap could be planned (from plan_swaps' stats)."""
    if st.get("sources") and not st.get("with_fields"):
        miss = ", ".join(st.get("missing") or []) or "none found"
        return (f"None of the {st['sources']} source alpha(s) uses a datafield that is in the Data Catalog for {region} delay {delay} "
                f"(fields in them: {miss}). Download the dataset category those fields belong to in Data Catalog, or check the region/delay.")
    if st.get("found") and st.get("already_seen") >= st["found"]:
        return (f"All {st['found']} possible swaps were already simulated in {region} before. Raise 'swaps per alpha', move the similarity slider, "
                "add more source alphas, or pull more datafields.")
    if not st.get("found"):
        return ("No similar datafield was found for the fields in your source alphas (the catalogue has no field of the same type with enough "
                "in common). Download more datasets for this region, or move the similarity slider.")
    return "No new swaps could be planned."


# ── Your own pasted alphas ───────────────────────────────────────────────────────────────

_LEAD = re.compile(r"^\s*(?:[-*\u2022]\s+|\d+[.)]\s+)")
_CONT_END = (";", ",", "+", "-", "*", "/", "=", "?", ":", "&&", "||", "<", ">")


def _strip_comment(line: str) -> str:
    return line.split("#", 1)[0] if "#" in line else line


def parse_pasted(text: str) -> list:
    """Alphas pasted as text -> [{id, expr}] (ids mine1, mine2, ...). Pure.
    One alpha per line. A blank line always ends an alpha. A line continues the previous one while its brackets are
    still open or it ends with ';' ',' or an operator, so multi-line alphas (a = ...; rank(a)) stay in one piece.
    '# comments', list bullets ('- ', '1. ') and duplicates (ignoring spaces and case) are dropped."""
    blocks: list = []
    cur: list = []

    def flush():
        if cur:
            blocks.append(" ".join(cur))
            cur.clear()

    for raw in str(text or "").replace("\r", "").split("\n"):
        line = _strip_comment(raw).strip()
        if not line:
            flush()
            continue
        if cur:
            joined = " ".join(cur)
            if joined.count("(") > joined.count(")") or joined.rstrip().endswith(_CONT_END):
                cur.append(line)
                continue
            flush()
        cur.append(_LEAD.sub("", line).strip())
    flush()
    out, seen = [], set()
    for b in blocks:
        e = re.sub(r"\s+", " ", b).strip().rstrip(";").strip()
        key = re.sub(r"\s+", "", e).lower()
        if not e or key in seen:
            continue
        seen.add(key)
        out.append({"id": f"mine{len(out) + 1}", "expr": e})
    return out


def describe_pasted(text: str, catalog: list) -> dict:
    """What the parser made of the pasted text, for the preview: per alpha the catalogue fields it holds (the ones a swap
    can replace) and why it would be skipped (unbalanced brackets, no catalogue field)."""
    index = Index(catalog) if catalog else None
    rows = []
    for a in parse_pasted(text):
        e = a["expr"]
        flds = fields_in(e)
        known = catalogue_fields_in(e, index) if index else []
        problem = ""
        if e.count("(") != e.count(")"):
            problem = "brackets do not match"
        elif is_python_alpha(code=e):
            problem = "looks like a Python alpha: skipped"
        elif not flds:
            problem = "no datafield found"
        elif index and not known:
            problem = "none of its datafields is in the Data Catalog for this region and delay"
        rows.append({**a, "fields": flds, "swappable": [o for o, _ in known], "problem": problem})
    return {"alphas": rows, "usable": sum(1 for r in rows if not r["problem"]), "total": len(rows)}
