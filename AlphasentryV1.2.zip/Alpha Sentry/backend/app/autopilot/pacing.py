"""Pacing for BRAIN's production-correlation checks (pure, no BRAIN or database).

With a delay, checks run ONE AT A TIME with the wait before each, so BRAIN is not hit with several correlation requests at once
and has had time to finish computing them. delay 0 keeps the old behaviour (up to 4 checks side by side)."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from typing import Callable


def run_checks(items: list, check: Callable, delay: float, sleep: Callable[[float], None], cancelled: Callable[[], bool],
               say: Callable[[str], None] | None = None, workers: int = 4) -> list:
    """check(item) -> result or None, in order. Returns the results that are not None.
    delay > 0: sequential, `delay` seconds before every check (the wait stops early when cancelled). delay <= 0: `workers` at a time."""
    if not items:
        return []
    if delay and delay > 0:
        out = []
        for i, it in enumerate(items, 1):
            if cancelled():
                break
            if say:
                say(f"waiting {int(delay)} s before prod check {i}/{len(items)}…")
            sleep(delay)
            if cancelled():
                break
            r = check(it)
            if r is not None:
                out.append(r)
        return out
    with ThreadPoolExecutor(max_workers=max(1, min(workers, len(items)))) as ex:
        return [r for r in ex.map(check, items) if r is not None]
