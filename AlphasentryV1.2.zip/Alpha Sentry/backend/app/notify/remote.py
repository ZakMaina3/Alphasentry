"""Telegram REMOTE CONTROL for the two Autosentries.

Send commands to your bot from your phone while away from the computer. The backend long-polls Telegram
(no public URL needed), accepts messages ONLY from your saved chat, and can:

    /status  /winners  /session            look at what is happening
    /start regular|super   /stop           start / stop an engine (reuses the settings of its last run)
    /switch regular|super  /restart        stop one, wait for its current step, start the other / the same
    /set [regular|super] <setting> <value> change settings (neutralizations, region for super, corr limits…)
    /settings  /refresh  /menu  /help      show settings, renew the BRAIN session, buttons, help

It never submits anything to BRAIN. The computer must be on with the app running.
"""

from __future__ import annotations

import json
import re
import threading
import time
import traceback

from app.core.config import get_settings
from app.core.jobs import jobs
from app.notify import engine_remote as _ER
from app.notify import telegram as TG

_FILE = get_settings().data_dir / "remote_state.json"
_LOCK = threading.Lock()
_CTRL = threading.Lock()                       # one start/stop/switch/refresh at a time
_thread: threading.Thread | None = None
ENGINES = ("regular", "super")


# ── saved settings per engine ────────────────────────────────────────────────────────

def _load() -> dict:
    try:
        d = json.loads(_FILE.read_text())
    except Exception:
        d = {}
    d.setdefault("last_engine", "super")
    d.setdefault("cfg", {})
    d.setdefault("overrides", {})
    return d


def _save(d: dict) -> None:
    try:
        _FILE.write_text(json.dumps(d))
    except Exception:
        pass


def remember_start(engine_name: str, cfg_in: dict) -> None:
    """Called by each engine's start(): the settings of the last run are what a remote start reuses."""
    with _LOCK:
        d = _load()
        d["cfg"][engine_name] = cfg_in
        d["overrides"][engine_name] = {}
        d["last_engine"] = engine_name
        _save(d)


def merged_cfg(engine_name: str) -> dict | None:
    d = _load()
    base = d["cfg"].get(engine_name)
    if base is None:
        return None
    return {**base, **d["overrides"].get(engine_name, {})}


def _set_override(engine_name: str, key: str, value) -> None:
    with _LOCK:
        d = _load()
        d["overrides"].setdefault(engine_name, {})[key] = value
        _save(d)


# ── engines ──────────────────────────────────────────────────────────────────────────

def _mod(engine_name: str):
    if engine_name == "regular":
        from app.autopilot import service as m
    else:
        from app.superpilot import service as m
    return m


def is_running(engine_name: str) -> bool:
    m = _mod(engine_name)
    return bool(m.status().get("running")) if engine_name == "regular" else m.is_running()


def running_engine() -> str | None:
    for e in ENGINES:
        if is_running(e):
            return e
    return None


def _stop(engine_name: str) -> bool:
    m = _mod(engine_name)
    if hasattr(m, "stop"):
        return bool(m.stop())
    jid = m._LIVE.get("job_id")
    return bool(jid and jobs.cancel(jid))


def _wait_stopped(engine_name: str, timeout: float = 900) -> bool:
    end = time.time() + timeout
    while time.time() < end:
        if not is_running(engine_name):
            return True
        time.sleep(3)
    return False


def _start(engine_name: str) -> tuple[bool, str]:
    cfg = merged_cfg(engine_name)
    if cfg is None:
        if engine_name == "regular":
            return False, ("The regular Autosentry has never been started from the app, so I don't know which datafields to "
                           "use. Start it once on the computer; after that I can start it remotely.")
        return False, "The Supersentry has never been started from the app. Start it once on the computer (or tell me /set super …) first."
    try:
        r = _mod(engine_name).start(cfg)
    except RuntimeError as e:
        return False, str(e)
    except Exception as e:  # noqa: BLE001
        return False, f"{type(e).__name__}: {e}"
    return True, "already running" if r.get("already_running") else "started"


# ── settings: whitelist, parsing, validation ─────────────────────────────────────────

def _bool(v: str) -> bool:
    x = v.strip().lower()
    if x in ("on", "true", "1", "yes", "y"):
        return True
    if x in ("off", "false", "0", "no", "n"):
        return False
    raise ValueError("use on or off")


def _num(lo, hi, cast=float):
    def f(v: str):
        try:
            x = cast(v.strip())
        except Exception:
            raise ValueError("expected a number")
        if not lo <= x <= hi:
            raise ValueError(f"must be between {lo} and {hi}")
        return x
    return f


def _words(v: str) -> list:
    out = [t.upper() for t in re.split(r"[,\s]+", v.strip()) if t]
    if not out or not all(re.fullmatch(r"[A-Z0-9_\-]+", t) for t in out):
        raise ValueError("give names separated by commas, e.g. FAST,SLOW")
    return out


def _word(v: str) -> str:
    return _words(v)[0]


_COMMON = {
    "neutralizations": (_words, "neutralizations, comma-separated (e.g. FAST,SLOW)", False),
    "max_corr": (_num(0.1, 1.0), "max self/prod/pool correlation", False),
    "max_turnover": (_num(0.05, 1.0), "max turnover", False),
    "use_library": (_bool, "use library & lessons (on/off)", False),
    "flip": (_bool, "reverse alphas with Sharpe below -1 (on/off)", False),
    "decorrelate": (_bool, "cut correlation (on/off)", False),
    "decay": (_num(0, 512, int), "decay", False),
    "truncation": (_num(0, 1), "truncation", False),
    "max_winners": (_num(0, 100000, int), "stop after N winners (0 = never)", False),
    "min_sharpe": (_num(0, 10), "|Sharpe| gate (0 = default)", True),
    "min_fitness": (_num(0, 10), "|Fitness| gate (0 = default)", True),
}
_REGULAR = {
    "batch_size": (_num(2, 10, int), "alphas per batch (2-10)", False),
    "concurrency": (_num(1, 3, int), "parallel batches (1-3)", False),
    "max_rounds": (_num(1, 50, int), "rounds per hypothesis", False),
    "max_cycles": (_num(0, 100000, int), "stop after N hypotheses (0 = never)", False),
    "boost": (_bool, "boosters (on/off)", False),
    "booster_trigger": (_num(0, 5), "Sharpe that triggers boosters", False),
    "builtin_boosters": (_bool, "built-in starter boosters when your library has none (on/off)", False),
    "triage": (_bool, "drop an idea after its first batch if it is weak (on/off)", False),
    "triage_sharpe": (_num(0, 3), "best |Sharpe| an idea needs after its first batch", False),
    "nudge": (_bool, "try window nudges on promising alphas (on/off)", False),
}
_SUPER = {
    "per_round": (_num(2, 30, int), "SuperAlphas per round", False),
    "n_selections": (_num(2, 12, int), "selections per round", False),
    "n_combos": (_num(2, 12, int), "combos per round", False),
    "min_components": (_num(1, 200, int), "alphas a selection must pick (11 = more than 10)", False),
    "selection_limit": (_num(1, 10000, int), "selection limit", False),
    "selection_handling": (lambda v: _pick(v, ("POSITIVE", "NEGATIVE", "ABSOLUTE")), "POSITIVE / NEGATIVE / ABSOLUTE", False),
    "own": (_bool, "own alphas only (on/off)", False),
    "max_rounds": (_num(0, 100000, int), "stop after N rounds (0 = never)", False),
    "region": (_word, "region, e.g. USA, DEU, EUR, ASI (applies after /restart)", True),
    "universe": (_word, "universe, e.g. ILLIQUID_MINVOL1M (applies after /restart)", True),
    "delay": (_num(0, 1, int), "delay 0 or 1 (applies after /restart)", True),
}


def _pick(v: str, allowed: tuple) -> str:
    x = v.strip().upper()
    if x not in allowed:
        raise ValueError("one of " + ", ".join(allowed))
    return x


def spec_for(engine_name: str) -> dict:
    return {**_COMMON, **(_REGULAR if engine_name == "regular" else _SUPER)}


def _neut_check(engine_name: str, cfg: dict, names: list) -> str | None:
    try:
        from app.brain import engine
        valid = engine.valid_neutralizations(cfg.get("instrument", "EQUITY"), cfg.get("region", "USA"))
    except Exception:
        return None
    bad = [n for n in names if valid and n not in valid]
    return f"{', '.join(bad)} not offered for {cfg.get('region')} — BRAIN offers: {', '.join(sorted(valid))}" if bad else None


def _region_check(cfg: dict, region: str) -> tuple[str | None, dict]:
    """Region must exist in BRAIN's option list (when loaded). Snap universe/delay to a real combination."""
    extra: dict = {}
    try:
        from app.brain import engine
        recs = [r for r in engine.get_options().get("records", []) if r["instrument"] == cfg.get("instrument", "EQUITY")]
    except Exception:
        return None, extra
    if not recs:
        return None, extra
    regions = sorted({r["region"] for r in recs})
    if region not in regions:
        return f"{region} is not a BRAIN region for {cfg.get('instrument', 'EQUITY')}. Available: {', '.join(regions)}", extra
    mine = [r for r in recs if r["region"] == region]
    unis = sorted({u for r in mine for u in r["universes"]})
    delays = sorted({r["delay"] for r in mine})
    if cfg.get("universe") not in unis and unis:
        extra["universe"] = "ILLIQUID_MINVOL1M" if "ILLIQUID_MINVOL1M" in unis else unis[0]
    if cfg.get("delay") not in delays and delays:
        extra["delay"] = delays[-1]
    return None, extra


def apply_setting(engine_name: str, key: str, raw: str) -> str:
    spec = spec_for(engine_name)
    if key not in spec:
        names = ", ".join(sorted(spec))
        hint = ""
        if engine_name == "regular" and key in ("region", "universe", "delay"):
            hint = " (the regular Autosentry's datafields belong to one region/universe — change it on the computer)"
        return f"❌ '{key}' is not a {engine_name} setting{hint}.\nAvailable: {names}"
    parser, _, restart = spec[key]
    try:
        value = parser(raw)
    except ValueError as e:
        return f"❌ {key}: {e}."
    base = merged_cfg(engine_name) or {}
    live = _mod(engine_name).live_cfg()
    ctx = {**base, **(live or {})}
    extras: dict = {}
    if key == "neutralizations":
        problem = _neut_check(engine_name, ctx, value)
        if problem:
            return f"❌ {problem}"
    if key == "region":
        problem, extras = _region_check(ctx, value)
        if problem:
            return f"❌ {problem}"
    if key in ("min_sharpe", "min_fitness") and value == 0:
        value = None
    _set_override(engine_name, key, value)
    for k, v in extras.items():
        _set_override(engine_name, k, v)
    shown = ", ".join(value) if isinstance(value, list) else value
    note = ""
    if extras:
        note = "\n   also set " + ", ".join(f"{k} = {v}" for k, v in extras.items()) + " (valid for that region)"
    if live is not None and not restart:
        live[key] = value
        if key == "concurrency":
            live["parallel"] = max(1, min(3, int(value)))
        if key == "neutralizations":
            live["neutralizations"] = list(value)
        return f"✅ {engine_name}: {key} = {shown}  — applied now (next simulation/check){note}"
    if live is not None and restart:
        return f"✅ {engine_name}: {key} = {shown}  — saved; needs a restart to take effect: send /restart{note}"
    return f"✅ {engine_name}: {key} = {shown}  — saved for the next start{note}"


def settings_text(engine_name: str) -> str:
    cfg = merged_cfg(engine_name)
    if cfg is None:
        return f"{engine_name}: no saved settings yet (start it once from the app)."
    live = _mod(engine_name).live_cfg()
    lines = [f"⚙ {engine_name} settings" + (" (running)" if live is not None else "")]
    for k in spec_for(engine_name):
        saved = cfg.get(k)
        if k not in cfg and (live is None or k not in live):
            continue
        shown = ", ".join(saved) if isinstance(saved, list) else saved
        if live is not None and k in live and live.get(k) != saved:
            now = live.get(k)
            lines.append(f"  {k} = {', '.join(now) if isinstance(now, list) else now}   (→ {shown} after /restart)")
        else:
            lines.append(f"  {k} = {shown}")
    return "\n".join(lines)


# ── session refresh ──────────────────────────────────────────────────────────────────

def refresh_session(auto: bool = False, rem: int | None = None, timeout_min: int = 25) -> None:
    """Renew the BRAIN session NOW (BRAIN's 4-hour clock restarts): send the biometrics link, wait for the face
    scan, confirm. The engines keep running on the old session until the new one is ready."""
    from app.autopilot import service as A
    from app.brain import engine
    c = TG.config()
    if not TG.ready(c):
        return
    if not A._REAUTH_LOCK.acquire(blocking=False):
        TG.send("A BRAIN login is already in progress — finish that one first.", cfg=c)
        return
    try:
        try:
            r = engine.sm.begin_login()
        except Exception as e:  # noqa: BLE001
            r = {"state": "error", "message": str(e)}
        st = r.get("state")
        if st == "done":
            A._LIVE_OK["t"] = 0.0
            TG.send("✅ BRAIN session refreshed — a fresh 4 hours.", cfg=c, silent=True)
            return
        if st != "biometrics":
            TG.send(f"⚠ Couldn't start the refresh: {str(r.get('message') or 'login failed')[:200]}", cfg=c)
            return
        left = f" (~{max(1, (rem or 0) // 60)} min left on the current session)" if rem else ""
        TG.send(("⏳ Session running low" + left + ". " if auto else "🔄 Refreshing the BRAIN session. ")
                + "Tap the button and complete the face scan; the Autosentry keeps going meanwhile.",
                url=r["url"], button="Complete biometrics", cfg=c)
        end = time.time() + timeout_min * 60
        while time.time() < end:
            time.sleep(10)
            try:
                res = engine.sm.complete_login() or {}
            except Exception:
                continue
            if res.get("state") == "done":
                A._LIVE_OK["t"] = 0.0
                TG.send("✅ BRAIN session refreshed — a fresh 4 hours.", cfg=c, silent=True)
                return
        TG.send("⌛ The refresh link timed out. Send /refresh for a new one.", cfg=c)
    finally:
        A._REAUTH_LOCK.release()


def _session_text() -> str:
    try:
        from app.brain import engine
        rem = engine.sm.remaining_seconds()
    except Exception:
        rem = 0
    return (f"🔐 BRAIN session: ~{rem // 3600}h {(rem % 3600) // 60}m left" if rem > 0
            else "🔐 BRAIN session: expired, missing or unreachable — /refresh to log in")


# ── messages ─────────────────────────────────────────────────────────────────────────

HELP = (
    "🤖 Alpha Sentry remote control\n\n"
    "/menu — buttons\n/status — what's running, round, winners, session\n/winners — latest winners\n"
    "/start regular|super — start an engine with its last settings\n/stop — stop the running engine\n"
    "/switch regular|super — stop the running one, wait for its step, start the other\n/restart — stop and start again (applies region etc.)\n"
    "/settings [regular|super] — show settings\n"
    "/set [regular|super] <setting> <value> — e.g.\n"
    "   /set neutralizations FAST,SLOW\n   /set super region DEU\n   /set max_corr 0.6\n   /set per_round 8\n"
    "/neut FAST,SLOW · /region DEU — shortcuts\n"
    "/refresh — renew the BRAIN session now · /session — time left\n\n"
    "SentryEngine:\n/engine — status · /engine on|off — its switch · /engine start|stop · /engine score\n"
    "/tasks — its tasks · /task pause|resume|stop <id>\n\n"
    "Without an engine name, /set and /settings use the running engine, else the last one used.\n"
    "Nothing is ever submitted to BRAIN from here.")


def _menu(c: dict) -> None:
    TG.send("What now?", cfg=c, buttons=[
        [{"text": "📊 Status", "cb": "cmd:status"}, {"text": "🏆 Winners", "cb": "cmd:winners"}],
        [{"text": "▶ Regular", "cb": "cmd:start_regular"}, {"text": "▶ Super", "cb": "cmd:start_super"}],
        [{"text": "⏹ Stop", "cb": "cmd:stop"}, {"text": "🔁 Restart", "cb": "cmd:restart"}],
        [{"text": "🔄 Refresh session", "cb": "cmd:refresh"}, {"text": "⚙ Settings", "cb": "cmd:settings"}],
        [{"text": "🔀 Switch to Regular", "cb": "cmd:switch_regular"}, {"text": "🔀 Switch to Super", "cb": "cmd:switch_super"}],
        [{"text": "⚙ SentryEngine", "cb": "cmd:engine"}, {"text": "📋 Engine tasks", "cb": "cmd:tasks"}]])


def _status(c: dict) -> None:
    eng = running_engine()
    lines = []
    if eng:
        st = _mod(eng).status()
        state = st.get("state", {})
        winners = state.get("winners", [])
        if eng == "regular":
            hyp = (st.get("hypothesis") or {}).get("idea", "")
            lines.append(f"▶ Regular Autosentry — {st.get('phase')} · cycle {st.get('cycle')} round {st.get('round')}"
                         + (f"\n   hypothesis: {hyp[:140]}" if hyp else ""))
            lines.append(f"   {state.get('simulated', 0)} simulated · {len(winners)} winners")
        else:
            lines.append(f"▶ Supersentry — {st.get('phase')} · round {st.get('round')}")
            lines.append(f"   {state.get('rounds', 0)} rounds · {state.get('simulated', 0)} simulated · {len(winners)} winners")
        if st.get("wait"):
            lines.append(f"   ⏸ {st['wait']}")
        for e in (st.get("events") or [])[-3:]:
            lines.append("   · " + e["msg"][:150])
    else:
        d = _load()
        lines.append(f"⏹ No engine is running. Last used: {d['last_engine']}.")
    try:
        lines.append(_ER.status_text(with_tasks=False))
    except Exception:  # noqa: BLE001 — never let the engine line break /status
        pass
    lines.append(_session_text())
    TG.send("\n".join(lines), cfg=c, buttons=[[{"text": "🔄 Refresh session", "cb": "cmd:refresh"}, {"text": "📋 Menu", "cb": "cmd:menu"}]])


def _winners(c: dict) -> None:
    out = []
    for e in ENGINES:
        w = _mod(e).status().get("state", {}).get("winners", [])[-5:]
        for x in reversed(w):
            out.append(f"{'R' if e == 'regular' else 'S'} {x.get('alpha_id')} · Sharpe {(x.get('sharpe') or 0):.2f} · Fit {(x.get('fitness') or 0):.2f}"
                       + (f" · corr {x['self_corr']:.2f}/{x['prod_corr']:.2f}" if x.get("self_corr") is not None and x.get("prod_corr") is not None else ""))
    TG.send("🏆 Latest winners\n" + ("\n".join(out) if out else "None yet."), cfg=c)


def _target(args: list) -> tuple[str, list]:
    if args and args[0].lower() in ENGINES:
        return args[0].lower(), args[1:]
    return (running_engine() or _load()["last_engine"]), args


def _do_start(engine_name: str, c: dict) -> None:
    other = [e for e in ENGINES if e != engine_name][0]
    if is_running(other):
        TG.send(f"⚠ The {other} Autosentry is running. Use /switch {engine_name} to stop it and start the {engine_name} one.", cfg=c)
        return
    ok, msg = _start(engine_name)
    TG.send(("▶ " if ok else "❌ ") + (f"{engine_name} Autosentry {msg}." if ok else msg), cfg=c)


def _do_stop(c: dict) -> None:
    eng = running_engine()
    if not eng:
        TG.send("Nothing is running.", cfg=c)
        return
    _stop(eng)
    TG.send(f"⏹ Stopping the {eng} Autosentry after its current step…", cfg=c)
    if _wait_stopped(eng):
        TG.send(f"⏹ {eng} Autosentry stopped.", cfg=c, silent=True)


def _do_switch(target: str, c: dict, restart: bool = False) -> None:
    cur = running_engine()
    if cur == target and not restart:
        TG.send(f"The {target} Autosentry is already running.", cfg=c)
        return
    if cur:
        TG.send(f"⏳ Stopping the {cur} Autosentry (it finishes its current step first — can take a few minutes)…", cfg=c)
        _stop(cur)
        if not _wait_stopped(cur):
            TG.send(f"❌ The {cur} Autosentry did not stop within 15 minutes; not starting the {target} one.", cfg=c)
            return
    ok, msg = _start(target)
    TG.send(("✅ " if ok else "❌ ") + (f"{target} Autosentry {msg}." if ok else msg), cfg=c)


def _run_control(fn, c: dict, *a) -> None:
    if not _CTRL.acquire(blocking=False):
        TG.send("⏳ Another action is still in progress — try again in a moment.", cfg=c)
        return
    try:
        fn(*a)
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        TG.send(f"❌ {type(e).__name__}: {str(e)[:200]}", cfg=c)
    finally:
        _CTRL.release()


def handle(text: str, c: dict) -> None:
    """One command (typed, or from a button as 'cmd:...')."""
    t = (text or "").strip()
    if t.startswith("cmd:"):
        t = "/" + t[4:].replace("_", " ")
    if not t.startswith("/"):
        TG.send("Send /help for the commands, or /menu for buttons.", cfg=c, silent=True)
        return
    parts = t.split()
    cmd = parts[0][1:].split("@")[0].lower()
    args = parts[1:]

    if cmd in ("help", "h"):
        TG.send(HELP, cfg=c)
    elif cmd == "menu" or (cmd == "start" and not args):
        _menu(c)
    elif cmd == "status":
        _status(c)
    elif cmd == "winners":
        _winners(c)
    elif cmd == "session":
        TG.send(_session_text(), cfg=c)
    elif cmd == "refresh":
        threading.Thread(target=_run_control, args=(refresh_session, c), daemon=True).start()
    elif cmd == "start":
        if args[0].lower() not in ENGINES:
            TG.send("Use /start regular or /start super.", cfg=c)
        else:
            _run_control(_do_start, c, args[0].lower(), c)
    elif cmd == "stop":
        threading.Thread(target=_run_control, args=(_do_stop, c, c), daemon=True).start()
    elif cmd == "switch":
        if not args or args[0].lower() not in ENGINES:
            TG.send("Use /switch regular or /switch super.", cfg=c)
        else:
            threading.Thread(target=_run_control, args=(_do_switch, c, args[0].lower(), c), daemon=True).start()
    elif cmd == "restart":
        eng = running_engine() or _load()["last_engine"]
        threading.Thread(target=_run_control, args=(_do_switch, c, eng, c, True), daemon=True).start()
    elif cmd == "settings":
        eng, _ = _target(args)
        TG.send(settings_text(eng), cfg=c)
    elif cmd == "set":
        eng, rest = _target(args)
        if len(rest) < 2:
            TG.send("Usage: /set [regular|super] <setting> <value>\nSend /settings to see the names.", cfg=c)
        else:
            msg = apply_setting(eng, rest[0].lower(), " ".join(rest[1:]))
            TG.send(msg, cfg=c, buttons=[[{"text": "🔁 Restart now", "cb": "cmd:restart"}]] if "send /restart" in msg else None)
    elif cmd in ("neut", "neutralization", "neutralizations", "region"):
        eng, rest = _target(args)
        key = "region" if cmd == "region" else "neutralizations"
        if cmd == "region":
            eng = "super"                    # region changes are for the Supersentry
        if not rest:
            TG.send(f"Usage: /{cmd} " + ("DEU" if key == "region" else "FAST,SLOW"), cfg=c)
        else:
            msg = apply_setting(eng, key, " ".join(rest))
            TG.send(msg, cfg=c, buttons=[[{"text": "🔁 Restart now", "cb": "cmd:restart"}]] if "/restart" in msg else None)
    elif cmd in _ER.CMDS:
        # SentryEngine (the batch engine). Start/stop/score may wait on BRAIN, so they run on a thread like the Autosentry controls.
        def _send(text, buttons=None):
            TG.send(text, cfg=c, buttons=buttons)
        threading.Thread(target=_ER.handle, args=(cmd, args, _send), daemon=True).start()
    elif cmd == "reset":
        TG.send("Clear BOTH engines' winners lists and result history? (Stored simulation results stay.)", cfg=c,
                buttons=[[{"text": "Yes, clear", "cb": "cmd:resetok"}, {"text": "Cancel", "cb": "cmd:menu"}]])
    elif cmd == "resetok":
        if running_engine():
            TG.send("Stop the engine first.", cfg=c)
        else:
            from app.autopilot import service as A
            from app.superpilot import service as SP
            A.reset_state(); SP.reset_state()
            TG.send("🧹 History cleared.", cfg=c)
    else:
        TG.send(f"Unknown command /{cmd}. Send /help.", cfg=c, silent=True)


# ── listener ─────────────────────────────────────────────────────────────────────────

def _dispatch(u: dict, c: dict) -> None:
    chat_id = str(c["chat_id"]).strip()
    cb = u.get("callback_query")
    if cb:
        msg = cb.get("message") or {}
        if str((msg.get("chat") or {}).get("id")) != chat_id:
            return
        TG.answer_callback(c["token"], cb["id"])
        data = str(cb.get("data", ""))
        if data.startswith("cmd:"):
            threading.Thread(target=handle, args=(data, c), daemon=True).start()
        return
    m = u.get("message") or {}
    if str((m.get("chat") or {}).get("id")) != chat_id or (m.get("chat") or {}).get("type") != "private":
        return                                           # strangers are ignored silently
    handle(m.get("text") or "", c)


def _loop() -> None:
    offset = None
    primed = False
    backoff = 5
    while True:
        try:
            c = TG.config()
            if not (c.get("remote_enabled") and c.get("token") and str(c.get("chat_id")).strip()):
                offset, primed = None, False
                time.sleep(10)
                continue
            if not primed:                               # skip anything sent while the app was off: no stale /stop
                ups = TG.get_updates(c["token"], -1, 0)
                offset = ups[-1]["update_id"] + 1 if ups else None
                primed = True
                print("[remote] Telegram remote control is on")
            ups = TG.get_updates(c["token"], offset, 25)
            for u in ups:
                offset = u["update_id"] + 1
                try:
                    _dispatch(u, c)
                except Exception:  # noqa: BLE001
                    traceback.print_exc()
            backoff = 5
        except Exception as e:  # noqa: BLE001
            msg = str(e)
            if "Conflict" in msg:                        # another app instance is polling the same bot
                time.sleep(20)
            else:
                time.sleep(backoff)
                backoff = min(60, backoff * 2)


def start_listener() -> None:
    global _thread
    if _thread and _thread.is_alive():
        return
    _thread = threading.Thread(target=_loop, name="telegram-remote", daemon=True)
    _thread.start()
