"""Telegram notifier — pushes messages (with a tappable button) to your phone.

Used by the Autosentry to ask you for the BRAIN biometrics scan when the 4-hour session expires.
Config lives in ~/secrets/ace_notify.json (outside the repo), like the other secrets.

Telegram has no 24-hour/template rule: a bot can message you at any time once you have sent it
one message. Setup: @BotFather -> /newbot -> copy the token; send any message to your new bot;
then use "Find my chat ID" in the Autosentry panel.
"""

from __future__ import annotations

import json
import os
import threading
import time

import requests

CONFIG_FILE = os.path.join(os.path.expanduser("~"), "secrets", "ace_notify.json")
API = os.environ.get("ACE_TELEGRAM_API", "https://api.telegram.org").rstrip("/")

DEFAULTS = {"enabled": False, "token": "", "chat_id": "", "heads_up_min": 15,
            "resend_min": 15, "notify_winners": False,
            "remote_enabled": False,        # accept commands sent from YOUR chat (see app/notify/remote.py)
            "auto_refresh_min": 0}          # >0: send the biometrics link early when this many minutes are left
_lock = threading.Lock()


def _read() -> dict:
    try:
        with open(CONFIG_FILE) as f:
            return {**DEFAULTS, **json.load(f)}
    except Exception:
        return dict(DEFAULTS)


def _write(d: dict) -> None:
    os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(d, f, indent=2)
    try:
        os.chmod(CONFIG_FILE, 0o600)
    except Exception:
        pass


def config() -> dict:
    """Full config including the token — backend use only."""
    return _read()


def ready(c: dict | None = None) -> bool:
    c = c or _read()
    return bool(c["enabled"] and c["token"] and str(c["chat_id"]).strip())


def public_config() -> dict:
    c = _read()
    tok = c["token"]
    return {"enabled": c["enabled"], "token_set": bool(tok),
            "token_masked": (tok[:6] + "…" + tok[-4:]) if len(tok) > 12 else ("set" if tok else ""),
            "chat_id": str(c["chat_id"]), "heads_up_min": c["heads_up_min"],
            "resend_min": c["resend_min"], "notify_winners": c["notify_winners"],
            "remote_enabled": c["remote_enabled"], "auto_refresh_min": c["auto_refresh_min"]}


def save_config(patch: dict) -> dict:
    with _lock:
        c = _read()
        for k in ("enabled", "notify_winners", "remote_enabled"):
            if k in patch and patch[k] is not None:
                c[k] = bool(patch[k])
        for k, lo, hi in (("heads_up_min", 0, 120), ("resend_min", 5, 240), ("auto_refresh_min", 0, 120)):
            if patch.get(k) is not None:
                c[k] = max(lo, min(hi, int(patch[k])))
        if patch.get("token"):                      # empty / missing = keep the saved token
            c["token"] = str(patch["token"]).strip()
        if patch.get("chat_id") is not None and str(patch["chat_id"]).strip() != "":
            c["chat_id"] = str(patch["chat_id"]).strip()
        _write(c)
    return public_config()


def _call(token: str, method: str, payload: dict | None = None, timeout: int = 15) -> dict:
    r = requests.post(f"{API}/bot{token}/{method}", json=payload or {}, timeout=timeout)
    try:
        d = r.json()
    except Exception:
        raise RuntimeError(f"Telegram returned HTTP {r.status_code}")
    if not d.get("ok"):
        raise RuntimeError(d.get("description") or f"Telegram error {r.status_code}")
    return d["result"]


def bot_info(token: str | None = None) -> dict:
    return _call(token or _read()["token"], "getMe")


def discover_chat_id(token: str | None = None) -> dict:
    """Find the chat that most recently messaged the bot."""
    tok = token or _read()["token"]
    if not tok:
        raise RuntimeError("Save the bot token first.")
    updates = _call(tok, "getUpdates", {"limit": 50, "timeout": 0})
    for u in reversed(updates):
        m = u.get("message") or u.get("edited_message") or u.get("channel_post")
        if m and m.get("chat", {}).get("type") == "private":
            ch = m["chat"]
            name = " ".join(x for x in (ch.get("first_name"), ch.get("last_name")) if x) or ch.get("username", "")
            return {"chat_id": str(ch["id"]), "name": name}
    raise RuntimeError("No message found. Open your bot in Telegram, press Start / send it any message, then try again.")


def send(text: str, url: str | None = None, button: str = "Open", silent: bool = False,
         cfg: dict | None = None, buttons: list | None = None) -> bool:
    """Send a message (optionally with one tappable URL button, or rows of buttons:
    buttons=[[{"text": "Stop", "cb": "cmd:stop"}, {"text": "Open", "url": "https://..."}], ...]).
    Never raises; returns success."""
    c = cfg or _read()
    if not (c["token"] and str(c["chat_id"]).strip()):
        return False
    payload = {"chat_id": str(c["chat_id"]).strip(), "text": text[:3900],
               "disable_web_page_preview": True, "disable_notification": silent}
    if buttons:
        rows = []
        for row in buttons:
            rows.append([({"text": b["text"], "url": b["url"]} if b.get("url") else
                          {"text": b["text"], "callback_data": b["cb"][:60]}) for b in row])
        payload["reply_markup"] = {"inline_keyboard": rows}
    elif url:
        payload["reply_markup"] = {"inline_keyboard": [[{"text": button, "url": url}]]}
    try:
        _call(c["token"], "sendMessage", payload)
        return True
    except Exception as e:  # noqa: BLE001
        print(f"[notify] telegram send failed: {e}")
        return False


def send_async(*a, **kw) -> None:
    threading.Thread(target=send, args=a, kwargs=kw, daemon=True).start()


def get_updates(token: str, offset: int | None, timeout: int = 25) -> list:
    """Long-poll for new messages / button taps (works from behind NAT: no public URL needed)."""
    payload = {"timeout": timeout, "allowed_updates": ["message", "callback_query"]}
    if offset is not None:
        payload["offset"] = offset
    return _call(token, "getUpdates", payload, timeout=timeout + 10)


def answer_callback(token: str, cb_id: str, text: str = "") -> None:
    try:
        _call(token, "answerCallbackQuery", {"callback_query_id": cb_id, "text": text[:180]})
    except Exception:
        pass
