"""Telegram remote control for SentryEngine (the batch engine + labs + tasks).

Commands (all also reachable from the /menu buttons):
  /engine                 status: switch, running or not, slots, queue, tasks
  /engine on | off        turn the "SentryEngine + labs" switch on or off
  /engine start | stop    start or stop the batch engine (stop: finishes batches already running)
  /engine score           score finished simulations into Results now (BRAIN reads only)
  /tasks                  list tasks with progress
  /task pause|resume|stop <id>
Nothing here can submit an alpha to BRAIN: the engine only simulates and scores, same as in the app.
`handle(cmd, args, send)` returns True when the command was one of ours. `api` is injectable so it can be tested without the app."""
from __future__ import annotations

from typing import Any, Callable

CMDS = ("engine", "sentryengine", "tasks", "task")
FLAG = "harness_engine"
_STATUS_ICON = {"running": "▶", "paused": "⏸", "stopped": "⏹", "done": "✅", "failed": "❌", "complete": "✅"}


class _Api:
    """The real thing: the same functions the SentryEngine screen calls, imported lazily so this module loads anywhere."""

    def _he(self):
        from app.modules import harness_engine as HE
        return HE

    def flags(self) -> dict[str, bool]:
        from app.harness import flags
        return flags.get_all()

    def set_flag(self, name: str, value: bool) -> None:
        from app.harness import flags
        flags.set_flag(name, value)

    def status(self) -> dict:
        eng = self._he()._engine
        return eng.status() if eng is not None else {"running": False, "counts": {}, "lease": None, "in_flight_by_task": {}}

    def start(self) -> dict:
        return self._he().start()

    def stop(self) -> dict:
        return self._he().stop()

    def score(self) -> dict:
        return self._he().score_now(40)

    def tasks(self) -> list[dict]:
        return self._he()._get_runner().list_tasks()

    def task_action(self, task_id: int, action: str) -> None:
        r = self._he()._get_runner()
        if action == "pause":
            r.set_status(task_id, "paused")
        elif action == "resume":
            r.set_status(task_id, "running")
        else:
            r.stop(task_id)


def _err(e: Exception) -> str:
    detail = getattr(e, "detail", None)
    return str(detail or e)[:200]


def status_text(api: Any = None, with_tasks: bool = True) -> str:
    api = api or _Api()
    on = bool(api.flags().get(FLAG))
    st = api.status()
    c = st.get("counts") or {}
    lines = [f"⚙ SentryEngine — switch {'ON' if on else 'OFF'} · engine {'RUNNING' if st.get('running') else 'stopped'}"
             + (" (dry run)" if st.get("dry_run") else "")]
    lease = st.get("lease")
    if isinstance(lease, dict) and lease.get("total") is not None:
        lines.append(f"   slots {lease.get('used', 0)}/{lease.get('total')}")
    lines.append(f"   queued {c.get('queued', 0)} · running {c.get('running', 0)} · done {c.get('done', 0)}"
                 f" · scored {c.get('scored', 0)} · failed {c.get('failed', 0)}")
    if with_tasks and on:
        try:
            ts = [t for t in api.tasks() if t.get("status") in ("running", "paused")]
        except Exception:  # noqa: BLE001 — tables may not exist yet
            ts = []
        for t in ts[:6]:
            lines.append(f"   {_STATUS_ICON.get(t['status'], '·')} #{t['id']} {t.get('name') or t.get('lab')} — {round((t.get('progress') or 0) * 100)}% of {t.get('budget')}")
        if len(ts) > 6:
            lines.append(f"   … and {len(ts) - 6} more (/tasks)")
    if not on:
        lines.append("   Turn it on with /engine on.")
    return "\n".join(lines)


def tasks_text(api: Any = None) -> str:
    api = api or _Api()
    ts = api.tasks()
    if not ts:
        return "No tasks yet. Create them in the SentryEngine screen."
    out = ["📋 SentryEngine tasks"]
    for t in ts[:15]:
        out.append(f"{_STATUS_ICON.get(t['status'], '·')} #{t['id']} {t.get('name') or t.get('lab')} · {t['status']} · "
                   f"{round((t.get('progress') or 0) * 100)}% of {t.get('budget')}")
    out.append("Control: /task pause|resume|stop <id>")
    return "\n".join(out)


def handle(cmd: str, args: list[str], send: Callable[..., Any], api: Any = None) -> bool:
    """Run one command; reply through send(text, buttons=None). False when `cmd` is not ours."""
    if cmd not in CMDS:
        return False
    api = api or _Api()
    try:
        if cmd in ("tasks",):
            send(tasks_text(api))
        elif cmd == "task":
            if len(args) != 2 or args[0].lower() not in ("pause", "resume", "stop") or not args[1].isdigit():
                send("Usage: /task pause|resume|stop <id>   (ids are in /tasks)")
            else:
                api.task_action(int(args[1]), args[0].lower())
                send(f"{args[0].lower().capitalize()}: task #{args[1]} done. /tasks to check.")
        else:
            sub = (args[0].lower() if args else "status")
            if sub == "status":
                send(status_text(api), buttons=[[{"text": "▶ Start", "cb": "cmd:engine_start"}, {"text": "⏹ Stop", "cb": "cmd:engine_stop"}],
                                                 [{"text": "📋 Tasks", "cb": "cmd:tasks"}, {"text": "🧮 Score now", "cb": "cmd:engine_score"}]])
            elif sub in ("on", "off"):
                api.set_flag(FLAG, sub == "on")
                send(f"SentryEngine switch is now {sub.upper()}." + (" Use /engine start to run it." if sub == "on" else
                                                                      " (A running engine keeps going until /engine stop.)"))
            elif sub == "start":
                if not api.flags().get(FLAG):
                    send("The SentryEngine switch is OFF. Send /engine on first.")
                else:
                    r = api.start()
                    send("▶ SentryEngine started." if r.get("started") else f"ℹ {r.get('message') or 'already running'}.")
            elif sub == "stop":
                st = api.status()
                if not st.get("running"):
                    send("The engine is not running.")
                else:
                    api.stop()
                    send("⏹ Stopping SentryEngine. Batches already on BRAIN finish and are scored; nothing new starts.")
            elif sub == "score":
                r = api.score()
                send(f"🧮 Scored: {r}" if r else "Nothing to score.")
            else:
                send("Use: /engine [status|on|off|start|stop|score] · /tasks · /task pause|resume|stop <id>")
    except Exception as e:  # noqa: BLE001
        send(f"❌ {type(e).__name__}: {_err(e)}")
    return True
