"""Alpha Sentry v2 backend package."""

__version__ = "2.0.0-dev"
