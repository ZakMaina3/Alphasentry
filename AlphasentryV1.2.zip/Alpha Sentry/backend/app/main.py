"""Alpha Sentry v2 — FastAPI application factory.

Responsibilities kept deliberately thin:
  - build the app, apply CORS for the Vite dev server,
  - mount every enabled feature module (see app.modules.ENABLED),
  - in production, serve the built React frontend (frontend/dist) with no-store so the
    single-page app is never cached stale.

Run (dev):   uvicorn app.main:app --app-dir backend --reload --port 8765
Run (prod):  build the frontend, then the same command serves it at /.
"""

from __future__ import annotations

import traceback
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from app.core.config import get_settings
from app.core.module import register_modules
from app.modules import ENABLED

settings = get_settings()

app = FastAPI(title=settings.app_name, version=settings.version)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_dev_origin],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def _json_errors(request: Request, exc: Exception):
    """Always return JSON so the frontend can humanise the message — never an HTML 500."""
    traceback.print_exc()
    return JSONResponse(status_code=500, content={"error": f"{type(exc).__name__}: {exc}"})


_loaded = register_modules(app, ENABLED)
print(f"[sentry] mounted modules: {', '.join(_loaded) or '(none)'}")


@app.on_event("startup")
def _start_telegram_remote() -> None:
    """Telegram remote control (opt-in in the Autosentry's Telegram panel). The listener idles until enabled."""
    try:
        from app.notify import remote
        remote.start_listener()
    except Exception as e:  # noqa: BLE001
        print(f"[sentry] Telegram remote control not started: {e}")


@app.on_event("startup")
def _merge_harness_seed() -> None:
    """SentryEngine: add the rows of the shipped seed/ database that your database lacks (insert-only, once per seed file; flag harness_seed)."""
    try:
        from app.harness import seed
        r = seed.merge_on_startup()
        if r.get("added"):
            print(f"[sentry] seed data merged: {sum(r['added'].values())} new row(s) {r['added']}")
        elif r.get("error") or r.get("problems"):
            print(f"[sentry] seed data not merged cleanly: {r}")
    except Exception as e:  # noqa: BLE001
        print(f"[sentry] seed data not merged: {e}")


# ── production: serve the built frontend (if present) ────────────────────────────────
_DIST = settings.repo_root / "frontend" / "dist"
_NO_STORE = {"Cache-Control": "no-store, must-revalidate", "Pragma": "no-cache", "Expires": "0"}


@app.get("/api")
def api_root():
    return {"app": settings.app_name, "version": settings.version, "modules": _loaded}


if _DIST.exists():
    # Hash-named assets can cache forever; index.html must not (SPA freshness).
    app.mount("/assets", StaticFiles(directory=_DIST / "assets"), name="assets")

    @app.get("/{full_path:path}")
    def spa(full_path: str):
        candidate = _DIST / full_path
        if full_path and candidate.is_file():
            return FileResponse(candidate)
        return FileResponse(_DIST / "index.html", headers=_NO_STORE)
else:
    @app.get("/")
    def _dev_notice():
        return {"message": "Backend up. In dev, open the Vite server at "
                           f"{settings.frontend_dev_origin}. In prod, build the frontend first."}
