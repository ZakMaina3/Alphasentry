"""The built-in Fast Expression -> Python Alpha guidelines, and the deterministic checks computed for every translation.

The guidelines are the user's own, written down once and shipped inside the app, so translation works with ONE click on a fresh install.
`data/pyalpha_guideline.md` still overrides them when the user has written their own (edited on the page; "Restore built-in" removes it).
Everything here is pure (no database, no network) so it can be tested.
"""
from __future__ import annotations

import json
import re
from typing import Any

from app.harness.labs import exprtree as X
from app.harness.labs.exprtools import GROUPING_FIELDS, fields_in, operators_in

PLACEHOLDER = "<<PASTE>>"

from app.pyalpha.guideline_article import ARTICLE

ARTICLE_HEADING = "\n\n---\n\n# Reference article (BRAIN, included exactly as published; the rules above are the working checklist)\n\n"

DEFAULT_GUIDELINE = """# Fast Expression → Python Alpha: translation guidelines

## 1. Input
- The Fast Expression, the fields used, and the operators used.
- Target settings (region, universe, delay, decay, truncation, neutralization). Use the same settings as the original sim, so the comparison is fair.

## 2. The @alpha contract
- One self-contained module. Every helper lives in the file, with no local imports.
- `data=[...]` lists only MATRIX fields. Never list "universe". Use `data.universe[-1]` for today's mask.
- The engine calls the function once per day. Each `data.<field>` is `[rows, n_instruments]`, float32, with today in the last row.
- Input arrays are read-only. `.copy()` before mutating.
- Return a 1-D float32 array. Always finish with `.astype(np.float32)`, since numpy silently promotes to float64.
- Group fields (sector, subindustry) are assumed to load as numeric codes. Verify this before relying on it.

## 3. Default architecture (stateful, lookback=0)
- Compute cross-sectional steps on today's row only.
- Keep every time-series stage in `store`:
  - A rolling cache (`"dims": "xi"`, extend of NaN) for windows such as ts_decay_linear, ts_rank and ts_mean.
  - Last-valid and age vectors (`"dims": "i"`) for ts_backfill.
  - Initialize on `store.<name> is None`, and assign back every step.
  - The extend dtype must match the array dtype (`np.float64(np.nan)`).
- Fall back to a windowed (stateless) version only if the operator needs the full raw window, and then set the simulation lookback to at least the largest window.

## 4. Operator mapping
| Fast Expression | Python implementation |
|---|---|
| rank(x) | Cross-sectional rank in [0, 1]. Ties get the averaged rank, not ordinal. NaNs stay NaN. |
| zscore(x) | (x - mean) / std over valid entries. The result is signed, unlike rank. |
| group_rank(x, g) | Rank within each group in [0, 1], ties averaged. Singleton groups give NaN. |
| ts_decay_linear(x, d) | Weights 1..d, newest row heaviest. Normalize by the weights of each name's valid days only. |
| ts_rank(x, d) | Rank of the newest row within the window, ties averaged. Needs at least 2 valid values. |
| ts_backfill(x, d) | Fill NaN with the last valid value if it is at most d days old. |
| a * b, a / b | Elementwise. Guard divisions (non-positive denominators → NaN) and wrap in np.errstate. |

## 5. Rules for composing
- Translate inside out, following the parentheses exactly. Note which term each ts_backfill wraps, and apply the later terms after it.
- Mask out-of-universe names with NaN before any rank (`np.where(u_bool, x, np.nan)`).
- End with pasteurize (NaN outside the universe), then cast to float32.
- Don't add neutralize or scale unless the original needs them. The sim settings already handle neutralization, and extra steps muddy the baseline comparison.
- Don't "improve" the signal during translation. First match the original, then use the article's Part 2 ideas.

## 6. Checks to report with every port
- Field loading: All fields and group fields must load as MATRIX fields in the region.
- Cold start: With lookback=0, windows fill during the sim. Fully warmed positions need roughly the sum of all stage windows.
- Backfill convention: If the stats drift, test `age <= window - 1`.
- Sparse fields: NaN days should add nothing to decays. Check whether the original backfilled the field first.
- Ties: Averaged vs ordinal ranks change results on quantized fields.
- Signed terms: zscore can flip the sign of the product.
- Settings: Match region, universe, delay, decay, truncation and neutralization.
- Correlation: Shared legs (the same tm_ field, the same decay window) mean ports will correlate. Check self-correlation before submitting several.
- Tagging: Tag the Python Alpha with the original Fast Expression Alpha's ID.

## 7. Output format
- One code block with the full module, in this order: constants, helpers (cs_rank, decay, etc.), then the @alpha function.
- Comments mark which Fast Expression term each block implements.
- A short checklist of the points above that apply to this alpha, with no more than a sentence each.
"""
DEFAULT_GUIDELINE = DEFAULT_GUIDELINE + ARTICLE_HEADING + ARTICLE

# operators the mapping table in the guideline covers; anything else must be mapped from the principles in sections 2, 3 and 5
MAPPED = frozenset({"rank", "zscore", "group_rank", "ts_decay_linear", "ts_rank", "ts_backfill"})
ARITHMETIC_OK = True


def is_custom(text: str | None) -> bool:
    """A user-written guideline: long enough to be real and with no PASTE placeholder left in it."""
    t = (text or "").strip()
    return len(t) > 200 and PLACEHOLDER not in t


def effective(file_text: str | None) -> tuple[str, bool]:
    """(the guideline to use, whether it is the built-in one)."""
    return (file_text, False) if is_custom(file_text) else (DEFAULT_GUIDELINE, True)


def _windows(expression: str) -> list[tuple[str, int]]:
    try:
        tree = X.parse(expression)
    except X.ExprError:
        return []
    out: list[tuple[str, int]] = []
    for _p, node in X.walk(tree):
        if isinstance(node, X.Call) and node.name.startswith("ts_"):
            for a in node.args[1:]:
                if isinstance(a, X.Num) and a.is_int and int(a.text) >= 1:
                    out.append((node.name, int(a.text)))
    return out


def analyse(expression: str, field_types: dict[str, str] | None = None) -> dict[str, Any]:
    """Facts about the expression the guideline asks every port to report, computed here instead of trusted to the model."""
    field_types = {k: str(v).upper() for k, v in (field_types or {}).items()}
    names = sorted(fields_in(expression))
    groups = [n for n in names if n in GROUPING_FIELDS or field_types.get(n) == "SYMBOL"]
    matrix, vector, unknown = [], [], []
    for n in names:
        if n in groups:
            continue
        t = field_types.get(n)
        (matrix if t == "MATRIX" else vector if t == "VECTOR" else unknown).append(n)
    ops = sorted(set(operators_in(expression)))
    unmapped = [o for o in ops if o not in MAPPED]
    wins = _windows(expression)
    checks: list[str] = []
    if matrix or unknown:
        checks.append("data=[...] must list: " + ", ".join(matrix + unknown) + " (MATRIX fields only; never \"universe\").")
    if groups:
        checks.append("Group fields (" + ", ".join(groups) + ") are not in data=[...] unless the platform loads them as MATRIX; "
                      "verify they arrive as numeric codes.")
    if vector:
        checks.append("VECTOR field(s) " + ", ".join(vector) + ": the guideline covers MATRIX only, so reduce them first and say how.")
    if unknown:
        checks.append("Type unknown for " + ", ".join(unknown) + " in this region: confirm they load as MATRIX fields.")
    if unmapped:
        checks.append("Not in the guideline's mapping table: " + ", ".join(unmapped) + ". Implement from sections 2, 3 and 5 and flag the choice.")
    if wins:
        total = sum(w for _, w in wins)
        checks.append(f"Cold start: windows {', '.join(f'{n}({w})' for n, w in wins)} sum to about {total} days before positions are fully warmed.")
    if "ts_backfill" in ops:
        checks.append("ts_backfill is present: note which term it wraps and apply the later terms after it; if stats drift, test age <= window - 1.")
    if "zscore" in ops:
        checks.append("zscore is signed: check it does not flip the sign of a product.")
    checks.append("Ties are averaged ranks, not ordinal.")
    checks.append("Tag the Python alpha with the original Fast Expression alpha's ID.")
    return {"fields": {"matrix": matrix, "vector": vector, "group": groups, "unknown": unknown}, "operators": ops,
            "unmapped": unmapped, "windows": wins, "coldStartDays": sum(w for _, w in wins), "checks": checks}


def facts_block(a: dict[str, Any]) -> str:
    f = a["fields"]
    lines = ["MATRIX fields: " + (", ".join(f["matrix"]) or "none known"),
             "Group fields: " + (", ".join(f["group"]) or "none"),
             "VECTOR fields: " + (", ".join(f["vector"]) or "none"),
             "Type not known: " + (", ".join(f["unknown"]) or "none"),
             "Operators used: " + (", ".join(a["operators"]) or "none"),
             "Operators outside the guideline's mapping table: " + (", ".join(a["unmapped"]) or "none"),
             f"Sum of time-series windows (cold start): about {a['coldStartDays']} days"]
    return "\n".join(lines)


OUTPUT_SPEC = (
    "Return ONLY a JSON array of EXACTLY TWO strings. The FIRST is the complete Python module in the order the guideline's section 7 sets "
    "(constants, helpers, then the @alpha function), with comments marking which Fast Expression term each block implements (use \\n for newlines, "
    "no markdown fences inside the string). The SECOND is the short checklist of the guideline's points that apply to THIS alpha, one sentence "
    "each, one point per line. No other prose.")


def parse_answer(items: list | None) -> tuple[str, str]:
    """(code, checklist) from the model's answer; tolerates a single item, fences, or a JSON array sent as one string."""
    seq = [str(x) for x in (items or []) if x is not None]
    if len(seq) == 1 and seq[0].lstrip().startswith("["):
        try:
            again = json.loads(seq[0])
            if isinstance(again, list) and again:
                seq = [str(x) for x in again]
        except ValueError:
            pass
    code = re.sub(r"^```(?:python)?\s*|\s*```$", "", (seq[0] if seq else "").strip()).strip("\n")
    checklist = (seq[1] if len(seq) > 1 else "").strip()
    return code, checklist
