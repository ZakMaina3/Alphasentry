"""Alpha Translation — Fast Expression → Python Alpha, then simulate it on BRAIN.

The translation rules are built in (pyalpha/guidelines.py: the contract, architecture, operator mapping, composing rules and the checks every port must report),
so translation works with one click on a fresh install. `data/pyalpha_guideline.md` overrides them when you have written your own on the page; "Restore
built-in" deletes that file. Every translation sends the guideline verbatim to the LLM (your own API key), together with the definition of each operator
the expression uses, the type of each field (MATRIX / VECTOR / group), and checks computed here (cold-start days, fields to list in data=[...], operators the
mapping table does not cover), so the code follows the rules and the report does not depend on the model remembering them.

Simulation uses the PYTHON alpha type (ace.generate_alpha(alpha_type="PYTHON")). The raw BRAIN
error text is captured and returned so the page can send it back to the LLM for a fix.
"""

from __future__ import annotations

import ast
import json
import re
import time

from app.brain import engine
from app.core.config import get_settings
from app.generation import service as G
from app.pyalpha import guidelines as GL
from app.simulation import service as S

import ace_lib as ace          # noqa: E402
import llm_providers as L      # noqa: E402
import keys as keymgr          # noqa: E402

_GUIDE = get_settings().data_dir / "pyalpha_guideline.md"
PLACEHOLDER = GL.PLACEHOLDER


def get_guideline() -> dict:
    try:
        raw = _GUIDE.read_text(encoding="utf-8")
    except Exception:
        raw = None
    text, builtin = GL.effective(raw)
    return {"text": text, "ready": True, "builtin": builtin, "builtinText": GL.DEFAULT_GUIDELINE}


def save_guideline(text: str) -> dict:
    """Saving text that is empty, a placeholder or identical to the built-in one removes the override."""
    t = (text or "").strip()
    if not GL.is_custom(t) or t == GL.DEFAULT_GUIDELINE.strip():
        return reset_guideline()
    _GUIDE.write_text(text, encoding="utf-8")
    return get_guideline()


def reset_guideline() -> dict:
    try:
        _GUIDE.unlink()
    except FileNotFoundError:
        pass
    return get_guideline()


def _field_types(expression: str, region: str) -> dict:
    """Field id -> MATRIX / VECTOR / SYMBOL from the local catalogue (best effort; empty when unknown)."""
    try:
        from sqlalchemy import select

        from app.db import models as M
        from app.db.base import SessionLocal
        from app.harness.labs.exprtools import fields_in
        names = sorted(fields_in(expression))
        if not names:
            return {}
        with SessionLocal() as db:
            q = select(M.Field.field_id, M.Field.type).where(M.Field.field_id.in_(names))
            if region:
                q = q.where(M.Field.region == region)
            return {fid: t for fid, t in db.execute(q).all()}
    except Exception:
        return {}


# ── translation ──────────────────────────────────────────────────────────────────────

def _op_defs(expr: str) -> str:
    """Definitions of just the operators this expression uses (keeps the prompt small + exact)."""
    try:
        names = sorted(set(G._operators_in(expr)))
        df = engine.operators_df()
        name_col = next((c for c in ("name", "id") if c in df.columns), None)
        desc_col = next((c for c in ("definition", "description", "desc") if c in df.columns), None)
        if not name_col or not names:
            return ", ".join(names)
        lines = []
        for _, r in df.iterrows():
            if r[name_col] in names:
                d = str(r[desc_col])[:400] if desc_col else ""
                lines.append(f"- {r[name_col]}: {d}")
        return "\n".join(lines) or ", ".join(names)
    except Exception:
        return ""


def _extract_code(items: list) -> str:
    return GL.parse_answer(items)[0]


def _syntax(code: str) -> str:
    try:
        ast.parse(code)
        return ""
    except SyntaxError as e:
        return f"line {e.lineno}: {e.msg}"


def translate(*, expression: str, settings: dict, notes: str = "", prior_code: str = "",
              error: str = "", progress=None) -> dict:
    g = get_guideline()
    chain = L.default_chain(keymgr.get_preferred())
    if not chain:
        raise RuntimeError("No LLM providers set up. Add an API key in Settings.")
    expression = (expression or "").strip()
    if not expression:
        raise RuntimeError("No Fast Expression to translate.")

    cfg = ", ".join(f"{k}={v}" for k, v in settings.items() if v not in (None, ""))
    facts = GL.analyse(expression, _field_types(expression, str(settings.get("region") or "")))
    fix = ""
    if prior_code:
        fix = ("\n=== PREVIOUS ATTEMPT (fix it) ===\n" + prior_code[:12000] +
               ("\n=== ERROR FROM THE PLATFORM / CHECKER ===\n" + error[:3000] if error else "") +
               "\nReturn the corrected COMPLETE alpha; keep everything that was already right.\n")
    meta = (
        "You translate WorldQuant BRAIN Fast Expression alphas into Python Alphas. FOLLOW THE GUIDELINE BELOW "
        "EXACTLY — it is authoritative over anything you assume about BRAIN's Python runtime.\n\n"
        f"=== GUIDELINE ===\n{g['text']}\n\n"
        f"=== FAST EXPRESSION ===\n{expression}\n"
        f"=== SIMULATION SETTINGS ===\n{cfg}\n"
        f"=== FACTS ABOUT THIS EXPRESSION (computed, authoritative) ===\n{GL.facts_block(facts)}\n"
        f"=== DEFINITIONS OF THE OPERATORS USED ===\n{_op_defs(expression)}\n"
        + (f"=== EXTRA NOTES FROM THE USER ===\n{notes}\n" if notes.strip() else "") + fix +
        "Translate faithfully: same signal, same operator order, same window lengths and parameters; do not "
        "'improve' the alpha. " + GL.OUTPUT_SPEC)
    t0 = time.time()
    res = L.MultiLLM(chain).generate_list(meta, n=1)
    code, checklist = GL.parse_answer(res.expressions)
    err = _syntax(code)
    if err:     # one automatic repair pass for plain syntax errors
        meta2 = meta + f"\n=== YOUR LAST ANSWER HAD A SYNTAX ERROR ({err}) — return the corrected full source ===\n{code[:12000]}\n"
        res = L.MultiLLM(chain).generate_list(meta2, n=1)
        code, checklist2 = GL.parse_answer(res.expressions)
        checklist = checklist2 or checklist
        err = _syntax(code)
    return {"code": code, "checklist": checklist, "checks": facts["checks"], "coldStartDays": facts["coldStartDays"],
            "builtinGuideline": g["builtin"], "syntax_error": err, "provider": res.provider, "model": res.model,
            "seconds": round(time.time() - t0, 1)}


# ── simulation ───────────────────────────────────────────────────────────────────────

def _poll(s, url, should_cancel) -> dict:
    for _ in range(2000):
        if should_cancel():
            return {"error": "cancelled"}
        r = s.get(url)
        if r.status_code // 100 != 2:
            return {"error": f"HTTP {r.status_code}: {r.text[:600]}"}
        ra = float(r.headers.get("Retry-After", 0) or 0)
        if ra == 0:
            return {"json": r.json()}
        time.sleep(min(ra, 10))
    return {"error": "timed out waiting for the simulation"}


def _row(is_stats, tests, thr, max_turnover):
    sharpe = fitness = turnover = returns = drawdown = margin = None
    if hasattr(is_stats, "empty") and not is_stats.empty:
        d = is_stats.iloc[0].to_dict()
        sharpe, fitness, turnover = S._num(d.get("sharpe")), S._num(d.get("fitness")), S._num(d.get("turnover"))
        returns, drawdown, margin = S._num(d.get("returns")), S._num(d.get("drawdown")), S._num(d.get("margin"))
    failed = []
    if hasattr(tests, "empty") and not tests.empty and "result" in tests.columns:
        failed = [str(r.get("name")) for _, r in tests.iterrows() if r.get("result") == "FAIL"]
    turn = S._norm_turnover(turnover)
    reasons = []
    if sharpe is None or abs(sharpe) < thr["sharpe"]:
        reasons.append("Sharpe below gate")
    if fitness is None or abs(fitness) < thr["fitness"]:
        reasons.append("Fitness below gate")
    if turn is not None and turn >= max_turnover:
        reasons.append("turnover too high")
    reasons += [f"test: {n}" for n in failed]
    return {"sharpe": sharpe, "fitness": fitness, "turnover": turn, "returns": returns,
            "drawdown": drawdown, "margin": margin, "failed_tests": failed,
            "passed": not reasons, "reasons": reasons}


def simulate_python(*, code: str, settings: dict, progress, should_cancel) -> dict:
    s = engine.require_session()
    st = settings
    data = ace.generate_alpha(
        code, alpha_type="PYTHON", region=st.get("region", "USA"), universe=st.get("universe", "TOP3000"),
        delay=int(st.get("delay", 1)), decay=int(st.get("decay", 0)),
        neutralization=st.get("neutralization", "MARKET"), truncation=float(st.get("truncation", 0.08)),
        pasteurization=st.get("pasteurization", "ON"), test_period="P0Y0M0D",
        unit_handling="VERIFY", nan_handling=st.get("nan_handling", "ON"), max_trade="OFF",
        visualization=False, lookback=(int(st["lookback"]) if st.get("lookback") not in (None, "") else None))
    progress(message="submitting the Python alpha…")
    r = ace.start_simulation(s, data)
    if r.status_code // 100 != 2:
        return {"ok": False, "error": f"HTTP {r.status_code}: {r.text[:1800]}"}
    progress(message="simulating on BRAIN (Python alphas are slower)…")
    p = _poll(s, r.headers["Location"], should_cancel)
    if p.get("error"):
        return {"ok": False, "error": p["error"]}
    j = p["json"]
    aid = j.get("alpha")
    if j.get("status") in ("ERROR", "FAIL", "FAILED") or not aid:
        return {"ok": False, "error": json.dumps({k: j.get(k) for k in ("status", "message", "messages", "children") if j.get(k)})[:2500]
                or json.dumps(j)[:2500]}
    progress(message="fetching metrics…")
    stats = ace.get_specified_alpha_stats(s, aid, data, check_submission=bool(st.get("check_submission")))
    thr = S.gate_thresholds(int(st.get("delay", 1)))
    out = _row(stats.get("is_stats"), stats.get("is_tests"), thr, 0.70)
    out.update({"ok": True, "alpha_id": aid})
    return out


def simulate_fast(*, expression: str, settings: dict, progress, should_cancel) -> dict:
    """Baseline: the ORIGINAL Fast Expression, same settings, so the two can be compared."""
    st = settings
    t = S.gate_thresholds(int(st.get("delay", 1)))
    res = S.run_simulation(
        expressions=[expression], region=st.get("region", "USA"), delay=int(st.get("delay", 1)),
        instrument="EQUITY", universes=[st.get("universe", "TOP3000")],
        neutralizations=[st.get("neutralization", "MARKET")], decay=int(st.get("decay", 0)),
        truncation=float(st.get("truncation", 0.08)), test_period="P0Y0M0D",
        pasteurization=st.get("pasteurization", "ON"), unit_handling="VERIFY", nan_handling="OFF",
        max_trade="OFF", visualization=False, concurrency=1, limit_of_multi=2, max_turnover=0.70,
        min_sharpe=t["sharpe"], min_fitness=t["fitness"], max_corr=0.70, tag="", winner_tag="",
        winner_color="GREEN", tag_winners_above=99.0, check_submission=False, get_pnl=False,
        get_stats=False, progress=progress, should_cancel=should_cancel)
    rows = res.get("results") or []
    if not rows:
        return {"ok": False, "error": "; ".join(res.get("errors") or ["simulation returned nothing"])[:1500]}
    r = rows[0]
    return {"ok": True, "alpha_id": r.get("alpha_id"), "sharpe": r.get("sharpe"), "fitness": r.get("fitness"),
            "turnover": r.get("turnover"), "returns": r.get("returns"), "drawdown": r.get("drawdown"),
            "margin": r.get("margin"), "passed": r.get("passed"), "reasons": r.get("reasons") or [],
            "failed_tests": []}
