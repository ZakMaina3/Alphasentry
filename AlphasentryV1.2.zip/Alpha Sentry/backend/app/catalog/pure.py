"""Pure helpers for the Data Catalog (no database, no network): the pull loop, filters and exports."""
from __future__ import annotations

import csv
import io
import time
import zipfile
from xml.sax.saxutils import escape

COLUMNS = ["field_id", "dataset_id", "dataset_name", "category", "region", "delay", "universe", "type",
           "description", "alpha_count", "coverage", "prefix"]


def scope_key(sc: dict) -> str:
    return f"{sc['region']}|{int(sc['delay'])}|{sc.get('universe') or ''}"


def chunks(seq: list, n: int):
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


def pull(scopes: list, categories: list, state: dict, *, list_datasets, fetch_fields, save_datasets, save_fields,
         save_state, progress, cancel, force: bool = False, chunk: int = 5) -> list:
    """Download datasets and their datafields for each scope (region, delay, universe), limited to `categories`
    (empty = all). ONE-TIME by design: a dataset already downloaded for a scope is skipped unless `force`.
    State is saved after every chunk, so an interrupted pull resumes where it stopped.
    Callables: list_datasets(scope, categories) -> [dataset dict with id]; fetch_fields(scope, dataset_ids) -> [field dicts
    with id, description, type, dataset_id ...]; save_datasets(scope, rows); save_fields(scope, rows)."""
    summary = []
    for sc in scopes:
        if cancel():
            break
        key = scope_key(sc)
        done = state.setdefault(key, {})
        try:
            ds = list_datasets(sc, categories)
        except Exception as e:  # noqa: BLE001
            summary.append({"scope": key, "datasets": 0, "fields": 0, "skipped": 0, "errors": [f"listing datasets: {str(e)[:160]}"]})
            continue
        save_datasets(sc, ds)
        todo = [d for d in ds if force or d["id"] not in done]
        rec = {"scope": key, "datasets": len(ds), "fields": 0, "skipped": len(ds) - len(todo), "errors": []}
        progress(message=f"{key}: {len(todo)} dataset(s) to download ({rec['skipped']} already have)")
        for ids in chunks([d["id"] for d in todo], chunk):
            if cancel():
                break
            try:
                rows = fetch_fields(sc, ids)
                if len(ids) > 1 and any(not r.get("dataset_id") for r in rows):     # cannot tell which dataset a field is from
                    rows = []
                    for one in ids:
                        for r in fetch_fields(sc, [one]):
                            r["dataset_id"] = r.get("dataset_id") or one
                            rows.append(r)
                elif len(ids) == 1:
                    for r in rows:
                        r["dataset_id"] = r.get("dataset_id") or ids[0]
                save_fields(sc, rows)
                rec["fields"] += len(rows)
                now = time.time()
                for i in ids:
                    done[i] = now
                save_state(state)
            except Exception as e:  # noqa: BLE001
                rec["errors"].append(f"{', '.join(ids)}: {str(e)[:120]}")
            progress(message=f"{key}: {rec['fields']} fields so far", log=None)
        summary.append(rec)
    return summary


def matches(row: dict, q: str = "", type_: str = "", category: str = "", dataset: str = "") -> bool:
    if type_ and str(row.get("type", "")).upper() != type_.upper():
        return False
    if category and category.lower() not in str(row.get("category", "")).lower():
        return False
    if dataset and dataset.lower() not in (str(row.get("dataset_id", "")) + " " + str(row.get("dataset_name", ""))).lower():
        return False
    if q:
        hay = " ".join(str(row.get(k, "")) for k in ("field_id", "description", "dataset_id", "dataset_name")).lower()
        return all(t in hay for t in q.lower().split())
    return True


def to_csv(rows: list) -> bytes:
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=COLUMNS, extrasaction="ignore")
    w.writeheader()
    for r in rows:
        w.writerow({c: r.get(c, "") for c in COLUMNS})
    return ("﻿" + buf.getvalue()).encode("utf-8")        # BOM so Excel opens UTF-8 correctly


def _col(i: int) -> str:
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def to_xlsx(rows: list, sheet: str = "Datafields") -> bytes:
    """A minimal .xlsx (zip of XML, no extra library). One sheet; header row; numbers stay numbers."""
    def cell(ref, v):
        if isinstance(v, bool) or v is None or v == "":
            return f'<c r="{ref}" t="inlineStr"><is><t></t></is></c>' if v in ("", None) else f'<c r="{ref}"><v>{int(v)}</v></c>'
        if isinstance(v, (int, float)):
            return f'<c r="{ref}"><v>{v}</v></c>'
        t = escape(str(v)).replace("\x00", "")
        return f'<c r="{ref}" t="inlineStr"><is><t xml:space="preserve">{t}</t></is></c>'

    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
           '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>']
    out.append('<row r="1">' + "".join(cell(f"{_col(i)}1", c) for i, c in enumerate(COLUMNS)) + "</row>")
    for n, r in enumerate(rows, start=2):
        out.append(f'<row r="{n}">' + "".join(cell(f"{_col(i)}{n}", r.get(c, "")) for i, c in enumerate(COLUMNS)) + "</row>")
    out.append("</sheetData></worksheet>")
    files = {
        "[Content_Types].xml": '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>',
        "_rels/.rels": '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
        "xl/workbook.xml": f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="{escape(sheet)[:31]}" sheetId="1" r:id="rId1"/></sheets></workbook>',
        "xl/_rels/workbook.xml.rels": '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>',
        "xl/worksheets/sheet1.xml": "".join(out),
    }
    bio = io.BytesIO()
    with zipfile.ZipFile(bio, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in files.items():
            z.writestr(name, data)
    return bio.getvalue()


def categories_from(rows: list) -> list:
    """[{id, name, count}] from dataset rows (get_datasets shape: category_id / category_name)."""
    acc: dict = {}
    for r in rows:
        cid = str(r.get("category_id") or "").strip()
        if not cid:
            continue
        a = acc.setdefault(cid, {"id": cid, "name": str(r.get("category_name") or cid), "count": 0})
        a["count"] += 1
    return sorted(acc.values(), key=lambda x: -x["count"])
