"""Markets (region / delay / universe) known from the data already stored on this computer.

Feeds the Region, Delay and Universe dropdowns of Autosentry, Supersentry and SentryEngine, so they work without BRAIN's
option list and only offer markets you actually have data for. Plain sqlite3 through the harness Store; read-only.
"""
from __future__ import annotations

from typing import Any

#: Last resort when nothing is stored yet (fresh install, never pulled anything): BRAIN's usual markets.
FALLBACK = {
    "USA": {1: ["TOP3000", "TOP1000", "TOP500", "TOP200", "TOPSP500", "ILLIQUID_MINVOL1M"], 0: ["TOP3000", "TOP1000", "TOP500", "TOP200"]},
    "GLB": {1: ["TOP3000", "MINVOL1M"]},
    "EUR": {1: ["TOP2500", "TOP1200", "TOP800", "TOP400", "ILLIQUID_MINVOL1M"], 0: ["TOP2500", "TOP1200", "TOP800", "TOP400"]},
    "ASI": {1: ["MINVOL1M", "ILLIQUID_MINVOL1M"]},
    "CHN": {1: ["TOP2000U"], 0: ["TOP2000U"]},
    "JPN": {1: ["TOP1600", "TOP1200"]},
    "IND": {1: ["TOP500"], 0: ["TOP500"]},
    "KOR": {1: ["TOP600"]},
    "TWN": {1: ["TOP500", "TOP100"]},
    "HKG": {1: ["TOP800", "TOP500"]},
    "GBR": {1: ["TOP1200"]},
    "DEU": {1: ["TOP1000"]},
    "AMR": {1: ["TOP600"]},
}


def build(universe_rows: list[tuple], field_rows: list[tuple], option_records: list[dict] | None = None,
          fallback: dict | None = FALLBACK) -> dict:
    """Merge every source into {regions: [{region, delays: [..], universes: {"1": [..]}, instrument, local: bool}]}.
    universe_rows: (region, delay, universe, n) from datasets/results; field_rows: (region, delay) known to have fields;
    option_records: BRAIN's own list (optional, from the frontend's cached options)."""
    seen: dict[tuple[str, int], dict[str, int]] = {}
    local: set[str] = set()

    def add(region: Any, delay: Any, universe: Any, n: int = 1, is_local: bool = True) -> None:
        region, universe = str(region or "").strip().upper(), str(universe or "").strip().upper()
        if not region:
            return
        try:
            delay = int(delay)
        except (TypeError, ValueError):
            return
        u = seen.setdefault((region, delay), {})
        if universe:
            u[universe] = u.get(universe, 0) + max(1, int(n or 1))
        if is_local:
            local.add(region)

    for r, d, u, n in universe_rows:
        add(r, d, u, n)
    for r, d in field_rows:
        add(r, d, "")
    for rec in option_records or []:
        for u in rec.get("universes") or [""]:
            add(rec.get("region"), rec.get("delay"), u, 1, is_local=False)
    if not seen and fallback:
        for region, delays in fallback.items():
            for d, unis in delays.items():
                for u in unis:
                    add(region, d, u, 1, is_local=False)
    regions: dict[str, dict] = {}
    for (region, delay), unis in seen.items():
        rec = regions.setdefault(region, {"region": region, "delays": [], "universes": {}, "local": region in local})
        rec["delays"].append(delay)
        rec["universes"][str(delay)] = [u for u, _ in sorted(unis.items(), key=lambda kv: (-kv[1], kv[0]))]
    out = []
    for region in sorted(regions, key=lambda r: (r not in local, r != "USA", r)):
        rec = regions[region]
        rec["delays"] = sorted(set(rec["delays"]))
        out.append(rec)
    return {"regions": out}


def local_scopes(store, option_records: list[dict] | None = None) -> dict:
    """The markets stored locally (datasets pulled, alphas simulated, fields downloaded), merged with BRAIN's list when given."""
    rows: list[tuple] = []
    fields: list[tuple] = []
    for sql, sink, cols in (
        ("SELECT region, delay, universe, COUNT(*) AS n FROM datasets WHERE region != '' GROUP BY region, delay, universe", rows, 4),
        ("SELECT region, delay, universe, COUNT(*) AS n FROM sim_results WHERE region != '' GROUP BY region, delay, universe", rows, 4),
        ("SELECT DISTINCT region, delay FROM fields WHERE region != ''", fields, 2),
    ):
        try:
            for r in store.query(sql):
                sink.append(tuple(r[i] for i in range(cols)))
        except Exception:  # noqa: BLE001      a table that does not exist yet is simply no data
            pass
    return build(rows, fields, option_records)
