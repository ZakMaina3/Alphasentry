"""Data Catalog service: pulls datasets and datafields from BRAIN ONCE per region/delay/category, keeps them in the
shared knowledge database (`datasets`, `fields`) and serves browsing and CSV/Excel export. Read-only towards BRAIN."""
from __future__ import annotations

import json
import time

from sqlalchemy import and_, func, or_, select

from app.brain import engine
from app.catalog import pure as C
from app.core.config import get_settings
from app.db import models as M
from app.db.base import SessionLocal
from app.knowledge import service as knowledge

_STATE = get_settings().data_dir / "catalog_state.json"


def _load_state() -> dict:
    try:
        return json.loads(_STATE.read_text())
    except Exception:
        return {}


def _save_state(st: dict) -> None:
    tmp = _STATE.with_suffix(".tmp")
    tmp.write_text(json.dumps(st))
    tmp.replace(_STATE)


# ── what BRAIN offers ────────────────────────────────────────────────────────────────

def scopes_offered() -> list:
    recs = engine.get_options().get("records", [])
    out = []
    for r in recs:
        if r.get("instrument") != "EQUITY":
            continue
        out.append({"region": r["region"], "delay": r["delay"], "universe": (r.get("universes") or [""])[0],
                    "universes": r.get("universes") or []})
    return sorted(out, key=lambda x: (x["region"], x["delay"]))


def list_categories(scopes: list) -> list:
    """Datasets for the chosen scopes (stored too), reduced to their categories."""
    rows = []
    for sc in scopes:
        got = engine.get_datasets(region=sc["region"], universe=sc.get("universe") or "TOP3000", delay=int(sc["delay"]),
                                  instrument_type="EQUITY")
        try:
            knowledge.ingest_datasets(sc["region"], int(sc["delay"]), "EQUITY", sc.get("universe") or "", got)
        except Exception as e:  # noqa: BLE001
            print(f"[catalog] dataset ingest skipped: {e}")
        rows += got
    return C.categories_from(rows)


# ── storing ──────────────────────────────────────────────────────────────────────────

def _save_datasets(sc: dict, rows: list) -> None:
    knowledge.ingest_datasets(sc["region"], int(sc["delay"]), "EQUITY", sc.get("universe") or "", rows)


def _save_fields(sc: dict, rows: list) -> None:
    """Insert new fields and refresh description / type / alpha count on ones we already have. Never deletes."""
    if not rows:
        return
    region, delay, now = sc["region"], int(sc["delay"]), time.time()
    with SessionLocal() as db:
        have = {f.field_id: f for f in db.scalars(select(M.Field).where(
            M.Field.region == region, M.Field.delay == delay,
            M.Field.field_id.in_([str(r.get("id") or "") for r in rows])))}
        for r in rows:
            fid = str(r.get("id") or "").strip()
            if not fid:
                continue
            f = have.get(fid)
            if f is not None:
                f.last_seen = now
                f.description = str(r.get("description") or f.description or "")
                f.type = str(r.get("type") or f.type or "MATRIX").upper()
                f.alpha_count = int(r.get("alphaCount") or f.alpha_count or 0)
                if not f.dataset_id and r.get("dataset_id"):
                    f.dataset_id = str(r["dataset_id"])
            else:
                pfx = r.get("prefix") or (fid.split("_", 1)[0] if "_" in fid else "general")
                db.add(M.Field(field_id=fid, dataset_id=str(r.get("dataset_id") or ""), region=region, delay=delay,
                               type=str(r.get("type") or "MATRIX").upper(), prefix=str(pfx).lower(),
                               description=str(r.get("description") or ""), alpha_count=int(r.get("alphaCount") or 0),
                               is_virgin=bool(r.get("is_virgin"))))
        db.commit()


def _fetch_fields(sc: dict, ids: list) -> list:
    df, _raw = engine.fetch_fields(ids, region=sc["region"], universe=sc.get("universe") or "TOP3000",
                                   delay=int(sc["delay"]), instrument_type="EQUITY")
    if df is None or getattr(df, "empty", True):
        return []
    cols = [c for c in ["id", "description", "type", "alphaCount", "coverage", "is_virgin", "dataset_id"] if c in df.columns]
    rows = df[cols].to_dict(orient="records")
    for r in rows:
        fid = str(r.get("id", ""))
        r["prefix"] = fid.split("_", 1)[0].lower() if "_" in fid else "general"
    return engine._json_safe(rows)


def _list_datasets(sc: dict, categories: list) -> list:
    return engine.get_datasets(region=sc["region"], universe=sc.get("universe") or "TOP3000", delay=int(sc["delay"]),
                               instrument_type="EQUITY", category=",".join(categories))


def pull(scopes: list, categories: list, force: bool, progress, should_cancel) -> dict:
    engine.require_session()
    state = _load_state()
    summary = C.pull(scopes, categories, state, list_datasets=_list_datasets, fetch_fields=_fetch_fields,
                     save_datasets=_save_datasets, save_fields=_save_fields, save_state=_save_state,
                     progress=progress, cancel=should_cancel, force=force)
    st = _load_state()
    for s in summary:
        st.setdefault("_pulls", {})[s["scope"]] = {"t": time.time(), "categories": categories}
    _save_state(st)
    return {"scopes": summary, "fields": sum(s["fields"] for s in summary),
            "errors": [e for s in summary for e in s["errors"]]}


# ── reading ──────────────────────────────────────────────────────────────────────────

def _query(region="", delay=None, q="", type_="", category="", dataset=""):
    j = and_(M.Dataset.dataset_id == M.Field.dataset_id, M.Dataset.region == M.Field.region, M.Dataset.delay == M.Field.delay)
    stmt = (select(M.Field, M.Dataset.name, M.Dataset.category, M.Dataset.universe, M.Dataset.coverage)
            .outerjoin(M.Dataset, j))
    if region:
        stmt = stmt.where(M.Field.region == region)
    if delay is not None and str(delay) != "":
        stmt = stmt.where(M.Field.delay == int(delay))
    if type_:
        stmt = stmt.where(M.Field.type == type_.upper())
    if category:
        stmt = stmt.where(M.Dataset.category.ilike(f"%{category}%"))
    if dataset:
        stmt = stmt.where(or_(M.Field.dataset_id.ilike(f"%{dataset}%"), M.Dataset.name.ilike(f"%{dataset}%")))
    for t in (q or "").split():
        stmt = stmt.where(or_(M.Field.field_id.ilike(f"%{t}%"), M.Field.description.ilike(f"%{t}%"),
                              M.Field.dataset_id.ilike(f"%{t}%")))
    return stmt


def _row(f, name, cat, universe, cov) -> dict:
    return {"field_id": f.field_id, "dataset_id": f.dataset_id, "dataset_name": name or "", "category": cat or "",
            "region": f.region, "delay": f.delay, "universe": universe or "", "type": f.type,
            "description": f.description, "alpha_count": f.alpha_count, "coverage": cov, "prefix": f.prefix}


def browse(limit: int = 200, offset: int = 0, **flt) -> dict:
    stmt = _query(**flt)
    with SessionLocal() as db:
        total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
        rows = db.execute(stmt.order_by(M.Field.region, M.Field.delay, M.Field.dataset_id, M.Field.field_id)
                          .limit(max(1, min(limit, 1000))).offset(max(0, offset))).all()
    return {"total": total, "rows": [_row(*r) for r in rows]}


def export(fmt: str, **flt) -> tuple[bytes, str, str]:
    stmt = _query(**flt)
    with SessionLocal() as db:
        rows = [_row(*r) for r in db.execute(stmt.order_by(M.Field.region, M.Field.delay, M.Field.field_id).limit(300000)).all()]
    stamp = time.strftime("%Y%m%d")
    if fmt == "xlsx":
        return (C.to_xlsx(rows), f"alpha_sentry_datafields_{stamp}.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    return C.to_csv(rows), f"alpha_sentry_datafields_{stamp}.csv", "text/csv; charset=utf-8"


def summary() -> dict:
    with SessionLocal() as db:
        fl = db.execute(select(M.Field.region, M.Field.delay, func.count()).group_by(M.Field.region, M.Field.delay)).all()
        ds = db.execute(select(M.Dataset.region, M.Dataset.delay, func.count()).group_by(M.Dataset.region, M.Dataset.delay)).all()
        cats = db.execute(select(M.Dataset.category, func.count()).where(M.Dataset.category != "").group_by(M.Dataset.category)).all()
    pulls = _load_state().get("_pulls", {})
    d = {(r, dl): n for r, dl, n in ds}
    out = []
    for r, dl, n in fl:
        pulled = next((v for k, v in pulls.items() if k.startswith(f"{r}|{dl}|")), None)
        out.append({"region": r, "delay": dl, "fields": n, "datasets": d.get((r, dl), 0),
                    "pulled_at": pulled["t"] if pulled else None})
    return {"scopes": sorted(out, key=lambda x: (x["region"], x["delay"])),
            "categories": sorted([{"id": c, "count": n} for c, n in cats], key=lambda x: -x["count"])}
