"""Data Catalog: a one-time download of datasets and datafields from BRAIN (by region and category),
stored in the shared knowledge database that Autosentry, Clone and swap and SentryEngine all read."""
