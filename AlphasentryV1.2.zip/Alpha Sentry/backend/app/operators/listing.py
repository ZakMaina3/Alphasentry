"""Operator Atlas -> prompt text (pure: takes the atlas rows, returns a string)."""
from __future__ import annotations


def atlas_listing(ops: list[dict], *, skip_prefixes: tuple[str, ...] = (), skip_names: set[str] | None = None, limit: int = 200) -> str:
    """`signature   # e.g. example   -- note` per operator, user-edited rows first (your own notes matter most), then by name."""
    skip_names = skip_names or set()
    rows = [o for o in ops if o.get("name") and o["name"] not in skip_names and not any(o["name"].startswith(p) for p in skip_prefixes)]
    rows.sort(key=lambda o: (not o.get("user_edited"), str(o["name"])))
    lines: list[str] = []
    for o in rows[:limit]:
        sig = str(o.get("signature") or o["name"]).strip()
        ex = str(o.get("example") or "").strip()
        note = " ".join(str(o.get("notes") or "").split())[:160]
        line = f"  {sig}"
        if ex and ex != sig:
            line += f"   # e.g. {ex}"
        if note:
            line += f"   -- {note}"
        lines.append(line)
    return "\n".join(lines) + "\n" if lines else ""
