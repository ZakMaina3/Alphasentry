"""Research engine.

An LLM research step that is deliberately SEPARATE from generation: the user researches a
category / datasets / region (optionally attaching a research paper), gets structured
hypotheses grounded in the exact fields provided, and only then pushes chosen ideas to
generation or templates. It reuses the studio's provider stack (llm_providers, keys) via
the brain adapter's sys.path, so no LLM code is duplicated.

Output is requested as a JSON array of delimited strings
    idea ||| mechanism ||| expected sign ||| horizon ||| candidate FastExpr
which `extract_list` returns cleanly, and we parse into structured hypotheses. This keeps
one LLM call and avoids relying on nested-object parsing.
"""

from __future__ import annotations

import json
import time

from app.brain import engine  # noqa: F401  — loads the vendored engine

import llm_providers as L  # noqa: E402
import keys as keymgr       # noqa: E402

DELIM = "|||"


def providers() -> dict:
    preferred = keymgr.get_preferred()
    return {"available": [p.name for p in L.all_available()],
            "preferred": preferred,
            "used": [p.name for p in L.default_chain(preferred)]}


def _field_summary(fields: list, categories: dict | None = None, max_fields: int = 40) -> str:
    # Reuse Generation's grounded summary: FULL descriptions + a data-nature tag (continuous/ratio/
    # count/event/group/vector), so hypotheses are formed from what each field actually measures.
    from app.generation import service as gen
    return gen._field_summary(fields, categories or {}, max_fields=max_fields)


def _generalisation_rule(categories: dict) -> str:
    cats = sorted({str(c) for c in (categories or {}).values() if c})
    if len(cats) > 1:
        return ("GENERALISE ACROSS CATEGORIES: several data categories are present (" + ", ".join(cats) +
                "). Frame each hypothesis at the CATEGORY / mechanism level and span the different "
                "categories — not a single field or a single category.\n")
    return ("GENERALISE ACROSS THE DATAFIELDS: a single category is being explored, so frame each "
            "hypothesis generally over its datafields (the shared signal they carry), not overfit to one field.\n")


_MODE_RULES = {
    "single": (
        "FIELD USE — SINGLE FIELD (default): each candidate FastExpr uses EXACTLY ONE datafield. "
        "Operators needing 2+ inputs reuse that SAME field under a DIFFERENT transformation — never a "
        "second field."),
    "multi_single_dataset": (
        "FIELD USE — MULTI-FIELD, ONE DATASET (STRICT): each candidate MUST combine TWO OR MORE DIFFERENT "
        "datafields, ALL from the SAME dataset — never just one field, and never a field from another "
        "dataset. Combine them meaningfully (ratio, spread, ts_corr, conditioning)."),
    "multi_two_categories": (
        "FIELD USE — MULTI-FIELD, TWO CATEGORIES (STRICT): each candidate MUST combine datafields from TWO "
        "DIFFERENT categories (each field's category is in its [TYPE|category] tag) — never a single "
        "category, and NEVER three or more (that overfits and is rejected)."),
}


def _prompt(category, region, delay, instrument, dataset_names, fields, categories, goal,
            paper_text, paper_is_community, mode, max_operators, n) -> str:
    paper_block = ""
    if paper_text:
        which = ("This is a WorldQuant COMMUNITY paper — map its mechanism ONLY onto the specific datasets/"
                 "fields the user selected for it. " if paper_is_community else
                 "This is the user's own paper. ")
        paper_block = ("\n=== RESEARCH PAPER EXCERPT ===\n" + which +
                       "Extract the underlying economic mechanism and adapt it to the datafields below. "
                       "Do NOT invent or reference any field the paper mentions but that is not in the list.\n"
                       + paper_text[:40000] + "\n")   # use the whole paper / specified pages
    goal_line = f"User goal: {goal}\n" if goal else ""
    mode_rule = _MODE_RULES.get(mode, _MODE_RULES["single"])
    from app.generation import service as gen
    from app.knowledge import categories as cats
    from app.operators import service as opsvc
    op_block = gen.operator_summary()
    op_examples = opsvc.reference_block("REGULAR")
    cat_guide = cats.combination_guidance(mode, list((categories or {}).values()))
    return (
        "You are a senior quantitative researcher designing alpha ideas for the WorldQuant BRAIN platform. "
        "Your hypotheses must be concrete, mechanism-first, and directly testable — not generic.\n"
        f"Market context: region {region}, delay {delay}, {instrument}. "
        f"Data category: {category or 'unspecified'}. Datasets: {', '.join(dataset_names) or 'unspecified'}.\n"
        "Reason explicitly about what drives THIS market and region — liquidity and microstructure, who "
        "trades and why, settlement/delay conventions, how and how fast information diffuses into prices — "
        "and about which of the fields below actually captures that force, on what horizon, and why the "
        "effect should persist rather than be arbitraged away.\n"
        + (f"NOTE: delay {delay} — for delay 0, favour ideas whose edge is a strong risk-adjusted return "
           "(Sharpe), since delay-0 alphas are judged primarily on Sharpe.\n" if str(delay) == "0" else "")
        + goal_line + paper_block +
        f"\nPropose {n} DISTINCT, testable hypotheses. Each must exploit a DIFFERENT economic mechanism AND a "
        "DIFFERENT operator family; extract signal in varied ways (arithmetic, time-series momentum/reversal/"
        "seasonality, cross-sectional rank/zscore/scale, group-relative neutralisation, logical/conditional "
        "regime gates) — never repeat one shape.\n"
        + _generalisation_rule(categories) +
        "The IDEA and MECHANISM must be GENERAL (about the data, not one specific field); the candidate "
        "expression then ILLUSTRATES it using specific field(s) from the list.\n"
        "DATASET/CATEGORY COVERAGE (critical): across the " + str(n) + " hypotheses, represent EVERY dataset AND "
        "every category provided (" + (", ".join(dataset_names) or "the datasets") + ") ROUGHLY EQUALLY — each "
        "dataset must appear in at least one hypothesis (and its candidate expression) before any dataset is used a "
        "second time. When fields come from several categories, ensure both single-category and cross-category "
        "ideas appear. Never fixate on one dataset or category.\n"
        "=== HARD RULES FOR THE CANDIDATE EXPRESSION ===\n"
        f"- {mode_rule}\n"
        "- Use ONLY the datafields listed below. NEVER invent, rename, or assume any other field.\n"
        "- FIELD TYPE MATTERS: a [VECTOR] field MUST be wrapped in a vec_* operator (vec_avg, vec_sum, "
        "vec_max, vec_min, vec_stddev, vec_norm, …) to reduce it to a scalar BEFORE any other operator uses "
        "it — e.g. ts_zscore(vec_avg(field), 120), never ts_zscore(field, 120) for a VECTOR field. A "
        "[MATRIX] field is used directly and must NOT be wrapped in vec_*.\n"
        f"- Use EXACTLY {max_operators} operators in the candidate expression — not more, not fewer. The idea is a "
        "DIRECTION: choose operators WISELY to fit it; do not restrict to any one named operator. Pass NAMED "
        "parameters as keywords (name=value); windows/groups are positional bare values; a group is an identifier "
        "(industry/subindustry/sector/market/country), never a number. NEVER use bucket().\n\n"
        + cat_guide + "\n"
        + f"=== OPERATORS (use ONLY these, with correct arity) ===\n{op_block}\n{op_examples}\n"
        + f"=== DATAFIELDS (type|category tagged) ===\n{_field_summary(fields, categories)}\n\n"
        + f"Return ONLY a JSON array of {n} strings. Each string MUST use this exact delimited form:\n"
        f"  idea {DELIM} mechanism (why it predicts returns, region-aware) {DELIM} expected sign {DELIM} "
        f"horizon in days {DELIM} confidence 1-5 (your conviction in the edge) {DELIM} candidate FastExpr "
        f"(following ALL rules above)\n"
    )


def _parse(items: list) -> tuple[list, list]:
    hypotheses, expressions = [], []
    for s in items:
        parts = [p.strip() for p in str(s).split(DELIM)]
        if len(parts) >= 2:
            # The expression is always the LAST field; confidence (1-5) is the 5th when present.
            conf = ""
            if len(parts) >= 6:
                conf, expr = parts[4], parts[5]
            else:
                expr = parts[4] if len(parts) > 4 else ""
            try:
                conf_n = max(1, min(5, int(float(conf))))
            except (TypeError, ValueError):
                conf_n = 0
            h = {"idea": parts[0], "mechanism": parts[1],
                 "sign": parts[2] if len(parts) > 2 else "",
                 "horizon": parts[3] if len(parts) > 3 else "",
                 "confidence": conf_n, "expression": expr}
            hypotheses.append(h)
            if h["expression"]:
                expressions.append(h["expression"])
        else:
            hypotheses.append({"idea": str(s), "mechanism": "", "sign": "", "horizon": "", "confidence": 0, "expression": ""})
    return hypotheses, expressions


MAX_HYPOTHESIS_REPEATS = 2  # never suggest the same hypothesis (by fingerprint) more than this


def _idea_fingerprint(idea: str) -> str:
    """Coarse fingerprint for deduping hypotheses across sessions: normalized text, stopwords
    dropped, first 12 significant words — close paraphrases collapse to the same fingerprint
    so 'don't repeat this idea' holds up even if the LLM rewords it slightly."""
    norm = _normalize(idea)
    words = _re.findall(r"[a-z0-9]+", norm)
    stop = {"the", "a", "an", "of", "to", "in", "on", "for", "and", "or", "that", "this",
            "with", "is", "are", "its", "it's", "by", "as", "be", "will", "than"}
    sig = [w for w in words if w not in stop][:12]
    return " ".join(sig)


def _hypothesis_history(category: str, region: str) -> dict:
    """fingerprint -> HypothesisLog row, for enforcing the repeat cap."""
    from app.db.base import SessionLocal
    from app.db import models as M
    from sqlalchemy import select
    with SessionLocal() as db:
        rows = db.scalars(select(M.HypothesisLog).where(
            M.HypothesisLog.category == category, M.HypothesisLog.region == region)).all()
        return {r.fingerprint: r for r in rows}


def _credit_hypotheses(category: str, region: str, ideas: list) -> None:
    from app.db.base import SessionLocal
    from app.db import models as M
    from sqlalchemy import select
    now = time.time()
    with SessionLocal() as db:
        for idea in ideas:
            fp = _idea_fingerprint(idea)
            if not fp:
                continue
            row = db.scalar(select(M.HypothesisLog).where(
                M.HypothesisLog.fingerprint == fp, M.HypothesisLog.category == category,
                M.HypothesisLog.region == region))
            if row:
                row.times_suggested += 1
                row.last_suggested_at = now
            else:
                db.add(M.HypothesisLog(fingerprint=fp, category=category, region=region, idea=idea,
                                       times_suggested=1, first_suggested_at=now, last_suggested_at=now))
        db.commit()


def brainstorm_hypotheses(*, category, region, delay, instrument, goal="", n=6) -> dict:
    """STEP 1 of the hypothesis-FIRST workflow: propose testable stock-price-prediction
    hypotheses BEFORE any datafield is fetched. Each one names the KIND of data it needs as
    plain search keywords (not a real field id — none have been fetched yet); pass those
    keywords to fields_for_hypothesis() to get an actual datafield shortlist, THEN run the
    normal grounded research/generation pipeline on those fields.

    Never suggests the same hypothesis (by fingerprint) more than MAX_HYPOTHESIS_REPEATS
    times for this category/region."""
    chain = L.default_chain(keymgr.get_preferred())
    if not chain:
        raise RuntimeError("No LLM providers set up. Add an API key in Settings.")
    history = _hypothesis_history(category, region)
    exhausted = [r.idea for r in history.values() if r.times_suggested >= MAX_HYPOTHESIS_REPEATS]
    goal_line = f"User goal: {goal}\n" if goal else ""
    avoid_block = ""
    if exhausted:
        avoid_block = ("\nDo NOT suggest any of these ideas again — each has already been proposed "
                       f"{MAX_HYPOTHESIS_REPEATS} times before. Propose genuinely different economic "
                       "mechanisms instead:\n- " + "\n- ".join(exhausted[:25]) + "\n")
    meta = (
        "You are a senior quantitative researcher proposing STOCK PRICE PREDICTION hypotheses for "
        f"the WorldQuant BRAIN platform. Market context: region {region}, delay {delay}, {instrument}. "
        f"Category focus: {category or 'unspecified — propose across sensible categories'}.\n"
        + goal_line + avoid_block +
        f"Propose {n} DISTINCT, testable hypotheses for predicting stock returns, each exploiting a "
        "DIFFERENT economic mechanism (momentum/reversal, liquidity/microstructure, sentiment/news, "
        "fundamentals, analyst behaviour, ownership/flow, seasonality, cross-sectional relative value, "
        "risk/volatility, etc). Do NOT reference any specific datafield id — the data catalogue has not "
        "been fetched yet; instead name the KIND of data each hypothesis needs.\n"
        f"Return ONLY a JSON array of exactly {n} strings, each in this exact delimited form:\n"
        f"  idea {DELIM} mechanism (why it should predict returns, region-aware) {DELIM} expected sign "
        f"{DELIM} horizon in trading days {DELIM} 3-6 short search keywords for the KIND of datafield "
        "needed, comma-separated (e.g. 'short interest, borrow fee, days to cover')\n"
    )
    res = L.MultiLLM(chain).generate_list(meta, n=n)
    out = []
    for s in res.expressions:
        parts = [p.strip() for p in str(s).split(DELIM)]
        if len(parts) < 2:
            continue
        idea, mechanism = parts[0], parts[1]
        sign = parts[2] if len(parts) > 2 else ""
        horizon = parts[3] if len(parts) > 3 else ""
        kw_raw = parts[4] if len(parts) > 4 else ""
        keywords = [k.strip() for k in kw_raw.split(",") if k.strip()]
        out.append({"idea": idea, "mechanism": mechanism, "sign": sign, "horizon": horizon,
                    "field_keywords": keywords})

    # Hard cap, belt-and-braces: drop anything that (by fingerprint) already hit the repeat
    # limit even if the LLM ignored the "don't repeat" instruction above.
    filtered = []
    for h in out:
        fp = _idea_fingerprint(h["idea"])
        prior = history.get(fp)
        if prior and prior.times_suggested >= MAX_HYPOTHESIS_REPEATS:
            continue
        filtered.append(h)

    _credit_hypotheses(category, region, [h["idea"] for h in filtered])
    return {"hypotheses": filtered, "provider": res.provider, "model": res.model}


def fields_for_hypothesis(*, region, delay, instrument, universe, keywords, limit=25,
                          live_fetch=True) -> dict:
    """STEP 2 of the hypothesis-FIRST workflow: given a hypothesis's search keywords, find the
    datafields that actually match it. Tries the local knowledge DB first (fields you've
    already fetched from BRAIN before, in this region/delay); if that comes up short and
    live_fetch is on, falls back to a live BRAIN dataset+field search on the same keywords so
    a brand-new region/category still works on the first try."""
    from app.db.base import SessionLocal
    from app.db import models as M
    from sqlalchemy import select
    kws = [k.lower().strip() for k in (keywords or []) if k.strip()]
    if not kws:
        return {"fields": [], "matched_keywords": [], "source": "none"}

    with SessionLocal() as db:
        rows = db.scalars(select(M.Field).where(
            M.Field.region == region, M.Field.delay == delay)).all()
    scored = []
    for r in rows:
        hay = f"{r.field_id} {r.description}".lower()
        hits = sum(1 for k in kws if k in hay)
        if hits:
            scored.append((hits, r))
    scored.sort(key=lambda x: -x[0])
    fields = [{"id": r.field_id, "dataset_id": r.dataset_id, "type": r.type,
              "description": r.description} for _, r in scored[:limit]]
    if fields or not live_fetch:
        return {"fields": fields, "matched_keywords": kws, "source": "local"}

    # Nothing cached locally for this region/delay yet — search BRAIN live, once per keyword,
    # merging + de-duplicating results (same shortcut the Data Explorer's search box uses).
    try:
        live = []
        seen = set()
        for kw in kws[:4]:   # a handful of calls, not one per keyword forever
            df, _raw = engine.fetch_fields([], region=region, universe=universe, delay=delay,
                                           instrument_type=instrument, data_type="ALL", search=kw)
            if df is None or getattr(df, "empty", True):
                continue
            for _, row in df.iterrows():
                fid = row.get("id")
                if not fid or fid in seen:
                    continue
                seen.add(fid)
                live.append({"id": fid, "dataset_id": row.get("dataset_id", ""),
                            "type": row.get("type", "MATRIX"), "description": row.get("description", "")})
                if len(live) >= limit:
                    break
            if len(live) >= limit:
                break
        return {"fields": live, "matched_keywords": kws, "source": "live"}
    except Exception as e:  # noqa: BLE001
        return {"fields": [], "matched_keywords": kws, "source": "error", "error": str(e).splitlines()[0][:140]}


# ── hypothesis-FIRST workflow (propose ideas before any datafield is fetched) ─────────
# Normal `run_research` above is grounded in fields you've already selected. This section
# flips that: brainstorm_hypotheses() proposes mechanisms + search keywords with NO field
# catalogue in hand, then fields_for_hypothesis() turns those keywords into an actual
# datafield search — so the pipeline is idea -> data, not data -> idea.

MAX_HYPOTHESIS_REPEATS = 2  # never suggest the same hypothesis (by fingerprint) more than this


def _idea_fingerprint(idea: str) -> str:
    """Coarse fingerprint for deduping hypotheses across sessions: normalized text, stopwords
    dropped, first 12 significant words — close paraphrases collapse to the same fingerprint
    so the repeat cap holds up even when the LLM rewords an old idea."""
    norm = _normalize(idea)
    words = _re.findall(r"[a-z0-9]+", norm)
    stop = {"the", "a", "an", "of", "to", "in", "on", "for", "and", "or", "that", "this",
           "with", "is", "are", "its", "it's", "as", "by", "from", "will", "should"}
    sig = [w for w in words if w not in stop][:12]
    return " ".join(sig)


def _hypothesis_history(category: str, region: str) -> dict:
    from app.db.base import SessionLocal
    from app.db import models as M
    from sqlalchemy import select
    with SessionLocal() as db:
        rows = db.scalars(select(M.HypothesisLog).where(
            M.HypothesisLog.category == category, M.HypothesisLog.region == region)).all()
        return {r.fingerprint: r for r in rows}


def _credit_hypotheses(category: str, region: str, ideas: list) -> None:
    from app.db.base import SessionLocal
    from app.db import models as M
    from sqlalchemy import select
    now = time.time()
    with SessionLocal() as db:
        for idea in ideas:
            fp = _idea_fingerprint(idea)
            if not fp:
                continue
            row = db.scalar(select(M.HypothesisLog).where(
                M.HypothesisLog.fingerprint == fp, M.HypothesisLog.category == category,
                M.HypothesisLog.region == region))
            if row:
                row.times_suggested += 1
                row.last_suggested_at = now
            else:
                db.add(M.HypothesisLog(fingerprint=fp, category=category, region=region, idea=idea,
                                       times_suggested=1, first_suggested_at=now, last_suggested_at=now))
        db.commit()


def brainstorm_hypotheses(*, category, region, delay, instrument, goal="", n=6) -> dict:
    """STEP 1: propose testable stock-price-prediction hypotheses BEFORE any datafield is
    fetched. Each hypothesis names the KIND of data it needs as search keywords (not a real
    field id, since none has been chosen yet) — pass those into fields_for_hypothesis() to
    get an actual datafield shortlist for it. Never repeats the same hypothesis (by
    fingerprint) more than MAX_HYPOTHESIS_REPEATS times for this category/region."""
    chain = L.default_chain(keymgr.get_preferred())
    if not chain:
        raise RuntimeError("No LLM providers set up. Add an API key in Settings.")
    history = _hypothesis_history(category, region)
    exhausted = [r.idea for r in history.values() if r.times_suggested >= MAX_HYPOTHESIS_REPEATS]
    goal_line = f"User goal: {goal}\n" if goal else ""
    avoid_block = ""
    if exhausted:
        avoid_block = ("\nDo NOT suggest any of these ideas again (already proposed "
                       f"{MAX_HYPOTHESIS_REPEATS} times before) — propose genuinely different "
                       "mechanisms instead:\n- " + "\n- ".join(exhausted[:25]) + "\n")
    meta = (
        "You are a senior quantitative researcher proposing STOCK PRICE PREDICTION hypotheses "
        f"for the WorldQuant BRAIN platform, region {region}, delay {delay}, {instrument}. "
        f"Category focus: {category or 'unspecified — propose across sensible categories'}.\n"
        + goal_line + avoid_block +
        f"Propose {n} DISTINCT, testable hypotheses for predicting stock returns, each exploiting a "
        "DIFFERENT economic mechanism (momentum/reversal, liquidity, sentiment, fundamentals, analyst "
        "behaviour, ownership/flow, seasonality, cross-sectional relative value, etc). Do NOT reference "
        "any specific datafield id — you have not seen the field catalogue yet; describe the KIND of "
        "data each idea needs instead.\n"
        f"Return ONLY a JSON array of exactly {n} strings, each in this exact delimited form:\n"
        f"  idea {DELIM} mechanism (why it should predict returns) {DELIM} expected sign {DELIM} "
        f"horizon in days {DELIM} 3-6 short search keywords for the KIND of datafield needed, comma-separated\n"
    )
    res = L.MultiLLM(chain).generate_list(meta, n=n)
    out = []
    for s in res.expressions:
        parts = [p.strip() for p in str(s).split(DELIM)]
        if len(parts) < 2:
            continue
        idea, mechanism = parts[0], parts[1]
        sign = parts[2] if len(parts) > 2 else ""
        horizon = parts[3] if len(parts) > 3 else ""
        kw_raw = parts[4] if len(parts) > 4 else ""
        keywords = [k.strip() for k in kw_raw.split(",") if k.strip()]
        out.append({"idea": idea, "mechanism": mechanism, "sign": sign, "horizon": horizon,
                    "field_keywords": keywords})
    # Hard cap, belt-and-braces beyond the prompt hint: drop anything that (by fingerprint)
    # already hit the repeat limit even if the LLM ignored the "do not suggest again" list.
    filtered = []
    for h in out:
        fp = _idea_fingerprint(h["idea"])
        prior = history.get(fp)
        if prior and prior.times_suggested >= MAX_HYPOTHESIS_REPEATS:
            continue
        filtered.append(h)
    _credit_hypotheses(category, region, [h["idea"] for h in filtered])
    return {"hypotheses": filtered, "provider": res.provider, "model": res.model}


def fields_for_hypothesis(*, region, delay, instrument, universe, keywords, live=True, limit=25) -> dict:
    """STEP 2: given a hypothesis's search keywords, find matching datafields — LIVE against
    BRAIN first (so this works even the first time you touch a region), falling back to the
    local knowledge DB (fields cached from earlier fetches) if the live search comes back
    empty or the session isn't available."""
    kws = [k.strip() for k in (keywords or []) if k.strip()]
    if not kws:
        return {"fields": [], "matched_keywords": [], "source": "none"}

    if live:
        try:
            from app.brain import engine
            from app.knowledge import service as knowledge
            seen, merged = set(), []
            for kw in kws[:4]:  # a handful of live searches, not one per keyword forever
                df, _raw = engine.fetch_fields([], region=region, universe=universe, delay=delay,
                                               instrument_type=instrument, data_type="ALL", search=kw)
                if df is None or getattr(df, "empty", True):
                    continue
                for _, row in df.iterrows():
                    fid = row.get("id")
                    if not fid or fid in seen:
                        continue
                    seen.add(fid)
                    merged.append({"id": fid, "dataset_id": row.get("dataset_id", ""),
                                  "type": row.get("type", "MATRIX"),
                                  "description": row.get("description", "")})
            if merged:
                try:
                    ds_ids = sorted({m["dataset_id"] for m in merged if m.get("dataset_id")})
                    knowledge.ingest_fields(region, delay, ds_ids, merged)
                except Exception:
                    pass
                return {"fields": merged[:limit], "matched_keywords": kws, "source": "live"}
        except Exception:
            pass  # fall through to local search below

    from app.db.base import SessionLocal
    from app.db import models as M
    from sqlalchemy import select
    kws_l = [k.lower() for k in kws]
    with SessionLocal() as db:
        rows = db.scalars(select(M.Field).where(M.Field.region == region, M.Field.delay == delay)).all()
    scored = []
    for r in rows:
        hay = f"{r.field_id} {r.description}".lower()
        hits = sum(1 for k in kws_l if k in hay)
        if hits:
            scored.append((hits, r))
    scored.sort(key=lambda x: -x[0])
    fields = [{"id": r.field_id, "dataset_id": r.dataset_id, "type": r.type,
              "description": r.description} for _, r in scored[:limit]]
    return {"fields": fields, "matched_keywords": kws, "source": "local-cache"}


def suggest_goal(*, region, delay, instrument, dataset_names, fields, categories, paper_text) -> str:
    """Auto-generate a concise research goal from the DATA (datasets/fields/categories) or, if a
    paper was uploaded, from the PAPER. One or two sentences the user can edit."""
    chain = L.default_chain(keymgr.get_preferred())
    if not chain:
        raise RuntimeError("No LLM providers set up. Add an API key in Settings.")
    cats = sorted({str(v) for v in (categories or {}).values() if v})
    fld = ", ".join(f.get("id", "") for f in (fields or [])[:40])
    if (paper_text or "").strip():
        src = ("A research paper was provided. Base the goal on the paper's core, tradeable idea.\n"
               "=== PAPER (excerpt) ===\n" + paper_text.strip()[:8000] + "\n")
    else:
        src = ("Base the goal on the selected data below.\n"
               f"Datasets: {', '.join(dataset_names) or 'unspecified'}. Categories: {', '.join(cats) or 'unspecified'}.\n"
               f"Datafields: {fld or 'unspecified'}.\n")
    meta = (
        "You set the research goal for a WorldQuant BRAIN alpha-research session in "
        f"{region} ({instrument}, delay {delay}). " + src +
        "Write ONE clear, specific, mechanism-oriented research goal (1-2 sentences) that would guide generating "
        "diverse alphas from this data across ALL the datasets/categories provided. No preamble.\n"
        "Return ONLY a JSON array containing EXACTLY ONE string: the goal."
    )
    from app.core import llm_cache
    res = llm_cache.cached_generate_list(chain, meta, n=1)
    return (res.expressions[0].strip() if getattr(res, "expressions", None) else "")


def run_research(*, category, region, delay, instrument, dataset_names, fields, categories, goal,
                 paper_text, paper_is_community, mode, max_operators, n, progress,
                 economic_review=True) -> dict:
    chain = L.default_chain(keymgr.get_preferred())
    if not chain:
        raise RuntimeError("No LLM providers set up. Add an API key in Settings "
                           "(Claude, Gemini, OpenAI, DeepSeek, Groq, or Hugging Face).")
    progress(message=f"researching with {', '.join(p.name for p in chain)}…")
    meta = _prompt(category, region, delay, instrument, dataset_names, fields, categories, goal,
                   paper_text, paper_is_community, mode, max_operators, n)
    res = L.MultiLLM(chain).generate_list(meta, n=n)
    hypotheses, _ = _parse(res.expressions)

    # Validate every candidate against the EXACT fields provided (types + vector wrapping) so a
    # hypothesis can never carry an invented field or an unwrapped VECTOR into generation/simulation.
    from app.generation import service as gen
    multi = mode != "single"
    val = gen._validator(fields, max_operators=max_operators, multi_field=multi)
    field_ids = {f["id"] for f in fields}
    two_cat = mode == "multi_two_categories" and bool(categories)
    multi_ds = mode == "multi_single_dataset"

    expressions = []
    for h in hypotheses:
        e = (h.get("expression") or "").strip()
        if not e:
            h["expression_valid"] = False
            continue
        r = val.validate(e)
        ok = r.ok
        issues = [i.code for i in r.issues]
        if ok and two_cat:
            # STRICT: must combine EXACTLY two different categories — reject one, reject three+.
            used = {categories.get(fid) for fid in gen._fields_in(e, field_ids) if categories.get(fid)}
            if len(used) != 2:
                ok = False
                issues.append("NEEDS_TWO_CATEGORIES" if len(used) < 2 else "TOO_MANY_CATEGORIES")
        if ok and multi_ds:
            # STRICT: must combine two or more distinct datafields (all from the one dataset).
            if len(set(gen._fields_in(e, field_ids))) < 2:
                ok = False
                issues.append("NEEDS_MULTIPLE_FIELDS")
        h["expression_valid"] = ok
        if not ok:
            h["expression_issues"] = issues
        else:
            expressions.append(e)

    # Economic-sense gate (same critic as Generation): drop candidate expressions that don't make
    # economic sense for what their fields MEASURE, and mark the hypothesis with the reason.
    if economic_review and expressions:
        kept, dropped = gen._economic_review(expressions, fields, region, delay, instrument, chain, progress=progress)
        if dropped:
            reasons = {e: reason for e, reason in dropped}
            expressions = kept
            for h in hypotheses:
                he = (h.get("expression") or "").strip()
                if he in reasons:
                    h["expression_valid"] = False
                    h["expression_issues"] = (h.get("expression_issues") or []) + [f"no economic sense: {reasons[he]}"[:140]]

    progress(message=f"{len(expressions)} valid of {len(hypotheses)} hypotheses via {res.provider}")
    return {"hypotheses": hypotheses, "expressions": expressions,
            "provider": res.provider, "model": res.model}


# ── persistence ──────────────────────────────────────────────────────────────────────

def save_session(payload: dict) -> int:
    from app.db.base import SessionLocal
    from app.db import models as M
    with SessionLocal() as db:
        row = M.ResearchSession(
            category=payload.get("category", ""), region=payload.get("region", ""),
            delay=int(payload.get("delay", 1)), goal=payload.get("goal", ""),
            datasets_json=json.dumps(payload.get("dataset_names", [])),
            fields_json=json.dumps([f.get("id") for f in payload.get("fields", [])]),
            provider=payload.get("provider", ""), model=payload.get("model", ""),
            paper_name=payload.get("paper_name", ""),
            hypotheses_json=json.dumps(payload.get("hypotheses", [])),
            expressions_json=json.dumps(payload.get("expressions", [])),
            templates_json=json.dumps(payload.get("templates", [])))
        db.add(row)
        db.commit()
        return row.id


def list_sessions(limit: int = 30) -> list:
    from app.db.base import SessionLocal
    from app.db import models as M
    from sqlalchemy import select
    with SessionLocal() as db:
        rows = db.scalars(select(M.ResearchSession).order_by(M.ResearchSession.created_at.desc()).limit(limit)).all()
        out = []
        for r in rows:
            out.append({"id": r.id, "created_at": r.created_at, "category": r.category,
                        "region": r.region, "delay": r.delay, "goal": r.goal,
                        "provider": r.provider, "paper_name": r.paper_name,
                        "hypotheses": json.loads(r.hypotheses_json or "[]"),
                        "expressions": json.loads(r.expressions_json or "[]")})
        return out


import re as _re


def _normalize(text: str) -> str:
    return _re.sub(r"\s+", " ", (text or "").strip().lower())


def _fallback_name(category: str, region: str, source: str) -> str:
    base = (category or "Research").replace(",", " /").strip().title()
    tag = "Strategy" if source == "strategy" else "Research"
    return f"{base} {tag} · {region}"


def _fallback_compose(raw: str, category: str, region: str, dataset_names, source: str) -> dict:
    ds = ", ".join(dataset_names or []) or "the selected datasets"
    body = (
        "## Role\n"
        "You are a senior quantitative researcher and WorldQuant BRAIN alpha engineer, working with a "
        "risk-aware portfolio manager's mindset.\n\n"
        "## Context\n"
        f"Region {region}. Category: {category or 'mixed'}. Datasets: {ds}.\n\n"
        "## Objective\n"
        "Generate high-quality, diverse alpha expressions that TEST the researched ideas below and add "
        "genuine, low-correlation value.\n\n"
        "## Instructions\n" + (raw or "").strip() + "\n\n"
        "## Constraints\n"
        "Use ONLY the provided datafields; wrap VECTOR fields in a vec_* operator before use; pass named "
        "parameters as keywords; every expression must express a DIFFERENT mechanism; treat any example "
        "expression as an illustration, not a field restriction."
    )
    return {"name": _fallback_name(category, region, source), "body": body}


def nice_name(raw, category, region, source="research") -> str:
    """Just a concise, descriptive name for a saved prompt (no body rewrite). LLM name-only with a
    deterministic fallback."""
    chain = L.default_chain(keymgr.get_preferred())
    if not chain:
        return _fallback_name(category, region, source)
    meta = ("Return ONLY a JSON array containing exactly ONE string: a concise, descriptive 4-8 word name "
            "(human readable, NOT just the category) for a prompt that generates WorldQuant BRAIN alpha "
            "expressions from the notes below.\n"
            f"Region {region}. Category: {category or 'mixed'}.\n=== NOTES ===\n{(raw or '')[:1500]}\n")
    try:
        from app.core import llm_cache
        res = llm_cache.cached_generate_list(chain, meta, n=1)
        items = [str(x).strip().strip('"') for x in res.expressions if str(x).strip()]
        return items[0][:80] if items else _fallback_name(category, region, source)
    except Exception:
        return _fallback_name(category, region, source)


def compose_prompt(*, raw, category, region, dataset_names, source="research") -> dict:
    """Wrap raw research/strategy notes in a STRUCTURED prompt (Role → Context → Objective →
    Instructions → Constraints) with a concise, descriptive name. The LLM only writes the framing
    sections and the name; the ORIGINAL notes are embedded VERBATIM as the Instructions section,
    so every hypothesis/strategy survives intact. Falls back fully if no LLM is available."""
    raw = (raw or "").strip()
    ds_line = ", ".join(dataset_names or []) or "the selected datasets"
    instructions = (
        "## Instructions\n"
        "Generate diverse alpha expressions that TEST each of the ideas below. Treat every idea on its own; "
        "spread across the ideas and the available datafields. Any example expression is an ILLUSTRATION of the "
        "mechanism, NOT a field restriction.\n\n" + raw
    )
    chain = L.default_chain(keymgr.get_preferred())
    if not chain:
        return _fallback_compose(raw, category, region, dataset_names, source)
    meta = (
        "You are packaging research notes into a high-quality prompt for generating WorldQuant BRAIN alphas. Do "
        "NOT rewrite or summarise the notes themselves — only write the framing.\n"
        "Return ONLY a JSON array of strings:\n"
        "- FIRST string: 'NAME||| <a concise, descriptive 4-8 word name, human readable, NOT just the category>'.\n"
        "- Then ONE string per section, each starting with a '## ' header, in this order: '## Role' (assign one or "
        "MORE expert roles), '## Context' (region, category, datasets), '## Objective', '## Constraints' (use only "
        "provided datafields, wrap VECTOR fields in a vec_* op, pass named params as keywords, every expression a "
        "DIFFERENT mechanism, examples are illustrative). Do NOT include an Instructions section — it is added "
        "separately.\n"
        f"Region: {region}. Category: {category or 'mixed'}. Datasets: {ds_line}.\n"
        f"For reference only (do not copy): the notes have {raw.count(chr(10)) + 1} lines of ideas.\n")
    try:
        res = L.MultiLLM(chain).generate_list(meta, n=6)
        items = [str(x).strip() for x in res.expressions if str(x).strip()]
        name, role, context, objective, constraints = "", "", "", "", ""
        for it in items:
            up = it.upper()
            if up.startswith("NAME|||") or up.startswith("NAME:") or up.startswith("NAME "):
                name = _re.split(r"\|\|\||:", it, maxsplit=1)[-1].strip().strip('"')[:80]
            elif up.startswith("## ROLE"):
                role = it
            elif up.startswith("## CONTEXT"):
                context = it
            elif up.startswith("## OBJECTIVE"):
                objective = it
            elif up.startswith("## CONSTRAINT"):
                constraints = it
        if not (role or context or objective):
            return _fallback_compose(raw, category, region, dataset_names, source)
        role = role or "## Role\nYou are a senior quantitative researcher and WorldQuant BRAIN alpha engineer."
        context = context or f"## Context\nRegion {region}. Category: {category or 'mixed'}. Datasets: {ds_line}."
        objective = objective or "## Objective\nGenerate high-quality, diverse alphas that add low-correlation value."
        constraints = constraints or (
            "## Constraints\nUse ONLY the provided datafields; wrap VECTOR fields in a vec_* operator; pass named "
            "parameters as keywords; every expression must express a DIFFERENT mechanism.")
        body = "\n\n".join([role, context, objective, instructions, constraints])
        if not name:
            name = _fallback_name(category, region, source)
        return {"name": name, "body": body, "provider": res.provider}
    except Exception:
        return _fallback_compose(raw, category, region, dataset_names, source)


def save_prompt(*, name, scope, category, region, body, dataset_names, research_id=0) -> dict:
    """Save a prompt, avoiding duplicates: if an existing prompt in the same scope has the same
    (normalised) body, return it instead of creating another."""
    from app.db.base import SessionLocal
    from app.db import models as M
    from sqlalchemy import select
    norm = _normalize(body)
    with SessionLocal() as db:
        for e in db.scalars(select(M.Prompt).where(M.Prompt.scope == scope)).all():
            if _normalize(e.body) == norm:
                return {"id": e.id, "name": e.name, "duplicate": True}
        row = M.Prompt(name=name, scope=scope, category=category, region=region, body=body,
                       datasets_json=json.dumps(dataset_names or []), source_research_id=research_id)
        db.add(row)
        db.commit()
        return {"id": row.id, "name": row.name, "duplicate": False}


def export_all() -> dict:
    """Everything portable: saved prompts (generate + template scope) and research sessions."""
    from app.db.base import SessionLocal
    from app.db import models as M
    from sqlalchemy import select
    with SessionLocal() as db:
        prompts = [{"name": p.name, "scope": p.scope, "category": p.category, "region": p.region,
                    "body": p.body, "datasets": json.loads(p.datasets_json or "[]")}
                   for p in db.scalars(select(M.Prompt)).all()]
        sessions = [{"category": s.category, "region": s.region, "delay": s.delay, "goal": s.goal,
                     "dataset_names": json.loads(s.datasets_json or "[]"), "provider": s.provider,
                     "paper_name": s.paper_name, "hypotheses": json.loads(s.hypotheses_json or "[]"),
                     "expressions": json.loads(s.expressions_json or "[]")}
                    for s in db.scalars(select(M.ResearchSession)).all()]
    return {"format": "ace-studio/v2", "exported_at": time.time(), "prompts": prompts, "research_sessions": sessions}


def import_all(payload: dict) -> dict:
    """Merge an exported bundle back in, de-duplicating prompts by body."""
    added_p = 0
    for p in payload.get("prompts", []):
        r = save_prompt(name=p.get("name", ""), scope=p.get("scope", "generate"),
                        category=p.get("category", ""), region=p.get("region", ""),
                        body=p.get("body", ""), dataset_names=p.get("datasets", []))
        if not r.get("duplicate"):
            added_p += 1
    added_s = 0
    for s in payload.get("research_sessions", []):
        try:
            save_session(s); added_s += 1
        except Exception:
            pass
    return {"prompts_added": added_p, "sessions_added": added_s}


def extract_pdf_text(data: bytes, pages: str = "") -> str:
    """Extract text from a PDF. `pages` is a 1-based spec like '1-3,5' (empty = whole doc)."""
    import io
    from pypdf import PdfReader
    reader = PdfReader(io.BytesIO(data))
    total = len(reader.pages)
    want = _page_set(pages, total)
    chunks = []
    for i in range(total):
        if want is None or (i + 1) in want:
            try:
                chunks.append(reader.pages[i].extract_text() or "")
            except Exception:
                pass
    return "\n".join(chunks).strip()


def _page_set(spec: str, total: int):
    spec = (spec or "").strip()
    if not spec:
        return None
    out = set()
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            a, _, b = part.partition("-")
            try:
                out.update(range(int(a), int(b) + 1))
            except ValueError:
                pass
        elif part.isdigit():
            out.add(int(part))
    return {p for p in out if 1 <= p <= total} or None
