"""Evolution, part 2: generations run as a task (operators are in labs/ga.py).

An evolution task is an ordinary row of `harness_task` (lab "evolution", sampler "ga"), so listing, pause / resume / stop / remove,
progress, best trials and the Pareto front all work exactly as for a search task. What differs is how points are produced:

  generation 0   the seed alphas (plus mutants of them if there are fewer than a population's worth)
  generation g   `offspring` new alphas bred from the current survivors, only after generation g-1 has fully finished

Survivors are the best `population` finished alphas ever seen (parents and children compete together), ranked like every task:
feasible before infeasible, then by non-dominated front, then crowding. Parents are chosen by binary tournament on that ranking.

State lives entirely in the database (config in harness_task.template, one harness_trial per alpha with its generation, how it
was made and its parents), and the random generator is re-seeded per generation, so a restart continues where it left off and
produces the same offspring it would have. Nothing here submits anything: points go through the tracker like every other lab.
"""
from __future__ import annotations

import json
import random
import time
from typing import TYPE_CHECKING, Any

from app.harness.labs import exprtree as X
from app.harness.labs import ga
from app.harness.optimize import objectives as OB
from app.harness.payload import Scope, make_payload

if TYPE_CHECKING:
    from app.harness.tasks import TaskRunner

LAB = "evolution"
SAMPLER = "ga"
MAX_POPULATION, MAX_OFFSPRING = 200, 100


class _NoOptimizer:
    """Evolution has no Optuna-style optimizer: the trial bookkeeping in TaskRunner just needs something to `tell`."""
    def tell(self, *a: Any, **k: Any) -> None:
        return None


def _limits(cfg: dict[str, Any]) -> ga.Limits:
    c = cfg.get("constraints") or {}
    allowed = cfg.get("allowed_operators")
    kw = {"allowed_operators": frozenset(allowed)} if allowed else {}
    if c.get("power_pool"):
        return ga.Limits.power_pool(**kw)
    return ga.Limits(max_operators=c.get("max_operators"), max_fields=c.get("max_fields"), **kw)


def usable_seeds(seeds: list[str], limits: ga.Limits) -> tuple[list[str], list[str]]:
    """(seeds that parse, are distinct and stay inside the limits, one plain-language note per seed that was skipped)."""
    kept, notes, seen = [], [], set()
    for s in seeds:
        try:
            c = X.canon(s)
        except X.ExprError as e:
            notes.append(f"Skipped a seed that does not parse ({e}).")
            continue
        if c in seen:
            continue
        why = ga.check(s, limits)
        if why:
            notes.append(f"Skipped seed “{s[:60]}”: {why[0]}.")
            continue
        seen.add(c)
        kept.append(s)
    return kept, notes


def config(*, fields: list[str] | None = None, power_pool: bool = False, max_operators: int | None = None, max_fields: int | None = None,
           allowed_operators: list[str] | None = None, crossover_rate: float = 0.4) -> dict[str, Any]:
    """The parts of an evolution config that decide what offspring are allowed (also used by the free preview)."""
    return {"fields": list(fields or []), "crossover_rate": float(crossover_rate),
            "constraints": {"power_pool": bool(power_pool), "max_operators": max_operators, "max_fields": max_fields},
            "allowed_operators": sorted(allowed_operators) if allowed_operators else None}


def breed_preview(cfg: dict[str, Any], seeds: list[str], n: int, seed: int = 1) -> list[dict[str, Any]]:
    """Free: what a first round of offspring from these seeds could look like (nothing is queued or simulated)."""
    rng = random.Random(f"preview:{seed}")
    ctx = ga.Context(fields=list(cfg.get("fields") or []), limits=_limits(cfg))
    seen = {X.canon(s) for s in seeds}
    out: list[dict[str, Any]] = []
    for _ in range(n):
        a, b = rng.randrange(len(seeds)), rng.randrange(len(seeds))
        pool = [seeds[a]] if a == b else [seeds[a], seeds[b]]
        o = ga.make_offspring(pool, rng, ctx, seen, crossover_rate=float(cfg.get("crossover_rate", 0.4)))
        if o is None:
            break
        seen.add(X.canon(o.expression))
        out.append({"expression": o.expression, "how": o.how})
    return out


def create(runner: "TaskRunner", *, name: str, seeds: list[str], scope: Scope, objectives: list[str], budget: int, population: int = 20,
           offspring: int = 10, fields: list[str] | None = None, settings: dict[str, Any] | None = None, power_pool: bool = False,
           max_operators: int | None = None, max_fields: int | None = None, allowed_operators: list[str] | None = None,
           crossover_rate: float = 0.4, seed: int | None = None) -> dict[str, Any]:
    from app.harness.tasks import TaskError
    try:
        objs = OB.resolve(objectives)
    except OB.ObjectiveError as e:
        raise TaskError(str(e)) from e
    population, offspring = int(population), int(offspring)
    if not 2 <= population <= MAX_POPULATION:
        raise TaskError(f"The population must be between 2 and {MAX_POPULATION}.")
    if not 1 <= offspring <= MAX_OFFSPRING:
        raise TaskError(f"Offspring per generation must be between 1 and {MAX_OFFSPRING}.")
    if not 0.0 <= float(crossover_rate) <= 1.0:
        raise TaskError("The crossover rate must be between 0 and 1.")
    cfg: dict[str, Any] = {
        **config(fields=fields, power_pool=power_pool, max_operators=max_operators, max_fields=max_fields,
                 allowed_operators=allowed_operators, crossover_rate=crossover_rate),
        "kind": "evolution", "name": name, "population": population, "offspring": offspring, "settings": dict(settings or {}),
        "seed": seed if seed is not None else random.randrange(1, 2 ** 31)}
    kept, notes = usable_seeds(seeds, _limits(cfg))
    if not kept:
        raise TaskError("None of the starting alphas can be used. " + (notes[0] if notes else "Give at least one valid expression."))
    cfg["seeds"] = kept
    budget = max(1, min(int(budget), 5000))
    now = runner.clock()
    scope_json = {"region": scope.region, "delay": scope.delay, "universe": scope.universe, "instrument_type": scope.instrument_type}
    with runner.store.connect() as c:
        tid = c.execute(
            "INSERT INTO harness_task (lab, name, status, sampler, directions, objectives, space, template, scope, budget, batch, cores,"
            " seed, backend, params, notes, created, updated) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (LAB, name or "evolution", "running", SAMPLER, json.dumps([o.direction for o in objs]), json.dumps(objectives), "{}",
             json.dumps(cfg), json.dumps(scope_json), budget, offspring, 1, cfg["seed"], "builtin", "{}", json.dumps(notes), now, now)).lastrowid
    return {"id": tid, "budget": budget, "notes": notes, "seeds": len(kept)}


def _rows(runner: "TaskRunner", task_id: int) -> list[dict[str, Any]]:
    return [dict(r) for r in runner.store.query("SELECT * FROM harness_trial WHERE task_id=? ORDER BY number", (task_id,))]


def advance(runner: "TaskRunner", t: dict[str, Any]) -> int:
    """One scheduling pass for an evolution task. Returns how many alphas were queued."""
    from app.harness.tasks import _trial_views, rank
    cfg = json.loads(t["template"])
    objs = OB.resolve(json.loads(t["objectives"]))
    directions = [o.direction for o in objs]
    runner._harvest(t, _NoOptimizer(), {}, objs)
    counts = runner.counts(t["id"])
    if counts.get("queued", 0):
        return 0                                                             # generations are synchronous: wait for this one to finish
    rows = _rows(runner, t["id"])
    simulated = sum(v for k, v in counts.items() if k != "pruned")
    remaining = t["budget"] - simulated
    if remaining <= 0:
        _finish_task(runner, t)
        return 0
    params = [json.loads(r["params"]) for r in rows]
    gen = max((p.get("gen", 0) for p in params), default=-1) + 1
    seen = {X.canon(p["expr"]) for p in params if p.get("expr")}
    rng = random.Random(f"{cfg['seed']}:{t['id']}:{gen}")
    ctx = ga.Context(fields=list(cfg.get("fields") or []), limits=_limits(cfg))
    batch: list[dict[str, Any]] = []                                         # [{expr, how, parents}]

    if gen == 0:
        want = min(remaining, max(len(cfg["seeds"]), min(cfg["population"], remaining)))
        batch = [{"expr": s, "how": "seed", "parents": []} for s in cfg["seeds"][:want]]
        seen |= {X.canon(b["expr"]) for b in batch}
        while len(batch) < min(cfg["population"], remaining):
            o = ga.make_offspring(cfg["seeds"], rng, ctx, seen, crossover_rate=cfg["crossover_rate"])
            if o is None:
                break
            seen.add(X.canon(o.expression))
            batch.append({"expr": o.expression, "how": o.how, "parents": []})
    else:
        done = [v for v in _trial_views(rows) if v["status"] == "complete" and v["values"] is not None]
        if not done:
            runner._fail(t["id"], "None of the alphas produced a result, so there is nothing to breed from. Check that the seeds simulate.")
            return 0
        survivors = rank(done, directions)[:cfg["population"]]
        by_number = {r["number"]: json.loads(r["params"]).get("expr") for r in rows}

        def tournament() -> dict[str, Any]:
            a, b = rng.randrange(len(survivors)), rng.randrange(len(survivors))
            return survivors[min(a, b)]                                       # survivors are best-first, so the lower index wins

        for _ in range(min(cfg["offspring"], remaining)):
            pa, pb = tournament(), tournament()
            exprs = [by_number[pa["number"]]] + ([] if pb["number"] == pa["number"] else [by_number[pb["number"]]])
            o = ga.make_offspring(exprs, rng, ctx, seen, crossover_rate=cfg["crossover_rate"])
            if o is None:
                break
            seen.add(X.canon(o.expression))
            batch.append({"expr": o.expression, "how": o.how, "parents": [pa["number"], pb["number"]] if len(o.parents) == 2 else [pa["number"]]})
        if not batch:
            runner._note(t, "The population has run out of new variations to try, so the task stopped early.")
            _finish_task(runner, t)
            return 0

    scope = Scope(**json.loads(t["scope"]))
    name, now, number = f"{t['lab']}-{t['id']}", time.time(), sum(counts.values())
    for b in batch:
        number += 1
        payload = make_payload(b["expr"], scope, **cfg["settings"])
        rec = runner.tracker.enqueue(name, payload)["record_id"]
        runner.store.execute(
            "INSERT INTO harness_trial (task_id, number, params, record_id, status, created, updated) VALUES (?,?,?,?,?,?,?)",
            (t["id"], number, json.dumps({"expr": b["expr"], "gen": gen, "how": b["how"], "parents": b["parents"]}), rec, "queued", now, now))
    return len(batch)


def _finish_task(runner: "TaskRunner", t: dict[str, Any]) -> None:
    runner.store.execute("UPDATE harness_task SET status='done', updated=? WHERE id=?", (runner.clock(), t["id"]))


def generation_summary(views: list[dict[str, Any]], directions: list[str]) -> list[dict[str, Any]]:
    """Per generation: how many alphas, how many finished, and the best value of the first objective (the 'is it improving?' view)."""
    gens: dict[int, dict[str, Any]] = {}
    for v in views:
        g = gens.setdefault(int(v["params"].get("gen", 0)), {"generation": int(v["params"].get("gen", 0)), "alphas": 0, "finished": 0, "best": None})
        g["alphas"] += 1
        if v["status"] == "complete" and v["values"]:
            g["finished"] += 1
            x = v["values"][0]
            if g["best"] is None or (x > g["best"] if directions[0] == "maximize" else x < g["best"]):
                g["best"] = x
    return [gens[k] for k in sorted(gens)]
