"""From a scope to a day's worth of simulations (ported from alpha_harness.harvest.seeds).

Sync and pure: Alpha Sentry data access is injected (`best_fields`, `dataset_count`, `lookup`), so the
generation rules are unit-testable. Everything generated shares one region, delay, instrument type
and language, so a harvest fills whole batches instead of fragmenting into singletons.
"""
from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as dc_field
from typing import Any, Callable

from app.harness.payload import make_settings
from app.harness.harvest.patterns import GROUPS, PATTERNS, PATTERNS_BY_NAME, WINDOWS, Pattern

DEFAULT_MIN_ALPHAS = 3
DEFAULT_MIN_COVERAGE = 0.6
MAX_SIMULATIONS = 20_000


@dataclass
class Harvest:
    requests: list[dict] = dc_field(default_factory=list)
    fields: list[dict[str, Any]] = dc_field(default_factory=list)
    patterns: list[str] = dc_field(default_factory=list)
    windows: list[int] = dc_field(default_factory=list)
    settings: dict[str, Any] = dc_field(default_factory=dict)
    truncated: bool = False
    possible: int = 0
    worked_out: list[str] = dc_field(default_factory=list)

    @property
    def count(self) -> int:
        return len(self.requests)

    def summary(self, *, sample: int = 12) -> dict[str, Any]:
        batches = -(-self.count // 10)
        return {"simulations": self.count, "possible": self.possible, "truncated": self.truncated,
                "fields": len(self.fields), "patterns": self.patterns, "windows": self.windows,
                "settings": self.settings, "batches": batches, "fullBatches": self.count // 10,
                "efficiency": round(self.count / (batches * 10), 3) if batches else 0.0,
                "workedOut": self.worked_out,
                "sample": [{"expression": r["regular"], "settings": r["settings"]} for r in self.requests[:sample]],
                "fieldSample": self.fields[:sample]}


class SeedHarvester:
    """Turns a scope into simulations without the user writing anything.

    best_fields(per_dataset, min_alphas, max_alphas, min_coverage, limit, skip) -> [{field_id, dataset_id, ...}]
    dataset_count(min_alphas, max_alphas, min_coverage) -> int;  lookup(field_ids) -> [{field_id, ...}]
    """

    def __init__(self, *, best_fields: Callable[..., list[dict]], dataset_count: Callable[..., int],
                 lookup: Callable[[list[str]], list[dict]], saturated_shapes: set[str] | None = None,
                 skeleton_of: Callable[[str], str] | None = None) -> None:
        self._best, self._count, self._lookup = best_fields, dataset_count, lookup
        self.saturated, self.skeleton_of = saturated_shapes, skeleton_of

    def _drop_worked_out(self, chosen: list[Pattern], group: str) -> tuple[list[Pattern], list[str]]:
        """Leave out shapes this market has already answered; if EVERY shape is worked out the list
        is left alone (a filter narrows what a lab finds and must never be why it finds nothing)."""
        if not self.saturated or not self.skeleton_of or not chosen:
            return chosen, []
        keep = [p for p in chosen if self.skeleton_of(p.render("field", 252, group)) not in self.saturated]
        if not keep:
            return chosen, []
        return keep, [p.name for p in chosen if p not in keep]

    def harvest(self, scope: Any, *, target: int = 1000, patterns: list[str] | None = None,
                windows: list[int] | None = None, group: str = "industry", neutralization: str = "SUBINDUSTRY",
                decay: int = 0, truncation: float = 0.08, per_dataset: int = 1, min_alphas: int = DEFAULT_MIN_ALPHAS,
                max_alphas: int | None = None, min_coverage: float = DEFAULT_MIN_COVERAGE,
                fields: list[str] | None = None, skip: int = 0) -> Harvest:
        target = max(1, min(target, MAX_SIMULATIONS))
        chosen = [PATTERNS_BY_NAME[p] for p in (patterns or [])] or list(PATTERNS)
        chosen_windows = windows or list(WINDOWS)
        if group not in GROUPS:
            raise ValueError(f"{group!r} is not a grouping field. Use one of: {', '.join(GROUPS)}.")
        chosen, worked_out = self._drop_worked_out(chosen, group)
        per_field = len(chosen) * len(chosen_windows)

        if fields:
            # chosen for us: looked up so the preview shows real data, and fields absent from this scope
            # are dropped (simulating a missing field spends quota to learn nothing)
            fields_used = self._lookup(fields)
        else:
            needed = max(1, -(-target // max(1, per_field)))
            datasets = self._count(min_alphas, max_alphas, min_coverage)
            if datasets:   # one field per dataset caps the pool; reach deeper when the target demands it
                per_dataset = max(per_dataset, -(-needed // datasets))
            pick = dict(per_dataset=per_dataset, min_alphas=min_alphas, max_alphas=max_alphas,
                        min_coverage=min_coverage, limit=needed)
            fields_used = self._best(**pick, skip=skip * per_dataset)
            if not fields_used and skip:           # depth must never be the reason nothing is found
                fields_used = self._best(**pick, skip=0)
            if not fields_used and (max_alphas is not None or min_alphas > DEFAULT_MIN_ALPHAS):
                fields_used = self._best(per_dataset=per_dataset, min_alphas=DEFAULT_MIN_ALPHAS, max_alphas=None,
                                         min_coverage=min_coverage, limit=needed, skip=0)

        settings = make_settings(scope, neutralization=neutralization, decay=decay, truncation=truncation)
        result = Harvest(fields=fields_used, patterns=[p.name for p in chosen], windows=chosen_windows,
                         settings=settings, possible=len(fields_used) * per_field, worked_out=worked_out)
        # Field varies fastest so a truncated list is a broad sweep, not every window of the first few fields.
        for pattern in chosen:
            for window in chosen_windows:
                for row in fields_used:
                    if len(result.requests) >= target:
                        result.truncated = result.possible > target
                        return result
                    result.requests.append({"type": "REGULAR", "settings": dict(settings),
                                            "regular": pattern.render(str(row["field_id"]), window, group)})
        return result
