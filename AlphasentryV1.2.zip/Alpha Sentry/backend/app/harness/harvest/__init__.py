"""Seed harvesting: from a scope to a day's worth of plain, sensible simulations."""
