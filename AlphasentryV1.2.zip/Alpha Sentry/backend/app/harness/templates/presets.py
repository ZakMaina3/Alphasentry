"""Ready-made starter templates for the Tasks tab (served by GET /templates/presets).

Each preset is a complete template plus the sampler / objectives / budget that suit it. They are starting points: the data-field
variables use catalogue filters (category, alpha count) so they resolve against whatever data the user has downloaded; edit the
filters in the UI if a category does not exist for your market. tests/test_templates.py parses and realises every preset.
"""
from __future__ import annotations

from typing import Any

PRESETS: list[dict[str, Any]] = [
    {
        "id": "reversion",
        "label": "Reversion",
        "description": "Rank the negative z-score of a field: bet that stretched values snap back. Sweeps lookback and neutralization.",
        "sampler": "nsga2", "objectives": ["fitness", "turnover"], "budget": 60,
        "template": """name: reversion on a ranked field
description: Rank the negative z-score of a field; sweep the lookback and neutralization.
expr: rank(-ts_zscore($field, $lookback))
vars:
  field:    {type: datafield, category: fundamental, max_alpha_count: 50, limit: 10}
  lookback: {type: int, grid: [5, 10, 22, 63, 126, 252]}
settings:
  neutralization: [SUBINDUSTRY, INDUSTRY]
  decay: [0, 4, 8]
constraints:
  max_simulations: 200
""",
    },
    {
        "id": "momentum",
        "label": "Momentum",
        "description": "Rank the recent change of a field relative to its typical size: bet that trends continue.",
        "sampler": "nsga2", "objectives": ["fitness", "turnover"], "budget": 60,
        "template": """name: momentum on a ranked field
description: Rank the change over a window, scaled by the field's average size over the same window.
expr: rank(ts_delta($field, $window) / ts_mean(abs($field), $window))
vars:
  field:  {type: datafield, category: fundamental, max_alpha_count: 50, limit: 10}
  window: {type: int, low: 5, high: 126, step: 1}
settings:
  neutralization: [SUBINDUSTRY, INDUSTRY, MARKET]
  decay: [0, 4]
constraints:
  max_simulations: 200
""",
    },
    {
        "id": "grouped_rank",
        "label": "Grouped rank",
        "description": "Rank a z-scored field inside industry groups, so each stock is compared only with its peers.",
        "sampler": "tpe", "objectives": ["sharpe"], "budget": 60,
        "template": """name: z-score ranked within a group
description: Compare each stock with its group peers rather than the whole market.
expr: group_rank(ts_zscore($field, $lookback), $group)
vars:
  field:    {type: datafield, category: fundamental, max_alpha_count: 50, limit: 10}
  lookback: {type: int, grid: [22, 63, 126, 252]}
  group:    {type: choice, values: [subindustry, industry, sector]}
settings:
  neutralization: [SUBINDUSTRY, INDUSTRY]
  decay: 4
constraints:
  max_simulations: 200
""",
    },
    {
        "id": "power_pool", "lab": "power",
        "label": "Power Pool (3 fields)",
        "description": "Three ranked fields added together. Stays inside the Power Pool limits (at most 8 operators and 3 data fields); a point that would break them is dropped before it is queued.",
        "sampler": "nsga2", "objectives": ["sharpe", "turnover"], "budget": 80,
        "template": """name: power pool three-field blend
description: Sum of three ranked z-scores. Power Pool limits are enforced before anything is queued.
expr: rank(ts_zscore($f1, $window)) + rank(ts_zscore($f2, $window)) + rank(ts_zscore($f3, $window))
vars:
  f1:     {type: datafield, category: fundamental, max_alpha_count: 100, limit: 8}
  f2:     {type: datafield, category: fundamental, max_alpha_count: 100, limit: 8}
  f3:     {type: datafield, category: fundamental, max_alpha_count: 100, limit: 8}
  window: {type: int, grid: [22, 63, 126]}
settings:
  neutralization: [SUBINDUSTRY, INDUSTRY]
  decay: 4
constraints:
  power_pool: true
  max_simulations: 300
""",
    },
    {
        "id": "grid_sweep", "lab": "template",
        "label": "Grid sweep",
        "description": "Every combination of a short list of fields, windows, decays and neutralizations, tried exactly once (exhaustive sampler).",
        "sampler": "brute", "objectives": ["sharpe"], "budget": 48,
        "template": """name: exhaustive grid
description: Edit the field list, then every combination is simulated once. Preview shows the grid size first.
expr: ts_mean($field, $window)
vars:
  field:  {type: datafield, values: [close, volume]}
  window: {type: int, grid: [5, 22, 63, 252]}
settings:
  neutralization: [SUBINDUSTRY, MARKET]
  decay: [0, 4, 8]
constraints:
  max_simulations: 100
""",
    },
]


def catalogue() -> list[dict[str, Any]]:
    """Every preset, each with the lab it belongs to (default "search")."""
    return [{"lab": "search", **p} for p in PRESETS]
