"""Which sampler suits this search, and why (shown next to the sampler menu; advice only, the user decides)."""
from __future__ import annotations

from typing import Any


def recommend(*, grid_size: int | None, dims: int, objectives: int, budget: int, optuna: bool = False,
              all_continuous: bool = False) -> dict[str, Any]:
    """{sampler, why, alternatives:[{sampler, why}]}. Rules, in order: a grid that fits the budget is simply tried in full; a tiny
    budget cannot learn anything; several objectives want NSGA-II/III; one objective with a small budget wants TPE."""
    budget = max(1, int(budget))
    alts: list[dict[str, str]] = []

    def add(name: str, why: str) -> None:
        if name not in [a["sampler"] for a in alts]:
            alts.append({"sampler": name, "why": why})

    if dims == 0:
        return {"sampler": "random", "why": "Nothing varies in this template, so there is nothing to choose between.", "alternatives": []}
    add("random", "A fair baseline: uniform draws. Use it to see whether a smarter sampler is actually helping.")
    add("qmc", "Even coverage of the space, ignoring results. Good when the budget is too small to learn from.")
    if grid_size is not None and grid_size <= budget:
        add("tpe", "Would learn from results, but pointless when every combination fits the budget anyway.")
        return {"sampler": "brute", "why": f"The whole grid is {grid_size} combinations and your budget is {budget}: every one is tried exactly "
                                          "once, so nothing is missed and nothing is repeated.", "alternatives": alts}
    if budget < 20:
        add("tpe", "Starts learning after about ten results; with this budget it will mostly be exploring.")
        return {"sampler": "qmc", "why": f"With only {budget} simulations no sampler can learn much, so spreading them evenly over the "
                                         "space is the safest use.", "alternatives": alts}
    if objectives >= 3:
        name = "nsga3"
        add("tpe", "Handles several objectives but treats them less evenly than the evolutionary samplers.")
        return {"sampler": name, "why": f"{objectives} objectives: an evolutionary sampler keeps a spread of good trade-offs instead of "
                                       "collapsing onto one.",
                "alternatives": alts}
    if objectives == 2:
        add("tpe", "Also handles two objectives; tends to win on small budgets (under ~100).")
        return {"sampler": "nsga2", "why": "Two objectives: NSGA-II evolves a population toward the best trade-offs and fills whole batches.",
                "alternatives": alts}
    if all_continuous and budget >= 60:
        add("tpe", "More robust if the surface is noisy or has mixed (list + range) variables.")
        return {"sampler": "cmaes", "why": "One objective and only continuous ranges: CMA-ES homes in on a good region efficiently.",
                "alternatives": alts}
    add("nsga2", "Better when the budget is large (hundreds): keeps exploring more broadly than TPE.")
    return {"sampler": "tpe", "why": f"One objective and a modest budget ({budget}): TPE learns which values did well and tries more like them.",
            "alternatives": alts}
