"""Alpha templates: one idea with holes in it ($field, $lookback, ...), a search space, and settings to sweep."""
