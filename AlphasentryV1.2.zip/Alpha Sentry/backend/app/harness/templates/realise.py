"""From a template to a search space, and from a chosen point to a simulation request (ported from
alpha_harness.optimize.study.build_space / split_params and templates.expand's validation)."""
from __future__ import annotations

import re
from typing import Any, Callable

from app.harness.labs.exprtools import (POWER_POOL_MAX_FIELDS, POWER_POOL_MAX_OPERATORS, count_operators,
                                        unique_data_fields)
from app.harness.optimize import space as sp
from app.harness.payload import Scope, make_payload
from app.harness.templates.spec import (BATCH_SPLITTING_SETTINGS, SETTING_PREFIX, TemplateSpec, setting_options,
                                        substitute)

Prepared = Callable[[Any], list[str]]      # a datafield Var -> the field ids that qualify

_PAYLOAD_SETTINGS = ("neutralization", "decay", "truncation", "universe")


def build_space(spec: TemplateSpec, prepared: Prepared | None = None, *, search_batch_settings: bool = False) -> sp.Space:
    """Template variables and swept settings as a declarative search space. Single-valued variables are not
    searched (they are filled in by split_params)."""
    space: sp.Space = {}
    for name, v in spec.vars.items():
        if name in spec.unused_vars:
            continue
        if v.type == "datafield":
            values = list(v.values or []) or (prepared(v) if prepared else [])
            if len(values) > 1:
                space[name] = {"kind": "categorical", "choices": values}
        elif v.type == "choice":
            if len(v.values or []) > 1:
                space[name] = {"kind": "categorical", "choices": list(v.values)}
        elif v.grid is not None:
            if len(v.grid) > 1:
                space[name] = {"kind": "categorical", "choices": list(v.grid)}
        elif v.low is not None and v.high is not None and v.low < v.high:
            kind = "int" if v.type == "int" else "float"
            space[name] = {"kind": kind, "low": v.low, "high": v.high, "step": (int(v.step or 1) if kind == "int" else v.step), "log": v.log}
    for name, value in spec.settings.items():
        options = setting_options(value)
        if len(options) <= 1 or (name in BATCH_SPLITTING_SETTINGS and not search_batch_settings):
            continue
        space[f"{SETTING_PREFIX}{name}"] = {"kind": "categorical", "choices": options}
    return space


def split_params(spec: TemplateSpec, params: dict[str, Any], prepared: Prepared | None = None) -> tuple[dict[str, Any], dict[str, Any]]:
    """Separate expression variables from settings and fill in everything that was pinned rather than searched."""
    assignment: dict[str, Any] = {}
    chosen: dict[str, Any] = {}
    for key, value in params.items():
        if key.startswith(SETTING_PREFIX):
            chosen[key[len(SETTING_PREFIX):]] = value
        else:
            assignment[key] = value
    for name, v in spec.vars.items():
        if name in assignment:
            continue
        if v.type == "choice" or (v.type == "datafield" and v.values):
            assignment[name] = v.values[0]
        elif v.type == "datafield" and prepared is not None:
            resolved = prepared(v)
            if resolved:
                assignment[name] = resolved[0]
        elif v.type in ("int", "float") and v.grid:
            assignment[name] = v.grid[0]
        elif v.type in ("int", "float") and v.low is not None:
            assignment[name] = v.low
    for name, value in spec.settings.items():
        if name not in chosen:
            chosen[name] = setting_options(value)[0]
    return assignment, chosen


_OUTER = re.compile(r"^\$(?:\{(\w+)\}|(\w+))\((.*)\)$", re.S)


def _balanced(inner: str) -> bool:
    depth = 0
    for ch in inner:
        depth += (ch == "(") - (ch == ")")
        if depth < 0:
            return False
    return depth == 0


def render(expr: str, assignment: dict[str, Any]) -> str:
    """Fill in an expression template. One refinement: when the LAST statement is `$name( ... )` and `$name` is the empty string,
    the wrapper is simply absent (Deepen's "no wrapper" choice), rather than leaving a pair of redundant parentheses behind."""
    cut = expr.rfind("; ") + 2 if "; " in expr else 0
    head, tail = expr[:cut], expr[cut:]
    m = _OUTER.match(tail.strip())
    if m and assignment.get(m.group(1) or m.group(2)) == "" and _balanced(m.group(3)):
        tail = m.group(3)
    return substitute(head + tail, assignment)


def realise(spec: TemplateSpec, params: dict[str, Any], scope: Scope, prepared: Prepared | None = None) -> dict[str, Any]:
    """One chosen point -> a ready simulation payload under `scope`, with the template's settings applied."""
    assignment, chosen = split_params(spec, params, prepared)
    expression = render(spec.expr, assignment)
    sc = Scope(str(chosen.get("region", scope.region)), int(chosen.get("delay", scope.delay)), str(chosen.get("universe", scope.universe)),
               str(chosen.get("instrumentType", scope.instrument_type)))
    known = {k: chosen[k] for k in _PAYLOAD_SETTINGS if k in chosen}
    other = {k: v for k, v in chosen.items() if k not in _PAYLOAD_SETTINGS and k not in ("region", "delay", "instrumentType", "type")}
    return make_payload(expression, sc, **known, **other)


def problems(expression: str, spec: TemplateSpec) -> list[str]:
    """Why an expanded alpha cannot qualify (checked BEFORE queueing: such a simulation spends quota for nothing)."""
    c, out = spec.constraints, []
    ops, flds = count_operators(expression), len(unique_data_fields(expression))
    max_ops = POWER_POOL_MAX_OPERATORS if c.power_pool and c.max_operators is None else c.max_operators
    max_flds = POWER_POOL_MAX_FIELDS if c.power_pool and c.max_unique_fields is None else c.max_unique_fields
    if max_ops is not None and ops > max_ops:
        out.append(f"uses {ops} operators; the limit is {max_ops}")
    if max_flds is not None and flds > max_flds:
        out.append(f"uses {flds} distinct data fields; the limit is {max_flds}")
    return out


def summary(spec: TemplateSpec, prepared: Prepared | None = None) -> dict[str, Any]:
    """What a search over this template looks like — free, nothing is simulated."""
    space = build_space(spec, prepared)
    size = sp.grid_size(space)
    notes: list[str] = []
    if spec.batch_splitting_sweeps:
        notes.append("Sweeping " + ", ".join(spec.batch_splitting_sweeps) + " splits work into separate batches (they are left out "
                     "of the search space), which lowers throughput.")
    if spec.unused_vars:
        notes.append("Declared but never used: " + ", ".join("$" + n for n in sorted(spec.unused_vars)) + " — usually a typo.")
    if not space:
        notes.append("Nothing in this template varies, so there is only one alpha to try.")
    return {"name": spec.name, "dimensions": {n: (s["kind"], len(s["choices"]) if s["kind"] == "categorical" else [s["low"], s["high"]])
                                                for n, s in space.items()},
            "gridSize": size, "continuous": size is None, "notes": notes, "maxSimulations": spec.constraints.max_simulations}
