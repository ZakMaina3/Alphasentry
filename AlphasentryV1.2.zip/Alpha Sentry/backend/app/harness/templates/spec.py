"""The template language (ported from alpha_harness.templates.schema; plain dataclasses, no pydantic).

    name: reversion on a ranked field
    expr: rank(ts_zscore($field, $lookback))
    vars:
      field:    {type: datafield, category: fundamental, max_alpha_count: 50}
      lookback: {type: int, grid: [5, 22, 63, 252]}
    settings: {neutralization: [SUBINDUSTRY, INDUSTRY], decay: 4}
    constraints: {power_pool: true, max_simulations: 500}

One document, two readers: expansion enumerates combinations (a grid sweep); optimization samples from it. A scalar
setting is fixed; a list is swept. Region/delay/instrumentType/language are batch-splitting settings: sweeping them
fragments multi-simulations, so they are reported, and kept out of the search space unless explicitly allowed.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any

PLACEHOLDER = re.compile(r"\$\{(\w+)\}|\$(\w+)")
BATCH_SPLITTING_SETTINGS = frozenset({"region", "delay", "instrumentType", "language", "type"})
SETTING_PREFIX = "setting:"
VAR_TYPES = ("datafield", "int", "float", "choice")
ORDER_BY = ("coverage", "alpha_count", "user_count", "pyramid_multiplier", "field_id")


class TemplateError(ValueError):
    """A template that cannot be parsed. `problems` has one entry per fault with its path, for an editor to point at."""

    def __init__(self, message: str, problems: list[dict[str, Any]] | None = None) -> None:
        super().__init__(message)
        self.problems = problems or [{"where": None, "message": message}]


def placeholders(expression: str) -> set[str]:
    return {a or b for a, b in PLACEHOLDER.findall(expression)}


def substitute(expression: str, values: dict[str, Any]) -> str:
    return PLACEHOLDER.sub(lambda m: str(values.get(m.group(1) or m.group(2), m.group(0))), expression)


def setting_options(value: Any) -> list[Any]:
    """A settings entry as the list of values it stands for."""
    if isinstance(value, dict):
        grid = value.get("grid")
        return list(grid) if isinstance(grid, list) else [value]
    return list(value) if isinstance(value, list) else [value]


@dataclass
class Var:
    type: str
    description: str | None = None
    values: list[Any] | None = None          # datafield (explicit list) / choice
    grid: list[Any] | None = None            # int / float
    low: float | None = None
    high: float | None = None
    step: float | None = None
    log: bool = False
    # datafield catalogue filters
    dataset: str | None = None
    category: str | None = None
    field_type: str | None = None
    min_coverage: float | None = None
    max_alpha_count: int | None = None
    min_alpha_count: int | None = None
    search: str | None = None
    order_by: str = "coverage"
    order_desc: bool = True
    limit: int = 25


@dataclass
class Constraints:
    max_operators: int | None = None
    max_unique_fields: int | None = None
    power_pool: bool = False
    max_simulations: int = 500


@dataclass
class TemplateSpec:
    name: str
    expr: str
    vars: dict[str, Var] = field(default_factory=dict)
    settings: dict[str, Any] = field(default_factory=dict)
    constraints: Constraints = field(default_factory=Constraints)
    description: str | None = None

    @property
    def unused_vars(self) -> set[str]:
        return set(self.vars) - placeholders(self.expr)

    @property
    def swept_settings(self) -> dict[str, list[Any]]:
        return {n: o for n, v in self.settings.items() if len(o := setting_options(v)) > 1}

    @property
    def batch_splitting_sweeps(self) -> list[str]:
        return sorted(set(self.swept_settings) & BATCH_SPLITTING_SETTINGS)

    def to_dict(self) -> dict[str, Any]:
        v = {n: {k: x for k, x in vars_.__dict__.items() if x not in (None, False) or k in ("type",)} for n, vars_ in self.vars.items()}
        return {"name": self.name, "description": self.description, "expr": self.expr, "vars": v, "settings": self.settings,
                "constraints": dict(self.constraints.__dict__)}


_VAR_KEYS = set(Var.__dataclass_fields__)
_CON_KEYS = set(Constraints.__dataclass_fields__)


def parse(document: str | dict[str, Any]) -> TemplateSpec:
    """YAML/JSON text or an already-decoded mapping -> TemplateSpec. Errors are written for whoever is editing it."""
    if isinstance(document, str):
        data: Any = None
        try:
            data = json.loads(document)
        except ValueError:
            try:
                import yaml
            except ImportError as exc:
                raise TemplateError("YAML templates need PyYAML (pip install pyyaml); JSON templates work without it.") from exc
            try:
                data = yaml.safe_load(document)
            except yaml.YAMLError as exc:
                raise TemplateError(f"This is not valid YAML. {exc}") from exc
    else:
        data = document
    if data is None:
        raise TemplateError("This template is empty. It needs at least `name` and `expr`.")
    if not isinstance(data, dict):
        raise TemplateError("A template must be a mapping with at least `name` and `expr`.")

    problems: list[dict[str, Any]] = []

    def bad(where: str | None, message: str) -> None:
        problems.append({"where": where, "message": message})

    for key in ("name", "expr"):
        if not isinstance(data.get(key), str) or not data[key].strip():
            bad(key, "this is required but missing")
    for key in set(data) - {"name", "description", "expr", "vars", "settings", "constraints", "type"}:
        bad(key, "not a recognised key — check the spelling")

    vars_: dict[str, Var] = {}
    raw_vars = data.get("vars") or {}
    if not isinstance(raw_vars, dict):
        bad("vars", "must be a mapping of variable name to its definition")
        raw_vars = {}
    for name, raw in raw_vars.items():
        if not isinstance(raw, dict) or raw.get("type") not in VAR_TYPES:
            bad(f"vars.{name}.type", "`type` must be one of: " + ", ".join(VAR_TYPES))
            continue
        extra = set(raw) - _VAR_KEYS
        if extra:
            bad(f"vars.{name}", f"not a recognised key: {', '.join(sorted(extra))}")
            continue
        v = Var(**raw)
        t = v.type
        if t in ("int", "float") and v.grid is None and (v.low is None or v.high is None):
            bad(f"vars.{name}", f"a {t} variable needs either `grid` or both `low` and `high`")
        if t in ("int", "float") and v.low is not None and v.high is not None and v.low > v.high:
            bad(f"vars.{name}", "`low` must not exceed `high`")
        if t == "choice" and not v.values:
            bad(f"vars.{name}.values", "a choice needs at least one value")
        if v.order_by not in ORDER_BY:
            bad(f"vars.{name}.order_by", "must be one of: " + ", ".join(ORDER_BY))
        if t == "datafield" and not 1 <= int(v.limit) <= 1000:
            bad(f"vars.{name}.limit", "must be between 1 and 1000")
        vars_[name] = v

    cons_raw = data.get("constraints") or {}
    if not isinstance(cons_raw, dict) or set(cons_raw) - _CON_KEYS:
        bad("constraints", "not a recognised key — use: " + ", ".join(sorted(_CON_KEYS)))
        cons = Constraints()
    else:
        cons = Constraints(**cons_raw)
        if not 1 <= int(cons.max_simulations) <= 10_000:
            bad("constraints.max_simulations", "must be between 1 and 10,000")

    settings = data.get("settings") or {}
    if not isinstance(settings, dict):
        bad("settings", "must be a mapping of setting name to a value or a list of values")
        settings = {}
    empty = sorted(n for n, v in settings.items() if not setting_options(v))
    if empty:
        bad("settings", ", ".join(empty) + " has no values. Give it a value, a list to sweep, or remove it.")

    if isinstance(data.get("expr"), str):
        missing = placeholders(data["expr"]) - set(vars_) - set(raw_vars)
        if missing:
            bad("expr", "the expression uses " + ", ".join(f"${n}" for n in sorted(missing)) + " but no such variable is declared")

    if problems:
        summary = "; ".join(f"{p['where']}: {p['message']}" if p["where"] else str(p["message"]) for p in problems[:4])
        raise TemplateError(f"This template is not valid. {summary}", problems)
    return TemplateSpec(name=data["name"], expr=data["expr"], vars=vars_, settings=settings, constraints=cons,
                        description=data.get("description"))
