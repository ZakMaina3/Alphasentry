"""Autosentry speed settings, used only while `autopilot_via_engine` is on (fragment G1).

What the measurements of real Autosentry runs showed: a round of simulations took about as long as its SLOWEST batch (BRAIN took 20 s to 15 min
for a batch of ten, regardless of how full it was, once 94 min), only 3 batches ever ran side by side although BRAIN has 8 slots, and a stuck
batch held the whole round (the LLM, the next templates) hostage. So this module controls three things, none of which touch what Autosentry
decides to simulate:

  parallel     how many batches a round may run side by side (Alpha Sentry's own cap is 3). A round simulates batch_size x parallel alphas.
  ceiling      learned live: when BRAIN refuses a batch (HTTP 429) while we hold k, the ceiling drops to k-1 for a while, then is probed again.
  straggler_s  when some batches of a round are done and the rest have run longer than this, the round continues without them. They keep
               running on BRAIN (their slot stays held), and when they finish they are handed to the harness scorer so nothing is lost.

With the flag off, every function here returns Alpha Sentry's original behaviour.
"""
from __future__ import annotations

import json
import threading
import time
from pathlib import Path
from typing import Any

LEGACY_PARALLEL = 3
MAX_PARALLEL = 8
CEILING_TTL = 1200.0                 # seconds a learned ceiling stays in force before BRAIN is probed again
DEFAULTS: dict[str, Any] = {"parallel": 6, "straggler_s": 1500}
_lock = threading.Lock()
_ceiling: dict[str, float] = {"value": 0.0, "until": 0.0}      # value 0 = nothing learned


class SpeedError(ValueError):
    pass


def _path() -> Path:
    from app.core.config import get_settings
    d = Path(get_settings().data_dir) / "harness"
    d.mkdir(parents=True, exist_ok=True)
    return d / "speed.json"


def config() -> dict[str, Any]:
    out = dict(DEFAULTS)
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
        out.update({k: raw[k] for k in DEFAULTS if k in raw})
    except Exception:  # noqa: BLE001
        pass
    try:
        out["parallel"] = max(1, min(MAX_PARALLEL, int(out["parallel"])))
    except (TypeError, ValueError):
        out["parallel"] = DEFAULTS["parallel"]
    try:
        s = float(out["straggler_s"])
        out["straggler_s"] = 0.0 if s <= 0 else max(300.0, min(14400.0, s))
    except (TypeError, ValueError):
        out["straggler_s"] = float(DEFAULTS["straggler_s"])
    return out


def set_config(*, parallel: int | None = None, straggler_s: float | None = None) -> dict[str, Any]:
    cur = config()
    if parallel is not None:
        if not 1 <= int(parallel) <= MAX_PARALLEL:
            raise SpeedError(f"Batches side by side must be between 1 and {MAX_PARALLEL}.")
        cur["parallel"] = int(parallel)
    if straggler_s is not None:
        s = float(straggler_s)
        if s != 0 and not 300 <= s <= 14400:
            raise SpeedError("The slow-batch limit must be 0 (never) or between 5 minutes and 4 hours.")
        cur["straggler_s"] = s
    with _lock:
        _path().write_text(json.dumps({k: cur[k] for k in DEFAULTS}, indent=2), encoding="utf-8")
    return config()


def ceiling(now: float | None = None) -> int | None:
    """The learned limit on concurrent batches, or None when nothing is learned (or it has expired)."""
    now = time.time() if now is None else now
    with _lock:
        return int(_ceiling["value"]) if _ceiling["value"] and now < _ceiling["until"] else None


def note_busy(held_now: int, now: float | None = None) -> int:
    """BRAIN refused a batch while we hold `held_now` slots (the refused one included): at most held_now-1 can run. Returns the new ceiling."""
    now = time.time() if now is None else now
    value = max(2, int(held_now) - 1)                    # never below 2: one batch at a time is never the fix
    with _lock:
        cur = _ceiling["value"] if now < _ceiling["until"] else 0.0
        _ceiling["value"] = min(cur, value) if cur else float(value)
        _ceiling["until"] = now + CEILING_TTL
        return int(_ceiling["value"])


def reset_ceiling() -> None:
    with _lock:
        _ceiling.update(value=0.0, until=0.0)


def effective_parallel(routed: bool, concurrency: int | None = None, *, now: float | None = None) -> int:
    """How many batches a round runs side by side. Off the engine, or with Autosentry's own concurrency set below 3 (a deliberate choice),
    this is Alpha Sentry's original min(3, concurrency)."""
    legacy = max(1, min(LEGACY_PARALLEL, int(concurrency or 1)))
    if not routed or legacy < LEGACY_PARALLEL:
        return legacy
    want = config()["parallel"]
    c = ceiling(now)
    return max(1, min(want, c) if c else want)


def status() -> dict[str, Any]:
    c = ceiling()
    return {"settings": config(), "learnedCeiling": c, "ceilingSecondsLeft": max(0, int(_ceiling["until"] - time.time())) if c else 0,
            "legacyParallel": LEGACY_PARALLEL, "maxParallel": MAX_PARALLEL}
