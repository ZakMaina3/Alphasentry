"""Thin adapter between the harness and Alpha Sentry's BRAIN engine / ace_lib session.

Ported harness code NEVER imports ace_lib directly; it talks to this module only. All imports of
the vendored engine are lazy so importing the harness never touches the network or the session.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any


#: Longest the engine waits for one batch before giving its slot back (seconds). A batch BRAIN never finishes used to
#: hold a slot for ever, and after eight of those the engine looked frozen.
MAX_WAIT = 90 * 60


class SlotBusy(RuntimeError):
    """BRAIN refused the batch because its simulation slots/limit are full (retry later)."""


@dataclass
class SimHandle:
    sim_url: str
    multi: bool
    response: Any = None   # the live requests.Response, or a stand-in when adopting an orphan


class _Adopted:
    status_code = 200

    def __init__(self, url: str) -> None:
        self.headers = {"Location": url}
        self.text = ""


def _ace():
    from app.brain import engine  # noqa: F401  (puts the vendor dir on sys.path)
    import ace_lib as ace
    return engine, ace


def session():
    engine, ace = _ace()
    return ace.check_session_and_relogin(engine.require_session())


def start(payload: Any) -> SimHandle:
    """POST /simulations. `payload` is one simulation dict or a list of 2-10."""
    _, ace = _ace()
    s = session()
    resp = ace.start_simulation(s, payload)
    if resp.status_code == 429:
        raise SlotBusy(str(getattr(resp, "text", ""))[:200] or "simulation limit reached")
    if resp.status_code // 100 != 2:
        raise RuntimeError(f"BRAIN rejected the batch ({resp.status_code}): {str(resp.text)[:300]}")
    return SimHandle(sim_url=resp.headers["Location"], multi=isinstance(payload, list), response=resp)


def adopt(sim_url: str, multi: bool) -> SimHandle:
    """Re-attach to a simulation that was in flight when the app last stopped."""
    return SimHandle(sim_url=sim_url, multi=multi, response=_Adopted(sim_url))


def wait(handle: SimHandle, payload: Any, tag: str = "harness", cancel=None) -> list[dict]:
    """Block until the simulation finishes. Returns rows {alpha_id, simulate_data, error?}."""
    _, ace = _ace()
    s = session()
    if handle.multi:
        res = ace.multisimulation_progress(s, handle.response, max_wait=MAX_WAIT, cancel=cancel)
        errs = res.get("errors", []) or []
        rows = [{"alpha_id": None, "simulate_data": {}, "error": e} for e in errs]
        if not res.get("completed"):
            # same as ace.simulate_multi_alpha: BRAIN's error rows, else one empty row per submitted alpha
            return rows or [{"alpha_id": None, "simulate_data": x} for x in (payload if isinstance(payload, list) else [payload])]
        out = [{"alpha_id": x["id"],
                "simulate_data": {"type": x["type"], "settings": x["settings"], "regular": x["regular"]["code"]}}
               for x in res["result"]]
        for x in res["result"]:
            try:
                ace.set_alpha_properties(s, x["id"], tags=[tag])
            except Exception:  # noqa: BLE001
                pass
        return out + rows
    res = ace.simulation_progress(s, handle.response, max_wait=MAX_WAIT, cancel=cancel)
    if not res.get("completed"):
        return [{"alpha_id": None, "simulate_data": payload if isinstance(payload, dict) else {}}]
    aid = res["result"]["id"]
    try:
        ace.set_alpha_properties(s, aid, tags=[tag])
    except Exception:  # noqa: BLE001
        pass
    return [{"alpha_id": aid, "simulate_data": payload if isinstance(payload, dict) else {}}]


def tag_alpha(alpha_id: str, tag: str, color: str = "GREEN") -> None:
    """Label an alpha in BRAIN with a tag and colour (PATCH /alphas/{id}). Raises if BRAIN refuses, so the caller can keep the old label."""
    _, ace = _ace()
    r = ace.set_alpha_properties(session(), alpha_id, color=color, tags=[tag])
    if getattr(r, "status_code", 200) // 100 != 2:
        raise RuntimeError(f"BRAIN refused the tag for {alpha_id} (HTTP {r.status_code})")


def alpha_stats(alpha_id: str, simulate_data: dict, *, checks: bool = True, pnl: bool = False) -> dict:
    """IS stats (+ submission checks) for a simulated alpha, via Alpha Sentry's own helper."""
    _, ace = _ace()
    return ace.get_specified_alpha_stats(session(), alpha_id, simulate_data, get_pnl=pnl, get_stats=True,
                                         check_submission=checks, check_self_corr=checks, check_prod_corr=checks)


def check_submission(alpha_id: str):
    _, ace = _ace()
    return ace.get_check_submission(session(), alpha_id)


def daily_pnl(alpha_id: str):
    _, ace = _ace()
    return ace.get_alpha_daily_pnl(session(), alpha_id)


def alpha_detail(alpha_id: str) -> dict:
    """GET /alphas/{id}: {settings, checks, status}. A read — it costs no simulation quota."""
    _, ace = _ace()
    s = session()
    r = s.get(f"{ace.brain_api_url}/alphas/{alpha_id}")
    if r.status_code // 100 != 2:
        raise RuntimeError(f"alpha {alpha_id}: HTTP {r.status_code}")
    d = r.json()
    return {"settings": d.get("settings") or {}, "checks": (d.get("is") or {}).get("checks") or [],
            "status": d.get("status") or ""}
