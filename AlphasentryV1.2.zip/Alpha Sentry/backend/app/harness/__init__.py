"""SentryEngine capabilities ported into Alpha Sentry.

Everything here is additive: new modules under app/modules/harness_*, new tables prefixed
`harness_`, and a feature flag per area (default OFF). Existing Alpha Sentry code is not modified.
The AH data catalog is intentionally NOT ported; `labs/ace_sources` answers the same questions from Alpha Sentry's own knowledge DB (plain sqlite3, no SQLAlchemy).
No lab in this package has a submit path — submission stays in Alpha Sentry's existing, gated routes.
"""
