"""Shared pieces of the harness API modules: the scope fields every lab request carries, and the flag gate."""
from __future__ import annotations

from fastapi import HTTPException
from pydantic import BaseModel

from app.harness import flags
from app.harness.payload import Scope


class ScopeBase(BaseModel):
    region: str
    delay: int = 1
    universe: str = "TOP3000"
    instrument_type: str = "EQUITY"

    def scope(self) -> Scope:
        return Scope(self.region, self.delay, self.universe, self.instrument_type)


_NAMES = {"harness_engine": "SentryEngine", "harness_vault": "Returns vault", "harness_llm": "LLM labs"}


def need_flag(name: str) -> None:
    if not flags.enabled(name):
        raise HTTPException(409, f"{_NAMES.get(name, name)} is off. Enable the '{name}' flag first.")
