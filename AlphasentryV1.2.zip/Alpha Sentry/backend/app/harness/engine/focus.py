"""Engine focus: the one region (and optionally delay) SentryEngine works on right now.

BRAIN batches share one region, but the engine's queue is global, so after you switch region the old region's queued
simulations kept running and the new ones waited behind them (it looked stuck). With a focus set, the engine only starts
batches for that market; everything else is *parked* (stays queued, nothing lost) until you switch back or drop it.
Stored in a small json file next to the flags. Empty region = no focus (everything runs, the old behaviour).
"""
from __future__ import annotations

import json
import threading
from pathlib import Path

from app.harness.engine.packer import BatchKey

_lock = threading.Lock()


class Focus:
    def __init__(self, path: Path | str) -> None:
        self.path = Path(path)

    def _raw(self) -> dict:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            return raw if isinstance(raw, dict) else {}
        except Exception:  # noqa: BLE001
            return {}

    def follow(self) -> bool:
        """True (the default) = the engine works only on the region chosen in Autosentry and drops other regions' queued simulations at once."""
        with _lock:
            return bool(self._raw().get("follow", True))

    def set_follow(self, on: bool) -> bool:
        with _lock:
            raw = self._raw()
            raw["follow"] = bool(on)
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(json.dumps(raw), encoding="utf-8")
        return bool(on)

    def get(self) -> dict:
        with _lock:
            raw = self._raw()
        region = str(raw.get("region") or "").strip().upper()
        delay = raw.get("delay")
        return {"region": region, "delay": int(delay) if region and delay not in (None, "") else None}

    def set(self, region: str = "", delay: int | None = None) -> dict:
        region = str(region or "").strip().upper()
        with _lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            raw = self._raw()
            raw.update(region=region, delay=int(delay) if (region and delay not in (None, "")) else None)
            self.path.write_text(json.dumps(raw), encoding="utf-8")
        return self.get()

    def allows(self, key: BatchKey) -> bool:
        f = self.get()
        if not f["region"]:
            return True
        return key.region.upper() == f["region"] and (f["delay"] is None or key.delay == f["delay"])
