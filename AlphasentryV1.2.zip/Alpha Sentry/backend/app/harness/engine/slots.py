"""Shared slot lease: the single place that knows how many of BRAIN's 8 simulation slots are
in use, so the harness engine and (later) Autosentry never compete blindly for them."""
from __future__ import annotations

import threading

TOTAL_SLOTS = 8


class SlotLease:
    def __init__(self, total: int = TOTAL_SLOTS) -> None:
        self.total = int(total)
        self._held: dict[str, int] = {}
        self._waiting: dict[str, int] = {}
        self._lock = threading.Lock()

    def _used(self) -> int:
        return sum(self._held.values())

    def free(self) -> int:
        with self._lock:
            return max(0, self.total - self._used())

    def begin_wait(self, owner: str) -> None:
        """An owner is blocked waiting for a slot (others should leave one for it)."""
        with self._lock:
            self._waiting[owner] = self._waiting.get(owner, 0) + 1

    def end_wait(self, owner: str) -> None:
        with self._lock:
            n = self._waiting.get(owner, 0) - 1
            if n > 0:
                self._waiting[owner] = n
            else:
                self._waiting.pop(owner, None)

    def free_for(self, owner: str) -> int:
        """Free slots `owner` may take without jumping the queue: those not already spoken for by a
        DIFFERENT owner that is waiting (Autosentry polls slower than the engine ticks)."""
        with self._lock:
            others = sum(n for o, n in self._waiting.items() if o != owner)
            return max(0, self.total - self._used() - others)

    def acquire(self, owner: str, n: int = 1) -> bool:
        """Take n slots for `owner` atomically; False (and nothing taken) if they don't fit."""
        with self._lock:
            if n <= 0 or self._used() + n > self.total:
                return False
            self._held[owner] = self._held.get(owner, 0) + n
            return True

    def release(self, owner: str, n: int = 1) -> None:
        with self._lock:
            cur = self._held.get(owner, 0) - n
            if cur > 0:
                self._held[owner] = cur
            else:
                self._held.pop(owner, None)

    def snapshot(self) -> dict:
        with self._lock:
            return {"total": self.total, "used": self._used(), "free": max(0, self.total - self._used()),
                    "held": dict(self._held), "waiting": dict(self._waiting)}

    def held_by(self, owner: str) -> int:
        with self._lock:
            return self._held.get(owner, 0)


#: process-wide lease. Autosentry is routed through this later, behind the autopilot_via_engine flag.
shared_lease = SlotLease()
