"""Crash-safe tracker (plain sqlite3).

The simulation URL is appended to an fsync'd journal BEFORE the engine starts polling, so a crash or restart
can never orphan a running batch: on startup `orphan_batches()` returns every batch that started but never
finished and the engine adopts it. One writer lock serialises DB writes and the journal.
"""
from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path
from typing import Any

from app.harness.engine.dedup import hash_payload
from app.harness.engine.packer import WorkItem, key_of
from app.harness.store import Store, chunks, marks

LIVE = ("queued", "running", "done", "scored", "external")   # statuses that make a payload a duplicate


class Tracker:
    def __init__(self, store: Store, journal_path: Path) -> None:
        self.store = store
        self._journal = Path(journal_path)
        self._journal.parent.mkdir(parents=True, exist_ok=True)
        self._wlock = threading.Lock()

    # ── journal ────────────────────────────────────────────────────────────────────
    def _jwrite(self, row: dict) -> None:
        row["ts"] = time.time()
        with open(self._journal, "a", encoding="utf-8") as f:
            f.write(json.dumps(row) + "\n")
            f.flush()
            os.fsync(f.fileno())

    def orphan_batches(self) -> list[dict]:
        if not self._journal.exists():
            return []
        started: dict[str, dict] = {}
        for line in self._journal.read_text(encoding="utf-8").splitlines():
            try:
                row = json.loads(line)
            except Exception:  # noqa: BLE001
                continue
            if row.get("event") == "start":
                started[row["batch_id"]] = row
            elif row.get("event") == "finish":
                started.pop(row.get("batch_id"), None)
        return list(started.values())

    # ── queue ──────────────────────────────────────────────────────────────────────
    def enqueue(self, task: str, payload: dict, allow_duplicate: bool = False) -> dict:
        h, now = hash_payload(payload), time.time()
        with self._wlock, self.store.connect() as c:
            if not allow_duplicate:
                hit = c.execute(f"SELECT id, alpha_id FROM harness_sim_record WHERE payload_hash=? AND status IN ({marks(len(LIVE))}) LIMIT 1",
                                (h, *LIVE)).fetchone()
                if hit is not None:
                    return {"record_id": hit["id"], "duplicate": True, "alpha_id": hit["alpha_id"] or None}
            cur = c.execute("INSERT INTO harness_sim_record (task, payload_hash, payload, status, created, updated) VALUES (?,?,?,?,?,?)",
                            (task, h, json.dumps(payload), "queued", now, now))
            return {"record_id": cur.lastrowid, "duplicate": False, "alpha_id": None}

    def enqueue_many(self, task: str, payloads: list[dict]) -> dict:
        out = [self.enqueue(task, p) for p in payloads]
        return {"queued": sum(1 for o in out if not o["duplicate"]),
                "duplicates": sum(1 for o in out if o["duplicate"]), "items": out}

    def queued_items(self, limit: int = 500) -> list[WorkItem]:
        rows = self.store.query("SELECT id, task, payload FROM harness_sim_record WHERE status='queued' ORDER BY id LIMIT ?", (limit,))
        items = []
        for r in rows:
            p = json.loads(r["payload"])
            items.append(WorkItem(record_id=r["id"], key=key_of(p), task=r["task"], payload=p))
        return items

    def claim(self, record_ids: list[int], batch_id: str) -> list[int]:
        """queued -> running for exactly those ids still queued; returns the ones claimed."""
        with self._wlock, self.store.connect() as c:
            ok = [r["id"] for r in c.execute(f"SELECT id FROM harness_sim_record WHERE id IN ({marks(len(record_ids))}) AND status='queued'",
                                             record_ids).fetchall()]
            if ok:
                c.execute(f"UPDATE harness_sim_record SET status='running', batch_id=?, updated=? WHERE id IN ({marks(len(ok))})",
                          (batch_id, time.time(), *ok))
            return ok

    def register_running(self, task: str, payloads: list[dict], batch_id: str) -> list[int]:
        """Record a batch some OTHER runner (Autosentry) is simulating, already 'running' so the engine never
        picks it up. Gives the journal record ids to point at if the app dies mid-batch."""
        now, ids = time.time(), []
        with self._wlock, self.store.connect() as c:
            for p in payloads:
                cur = c.execute("INSERT INTO harness_sim_record (task, payload_hash, payload, status, batch_id, created, updated) "
                                "VALUES (?,?,?,?,?,?,?)", (task, hash_payload(p), json.dumps(p), "running", batch_id, now, now))
                ids.append(cur.lastrowid)
        return ids

    def batch_started(self, batch_id: str, sim_url: str, record_ids: list[int], multi: bool) -> None:
        """Journal FIRST (durable), then the DB."""
        with self._wlock:
            self._jwrite({"event": "start", "batch_id": batch_id, "sim_url": sim_url, "record_ids": record_ids, "multi": multi})
            self.store.execute(f"UPDATE harness_sim_record SET sim_url=?, updated=? WHERE id IN ({marks(len(record_ids))})",
                               (sim_url, time.time(), *record_ids))

    def batch_finished(self, batch_id: str) -> None:
        with self._wlock:
            self._jwrite({"event": "finish", "batch_id": batch_id})

    def finish_external(self, record_ids: list[int], alpha_ids: list[str | None]) -> None:
        """Autosentry's batch finished: keep each alpha id on its record (for yield accounting) but mark it
        'external' so the harness scorer leaves it alone — Autosentry scores its own results."""
        with self._wlock, self.store.connect() as c:
            now = time.time()
            for rid, aid in zip(record_ids, alpha_ids):
                c.execute("UPDATE harness_sim_record SET status='external', alpha_id=?, updated=? WHERE id=?", (aid or "", now, rid))

    def complete(self, record_id: int, alpha_id: str) -> None:
        self._set(record_id, "done", alpha_id or "", "")

    def fail(self, record_id: int, error: str) -> None:
        self._set(record_id, "error", None, str(error)[:500])

    def _set(self, record_id: int, status: str, alpha_id: str | None, error: str) -> None:
        with self._wlock:
            if alpha_id is None:
                self.store.execute("UPDATE harness_sim_record SET status=?, error=?, updated=? WHERE id=? AND status!='cancelled'",
                                   (status, error, time.time(), record_id))
            else:
                self.store.execute("UPDATE harness_sim_record SET status=?, alpha_id=?, error=?, updated=? WHERE id=? AND status!='cancelled'",
                                   (status, alpha_id, error, time.time(), record_id))

    def mark(self, record_ids: list[int], status: str, error: str = "") -> None:
        with self._wlock:
            self.store.execute(f"UPDATE harness_sim_record SET status=?, error=?, updated=? WHERE id IN ({marks(len(record_ids))}) AND status!='cancelled'",
                               (status, error, time.time(), *record_ids))      # a dropped (cancelled) record is final: nothing brings it back

    def requeue(self, record_ids: list[int]) -> None:
        """Put records back in the queue after BRAIN said 'busy'. Only ones still running: a record you dropped meanwhile stays dropped."""
        with self._wlock:
            self.store.execute(f"UPDATE harness_sim_record SET status='queued', updated=? WHERE status='running' AND id IN ({marks(len(record_ids))})",
                               (time.time(), *record_ids))

    def all_cancelled(self, record_ids: list[int]) -> bool:
        """True when every record of a batch was dropped (its poller can stop waiting for BRAIN)."""
        if not record_ids:
            return False
        rows = self.store.query(f"SELECT COUNT(*) AS n FROM harness_sim_record WHERE status!='cancelled' AND id IN ({marks(len(record_ids))})", list(record_ids))
        return int(rows[0]["n"]) == 0

    def running_batches(self) -> list[dict]:
        """Batches currently at BRAIN, one row each: who started it, market, how many simulations, when it was sent."""
        out: dict[str, dict] = {}
        for r in self.store.query("SELECT batch_id, task, payload, created, updated FROM harness_sim_record WHERE status='running' AND batch_id != '' ORDER BY updated"):
            reg, dly = self._market(r["payload"])
            b = out.setdefault(r["batch_id"], {"batch_id": r["batch_id"], "task": r["task"], "region": reg, "delay": dly, "size": 0, "since": r["updated"]})
            b["size"] += 1
            b["since"] = min(b["since"], r["updated"])
        return sorted(out.values(), key=lambda x: x["since"])

    def abandon_batch(self, batch_id: str) -> int:
        """Stop waiting for one batch: its simulations are marked cancelled (BRAIN finishes what it started; the result is ignored)."""
        with self._wlock:
            n = self.store.execute("UPDATE harness_sim_record SET status='cancelled', error='abandoned by you', updated=? WHERE batch_id=? AND status='running'",
                                   (time.time(), batch_id))
        return int(n or 0)

    def cancel_task(self, task: str) -> int:
        with self._wlock:
            return self.store.execute("UPDATE harness_sim_record SET status='cancelled', updated=? WHERE task=? AND status='queued'",
                                      (time.time(), task))

    # ── region handling ────────────────────────────────────────────────────────────
    @staticmethod
    def _market(payload_json: str) -> tuple[str, int]:
        try:
            st = (json.loads(payload_json).get("settings") or {})
            return str(st.get("region", "")).upper(), int(st.get("delay", 1))
        except Exception:  # noqa: BLE001
            return "", 1

    def region_counts(self) -> list[dict]:
        """Queued and running simulations per region and delay (what is waiting, so you can see what a switch would leave behind)."""
        out: dict[tuple[str, int], dict] = {}
        for r in self.store.query("SELECT payload, status FROM harness_sim_record WHERE status IN ('queued','running')"):
            k = self._market(r["payload"])
            row = out.setdefault(k, {"region": k[0], "delay": k[1], "queued": 0, "running": 0})
            row[r["status"]] += 1
        return sorted(out.values(), key=lambda x: (-x["queued"], x["region"], x["delay"]))

    def drop_queued(self, region: str | None = None, delay: int | None = None, keep_region: str | None = None,
                    keep_delay: int | None = None, include_running: bool = False) -> dict:
        """Cancel simulations: those of `region` [/delay], or everything except `keep_region` [/keep_delay].
        Queued ones are simply removed. With include_running, ones already sent to BRAIN are abandoned too: they are marked
        cancelled, the engine stops waiting for them and ignores their results (BRAIN itself finishes what it started).
        Autosentry's own running batches are never touched. Search trials are pruned, so a task does not wait for results that will never come."""
        region = (region or "").upper() or None
        keep_region = (keep_region or "").upper() or None
        ids: list[int] = []
        q = "SELECT id, payload, status FROM harness_sim_record WHERE status='queued'"
        if include_running:
            q = "SELECT id, payload, status FROM harness_sim_record WHERE status='queued' OR (status='running' AND task!='autopilot')"
        n_run = 0
        for r in self.store.query(q):
            reg, dly = self._market(r["payload"])
            if region is not None:
                hit = reg == region and (delay is None or dly == int(delay))
            elif keep_region is not None:
                hit = not (reg == keep_region and (keep_delay is None or dly == int(keep_delay)))
            else:
                hit = False
            if hit:
                ids.append(r["id"])
                n_run += 1 if r["status"] == "running" else 0
        if not ids:
            return {"dropped": 0, "abandoned_running": 0}
        now = time.time()
        with self._wlock, self.store.connect() as c:
            for part in chunks(ids):
                c.execute(f"UPDATE harness_sim_record SET status='cancelled', error='dropped by you', updated=? "
                          f"WHERE status IN ('queued','running') AND id IN ({marks(len(part))})", (now, *part))
                c.execute(f"UPDATE harness_trial SET status='pruned', error='dropped by you', updated=? "
                          f"WHERE status='queued' AND record_id IN ({marks(len(part))})", (now, *part))
        return {"dropped": len(ids), "abandoned_running": n_run}

    def cancel_queued(self, ids: list[int], reason: str = "dropped") -> int:
        """Cancel these records if they are still queued (final), and prune the search trials waiting on them."""
        ids = list(ids)
        if not ids:
            return 0
        now, n = time.time(), 0
        with self._wlock, self.store.connect() as c:
            for part in chunks(ids):
                n += c.execute(f"UPDATE harness_sim_record SET status='cancelled', error=?, updated=? WHERE status='queued' AND id IN ({marks(len(part))})",
                               (reason, now, *part)).rowcount
                c.execute(f"UPDATE harness_trial SET status='pruned', error=?, updated=? WHERE status='queued' AND record_id IN ({marks(len(part))})",
                          (reason, now, *part))
        return n

    def reset_all(self) -> dict:
        """Clean slate for the engine: every queued simulation, and every running one the engine owns, is cancelled (final), the search trials
        waiting on them are pruned, and the crash journal forgets the engine's unfinished batches. Autosentry's own running batches
        (task 'autopilot') and all finished results are left exactly as they are."""
        now = time.time()
        with self._wlock, self.store.connect() as c:
            ids = [r["id"] for r in c.execute("SELECT id FROM harness_sim_record WHERE status='queued' OR (status='running' AND task!='autopilot')").fetchall()]
            n_run = c.execute("SELECT COUNT(*) AS n FROM harness_sim_record WHERE status='running' AND task!='autopilot'").fetchone()["n"]
            for part in chunks(ids):
                c.execute(f"UPDATE harness_sim_record SET status='cancelled', error='engine reset', updated=? WHERE id IN ({marks(len(part))})", (now, *part))
                c.execute(f"UPDATE harness_trial SET status='pruned', error='engine reset', updated=? WHERE status='queued' AND record_id IN ({marks(len(part))})", (now, *part))
        closed = 0
        for o in self.orphan_batches():                       # forget unfinished engine batches (never Autosentry's)
            rec = self.records([int(i) for i in o.get("record_ids", [])])
            if not any(r["task"] == "autopilot" and r["status"] == "running" for r in rec):
                self.batch_finished(o["batch_id"])
                closed += 1
        return {"cancelled": len(ids), "abandoned_running": int(n_run), "journal_closed": closed}

    def reap_stale(self, live_batches: set[str], older_than: float = 7200.0) -> int:
        """A 'running' record whose batch is not alive in this process and has not moved for hours can never finish (its poller died):
        mark it as an error so the task that owns it stops waiting. Autosentry's own batches are left alone for the same long grace."""
        cutoff = time.time() - older_than
        rows = self.store.query("SELECT id, batch_id FROM harness_sim_record WHERE status='running' AND updated<?", (cutoff,))
        ids = [r["id"] for r in rows if r["batch_id"] not in live_batches]
        if ids:
            self.mark(ids, "error", "stale: batch never finished (timed out)")
        return len(ids)

    def records(self, ids: list[int]) -> list[dict]:
        out: list[dict[str, Any]] = []
        for part in chunks(list(ids)):
            for r in self.store.query(f"SELECT id, task, status, alpha_id, error, payload FROM harness_sim_record WHERE id IN ({marks(len(part))})", part):
                out.append({"id": r["id"], "task": r["task"], "status": r["status"], "alpha_id": r["alpha_id"],
                            "error": r["error"], "payload": json.loads(r["payload"])})
        return out

    def counts(self) -> dict[str, int]:
        return {r["status"]: int(r["n"]) for r in self.store.query("SELECT status, COUNT(*) AS n FROM harness_sim_record GROUP BY status")}
