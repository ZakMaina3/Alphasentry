"""Match BRAIN's returned rows back to the payloads that were submitted (shared by the engine and the
Autosentry route, which previously each needed this)."""
from __future__ import annotations

from collections import defaultdict
from typing import Any


def match_rows(payloads: list[dict], rows: list[dict]) -> tuple[list[str | None], list[str]]:
    """-> (alpha id or None per payload, BRAIN's error messages).

    Matching is by expression text (multi-sim results come back without their original index). A lone payload
    that got exactly one alpha back is matched even if BRAIN normalised the expression.
    """
    pool: dict[str, list[str]] = defaultdict(list)
    errors: list[str] = []
    good = [r for r in rows if r.get("alpha_id")]
    for r in rows:
        if r.get("alpha_id"):
            pool[str((r.get("simulate_data") or {}).get("regular", ""))].append(r["alpha_id"])
        elif r.get("error"):
            errors.append(str(r["error"]))
    out: list[str | None] = []
    for p in payloads:
        code = str(p.get("regular", ""))
        if pool.get(code):
            out.append(pool[code].pop(0))
        elif len(payloads) == 1 and len(good) == 1:
            out.append(good[0]["alpha_id"])
        else:
            out.append(None)
    return out, errors


def match_errors(payloads: list[dict], rows: list[dict]) -> list[str]:
    """BRAIN's rejection message for EACH payload (not one per batch): an error row is matched to its payload by expression text; error rows
    that carry no expression are handed out in order to the payloads still without a message; a payload nobody explains gets ''."""
    by_code: dict[str, list[str]] = defaultdict(list)
    loose: list[str] = []
    for r in rows:
        if r.get("alpha_id") or not r.get("error"):
            continue
        code = str((r.get("simulate_data") or {}).get("regular", ""))
        (by_code[code] if code else loose).append(str(r["error"]))
    ok_codes: dict[str, int] = defaultdict(int)
    for r in rows:
        if r.get("alpha_id"):
            ok_codes[str((r.get("simulate_data") or {}).get("regular", ""))] += 1
    out: list[str] = []
    done: list[bool] = []
    for p in payloads:
        code = str(p.get("regular", ""))
        done.append(bool(ok_codes.get(code)))
        if ok_codes.get(code):
            ok_codes[code] -= 1
            out.append("")
        elif by_code.get(code):
            out.append(by_code[code].pop(0))
        else:
            out.append("")
    for i, m in enumerate(out):
        if not m and not done[i] and loose:
            out[i] = loose.pop(0)
    return out
