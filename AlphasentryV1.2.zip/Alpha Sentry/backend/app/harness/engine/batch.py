"""BatchEngine: one background loop keeps BRAIN's 8 slots full.

Each round it asks the shared SlotLease how many slots are free, packs queued items into legal
2-10 child batches (shared 5-tuple), and starts one daemon thread per batch. The simulation URL is
journalled before polling, so a restart adopts orphaned batches instead of losing them. A dry-run
mode never calls simulate. There is NO submit path here.
"""
from __future__ import annotations

import threading
import time
import uuid
from collections import defaultdict
from typing import Any, Callable

from app.harness import brain_port as _bp
from app.harness.engine.match import match_errors, match_rows
from app.harness.engine.packer import Batch, allocate_slots, pack
from app.harness.engine.slots import SlotLease, shared_lease
from app.harness.engine.tracker import Tracker

OWNER = "harness"


class _Side:
    """Runs `fn` on a daemon thread at most every `every` seconds, never overlapping itself."""

    def __init__(self, fn: Callable[[], Any] | None, every: float, label: str, say: Callable[[str], None]) -> None:
        self.fn, self.every, self.label, self.say = fn, every, label, say
        self._last, self._thread = 0.0, None

    def poke(self) -> None:
        if not self.fn or (self._thread is not None and self._thread.is_alive()) or time.time() - self._last < self.every:
            return
        self._last = time.time()

        def run() -> None:
            try:
                res = self.fn()
                if isinstance(res, dict) and (res.get("scored") or res.get("failed")):
                    self.say(f"scored {res.get('scored', 0)} result(s), {res.get('failed', 0)} failed")
            except Exception as e:  # noqa: BLE001
                self.say(f"{self.label} error: {e}")

        self._thread = threading.Thread(target=run, daemon=True, name=f"harness-{self.label}")
        self._thread.start()


class BatchEngine:
    def __init__(self, tracker: Tracker, port=_bp, lease: SlotLease = shared_lease, *,
                 quotas: dict[str, int] | None = None, poll_interval: float = 2.0,
                 scorer: Callable[[], Any] | None = None, score_every: float = 20.0,
                 ticker: Callable[[], Any] | None = None, tick_every: float = 4.0,
                 focus: Any = None, stale_after: float = 7200.0, on_foreign: Callable[[str], Any] | None = None) -> None:
        self.tracker, self.port, self.lease = tracker, port, lease
        self.focus = focus                                 # engine.focus.Focus | None: only this market is started, the rest is parked
        self.on_foreign = on_foreign                       # called with the focused region after other regions' queued work was dropped (pauses their tasks)
        self.stale_after, self._last_reap = float(stale_after), 0.0
        self._epoch = 0                                    # bumped by reset(): threads of an older epoch no longer touch the slot lease
        self._live: set[str] = set()                       # batch ids with a poller thread alive in this process
        self.scorer, self.ticker = scorer, ticker
        self._side = {"score": _Side(scorer, score_every, "scoring", self._say), "tasks": _Side(ticker, tick_every, "tasks", self._say)}
        self.quotas = dict(quotas or {})
        self.poll_interval = poll_interval
        self.dry_run = False
        self._stop = threading.Event()
        self._threads: list[threading.Thread] = []
        self._in_flight: dict[str, int] = defaultdict(int)   # task -> batches running
        self._lock = threading.Lock()
        self.log: list[str] = []
        self.running = False

    # ── helpers ────────────────────────────────────────────────────────────────────
    def _say(self, msg: str) -> None:
        self.log.append(f"{time.strftime('%H:%M:%S')} {msg}")
        del self.log[:-200]

    def stop(self) -> None:
        self._stop.set()

    def reset(self) -> dict:
        """Forget everything this engine is doing: stop the loop, give back every slot it holds, clear its counters and log. Batches
        still waiting on BRAIN are cut loose (they stop as soon as their records are cancelled; see Tracker.reset_all)."""
        self._stop.set()
        with self._lock:
            self._epoch += 1
            held = self.lease.held_by(OWNER)
            if held:
                self.lease.release(OWNER, held)
            self._in_flight.clear()
        self._live.clear()
        self.log.clear()
        return {"slots_released": held}

    def status(self) -> dict:
        with self._lock:
            fl = dict(self._in_flight)
        return {"running": self.running, "dry_run": self.dry_run, "in_flight_by_task": fl,
                "lease": self.lease.snapshot(), "counts": self.tracker.counts(), "log": self.log[-30:],
                "focus": self.focus.get() if self.focus else {"region": "", "delay": None},
                "follow": self.focus.follow() if self.focus else False}

    # ── main loop ──────────────────────────────────────────────────────────────────
    def run(self, progress: Callable | None = None, should_cancel: Callable[[], bool] | None = None) -> dict:
        self.running = True
        self._stop.clear()
        try:
            self._adopt_orphans()
            while not self._stop.is_set() and not (should_cancel and should_cancel()):
                started = self.tick()
                self._maybe_side()
                self._maybe_reap()
                if progress:
                    c = self.tracker.counts()
                    progress(message=f"queued {c.get('queued', 0)} · running {c.get('running', 0)} · done {c.get('done', 0)}")
                self._stop.wait(self.poll_interval if not started else 0.2)
        finally:
            self.running = False
        return self.tracker.counts()

    def _maybe_reap(self) -> None:
        if time.time() - self._last_reap < 120:
            return
        self._last_reap = time.time()
        try:
            n = self.tracker.reap_stale(set(self._live), self.stale_after)
            if n:
                self._say(f"released {n} stale simulation record(s) whose batch never finished")
        except Exception as e:  # noqa: BLE001
            self._say(f"stale check error: {e}")

    def _maybe_side(self) -> None:
        """Scoring and task scheduling run on side threads, so BRAIN reads never delay slot scheduling. Both are
        skipped in dry-run (nothing is really simulated, so there is nothing to score and tasks must not burn budget)."""
        if self.dry_run:
            return
        for s in self._side.values():
            s.poke()

    def tick(self) -> int:
        """One scheduling round. Returns how many batches were started."""
        free = self.lease.free_for(OWNER)      # leaves slots for a waiting Autosentry worker
        if free <= 0:
            return 0
        items = self.tracker.queued_items()
        if self.focus is not None:
            keep = [it for it in items if self.focus.allows(it.key)]
            if len(keep) != len(items) and self.focus.follow():
                # Following Autosentry's region: queued simulations for any other region are dropped at once, not parked.
                gone = [it.record_id for it in items if not self.focus.allows(it.key)]
                n = self.tracker.cancel_queued(gone, "dropped: not the region chosen in Autosentry")
                if n:
                    region = self.focus.get()["region"]
                    self._say(f"dropped {n} queued simulation(s) for other regions (the engine follows Autosentry's region: {region})")
                    if self.on_foreign:
                        try:
                            self.on_foreign(region)
                        except Exception as e:  # noqa: BLE001
                            self._say(f"pausing other regions' tasks failed: {e}")
            items = keep                               # with follow off they are only parked (kept queued) until you switch back
        if not items:
            return 0
        demand: dict[str, int] = defaultdict(int)
        by_task: dict[str, int] = defaultdict(int)
        for it in items:
            by_task[it.task] += 1
        for t, n in by_task.items():
            demand[t] = max(1, -(-n // 10))
        with self._lock:
            running = dict(self._in_flight)
        alloc = allocate_slots(free, demand=dict(demand), quotas=self.quotas, in_flight=running)
        batches = pack(items, free_slots=free, task_capacity=alloc)
        n = 0
        for b in batches:
            if not self.lease.acquire(OWNER, 1):
                break
            bid = uuid.uuid4().hex[:12]
            claimed = self.tracker.claim(b.record_ids, bid)
            if not claimed:
                self.lease.release(OWNER, 1)
                continue
            if len(claimed) != len(b.record_ids):
                b = Batch(key=b.key, task=b.task, items=tuple(i for i in b.items if i.record_id in claimed))
            with self._lock:
                self._in_flight[b.task] += 1
            self._live.add(bid)
            t = threading.Thread(target=self._run_batch, args=(bid, b, None, self._epoch), daemon=True, name=f"harness-batch-{bid}")
            self._threads.append(t)
            t.start()
            n += 1
        self._threads = [t for t in self._threads if t.is_alive()]
        return n

    # ── one batch ──────────────────────────────────────────────────────────────────
    def _run_batch(self, bid: str, b: Batch, handle=None, epoch: int | None = None) -> None:
        ids = b.record_ids
        epoch = self._epoch if epoch is None else epoch
        try:
            if self.dry_run:
                self.tracker.mark(ids, "dryrun")
                self._say(f"dry-run {bid}: {len(ids)} item(s), simulate NOT called")
                return
            payload = b.wire_payload()
            if handle is None and self.tracker.all_cancelled(ids):
                self._say(f"batch {bid}: dropped before it was sent, nothing started")
                return
            if handle is None:
                handle = self.port.start(payload)
                self.tracker.batch_started(bid, handle.sim_url, ids, handle.multi)   # journal before polling
            rows = self._wait(handle, payload, ids)
            self._apply(b, rows)
            self.tracker.batch_finished(bid)
            self._say(f"batch {bid} finished ({len(ids)} item(s))")
        except _bp.SlotBusy as e:
            self.tracker.requeue(ids)
            self._say(f"batch {bid}: slots busy, requeued ({e})")
            time.sleep(5)
        except Exception as e:  # noqa: BLE001
            self.tracker.mark(ids, "error", str(e)[:300])
            try:
                self.tracker.batch_finished(bid)
            except Exception:  # noqa: BLE001
                pass
            self._say(f"batch {bid} failed: {e}")
        finally:
            self._live.discard(bid)
            if epoch == self._epoch:                       # after a reset the lease was already given back in one go
                self.lease.release(OWNER, 1)
                with self._lock:
                    self._in_flight[b.task] = max(0, self._in_flight[b.task] - 1)

    def _wait(self, handle, payload, ids):
        """Wait for BRAIN; stops early when every record of the batch was dropped (ports that cannot be interrupted just wait)."""
        import inspect
        try:
            takes_cancel = "cancel" in inspect.signature(self.port.wait).parameters
        except (TypeError, ValueError):
            takes_cancel = False
        if takes_cancel:
            return self.port.wait(handle, payload, cancel=lambda: self.tracker.all_cancelled(ids))
        return self.port.wait(handle, payload)

    def _apply(self, b: Batch, rows: list[dict]) -> None:
        payloads = [it.payload for it in b.items]
        ids, errors = match_rows(payloads, rows)
        each = match_errors(payloads, rows)
        for it, alpha_id, why in zip(b.items, ids, each):
            if alpha_id:
                self.tracker.complete(it.record_id, alpha_id)
            else:
                self.tracker.fail(it.record_id, why or (errors[0] if len(errors) == 1 else "") or "no alpha returned")

    # ── crash recovery ─────────────────────────────────────────────────────────────
    def _adopt_orphans(self) -> None:
        for o in self.tracker.orphan_batches():
            ids = [int(i) for i in o.get("record_ids", [])]
            recs = {r["id"]: r for r in self.tracker.records(ids)}
            from app.harness.engine.packer import WorkItem, key_of
            items = tuple(WorkItem(record_id=i, key=key_of(recs[i]["payload"]), task=recs[i]["task"],
                                   payload=recs[i]["payload"]) for i in ids if i in recs)
            if not items:
                self.tracker.batch_finished(o["batch_id"])
                continue
            if not self.lease.acquire(OWNER, 1):
                break
            b = Batch(key=items[0].key, task=items[0].task, items=items)
            with self._lock:
                self._in_flight[b.task] += 1
            self.tracker.mark(ids, "running")
            self._live.add(o["batch_id"])
            h = self.port.adopt(o["sim_url"], bool(o.get("multi")))
            t = threading.Thread(target=self._run_batch, args=(o["batch_id"], b, h, self._epoch), daemon=True)
            self._threads.append(t)
            t.start()
            self._say(f"adopted orphan batch {o['batch_id']} ({len(items)} item(s))")
