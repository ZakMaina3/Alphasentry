"""Execution core: packer + dedup (pure), tracker (crash-safe), slot lease, BatchEngine."""
