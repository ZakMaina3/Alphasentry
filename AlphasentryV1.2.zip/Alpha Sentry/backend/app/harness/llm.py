"""One door to Alpha Sentry's own LLM layer for every harness lab (fragment C1). Not a port of SentryEngine's llm service or key vault.

Alpha Sentry already knows your keys and providers (Settings; `llm_providers.default_chain(preferred)`). That layer only exposes
`generate_list(prompt)` -> a list of strings, so this adapter builds everything on that:

    llm = default_llm()
    reply = llm.complete(system, user, lab="invent")                  # reply.text
    reply = llm.complete(system, user, lab="invent", json=True)       # reply.data = parsed JSON
    reply = llm.complete_list(system, user, lab="invent", n=6)        # reply.items = list[str]

Every call goes through the daily budget (harness/llm_budget.py): refused with BudgetExceeded when over a cap, recorded in the usage
ledger otherwise (failures too: a failed call may still cost). Nothing is cached and nothing is retried automatically.
"""
from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from app.harness.llm_budget import Budget, BudgetExceeded, est_tokens  # noqa: F401  (BudgetExceeded re-exported)
from app.harness.store import Store, default_store


class LLMError(RuntimeError):
    pass


class LLMUnavailable(LLMError):
    pass


@dataclass
class Reply:
    items: list[str]
    provider: str = ""
    model: str = ""
    data: Any = None
    est_tokens: int = 0

    @property
    def text(self) -> str:
        return "\n".join(self.items).strip()


def parse_json_text(text: str) -> Any:
    """The JSON in a model's answer: tolerates code fences and chatter around it."""
    t = (text or "").strip()
    t = re.sub(r"^```(?:json|JSON)?\s*|\s*```$", "", t)
    for candidate in (t, *(m for m in _json_spans(t))):
        try:
            return json.loads(candidate)
        except ValueError:
            continue
    raise LLMError("The model's answer was not valid JSON. Try again (a second attempt usually works).")


def _json_spans(t: str):
    for open_, close in (("{", "}"), ("[", "]")):
        a, b = t.find(open_), t.rfind(close)
        if 0 <= a < b:
            yield t[a:b + 1]


def ace_provider():
    """Alpha Sentry's configured providers as one object with `generate_list(prompt, n=)` -> (.expressions, .provider, .model)."""
    try:
        from app.brain import engine  # noqa: F401  — puts the vendored modules on sys.path
        import keys as keymgr
        import llm_providers as L
    except Exception as e:  # noqa: BLE001
        raise LLMUnavailable(f"Alpha Sentry's LLM layer could not be loaded ({e}).") from e
    chain = L.default_chain(keymgr.get_preferred())
    if not chain:
        raise LLMUnavailable("No LLM providers set up. Add an API key in Settings.")
    return L.MultiLLM(chain)


def ace_status() -> dict[str, Any]:
    try:
        from app.brain import engine  # noqa: F401
        import keys as keymgr
        import llm_providers as L
        preferred = keymgr.get_preferred()
        return {"available": [p.name for p in L.all_available()], "preferred": preferred, "used": [p.name for p in L.default_chain(preferred)]}
    except Exception as e:  # noqa: BLE001
        return {"available": [], "preferred": None, "used": [], "error": str(e)[:200]}


class LLM:
    def __init__(self, store: Store, *, provider: Callable[[], Any] = ace_provider, budget: Budget | None = None,
                 status: Callable[[], dict[str, Any]] = ace_status, clock: Callable[[], float] = time.time) -> None:
        self.store, self._provider, self._status, self.clock = store, provider, status, clock
        self.budget = budget or Budget(store, clock=clock)

    def status(self) -> dict[str, Any]:
        return {**self._status(), "budget": self.budget.summary(7)}

    def _call(self, prompt: str, lab: str, n: int | None) -> Reply:
        self.budget.check(len(prompt))                                        # refuses before anything is sent
        start = self.clock()
        provider = model = ""
        try:
            multi = self._provider()
            res = multi.generate_list(prompt, n=n) if n else multi.generate_list(prompt)
            provider, model = str(getattr(res, "provider", "")), str(getattr(res, "model", ""))
            items = [str(x) for x in (getattr(res, "expressions", None) or [])]
        except BudgetExceeded:
            raise
        except LLMUnavailable:
            raise
        except Exception as e:  # noqa: BLE001
            msg = _friendly(e)
            self.budget.record(lab=lab, provider=provider, model=model, prompt_chars=len(prompt), completion_chars=0, ok=False, error=msg,
                               ms=int((self.clock() - start) * 1000))
            raise LLMError(msg) from e
        self.budget.record(lab=lab, provider=provider, model=model, prompt_chars=len(prompt), completion_chars=sum(len(i) for i in items),
                           ok=bool(items), error="" if items else "empty answer", ms=int((self.clock() - start) * 1000))
        if not items:
            raise LLMError("The model returned nothing. Try again.")
        return Reply(items, provider, model, None, est_tokens(len(prompt)) + est_tokens(sum(len(i) for i in items)))

    def complete_list(self, system: str, user: str, *, lab: str = "", n: int | None = None) -> Reply:
        how = f"exactly {n} strings" if n else "strings"
        return self._call(f"{system}\n\n{user}\n\nReturn ONLY a JSON array of {how}, one per item. No commentary.", lab, n)

    def complete(self, system: str, user: str, *, lab: str = "", json: bool = False) -> Reply:       # noqa: A002
        reply = self._call(f"{system}\n\n{user}\n\nReturn ONLY a JSON array containing exactly one string: your complete answer.", lab, 1)
        if json:
            reply.data = parse_json_text(reply.text)
        return reply


def _friendly(e: Exception) -> str:
    try:
        import llm_providers as L
        return str(L.friendly_error(e))[:300]
    except Exception:  # noqa: BLE001
        return f"{type(e).__name__}: {e}"[:300]


_default: LLM | None = None


def default_llm() -> LLM:
    global _default
    from app.core.config import get_settings
    store = default_store()
    if _default is None or _default.store is not store:
        _default = LLM(store, budget=Budget(store, Path(get_settings().data_dir) / "harness" / "llm_budget.json"))
    return _default
