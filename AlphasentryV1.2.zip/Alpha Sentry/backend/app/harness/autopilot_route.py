"""Route Autosentry's batch execution through the harness' shared slot lease and crash journal.

Only the BATCH EXECUTION step of simulation.service.run_simulation is replaced (when the `autopilot_via_engine`
flag is on). Everything after it — stats, gating, tagging, DB writes, Alpha Sentry's learning/credit hooks — still runs
inside run_simulation, unchanged, so Autosentry's behaviour is the same; what differs is:
  * its simulation slots come from the shared SlotLease, so Autosentry and the harness engine never fight over
    BRAIN's 8 slots;
  * every batch is journalled (fsync) before polling, so a crash cannot orphan a running batch: the engine's
    orphan adoption re-attaches and its results are scored into Alpha Sentry's Results.
Fast Stop is preserved: cancelling abandons the in-flight waits at once, exactly like the old pool.terminate().
Speed (fragment G1, harness/speed.py): more batches per round than Alpha Sentry's cap of 3 (the autopilot service asks speed.effective_parallel), a ceiling
learned from BRAIN's own refusals, and release of stuck batches: once some batches of a round are done, the round continues without batches that
have run longer than the slow-batch limit. A released batch keeps its slot until BRAIN finishes it and is then handed to the harness scorer.
Supersentry (type SUPER, no multi-sim) is routed by harness/super_route.py through the same switch, on the shared slot lease only (no batching,
no journal); the manual SuperAlpha screen is not routed. The flag is per-thread, set by `engine_routing()` around the Autosentry / Supersentry call only,
so the Simulation screen and other callers are unaffected.
"""
from __future__ import annotations

import queue
import threading
import time
import uuid
from contextlib import contextmanager
from typing import Any, Callable

from app.harness import flags
from app.harness.engine.match import match_rows

OWNER = "autopilot"
TASK = "autopilot"
_tl = threading.local()


@contextmanager
def engine_routing():
    """Wrap Autosentry's run_simulation call. Routing is on only if the flag is on right now."""
    prev = getattr(_tl, "on", False)
    try:
        _tl.on = flags.enabled("autopilot_via_engine")
    except Exception:  # noqa: BLE001
        _tl.on = False
    try:
        yield
    finally:
        _tl.on = prev


def routing_on() -> bool:
    return bool(getattr(_tl, "on", False))


def maybe_route(batches: list[list[dict]], conc: int, progress: Callable, should_cancel: Callable[[], bool],
                total: int, *, port=None, lease=None, tracker=None, poll: float = 1.0, straggler_s: float | None = None):
    """None = not routed (caller runs the original path). Otherwise (flat, done, cancelled, errors).

    Setup problems return None BEFORE any simulation starts, so falling back never double-spends. Once batches
    are running this never raises: problems become BATCH ERROR entries, like the original loop.
    """
    if not routing_on():
        return None
    try:
        if port is None:
            from app.harness import brain_port as port
        if lease is None:
            from app.harness.engine.slots import shared_lease as lease
        if tracker is None:
            from pathlib import Path

            from app.core.config import get_settings
            from app.harness.engine.tracker import Tracker
            from app.harness.store import default_store, ensure_tables
            ensure_tables(default_store())
            tracker = Tracker(default_store(), Path(get_settings().data_dir) / "harness" / "inflight.jsonl")
    except Exception:  # noqa: BLE001
        return None
    try:
        progress(log="routing batches through the harness engine (shared slots + crash journal)")
    except Exception:  # noqa: BLE001
        pass
    if straggler_s is None:
        try:
            from app.harness import speed
            straggler_s = float(speed.config()["straggler_s"])
        except Exception:  # noqa: BLE001
            straggler_s = 0.0
    return _execute(batches, conc, progress, should_cancel, total, port, lease, tracker, poll, straggler_s)


def _learn_busy(lease) -> None:
    """BRAIN said no while we hold k slots: remember that more than k-1 batches at once is not possible right now."""
    try:
        from app.harness import speed
        speed.note_busy(lease.held_by(OWNER))
    except Exception:  # noqa: BLE001
        pass


def _execute(batches, conc, progress, should_cancel, total, port, lease, tracker, poll, straggler_s=0.0):
    work: "queue.Queue[list[dict]]" = queue.Queue()
    for b in batches:
        work.put(b)
    out: "queue.Queue[tuple[str, Any]]" = queue.Queue()
    abandon = threading.Event()
    running: dict[str, float] = {}                      # batch id -> when BRAIN accepted it (only batches still running)
    released: set[str] = set()                          # batches the round stopped waiting for
    rlock = threading.Lock()

    def run_batch(batch: list[dict]) -> list[dict]:
        bid = uuid.uuid4().hex[:12]
        ids = tracker.register_running(TASK, batch, bid)
        started = False
        try:
            payload = batch[0] if len(batch) == 1 else list(batch)
            for attempt in range(60):                       # BRAIN briefly refusing = wait, not fail
                try:
                    handle = port.start(payload)
                    break
                except port.SlotBusy:
                    if attempt == 0:
                        _learn_busy(lease)
                    if abandon.is_set() or attempt == 59:
                        raise
                    time.sleep(5)
            tracker.batch_started(bid, handle.sim_url, ids, handle.multi)
            started = True
            with rlock:
                running[bid] = time.time()
            rows = port.wait(handle, payload, tag="ace_tag")    # Alpha Sentry's own BRAIN-side tag
            matched, _errs = match_rows(list(batch), rows)
            with rlock:
                running.pop(bid, None)
                late = bid in released
            if late:                                            # the round moved on: the harness scorer takes these results
                for rid, aid in zip(ids, matched):
                    (tracker.complete(rid, aid) if aid else tracker.fail(rid, "no result for this alpha"))
            else:
                tracker.finish_external(ids, matched)           # results belong to Autosentry's own pipeline
            tracker.batch_finished(bid)
            return rows
        except BaseException as e:
            with rlock:
                running.pop(bid, None)
            tracker.mark(ids, "error", str(e)[:300])
            if started:
                tracker.batch_finished(bid)
            raise

    def worker() -> None:
        while not abandon.is_set():
            try:
                batch = work.get_nowait()
            except queue.Empty:
                return
            lease.begin_wait(OWNER)                         # tell the engine to leave a slot for us
            try:
                while not abandon.is_set() and not lease.acquire(OWNER, 1):
                    time.sleep(min(1.0, poll))              # wait for a slot (shared with the harness engine)
            finally:
                lease.end_wait(OWNER)
            if abandon.is_set():
                return
            try:
                out.put(("ok", run_batch(batch)))
            except BaseException as e:  # noqa: BLE001
                out.put(("err", e))
            finally:
                lease.release(OWNER, 1)                    # freed when BRAIN is really done, even after a Stop

    workers = max(1, conc)
    if conc >= 3:                                           # a round may be wider than Alpha Sentry's own concurrency setting (speed.py);
        try:                                                # below 3 the user chose a gentle run on purpose, so it stays
            from app.harness import speed
            workers = max(workers, min(len(batches), speed.effective_parallel(True, conc)))
        except Exception:  # noqa: BLE001
            pass
    threads = [threading.Thread(target=worker, daemon=True, name=f"autopilot-route-{i}") for i in range(max(1, workers))]
    for t in threads:
        t.start()

    flat: list[dict] = []
    errors: list[str] = []
    done, received, cancelled = 0, 0, False
    try:
        while received < len(batches):
            if should_cancel():
                cancelled = True
                abandon.set()
                progress(log="STOP requested")
                break
            try:
                kind, res = out.get(timeout=poll)
            except queue.Empty:
                if straggler_s and received >= 1 and work.empty():
                    now = time.time()
                    with rlock:
                        slow = [b for b, t0 in running.items() if now - t0 > straggler_s]
                        everyone_slow = len(slow) == len(running) and len(running) > 0 and len(running) + received >= len(batches)
                        if everyone_slow:
                            released.update(slow)
                    if everyone_slow:
                        progress(log=f"{len(slow)} batch(es) still running after {int(straggler_s // 60)} min: continuing without them. "
                                     "BRAIN keeps working on them; the harness scores them when they finish.")
                        break
                continue
            received += 1
            if kind == "err":
                e = res
                msg = str(e).strip().splitlines()[0][:180] if str(e).strip() else type(e).__name__
                if msg not in errors:
                    errors.append(msg)
                progress(log=f"BATCH ERROR: {msg}")
                continue
            real = [x for x in res if x.get("alpha_id")]
            for x in res:
                e = x.get("error")
                if e and e not in errors:
                    errors.append(e)
            flat.extend(real)
            done += len(real)
            progress(done=done, log=f"+{len(real)} simulated ({done}/{total})")
    except BaseException as e:  # noqa: BLE001      never surface an exception after sims have started
        abandon.set()
        msg = f"routing error: {str(e)[:150]}"
        if msg not in errors:
            errors.append(msg)
    return flat, done, cancelled, errors
