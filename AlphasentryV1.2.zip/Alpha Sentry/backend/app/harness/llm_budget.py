"""LLM spend control (fragment C2): a daily cap and a usage ledger (table harness_llm_usage).

Alpha Sentry's LLM layer (`llm_providers`) returns only the model's answer, not token counts or prices, so this module works in what it can
measure honestly: CALLS and ESTIMATED tokens (characters / 4, a standard rough rule). An optional price per million tokens turns the
estimate into an estimated cost, which can also be capped. A cap of 0 means "no cap". Defaults are deliberately modest. The estimate is
only an estimate: treat the caps as a safety net, and check your provider's own dashboard for real spend.
"""
from __future__ import annotations

import json
import math
import threading
import time
from pathlib import Path
from typing import Any, Callable

from app.harness.store import Store

DEFAULTS: dict[str, float] = {"max_calls_per_day": 40, "max_tokens_per_day": 300_000, "usd_per_million_tokens": 0.0, "max_usd_per_day": 0.0}
COMPLETION_RESERVE = 3000          # tokens assumed for the answer when checking the cap before a call
_lock = threading.Lock()


class BudgetExceeded(RuntimeError):
    pass


def est_tokens(chars: int) -> int:
    return int(math.ceil(max(0, chars) / 4))


class Budget:
    def __init__(self, store: Store, path: Path | None = None, clock: Callable[[], float] = time.time) -> None:
        self.store, self.path, self.clock = store, path, clock
        self._mem: dict[str, float] = {}

    # ── config ──
    def config(self) -> dict[str, float]:
        out = dict(DEFAULTS)
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8")) if self.path else self._mem
            out.update({k: float(v) for k, v in raw.items() if k in DEFAULTS})
        except Exception:  # noqa: BLE001
            pass
        return out

    def set_config(self, **kw: Any) -> dict[str, float]:
        cur = self.config()
        for k, v in kw.items():
            if v is None:
                continue
            if k not in DEFAULTS:
                raise ValueError(f"Unknown budget setting: {k}.")
            try:
                f = float(v)
            except (TypeError, ValueError):
                raise ValueError(f"{k} must be a number.") from None
            if f < 0 or math.isnan(f) or math.isinf(f):
                raise ValueError(f"{k} cannot be negative (use 0 for no cap).")
            cur[k] = f
        with _lock:
            if self.path:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                self.path.write_text(json.dumps(cur, indent=2), encoding="utf-8")
            else:
                self._mem = dict(cur)
        return self.config()

    # ── ledger ──
    def day(self, ts: float | None = None) -> str:
        return time.strftime("%Y-%m-%d", time.gmtime(self.clock() if ts is None else ts))

    def used(self, day: str | None = None) -> dict[str, float]:
        r = self.store.query("SELECT COUNT(*) AS calls, COALESCE(SUM(prompt_tokens + completion_tokens), 0) AS tokens "
                             "FROM harness_llm_usage WHERE day=?", (day or self.day(),))[0]
        tokens, price = int(r["tokens"]), self.config()["usd_per_million_tokens"]
        return {"calls": int(r["calls"]), "tokens": tokens, "usd": round(tokens / 1e6 * price, 4)}

    def check(self, prompt_chars: int) -> None:
        """Raise BudgetExceeded (with a plain-language reason) if one more call could break today's caps."""
        c, u = self.config(), self.used()
        want = est_tokens(prompt_chars) + COMPLETION_RESERVE
        if c["max_calls_per_day"] and u["calls"] + 1 > c["max_calls_per_day"]:
            raise BudgetExceeded(f"Today's LLM call limit ({int(c['max_calls_per_day'])}) is used up. Raise it in the Invent tab, or wait until tomorrow (UTC).")
        if c["max_tokens_per_day"] and u["tokens"] + want > c["max_tokens_per_day"]:
            raise BudgetExceeded(f"This call could pass today's token limit ({int(c['max_tokens_per_day'])}; about {u['tokens']} used). Raise the limit or wait until tomorrow (UTC).")
        if c["max_usd_per_day"] and c["usd_per_million_tokens"] and u["usd"] + want / 1e6 * c["usd_per_million_tokens"] > c["max_usd_per_day"]:
            raise BudgetExceeded(f"This call could pass today's estimated spend limit (${c['max_usd_per_day']:g}; about ${u['usd']:.2f} used).")

    def record(self, *, lab: str, provider: str, model: str, prompt_chars: int, completion_chars: int, ok: bool, error: str = "", ms: int = 0) -> None:
        now = self.clock()
        self.store.execute(
            "INSERT INTO harness_llm_usage (ts, day, lab, provider, model, prompt_tokens, completion_tokens, ok, error, ms) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (now, self.day(now), lab, provider, model, est_tokens(prompt_chars), est_tokens(completion_chars), 1 if ok else 0, error[:300], int(ms)))

    def summary(self, days: int = 7) -> dict[str, Any]:
        days = max(1, min(int(days), 90))
        rows = self.store.query("SELECT day, COUNT(*) AS calls, SUM(ok) AS ok, SUM(prompt_tokens + completion_tokens) AS tokens "
                                "FROM harness_llm_usage GROUP BY day ORDER BY day DESC LIMIT ?", (days,))
        price = self.config()["usd_per_million_tokens"]
        by_lab = [dict(r) for r in self.store.query("SELECT lab, COUNT(*) AS calls, SUM(prompt_tokens + completion_tokens) AS tokens "
                                                    "FROM harness_llm_usage WHERE day >= ? GROUP BY lab ORDER BY calls DESC",
                                                    (self.day(self.clock() - 86400 * (days - 1)),))]
        return {"config": self.config(), "today": self.used(), "estimated": True,
                "days": [{"day": r["day"], "calls": r["calls"], "ok": int(r["ok"] or 0), "tokens": int(r["tokens"] or 0),
                          "usd": round(int(r["tokens"] or 0) / 1e6 * price, 4)} for r in rows], "byLab": by_lab}
