"""Supersentry on the shared slot lease (fragment E1) — the lease ONLY: no batching, no journal.

A SuperAlpha cannot be multi-simulated (BRAIN also caps SUPER concurrency at 3), so unlike regular Autosentry (harness/autopilot_route.py)
there is nothing to pack and nothing to re-attach. What routing adds is the one thing that matters when the harness engine and
Supersentry run together: each SuperAlpha simulation takes ONE slot from the same lease the engine uses, so the two never start
more simulations than BRAIN's 8 slots, and the engine leaves a slot free for a Super simulation that is waiting.

Only the call that starts a simulation is wrapped; everything Super does with the result (stats, gate, tagging, DB) is unchanged. The
switch is the same flag and the same per-thread context as regular Autosentry: `engine_routing()` around Supersentry's call, on only
if `autopilot_via_engine` is on at that moment. The manual SuperAlpha screen is never routed.

Fast Stop: `abandon` is set when the run is cancelled, so workers still waiting for a slot give up at once; a simulation already
started keeps its slot until BRAIN is really done with it (released in `finally`), exactly like regular Autosentry's routing.
"""
from __future__ import annotations

import threading
import time
from typing import Any, Callable

from app.harness.autopilot_route import routing_on

OWNER = "superpilot"


def routed(sim_one: Callable[[Any, dict], dict], abandon: threading.Event, *, lease: Any = None, poll: float = 1.0,
           active: Callable[[], bool] = routing_on) -> Callable[[Any, dict], dict]:
    """`sim_one` unchanged when routing is off (or the lease cannot be loaded); otherwise a wrapper that holds one shared slot while it runs."""
    try:
        if not active():
            return sim_one
        if lease is None:
            from app.harness.engine.slots import shared_lease as lease
    except Exception:  # noqa: BLE001      setup problems fall back BEFORE any simulation starts
        return sim_one

    def wrapped(s: Any, cfg: dict) -> dict:
        lease.begin_wait(OWNER)                              # tell the engine to leave a slot for us
        try:
            while not abandon.is_set() and not lease.acquire(OWNER, 1):
                time.sleep(min(1.0, poll))
        finally:
            lease.end_wait(OWNER)
        if abandon.is_set():
            return {"alpha_id": None, "simulate_data": cfg, "error": "stopped before a simulation slot was free"}
        try:
            return sim_one(s, cfg)
        finally:
            lease.release(OWNER, 1)                          # freed when BRAIN is really done, even after a Stop

    return wrapped
