"""Alpha stats table and one-by-one production-correlation checks (plain sqlite3 through the harness Store; BRAIN is reached only through a
function you pass in, so everything here is testable without a network)."""
from __future__ import annotations

import time
from typing import Any, Callable

from app.harness.scoring import MAX_CORR, _corr, _num

COLS = ["alpha_id", "expression", "region", "delay", "universe", "neutralization", "sharpe", "fitness", "turnover", "returns", "margin",
        "drawdown", "self_corr", "prod_corr", "powerpool_corr", "tests_failed", "passed_gate", "gate_reasons", "tagged", "submitted", "created_at"]
SORTABLE = {"sharpe", "fitness", "turnover", "returns", "margin", "drawdown", "self_corr", "prod_corr", "powerpool_corr", "created_at", "tests_failed"}
RESCUE_LIMIT = 0.74


def prod_state(prod, checked_at=None) -> str:
    """'unchecked' | 'ok' (< 0.70) | 'high' (0.70-0.74: worth fixing) | 'too_high' (> 0.74)."""
    if prod is None:
        return "unchecked"
    v = abs(float(prod))
    return "ok" if v < MAX_CORR else ("high" if v <= RESCUE_LIMIT else "too_high")


def list_alphas(store, *, q: str = "", region: str = "", passed: str = "", prod: str = "", source: str = "", sort: str = "created_at",
                desc: bool = True, limit: int = 100, offset: int = 0) -> dict:
    """One page of alpha stats from Results, each row with its source (the engine task, or the tag) and a prod state."""
    have = store.columns("sim_results")
    cols = [c for c in COLS if c in have]
    where, p = ["alpha_id != ''"], []
    if q.strip():
        where.append("(alpha_id LIKE ? OR expression LIKE ?)")
        p += [f"%{q.strip()}%"] * 2
    if region.strip():
        where.append("region=?")
        p.append(region.strip().upper())
    if passed == "yes":
        where.append("COALESCE(passed_gate,0)=1")
    elif passed == "no":
        where.append("COALESCE(passed_gate,0)=0")
    if prod == "unchecked":
        where.append("prod_corr IS NULL")
    elif prod == "checked":
        where.append("prod_corr IS NOT NULL")
    elif prod == "high":
        where.append("ABS(prod_corr) >= ?")
        p.append(MAX_CORR)
    elif prod == "ok":
        where.append("ABS(prod_corr) < ?")
        p.append(MAX_CORR)
    if source == "engine":
        where.append("alpha_id IN (SELECT alpha_id FROM harness_sim_record WHERE alpha_id != '' AND task != 'autopilot')")
    elif source == "autosentry":
        where.append("(alpha_id IN (SELECT alpha_id FROM harness_sim_record WHERE task='autopilot') OR tagged LIKE '%autopilot%')")
    key = sort if sort in SORTABLE and sort in have else ("created_at" if "created_at" in have else "alpha_id")
    order = f"{'ABS(' + key + ')' if key in ('sharpe', 'fitness', 'prod_corr', 'self_corr') else key} {'DESC' if desc else 'ASC'}"
    sql_where = " AND ".join(where)
    total = store.query(f"SELECT COUNT(*) AS n FROM sim_results WHERE {sql_where}", p)[0]["n"]
    rows = store.query(f"SELECT {', '.join(cols)} FROM sim_results WHERE {sql_where} ORDER BY {order} LIMIT ? OFFSET ?",
                       [*p, int(limit), int(offset)])
    ids = [r["alpha_id"] for r in rows]
    src: dict[str, str] = {}
    if ids:
        from app.harness.store import chunks, marks
        for part in chunks(ids):
            for r in store.query(f"SELECT alpha_id, task FROM harness_sim_record WHERE alpha_id IN ({marks(len(part))})", list(part)):
                src[r["alpha_id"]] = r["task"]
    out = []
    for r in rows:
        d = {k: r[k] for k in r.keys()}
        d["source"] = src.get(d["alpha_id"]) or (d.get("tagged") or "Alpha Sentry")
        d["prod_state"] = prod_state(d.get("prod_corr"))
        out.append(d)
    return {"total": int(total), "rows": out}


def check_result(df) -> dict:
    """BRAIN's submission-check table -> {self, prod, pool, failed: [names], pending}. `pending` = BRAIN has not finished the correlation yet."""
    out: dict[str, Any] = {"self": None, "prod": None, "pool": None, "failed": [], "pending": False}
    if df is None or getattr(df, "empty", True) or "name" not in getattr(df, "columns", []):
        out["pending"] = True
        return out
    out["self"], out["prod"] = _corr(df, "self"), _corr(df, "prod")
    out["pool"] = _corr(df, "pool") or _corr(df, "power")
    if "result" in df.columns:
        for _, row in df.iterrows():
            res = str(row.get("result", "")).upper()
            nm = str(row.get("name", ""))
            if res == "FAIL":
                out["failed"].append(nm)
            elif res == "PENDING" and ("corr" in nm.lower()):
                out["pending"] = True
    if out["prod"] is None and any("prod" in str(n).lower() for n in df["name"]):
        out["pending"] = True
    return out


def save_corr(store, alpha_id: str, res: dict) -> bool:
    """Write the checked correlations into Results (and mark a passing alpha as failing when a correlation is >= 0.70; never the other way)."""
    sets, p = [], []
    for col, key in (("self_corr", "self"), ("prod_corr", "prod"), ("powerpool_corr", "pool")):
        if res.get(key) is not None and col in store.columns("sim_results"):
            sets.append(f"{col}=?")
            p.append(res[key])
    if not sets:
        return False
    if any(res.get(k) is not None and abs(res[k]) >= MAX_CORR for k in ("self", "prod", "pool")):
        sets.append("passed_gate=0")
    store.execute(f"UPDATE sim_results SET {', '.join(sets)} WHERE alpha_id=?", [*p, alpha_id])
    return True


def check_one(store, alpha_id: str, fetch: Callable[[str], Any]) -> dict:
    """Check ONE alpha's production / self correlation through `fetch(alpha_id) -> DataFrame` and store it. Never raises."""
    t0 = time.time()
    try:
        res = check_result(fetch(alpha_id))
    except Exception as e:  # noqa: BLE001
        return {"alpha_id": alpha_id, "state": "error", "message": f"{type(e).__name__}: {str(e)[:200]}", "seconds": round(time.time() - t0, 1)}
    if res["pending"] or res["prod"] is None:
        return {"alpha_id": alpha_id, "state": "pending", "message": "BRAIN has not finished the correlation yet; try again in a minute.",
                "seconds": round(time.time() - t0, 1)}
    save_corr(store, alpha_id, res)
    return {"alpha_id": alpha_id, "state": prod_state(res["prod"]), "prod": res["prod"], "self": res["self"], "pool": res["pool"],
            "failed": res["failed"], "seconds": round(time.time() - t0, 1)}


class CheckRun:
    """One-after-another prod checks with a wait before each (default 60 s) and a Stop. State is plain data the UI polls. `sleep` / `check` are injectable."""

    def __init__(self) -> None:
        self.stop_flag = False
        self.state: dict[str, Any] = {"running": False, "total": 0, "done": 0, "current": "", "waiting": 0, "results": [], "message": ""}

    def stop(self) -> None:
        self.stop_flag = True

    def run(self, store, ids: list[str], *, delay: float, recheck: bool, fetch, sleep=time.sleep) -> dict:
        todo = list(dict.fromkeys(ids))
        if not recheck and todo:
            from app.harness.store import chunks, marks
            seen: set[str] = set()
            for part in chunks(todo):
                seen |= {r["alpha_id"] for r in store.query(f"SELECT alpha_id FROM sim_results WHERE prod_corr IS NOT NULL AND alpha_id IN ({marks(len(part))})", list(part))}
            skipped = [a for a in todo if a in seen]
            todo = [a for a in todo if a not in seen]
        else:
            skipped = []
        self.stop_flag = False
        self.state = {"running": True, "total": len(todo), "done": 0, "current": "", "waiting": 0, "skipped": len(skipped), "results": [], "message": ""}
        for i, aid in enumerate(todo):
            wait = max(0, int(delay))
            for left in range(wait, 0, -1):                 # the wait comes BEFORE every check, so BRAIN is never hit back to back
                if self.stop_flag:
                    break
                self.state["waiting"], self.state["current"] = left, aid
                sleep(1)
            if self.stop_flag:
                break
            self.state.update(waiting=0, current=aid)
            r = check_one(store, aid, fetch)
            self.state["results"].append(r)
            self.state["done"] += 1
        self.state.update(running=False, waiting=0, current="",
                          message="stopped" if self.stop_flag else f"checked {self.state['done']}, skipped {len(skipped)} already checked")
        return self.state


def missing_rows(store, winners: list[dict] | None = None, q: str = "") -> list[dict]:
    """Alphas we know about but Results does not have (engine records with an alpha id, Autosentry/Supersentry winners): shown red in the table."""
    known: dict[str, dict] = {}
    for r in store.query("SELECT alpha_id, task, payload FROM harness_sim_record WHERE alpha_id != '' ORDER BY id DESC LIMIT 3000"):
        try:
            import json
            expr = str(json.loads(r["payload"]).get("regular", ""))
        except Exception:  # noqa: BLE001
            expr = ""
        known.setdefault(r["alpha_id"], {"alpha_id": r["alpha_id"], "expression": expr,
                                         "source": {"autopilot": "Autosentry", "superpilot": "Supersentry"}.get(r["task"], f"Engine: {r['task']}")})
    for w in winners or []:
        aid = w.get("alpha_id")
        if aid:
            known.setdefault(aid, {"alpha_id": aid, "expression": w.get("expr", ""), "source": "Autosentry winner"})
            known[aid].update({k: w.get(k) for k in ("sharpe", "fitness", "turnover", "self_corr", "prod_corr", "neutralization") if w.get(k) is not None})
    if not known:
        return []
    from app.harness.store import chunks, marks
    have: set[str] = set()
    for part in chunks(list(known)):
        have |= {x["alpha_id"] for x in store.query(f"SELECT alpha_id FROM sim_results WHERE alpha_id IN ({marks(len(part))})", list(part))}
    needle = q.strip().lower()
    out = []
    for aid, d in known.items():
        if aid in have or (needle and needle not in aid.lower() and needle not in d["expression"].lower()):
            continue
        d.update(missing=True, prod_state=prod_state(d.get("prod_corr")))
        out.append(d)
    return out


def missing_rows(store, winners: list[dict] | None = None, q: str = "") -> list[dict]:
    """Alphas we know about but Results does not have (engine records with an alpha id, Autosentry/Supersentry winners): shown red in the table."""
    import json
    known: dict[str, dict] = {}
    for r in store.query("SELECT alpha_id, task, payload FROM harness_sim_record WHERE alpha_id != '' ORDER BY id DESC LIMIT 3000"):
        try:
            expr = str(json.loads(r["payload"]).get("regular", ""))
        except Exception:  # noqa: BLE001
            expr = ""
        known.setdefault(r["alpha_id"], {"alpha_id": r["alpha_id"], "expression": expr,
                                         "source": {"autopilot": "Autosentry", "superpilot": "Supersentry"}.get(r["task"], f"Engine: {r['task']}")})
    for w in winners or []:
        aid = w.get("alpha_id")
        if aid:
            known.setdefault(aid, {"alpha_id": aid, "expression": w.get("expr", ""), "source": "Autosentry winner"})
            known[aid].update({k: w.get(k) for k in ("sharpe", "fitness", "turnover", "self_corr", "prod_corr", "neutralization") if w.get(k) is not None})
    if not known:
        return []
    from app.harness.store import chunks, marks
    have: set[str] = set()
    for part in chunks(list(known)):
        have |= {x["alpha_id"] for x in store.query(f"SELECT alpha_id FROM sim_results WHERE alpha_id IN ({marks(len(part))})", list(part))}
    needle = q.strip().lower()
    out = []
    for aid, d in known.items():
        if aid in have or (needle and needle not in aid.lower() and needle not in d["expression"].lower()):
            continue
        d.update(missing=True, prod_state=prod_state(d.get("prod_corr")))
        out.append(d)
    return out
