"""Score finished harness simulations and store them as ordinary Alpha Sentry results (sim_results), so the
existing Results, Vault and Portfolio screens show lab output. Verdict rules mirror Alpha Sentry's own gate:
|Sharpe|/|Fitness| thresholds by delay, turnover < 0.70, any IS test fail, submission-check fail, or
self/prod/power-pool correlation >= 0.70 all keep an alpha from "passing"."""
from __future__ import annotations

import json
import math
from typing import Any, Callable

MAX_TURNOVER = 0.70
MAX_CORR = 0.70


def gate_thresholds(delay: int) -> dict:
    return {"sharpe": 2.69, "fitness": 1.5} if int(delay) == 0 else {"sharpe": 1.58, "fitness": 1.0}


def _num(v):
    try:
        f = float(v)
        return None if (math.isnan(f) or math.isinf(f)) else f
    except (TypeError, ValueError):
        return None


def _norm_turnover(t):
    if t is None:
        return None
    t = abs(t)
    return t / 100.0 if t > 1.5 else t     # BRAIN may give 0.42 or 42


def _corr(df, *needles):
    if df is None or getattr(df, "empty", True) or "name" not in df.columns:
        return None
    for _, row in df.iterrows():
        nm = str(row.get("name", "")).lower()
        if all(n in nm for n in needles):
            return _num(row.get("value"))
    return None


def build_row(alpha_id: str, simulate_data: dict, stats: dict, operators_in: Callable[[str], list] | None = None) -> dict[str, Any]:
    """stats = ace.get_specified_alpha_stats output ({is_stats, is_tests, check_submission} DataFrames)."""
    s = simulate_data.get("settings") or {}
    expr = simulate_data.get("regular") or ""
    delay = int(s.get("delay", 1))
    thr = gate_thresholds(delay)
    sharpe = fitness = turnover = returns = margin = drawdown = None
    st = stats.get("is_stats")
    if hasattr(st, "empty") and not st.empty:
        d = st.iloc[0].to_dict()
        sharpe, fitness, turnover, returns = (_num(d.get(k)) for k in ("sharpe", "fitness", "turnover", "returns"))
        margin, drawdown = _num(d.get("margin")), _num(d.get("drawdown"))
    tests = stats.get("is_tests")
    tests_failed = int((tests["result"] == "FAIL").sum()) if (hasattr(tests, "empty") and not tests.empty and "result" in tests.columns) else 0
    sub = stats.get("check_submission")
    self_c, prod_c = _corr(sub, "self"), _corr(sub, "prod")
    pool_c = _corr(sub, "pool") or _corr(sub, "power")
    sub_fail = bool(hasattr(sub, "empty") and not sub.empty and "result" in sub.columns and (sub["result"] == "FAIL").any())
    turn = _norm_turnover(turnover)
    reasons: list[str] = []
    if sharpe is None or abs(sharpe) < thr["sharpe"]:
        reasons.append(f"|Sharpe| {abs(sharpe):.2f}<{thr['sharpe']}" if sharpe is not None else "no Sharpe")
    if fitness is None or abs(fitness) < thr["fitness"]:
        reasons.append(f"|Fitness| {abs(fitness):.2f}<{thr['fitness']}" if fitness is not None else "no Fitness")
    if turn is not None and turn >= MAX_TURNOVER:
        reasons.append(f"turnover {turn:.0%}≥{MAX_TURNOVER:.0%}")
    if tests_failed:
        reasons.append(f"{tests_failed} IS test fail")
    if sub_fail:
        reasons.append("submission check FAIL")
    for label, val in (("self", self_c), ("prod", prod_c), ("powerpool", pool_c)):
        if val is not None and abs(val) >= MAX_CORR:
            reasons.append(f"{label}-corr {abs(val):.2f}≥{MAX_CORR}")
    return {"alpha_id": alpha_id, "expression": expr, "region": s.get("region", ""), "delay": delay,
            "universe": s.get("universe", ""), "neutralization": s.get("neutralization", ""),
            "sharpe": sharpe, "fitness": fitness, "turnover": turn, "returns": returns, "margin": margin,
            "drawdown": drawdown, "self_corr": self_c, "prod_corr": prod_c, "powerpool_corr": pool_c,
            "tests_failed": tests_failed, "passed_gate": not reasons, "gate_reasons": json.dumps(reasons),
            "n_ops": len(operators_in(expr)) if operators_in else 0, "tagged": "harness"}


def ace_learning_hooks(row: dict) -> None:
    """Feed a scored result into Alpha Sentry's own learning, exactly as run_simulation does for its results: credit the
    operators the alpha used (weighted by |fitness|) and the template stats. No-ops if Alpha Sentry isn't importable."""
    try:
        from app.simulation import service as S
    except Exception:  # noqa: BLE001
        return
    expr, fitness = row.get("expression") or "", row.get("fitness")
    if fitness is not None and abs(fitness) > 0:
        try:
            S._credit_usage(row.get("region", ""), list(set(S._operators_in(expr))), [], fitness)
        except Exception:  # noqa: BLE001
            pass
    if expr:
        try:
            S._credit_template_stat(row.get("region", ""), expr, row.get("sharpe"), fitness, bool(row.get("passed_gate")))
        except Exception:  # noqa: BLE001
            pass


def score_pending(limit: int = 40, fetch: Callable[[str, dict], dict] | None = None, store: Any = None,
                  learn: Callable[[dict], None] | None = ace_learning_hooks, winner: dict | None = None,
                  tagger: Callable[[str, str, str], Any] | None = None) -> dict[str, int]:
    """Score done-but-unscored harness records into sim_results. Reads from BRAIN only (no sim quota).
    Only columns that exist in this database are written, so an older Alpha Sentry layout cannot break it.

    Winner tag (E2): when a harness-level winner tag is set (harness/winner.py), a passing alpha with |Fitness| over the threshold gets that tag
    and colour in BRAIN, as Alpha Sentry's own runs do, and its stored row records it; otherwise the plain tag "harness" stays. `winner` / `tagger` are
    injectable for tests; by default the saved settings and BRAIN are used."""
    import time

    from app.harness import winner as W

    from app.harness import brain_port
    from app.harness.labs.exprtools import operators_in as ops
    from app.harness.store import default_store

    store = store or default_store()
    fetch = fetch or (lambda aid, sd: brain_port.alpha_stats(aid, sd, checks=True))
    wcfg = W.current() if winner is None else winner
    tagger = tagger or brain_port.tag_alpha
    have_cols = store.columns("sim_results")
    scored = failed = 0
    todo = store.query("SELECT id, alpha_id, payload FROM harness_sim_record WHERE status='done' AND alpha_id != '' ORDER BY id LIMIT ?", (limit,))
    for rec in todo:
        try:
            aid, payload = rec["alpha_id"], json.loads(rec["payload"])
            if not store.query("SELECT 1 FROM sim_results WHERE alpha_id=? LIMIT 1", (aid,)):
                row = build_row(aid, payload, fetch(aid, payload), ops)
                row["created_at"] = time.time()
                row["tagged"] = W.apply(row, wcfg, tagger, row.get("tagged", "harness"))      # while passed_gate is still a bool
                row["passed_gate"] = 1 if row["passed_gate"] else 0
                full = dict(row)
                row = {k: v for k, v in row.items() if k in have_cols}
                store.execute(f"INSERT INTO sim_results ({', '.join(row)}) VALUES ({', '.join('?' * len(row))})", list(row.values()))
                if learn:
                    try:
                        learn(full)     # Alpha Sentry's operator/template credit; a failure here never loses the stored result
                    except Exception:  # noqa: BLE001
                        pass
            store.execute("UPDATE harness_sim_record SET status='scored', updated=? WHERE id=?", (time.time(), rec["id"]))
            scored += 1
        except Exception as e:  # noqa: BLE001
            failed += 1
            try:
                store.execute("UPDATE harness_sim_record SET error=?, updated=? WHERE id=?", (f"scoring failed: {type(e).__name__}: {str(e)[:200]}", time.time(), rec["id"]))
            except Exception:  # noqa: BLE001
                pass
    return {"scored": scored, "failed": failed}
