"""Saved searches: a named template + the sampler / objectives / budget / scope to run it with (table harness_saved_search)."""
from __future__ import annotations

import json
import time
from typing import Any

from app.harness.store import Store


def _public(r: Any) -> dict[str, Any]:
    return {"id": r["id"], "name": r["name"], "template": r["template"], "sampler": r["sampler"],
            "objectives": json.loads(r["objectives"]), "budget": r["budget"], "batch": r["batch"], "cores": r["cores"],
            "seed": r["seed"], "scope": json.loads(r["scope"]), "created": r["created"], "updated": r["updated"]}


def save(store: Store, name: str, template: str, *, sampler: str = "", objectives: list[str] | None = None, budget: int = 50,
         batch: int = 10, cores: int = 2, seed: int | None = None, scope: dict[str, Any] | None = None) -> dict[str, Any]:
    """Create, or overwrite the search with the same name."""
    name = (name or "").strip()
    if not name:
        raise ValueError("Give the saved search a name.")
    if len(name) > 120:
        raise ValueError("Saved-search names are limited to 120 characters.")
    if not (template or "").strip():
        raise ValueError("There is no template to save.")
    now = time.time()
    store.execute(
        "INSERT INTO harness_saved_search (name, template, sampler, objectives, budget, batch, cores, seed, scope, created, updated) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(name) DO UPDATE SET template=excluded.template, sampler=excluded.sampler, "
        "objectives=excluded.objectives, budget=excluded.budget, batch=excluded.batch, cores=excluded.cores, seed=excluded.seed, "
        "scope=excluded.scope, updated=excluded.updated",
        (name, template, sampler, json.dumps(objectives or []), int(budget), int(batch), int(cores), seed, json.dumps(scope or {}), now, now))
    return get(store, name)                                    # type: ignore[return-value]


def get(store: Store, name_or_id: str | int) -> dict[str, Any] | None:
    col = "id" if isinstance(name_or_id, int) else "name"
    rows = store.query(f"SELECT * FROM harness_saved_search WHERE {col}=?", (name_or_id,))
    return _public(rows[0]) if rows else None


def list_all(store: Store) -> list[dict[str, Any]]:
    return [_public(r) for r in store.query("SELECT * FROM harness_saved_search ORDER BY updated DESC, id DESC")]


def delete(store: Store, saved_id: int) -> bool:
    n = store.query("SELECT COUNT(*) AS n FROM harness_saved_search WHERE id=?", (saved_id,))[0]["n"]
    store.execute("DELETE FROM harness_saved_search WHERE id=?", (saved_id,))
    return bool(n)
