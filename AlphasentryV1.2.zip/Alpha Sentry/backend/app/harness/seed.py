"""Bring the user's own knowledge into every version of the app, without ever overwriting what is already there (fragment G2).

The project ships `seed/ace_studio_v2.seed.db`, a SMALL file holding ONLY the public catalogue (`SHIPPED`): datasets, fields, operator reference.
No results, vault alphas, library, lessons or usage ship with the app, so every user starts with their own. (The merge code can still carry
history tables, for private seeds made with `tools/make_seed.py --with-history`.) On startup (flag
`harness_seed`, on by default because it was asked for) its rows are merged into the live database:

  * INSERT ONLY. A row is added when no row with the same natural key exists; existing rows are never changed or removed, and ids are never
    reused (the live database assigns its own).
  * ONCE per seed file (its SHA-256 is recorded in `harness_seed_log`), so rows you delete later do not come back on the next start.
    "Merge again" (force) re-adds what is missing.
  * A backup of the live database is written once before the first merge to `<data>/backups/`.
  * Live operational state is never part of a seed: simulation records, tasks, trials, plan runs, LLM usage, flags.

`build_seed()` makes a seed from any Alpha Sentry database (tools/make_seed.py is its command line).
"""
from __future__ import annotations

import hashlib
import shutil
import sqlite3
import time
from pathlib import Path
from typing import Any

SEED_NAME = "ace_studio_v2.seed.db"
# table -> natural key columns (None = the table's own primary key without `id`, handled by INSERT OR IGNORE)
TABLES: dict[str, tuple[str, ...]] = {
    "datasets": ("dataset_id", "region", "delay"),
    "fields": ("field_id", "region", "delay"),
    "operator_ref": ("name", "scope"),
    "sim_results": ("alpha_id",),
    "vault_alphas": ("alpha_id",),
    "template_stats": ("skeleton", "region"),
    "usage": ("kind", "key", "region"),
    "hypothesis_log": ("fingerprint", "region"),
    "harness_alpha_info": ("alpha_id",),
}
# What ships with the app: only the public catalogue (datasets, fields, operator reference), never anyone's own work.
SHIPPED = ("datasets", "fields", "operator_ref")
ORDER = list(TABLES)                         # sim_results before vault_alphas: the latter links to it
SKIP_COLS = {"id"}                           # autoincrement keys belong to the live database


def seed_path(repo_root: Path | None = None) -> Path:
    if repo_root is None:
        from app.core.config import get_settings
        repo_root = Path(get_settings().repo_root)
    return Path(repo_root) / "seed" / SEED_NAME


def sha_of(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _cols(c: sqlite3.Connection, schema: str, table: str) -> list[str]:
    return [r[1] for r in c.execute(f'PRAGMA {schema}.table_info("{table}")')]


def _has(c: sqlite3.Connection, schema: str, table: str) -> bool:
    return c.execute(f"SELECT 1 FROM {schema}.sqlite_master WHERE type='table' AND name=?", (table,)).fetchone() is not None


def build_seed(source_db: Path, out: Path, tables: tuple[str, ...] | None = None) -> dict[str, int]:
    """Copy only the TABLES rows of an Alpha Sentry database into a fresh, compact seed file. The source is opened read-only."""
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        out.unlink()
    src = sqlite3.connect(f"file:{Path(source_db).as_posix()}?mode=ro", uri=True)
    dst = sqlite3.connect(out)
    counts: dict[str, int] = {}
    try:
        for t in [x for x in ORDER if tables is None or x in tables]:
            row = src.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (t,)).fetchone()
            if not row or not row[0]:
                continue
            dst.execute(row[0])
            cols = [r[1] for r in src.execute(f'PRAGMA table_info("{t}")')]
            q = ",".join(f'"{x}"' for x in cols)
            rows = src.execute(f'SELECT {q} FROM "{t}"').fetchall()
            dst.executemany(f'INSERT OR IGNORE INTO "{t}" ({q}) VALUES ({",".join("?" * len(cols))})', rows)
            counts[t] = len(rows)
        dst.commit()
        dst.execute("VACUUM")
    finally:
        src.close()
        dst.close()
    return counts


def _ensure_log(c: sqlite3.Connection) -> None:
    c.execute("CREATE TABLE IF NOT EXISTS harness_seed_log (id INTEGER PRIMARY KEY AUTOINCREMENT, seed_sha TEXT NOT NULL, applied REAL NOT NULL, "
              "forced INTEGER NOT NULL DEFAULT 0, report TEXT NOT NULL DEFAULT '')")


def status(live_db: Path, seed: Path | None = None) -> dict[str, Any]:
    seed = seed or seed_path()
    out: dict[str, Any] = {"seedFile": str(seed), "present": seed.exists(), "sha": None, "applied": None, "tables": {}}
    if not seed.exists():
        return out
    out["sha"] = sha_of(seed)
    c = sqlite3.connect(live_db, timeout=30)
    try:
        _ensure_log(c)
        r = c.execute("SELECT applied, forced, report FROM harness_seed_log WHERE seed_sha=? ORDER BY id DESC LIMIT 1", (out["sha"],)).fetchone()
        out["applied"] = {"at": r[0], "forced": bool(r[1]), "report": r[2]} if r else None
        c.execute("ATTACH DATABASE ? AS seed", (str(seed),))
        for t in ORDER:
            if _has(c, "seed", t):
                out["tables"][t] = {"inSeed": c.execute(f'SELECT COUNT(*) FROM seed."{t}"').fetchone()[0],
                                    "live": c.execute(f'SELECT COUNT(*) FROM main."{t}"').fetchone()[0] if _has(c, "main", t) else None}
    finally:
        c.close()
    return out


def merge(live_db: Path, seed: Path | None = None, *, force: bool = False, backup_dir: Path | None = None, dry_run: bool = False) -> dict[str, Any]:
    """Insert the seed's missing rows into `live_db`. Returns {skipped | added per table, ...}. Never raises for one bad table."""
    seed = seed or seed_path()
    if not seed.exists():
        return {"ok": False, "skipped": "no seed file", "added": {}}
    sha = sha_of(seed)
    c = sqlite3.connect(live_db, timeout=30, isolation_level=None)          # autocommit: each table is its own explicit transaction
    try:
        _ensure_log(c)
        if not force and not dry_run and c.execute("SELECT 1 FROM harness_seed_log WHERE seed_sha=?", (sha,)).fetchone():
            return {"ok": True, "skipped": "this seed was already merged", "sha": sha, "added": {}}
        if not dry_run and backup_dir is not None and not any(Path(backup_dir).glob(f"*pre_seed.{sha[:8]}*")):
            Path(backup_dir).mkdir(parents=True, exist_ok=True)
            b = sqlite3.connect(Path(backup_dir) / f"{Path(live_db).stem}.pre_seed.{sha[:8]}.db")
            try:
                c.backup(b)
            finally:
                b.close()
        c.execute("ATTACH DATABASE ? AS seed", (str(seed),))
        added: dict[str, int] = {}
        problems: dict[str, str] = {}
        for t, key in TABLES.items():
            if not (_has(c, "seed", t) and _has(c, "main", t)):
                continue
            live_cols, seed_cols = _cols(c, "main", t), _cols(c, "seed", t)
            cols = [x for x in seed_cols if x in live_cols and x not in SKIP_COLS]
            if not cols or any(k not in cols for k in key):
                problems[t] = "columns do not match the live table"
                continue
            q = ",".join(f'"{x}"' for x in cols)
            sel = ",".join(f's."{x}"' for x in cols)
            if t == "vault_alphas" and "source_sim_result_id" in cols:        # re-point the link at the live sim_results id
                sel = sel.replace('s."source_sim_result_id"', '''COALESCE((SELECT l.id FROM main.sim_results l JOIN seed.sim_results x ON x.alpha_id = l.alpha_id
                                                                       WHERE x.id = s.source_sim_result_id LIMIT 1), 0)''')
            where = " AND ".join(f'm."{k}" IS s."{k}"' for k in key)
            sql_from = f'FROM seed."{t}" s WHERE NOT EXISTS (SELECT 1 FROM main."{t}" m WHERE {where})'
            try:
                if dry_run:
                    added[t] = c.execute(f"SELECT COUNT(*) {sql_from}").fetchone()[0]
                    continue
                before = c.total_changes
                c.execute("BEGIN")
                c.execute(f'INSERT INTO main."{t}" ({q}) SELECT {sel} {sql_from}')
                c.execute("COMMIT")
                added[t] = c.total_changes - before
            except sqlite3.Error as e:
                try:
                    c.execute("ROLLBACK")
                except sqlite3.Error:
                    pass
                problems[t] = f"{type(e).__name__}: {e}"[:200]
        report = {"added": added, "problems": problems}
        if not dry_run:
            c.execute("INSERT INTO harness_seed_log (seed_sha, applied, forced, report) VALUES (?,?,?,?)",
                      (sha, time.time(), 1 if force else 0, str(report)[:2000]))
            c.commit()
        return {"ok": not problems, "sha": sha, "dryRun": dry_run, **report}
    finally:
        c.close()


def merge_on_startup() -> dict[str, Any]:
    """Called once at app start. Never raises."""
    try:
        from app.core.config import get_settings
        from app.harness import flags
        if not flags.enabled("harness_seed"):
            return {"ok": True, "skipped": "switched off"}
        s = get_settings()
        return merge(Path(s.db_path), backup_dir=Path(s.data_dir) / "backups")
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
