"""Feature flags for the SentryEngine port. All default OFF except harness_seed (asked for); stored next to the DB so they survive
restarts. Thread-safe, no changes to Alpha Sentry's Settings model."""
from __future__ import annotations

import json
import threading
from pathlib import Path


DEFAULTS: dict[str, bool] = {
    "harness_engine": False,      # batch engine, tasks, relocate/repair and the other labs
    "harness_vault": False,       # returns vault + mixing
    "harness_planning": False,    # skeleton tracker, daily plan, budget, key vault
    "harness_llm": False,         # labs that call your LLM (Invent). Spends your API quota, within the daily caps in llm_budget
    "harness_seed": True,         # ON by default (asked for): on startup, merge the shipped seed/ database into yours, insert-only, once per seed file
    "autopilot_via_engine": False,  # Autosentry batches use the shared slot lease + crash journal; Supersentry uses the lease only
}
_lock = threading.Lock()


def _path() -> Path:
    from app.core.config import get_settings
    d = Path(get_settings().data_dir) / "harness"
    d.mkdir(parents=True, exist_ok=True)
    return d / "flags.json"


def get_all() -> dict[str, bool]:
    with _lock:
        out = dict(DEFAULTS)
        try:
            raw = json.loads(_path().read_text(encoding="utf-8"))
            out.update({k: bool(v) for k, v in raw.items() if k in DEFAULTS})
        except Exception:  # noqa: BLE001
            pass
        return out


def enabled(name: str) -> bool:
    return bool(get_all().get(name, False))


def set_flag(name: str, value: bool) -> dict[str, bool]:
    if name not in DEFAULTS:
        raise KeyError(name)
    with _lock:
        cur = dict(DEFAULTS)
        try:
            cur.update(json.loads(_path().read_text(encoding="utf-8")))
        except Exception:  # noqa: BLE001
            pass
        cur[name] = bool(value)
        _path().write_text(json.dumps(cur, indent=2), encoding="utf-8")
    return get_all()
