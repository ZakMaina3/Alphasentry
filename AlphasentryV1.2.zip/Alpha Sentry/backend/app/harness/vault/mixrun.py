"""Turn chosen alpha groups into one combined alpha each (ported from alpha_harness.api.vault mix/run).

Members must share a scope AND a neutralization: scope because combining USA with CHN is not a trade;
neutralization because the combined alpha gets exactly one, and the predicted Sharpe is only meaningful
when every member was neutralized the same way (neutralization is linear)."""
from __future__ import annotations

from typing import Any

from app.harness.payload import Scope, make_payload
from app.harness.vault.combine import Strategy, build, recommend


def scope_problems(members: list[dict[str, Any]]) -> list[str]:
    problems: list[str] = []
    scopes = {(m["instrument_type"], m["region"], m["delay"], m["universe"]) for m in members}
    if len(scopes) > 1:
        labels = sorted(f"{s[1]}/D{s[2]}/{s[3]}" for s in scopes)
        problems.append(f"These ran in different scopes ({', '.join(labels)}), so combining them would not be a tradeable alpha.")
    neuts = {m.get("neutralization") for m in members}
    if len(neuts) > 1:
        named = sorted(str(n) for n in neuts)
        problems.append(f"They were neutralized differently ({', '.join(named)}). The combined alpha gets only one "
                        "neutralization, so its behaviour would not be the sum of these — and the predicted Sharpe "
                        "would not mean anything.")
    return problems


def preview(members: list[dict[str, Any]], strategy: str | None = None, weights: list[float] | None = None) -> dict:
    exprs = [str(m.get("expression") or "") for m in members]
    advice = recommend(exprs)
    chosen = Strategy(strategy) if strategy else advice.strategy
    expression = build(exprs, strategy=chosen, weights=weights)      # ValueError if it cannot be combined
    return {"members": [m["alpha_id"] for m in members], "expression": expression, "strategy": str(chosen),
            "recommended": advice.to_dict(), "problems": scope_problems(members)}


def build_requests(groups: list[list[str]], lookup: dict[str, dict[str, Any]], strategy: str | None = None):
    """-> (requests, built, problems). Decay/truncation are properties of the NEW alpha (0 / 0.08), not
    inherited averages: the members' own values shaped series that were already measured."""
    requests: list[dict] = []
    built: list[dict] = []
    problems: list[dict] = []
    for group in groups:
        if not 2 <= len(group) <= 4:
            problems.append({"group": group, "reason": "A mix needs between two and four alphas."})
            continue
        missing = [m for m in group if m not in lookup]
        if missing:
            problems.append({"group": group, "reason": f"Not found in Alpha Sentry results: {', '.join(missing)}."})
            continue
        members = [lookup[m] for m in group]
        blockers = scope_problems(members)
        if blockers:
            problems.append({"group": group, "reason": " ".join(blockers)})
            continue
        exprs = [str(m.get("expression") or "") for m in members]
        chosen = Strategy(strategy) if strategy else recommend(exprs).strategy
        try:
            expression = build(exprs, strategy=chosen)
        except ValueError as exc:
            problems.append({"group": group, "reason": str(exc)})
            continue
        f = members[0]
        requests.append(make_payload(expression, Scope(f["region"], f["delay"], f["universe"], f["instrument_type"]),
                                     neutralization=f.get("neutralization"), decay=0, truncation=0.08))
        built.append({"group": group, "expression": expression, "strategy": str(chosen)})
    return requests, built, problems
