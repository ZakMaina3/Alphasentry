"""Returns vault storage + backfill (plain sqlite3). ACE-specific loading is in ace_vault."""
from __future__ import annotations

from typing import Any, Callable, Iterable

from app.harness.store import Store, chunks, marks


class PnlStore:
    def __init__(self, store: Store) -> None:
        self.store = store

    def ids_with_pnl(self, ids: Iterable[str]) -> set[str]:
        out: set[str] = set()
        for part in chunks(list(ids)):
            out |= {r["alpha_id"] for r in self.store.query(
                f"SELECT DISTINCT alpha_id FROM harness_alpha_pnl WHERE alpha_id IN ({marks(len(part))})", part)}
        return out

    def save(self, alpha_id: str, rows: list[tuple[str, float]]) -> int:
        with self.store.connect() as c:
            before = c.total_changes
            c.executemany("INSERT OR IGNORE INTO harness_alpha_pnl (alpha_id, date, pnl) VALUES (?,?,?)",
                          [(alpha_id, d, float(v)) for d, v in rows])
            return c.total_changes - before

    def load(self, ids: Iterable[str]) -> dict[str, dict[str, float]]:
        ids = list(ids)
        out: dict[str, dict[str, float]] = {i: {} for i in ids}
        for part in chunks(ids):
            for r in self.store.query(f"SELECT alpha_id, date, pnl FROM harness_alpha_pnl WHERE alpha_id IN ({marks(len(part))})", part):
                out[r["alpha_id"]][r["date"]] = float(r["pnl"] or 0.0)
        return out


def backfill(store: PnlStore, alpha_ids: list[str], fetch: Callable[[str], list[tuple[str, float]]], *,
             progress: Callable | None = None, should_cancel: Callable[[], bool] | None = None) -> dict[str, Any]:
    """Fetch and store daily returns for alphas that have none. One request per alpha; a failure on one
    alpha never stops the rest. `fetch(alpha_id)` returns [(YYYY-MM-DD, pnl)]."""
    have = store.ids_with_pnl(alpha_ids)
    todo = [a for a in alpha_ids if a not in have]
    done = failed = 0
    errors: list[str] = []
    if progress:
        progress(total=len(todo), message=f"{len(todo)} alpha(s) need returns")
    for i, a in enumerate(todo, 1):
        if should_cancel and should_cancel():
            break
        try:
            rows = fetch(a)
            if rows:
                store.save(a, rows)
                done += 1
            else:
                failed += 1
        except Exception as e:  # noqa: BLE001
            failed += 1
            if len(errors) < 5:
                errors.append(f"{a}: {e}")
        if progress:
            progress(done=i)
    return {"requested": len(todo), "stored": done, "failed": failed, "alreadyStored": len(alpha_ids) - len(todo),
            "errors": errors}
