"""Wires the returns vault + Mixer to Alpha Sentry (plain sqlite3): sim_results rows supply Sharpe/expression/
neutralization/submitted, harness_alpha_pnl supplies the daily series, BRAIN's daily-pnl recordset fills gaps."""
from __future__ import annotations


from app.harness.labs import ace_sources as src
from app.harness.payload import Scope
from app.harness.store import chunks, default_store, marks
from app.harness.vault.mixing import MIN_OVERLAP, Mixer, Series, correlation
from app.harness.vault.store import PnlStore, backfill


def pnl_store() -> PnlStore:
    return PnlStore(default_store())


def fetch_daily_pnl(alpha_id: str) -> list[tuple[str, float]]:
    from app.harness import brain_port
    df = brain_port.daily_pnl(alpha_id)
    if df is None or getattr(df, "empty", True):
        return []
    df = df.reset_index()
    col = next((c for c in df.columns if str(c).lower() == "pnl"), None)
    dcol = next((c for c in df.columns if "date" in str(c).lower()), df.columns[0])
    if col is None:
        return []
    return [(str(d)[:10], float(v)) for d, v in zip(df[dcol], df[col]) if v == v]     # drop NaN


def load_series(*, region, delay, universe, instrument_type="EQUITY", neutralization=None, min_sharpe=0.7,
                limit=200, include_submitted=True):
    store = pnl_store()
    rows = src.scoped_alphas(Scope(region, delay, universe, instrument_type), min_abs_sharpe=min_sharpe,
                             neutralization=neutralization, limit=limit * 3)
    have = store.ids_with_pnl(r["alpha_id"] for r in rows)
    rows = [r for r in rows if r["alpha_id"] in have][:limit]
    if not rows:
        return [], []
    by = store.load(r["alpha_id"] for r in rows)
    common = None
    for v in by.values():
        common = set(v) if common is None else common & set(v)
    dates = sorted(common or [])
    if len(dates) < MIN_OVERLAP:                  # a shared calendar, or the correlations mean nothing
        return [], dates
    series = [Series(alpha_id=r["alpha_id"], values=[by[r["alpha_id"]][d] for d in dates], sharpe=float(r["sharpe"]),
                     expression=r["expression"], submitted=r["submitted"], neutralization=r["neutralization"]) for r in rows]
    if not include_submitted:
        series = [s for s in series if not s.submitted]
    return series, dates


def load_submitted(scope: dict) -> list[dict]:
    rows = src.scoped_alphas(Scope(scope["region"], scope["delay"], scope["universe"], scope.get("instrumentType") or "EQUITY"),
                             min_abs_sharpe=0.0, submitted=True)
    by = pnl_store().load(r["alpha_id"] for r in rows)
    return [{"alpha_id": r["alpha_id"], "sharpe": float(r["sharpe"]), "by_date": by[r["alpha_id"]]}
            for r in rows if by[r["alpha_id"]]]


mixer = Mixer(load_series, load_submitted)


def backfill_scope(region, delay, universe, min_sharpe=0.7, limit=200, progress=None, should_cancel=None) -> dict:
    ids = [r["alpha_id"] for r in src.scoped_alphas(Scope(region, delay, universe), min_abs_sharpe=min_sharpe, limit=limit)]
    return backfill(pnl_store(), ids, fetch_daily_pnl, progress=progress, should_cancel=should_cancel)


def closest_partners(region, delay, universe, wanted: set[str]) -> dict[str, str]:
    """For each wanted alpha, the stored alpha it correlates with most (expression inlined by Repair for
    self-correlation fixes). Multi-statement partners are skipped: inlined whole, their working lines would
    be left behind and the result would not parse."""
    if not wanted:
        return {}
    series, _ = load_series(region=region, delay=delay, universe=universe, min_sharpe=0.0, limit=120)
    out: dict[str, str] = {}
    for seed in (s for s in series if s.alpha_id in wanted):
        best, closest = 0.0, None
        for other in series:
            if other.alpha_id == seed.alpha_id or not other.expression or ";" in other.expression:
                continue
            v = abs(correlation(seed.values, other.values))
            if v > best:
                best, closest = v, other.expression
        if closest:
            out[seed.alpha_id] = closest
    return out


def by_ids(ids: list[str]) -> dict[str, dict]:
    """sim_results rows keyed by alpha id, shaped for mixrun (instrument type is EQUITY: Alpha Sentry does not store it)."""
    out: dict[str, dict] = {}
    for part in chunks(list(ids)):
        for r in default_store().query(
                f"SELECT alpha_id, expression, region, delay, universe, neutralization FROM sim_results "
                f"WHERE alpha_id IN ({marks(len(part))})", part):
            out.setdefault(r["alpha_id"], {"alpha_id": r["alpha_id"], "expression": r["expression"], "instrument_type": "EQUITY",
                                           "region": r["region"], "delay": r["delay"], "universe": r["universe"],
                                           "neutralization": r["neutralization"]})
    return out
