"""Returns vault + mixing: store daily PnL per alpha, find uncorrelated groups worth mixing, and
predict (offline, from stored series) whether a mix would pass the platform's self-correlation test."""
