"""Winner tag + colour for lab results (fragment E2).

Alpha Sentry's own runs tag every kept alpha, and tag a PASSING alpha whose |Fitness| clears `tag_winners_above` with the user's winner tag and
colour (simulation/service.py). Lab results used to get only the plain tag "harness"; this gives them the same treatment, from ONE
harness-level default (data/harness/winner.json), because lab runs have no per-run form to take it from.

Off by default: with no winner tag set nothing changes. A tag is applied only to an alpha that PASSED Alpha Sentry's gate and has
|Fitness| >= the threshold, exactly Alpha Sentry's rule. It is a label on the alpha in BRAIN (and in Alpha Sentry's Results `tagged` column); it never
submits anything. A failure to tag never loses the stored result.
"""
from __future__ import annotations

import json
import re
import threading
from pathlib import Path
from typing import Any, Callable

DEFAULTS: dict[str, Any] = {"winner_tag": "", "winner_color": "GREEN", "tag_winners_above": 1.0}
COLORS = ("RED", "YELLOW", "GREEN", "BLUE", "PURPLE")
_TAG = re.compile(r"^[\w .:+\-]{1,40}$")
_lock = threading.Lock()


class WinnerError(ValueError):
    pass


class WinnerSettings:
    def __init__(self, path: Path | None = None) -> None:
        self.path, self._mem = path, dict(DEFAULTS)

    def config(self) -> dict[str, Any]:
        out = dict(DEFAULTS)
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8")) if self.path else self._mem
            out.update({k: raw[k] for k in DEFAULTS if k in raw})
        except Exception:  # noqa: BLE001
            return dict(DEFAULTS)
        try:
            out["tag_winners_above"] = float(out["tag_winners_above"])
        except (TypeError, ValueError):
            out["tag_winners_above"] = DEFAULTS["tag_winners_above"]
        if out["winner_color"] not in COLORS:
            out["winner_color"] = DEFAULTS["winner_color"]
        out["winner_tag"] = str(out["winner_tag"] or "")
        return out

    def set_config(self, *, winner_tag: str | None = None, winner_color: str | None = None, tag_winners_above: float | None = None) -> dict[str, Any]:
        cur = self.config()
        if winner_tag is not None:
            t = winner_tag.strip()
            if t and not _TAG.match(t):
                raise WinnerError("The winner tag may use letters, digits, spaces and . : + - _ (up to 40 characters).")
            cur["winner_tag"] = t
        if winner_color is not None:
            c = winner_color.strip().upper()
            if c not in COLORS:
                raise WinnerError("The colour must be one of " + ", ".join(COLORS) + ".")
            cur["winner_color"] = c
        if tag_winners_above is not None:
            try:
                f = float(tag_winners_above)
            except (TypeError, ValueError):
                raise WinnerError("The fitness threshold must be a number.") from None
            if f != f or f < 0 or f > 100:
                raise WinnerError("The fitness threshold must be between 0 and 100.")
            cur["tag_winners_above"] = f
        with _lock:
            if self.path:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                self.path.write_text(json.dumps(cur, indent=2), encoding="utf-8")
            else:
                self._mem = dict(cur)
        return self.config()


def default_settings() -> WinnerSettings:
    from app.core.config import get_settings
    return WinnerSettings(Path(get_settings().data_dir) / "harness" / "winner.json")


def current() -> dict[str, Any]:
    """The saved defaults; never raises (any problem reading them means 'off')."""
    try:
        return default_settings().config()
    except Exception:  # noqa: BLE001
        return dict(DEFAULTS)


def is_winner(row: dict[str, Any], cfg: dict[str, Any]) -> bool:
    f = row.get("fitness")
    return bool(cfg.get("winner_tag") and row.get("passed_gate") and f is not None and abs(float(f)) >= float(cfg.get("tag_winners_above", 1.0)))


def apply(row: dict[str, Any], cfg: dict[str, Any], tagger: Callable[[str, str, str], Any], default_tag: str = "harness") -> str:
    """Tag a scored row in BRAIN if it is a winner. Returns the tag now on it (the winner tag, or `default_tag` when untouched or on failure)."""
    if not row.get("alpha_id") or not is_winner(row, cfg):
        return default_tag
    try:
        tagger(row["alpha_id"], cfg["winner_tag"], cfg.get("winner_color") or "GREEN")
        return cfg["winner_tag"]
    except Exception:  # noqa: BLE001      a labelling failure must never lose the result
        return default_tag
