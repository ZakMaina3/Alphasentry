"""Tasks: a template + sampler + objectives + budget, run as repeated ask -> simulate -> score -> tell rounds
(the scheduler behind the search labs; ported from alpha_harness.labs.tasks + optimize.study, rebuilt on the harness).

Flow per round (all through machinery that already exists, so slots, dedup, crash recovery, scoring and yield come free):
  ask  the optimizer for points -> render each into a simulation payload -> tracker.enqueue(task "<lab>-<id>")
  the engine simulates them and the scorer stores each result in Alpha Sentry's sim_results
  harvest finished records -> objective values + constraint violations -> tell the optimizer

Restart-safe: the optimizer is rebuilt from stored trials; trials that were in flight have no live handle any more and
are told as replayed trials when they finish. A task only advances while the batch engine is running (it ticks it).
"""
from __future__ import annotations

import json
import re
import threading
import time
from typing import Any, Callable

from app.harness import optimize as O
from app.harness.engine.tracker import Tracker
from app.harness.optimize import objectives as OB
from app.harness.optimize.builtin import Trial, crowding, nondominated_fronts, violation
from app.harness.payload import Scope
from app.harness.store import Store, chunks, marks
from app.harness.templates import realise as R
from app.harness.templates import spec as T

ACTIVE = ("running", "paused")
MAX_PRUNE_FACTOR = 5


class TaskError(ValueError):
    pass


def _j(v: Any) -> str:
    return json.dumps(v, default=str)


class TaskRunner:
    def __init__(self, store: Store, tracker: Tracker, *, results: Callable[[list[str]], dict[str, dict]] | None = None,
                 pnl: Callable[[str], list[float] | None] | None = None, optimizer_factory=O.make_optimizer,
                 clock: Callable[[], float] = time.time) -> None:
        self.store, self.tracker, self.clock = store, tracker, clock
        self._results = results or self._results_from_store
        self._pnl = pnl or self._pnl_from_vault
        self._factory = optimizer_factory
        self._opts: dict[int, tuple[Any, dict[int, Any]]] = {}
        self._lock = threading.RLock()

    # ── data sources ──────────────────────────────────────────────────────────────
    def _results_from_store(self, alpha_ids: list[str]) -> dict[str, dict]:
        out: dict[str, dict] = {}
        for part in chunks(list(alpha_ids)):
            for r in self.store.query(
                    f"SELECT alpha_id, delay, sharpe, fitness, turnover, \"returns\" AS returns, margin, drawdown, self_corr, prod_corr, "
                    f"powerpool_corr, tests_failed FROM sim_results WHERE alpha_id IN ({marks(len(part))}) ORDER BY id", part):
                out[r["alpha_id"]] = dict(r)
        return out

    def _pnl_from_vault(self, alpha_id: str) -> list[float] | None:
        from app.harness.vault.store import PnlStore
        by = PnlStore(self.store).load([alpha_id]).get(alpha_id) or {}
        return [by[d] for d in sorted(by)] or None

    # ── creating and controlling ──────────────────────────────────────────────────
    def create(self, *, lab: str, name: str, spec: T.TemplateSpec, scope: Scope, sampler: str, objectives: list[str], budget: int,
               batch: int = 10, cores: int = 2, seed: int | None = None, backend: str = "auto", params: dict[str, Any] | None = None,
               prepared: R.Prepared | None = None) -> dict[str, Any]:
        if not re.fullmatch(r"[a-z]{2,20}", lab or ""):
            raise TaskError("A task's lab must be a short lower-case word (search, template, power, ...).")
        try:
            objs = OB.resolve(objectives)
        except OB.ObjectiveError as e:
            raise TaskError(str(e)) from e
        for n, v in spec.vars.items():
            if v.type == "datafield" and n not in spec.unused_vars and not v.values and prepared is not None and not prepared(v):
                raise TaskError(f"No data fields matched ${n} in this market. Download the data in Data Explorer first, or loosen the filters "
                                "(category, dataset, coverage, alpha count).")
        space = R.build_space(spec, prepared)
        if not space:
            raise TaskError("Nothing in this template varies, so there is nothing to search. Give a variable a range, a grid or a list.")
        pinned = {}
        for n, v in spec.vars.items():
            if v.type == "datafield" and n not in space and prepared and n not in spec.unused_vars:
                got = list(v.values or []) or prepared(v)
                if got:
                    pinned[n] = got[0]
        budget = max(1, min(int(budget), spec.constraints.max_simulations))
        try:
            opt = self._factory(sampler, space, [o.direction for o in objs], backend=backend, seed=seed, batch_size=batch, params=params)
        except (ValueError, RuntimeError) as e:
            raise TaskError(str(e)) from e
        now = self.clock()
        with self.store.connect() as c:
            cur = c.execute(
                "INSERT INTO harness_task (lab, name, status, sampler, directions, objectives, space, template, scope, budget, batch, cores,"
                " seed, backend, params, notes, created, updated) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (lab, name or spec.name, "running", sampler, _j([o.direction for o in objs]), _j(objectives), _j(space), _j(spec.to_dict()),
                 _j({"region": scope.region, "delay": scope.delay, "universe": scope.universe, "instrument_type": scope.instrument_type}),
                 budget, int(batch), int(cores), seed, backend, _j({"sampler": params or {}, "pinned": pinned}), _j(opt.notes), now, now))
            tid = cur.lastrowid
        return {"id": tid, "budget": budget, "notes": opt.notes, "backend": opt.backend, "space": R.summary(spec, prepared)}

    def create_evolution(self, **kw: Any) -> dict[str, Any]:
        """An Evolution task (see harness/evolution.py). Shares everything else — listing, controls, ranking — with search tasks."""
        from app.harness import evolution
        return evolution.create(self, **kw)

    def set_status(self, task_id: int, status: str) -> dict[str, Any]:
        with self._lock:
            return self._set_status(task_id, status)

    def _set_status(self, task_id: int, status: str) -> dict[str, Any]:
        cur = self.get(task_id)
        if cur is None:
            raise TaskError("No such task.")
        allowed = {"pause": ("running",), "resume": ("paused",)}
        if status == "paused" and cur["status"] not in allowed["pause"]:
            raise TaskError(f"A {cur['status']} task cannot be paused.")
        if status == "running" and cur["status"] not in allowed["resume"]:
            raise TaskError(f"A {cur['status']} task cannot be resumed.")
        self.store.execute("UPDATE harness_task SET status=?, updated=? WHERE id=?", (status, self.clock(), task_id))
        return self.get(task_id)

    def pause_other_markets(self, keep_region: str = "", keep_delay: int | None = None, only_region: str = "", only_delay: int | None = None) -> int:
        """Pause running tasks so they stop refilling a market you left: every task NOT in keep_region[/delay], or only those in
        only_region[/delay]. Paused tasks keep their history and resume with the Resume button."""
        n = 0
        with self._lock:
            for r in self.store.query("SELECT id, scope FROM harness_task WHERE status='running'"):
                try:
                    sc = json.loads(r["scope"])
                except ValueError:
                    continue
                reg, dly = str(sc.get("region", "")).upper(), int(sc.get("delay", 1))
                if only_region:
                    hit = reg == only_region.upper() and (only_delay is None or dly == int(only_delay))
                elif keep_region:
                    hit = not (reg == keep_region.upper() and (keep_delay is None or dly == int(keep_delay)))
                else:
                    hit = False
                if hit:
                    self._set_status(r["id"], "paused")
                    n += 1
        return n

    def stop(self, task_id: int) -> dict[str, Any]:
        with self._lock:                                                       # never interleave with a tick that is mid-ask
            return self._stop(task_id)

    def _stop(self, task_id: int) -> dict[str, Any]:
        t = self.get(task_id)
        if t is None:
            raise TaskError("No such task.")
        self.tracker.cancel_task(f"{t['lab']}-{task_id}")                     # queued work is dropped; running sims finish unseen
        now = self.clock()
        with self.store.connect() as c:
            c.execute("UPDATE harness_trial SET status='pruned', error='stopped', updated=? WHERE task_id=? AND status='queued'", (now, task_id))
            c.execute("UPDATE harness_task SET status='stopped', updated=? WHERE id=? AND status IN ('running','paused')", (now, task_id))
        self._opts.pop(task_id, None)
        return self.get(task_id)

    def stop_all(self) -> int:
        """Stop every running or paused task (their queued work is dropped; history stays visible in the Tasks tab)."""
        n = 0
        with self._lock:
            for r in self.store.query("SELECT id FROM harness_task WHERE status IN ('running','paused')"):
                self._stop(r["id"])
                n += 1
        return n

    def remove(self, task_id: int) -> None:
        with self._lock:
            if self.get(task_id) is None:
                return
            self._stop(task_id)
            with self.store.connect() as c:
                c.execute("DELETE FROM harness_trial WHERE task_id=?", (task_id,))
                c.execute("DELETE FROM harness_task WHERE id=?", (task_id,))

    # ── reading ───────────────────────────────────────────────────────────────────
    def get(self, task_id: int) -> dict[str, Any] | None:
        rows = self.store.query("SELECT * FROM harness_task WHERE id=?", (task_id,))
        return dict(rows[0]) if rows else None

    def counts(self, task_id: int) -> dict[str, int]:
        return {r["status"]: int(r["n"]) for r in self.store.query(
            "SELECT status, COUNT(*) AS n FROM harness_trial WHERE task_id=? GROUP BY status", (task_id,))}

    def list_tasks(self) -> list[dict[str, Any]]:
        out = []
        for r in self.store.query("SELECT * FROM harness_task ORDER BY id DESC"):
            out.append(self._public(dict(r), self.counts(r["id"])))
        return out

    @staticmethod
    def _public(t: dict[str, Any], counts: dict[str, int]) -> dict[str, Any]:
        done = counts.get("complete", 0) + counts.get("failed", 0)
        return {"id": t["id"], "lab": t["lab"], "name": t["name"], "status": t["status"], "sampler": t["sampler"],
                "objectives": json.loads(t["objectives"]), "budget": t["budget"], "batch": t["batch"], "cores": t["cores"],
                "counts": counts, "progress": round((done) / t["budget"], 3) if t["budget"] else 0.0,
                "notes": json.loads(t["notes"]), "error": t["error"], "created": t["created"], "updated": t["updated"]}

    def detail(self, task_id: int, limit: int = 100) -> dict[str, Any] | None:
        t = self.get(task_id)
        if t is None:
            return None
        trials = [dict(r) for r in self.store.query("SELECT * FROM harness_trial WHERE task_id=? ORDER BY number", (task_id,))]
        directions = json.loads(t["directions"])
        view = [self._trial_view(r) for r in trials]
        done = [v for v in view if v["status"] == "complete"]
        ranked = rank(done, directions)
        out = {**self._public(t, self.counts(task_id)), "directions": directions, "space": json.loads(t["space"]),
               "best": ranked[:10], "pareto": pareto(done, directions) if len(directions) > 1 else ranked[:1],
               "recent": view[-limit:], "scope": json.loads(t["scope"]), "powerPool": _power_pool(t)}
        if t["lab"] == "evolution":
            from app.harness import evolution
            out["generations"] = evolution.generation_summary(view, directions)
        return out

    def power_pool_view(self, task_id: int) -> dict[str, Any] | None:
        """Which finished alphas of this task could enter the Power Pool, and what stops the others (see labs/powerpool.py)."""
        from app.harness.labs import powerpool as PP
        t = self.get(task_id)
        if t is None:
            return None
        trials = [dict(r) for r in self.store.query(
            "SELECT number, alpha_id FROM harness_trial WHERE task_id=? AND status='complete' AND alpha_id != ''", (task_id,))]
        ids = sorted({r["alpha_id"] for r in trials})
        stats = self._results(ids) if ids else {}
        exprs: dict[str, str] = {}
        for part in chunks(ids):
            for r in self.store.query(f"SELECT alpha_id, expression FROM sim_results WHERE alpha_id IN ({marks(len(part))}) ORDER BY id", part):
                exprs[r["alpha_id"]] = r["expression"]
        rows = [{"alpha_id": a, "expression": exprs.get(a, ""), **{k: stats.get(a, {}).get(k) for k in ("sharpe", "fitness", "turnover", "powerpool_corr")}}
                for a in ids]
        return {"taskPowerPool": _power_pool(t), **PP.selection(rows)}

    @staticmethod
    def _trial_view(r: dict[str, Any]) -> dict[str, Any]:
        return {"number": r["number"], "status": r["status"], "params": json.loads(r["params"]), "alphaId": r["alpha_id"] or None,
                "values": json.loads(r["values_json"]) if r["values_json"] else None, "constraint": json.loads(r["constraint_json"]),
                "summary": json.loads(r["summary"]), "error": r["error"]}

    # ── scheduling ────────────────────────────────────────────────────────────────
    def tick(self) -> dict[int, int]:
        """One scheduling pass over every running task. Returns points asked per task. Never raises."""
        out: dict[int, int] = {}
        with self._lock:
            for t in [dict(r) for r in self.store.query("SELECT * FROM harness_task WHERE status='running' ORDER BY id")]:
                try:
                    out[t["id"]] = self._advance(t)
                except Exception as e:  # noqa: BLE001      one broken task must not stall the others
                    self._fail(t["id"], f"{type(e).__name__}: {e}")
        return out

    def _fail(self, task_id: int, msg: str) -> None:
        self.store.execute("UPDATE harness_task SET status='error', error=?, updated=? WHERE id=?", (msg[:500], self.clock(), task_id))
        self._opts.pop(task_id, None)

    def _advance(self, t: dict[str, Any]) -> int:
        if t["lab"] == "evolution":
            from app.harness import evolution
            return evolution.advance(self, t)
        spec = T.parse(json.loads(t["template"]))
        space = json.loads(t["space"])
        objs = OB.resolve(json.loads(t["objectives"]))
        opt, handles = self._optimizer(t, space, objs)
        self._harvest(t, opt, handles, objs)
        return self._ask(t, spec, Scope(**json.loads(t["scope"])), opt, handles)

    def _optimizer(self, t: dict[str, Any], space: dict, objs: list[OB.Objective]):
        cached = self._opts.get(t["id"])
        if cached:
            return cached
        history = []
        for r in self.store.query("SELECT params, status, values_json, constraint_json FROM harness_trial WHERE task_id=? ORDER BY number", (t["id"],)):
            state = {"complete": "COMPLETE", "pruned": "PRUNED"}.get(r["status"], "FAIL")      # in-flight: remembered, not learned from
            vals = json.loads(r["values_json"]) if (r["values_json"] and state == "COMPLETE") else None
            history.append({"params": json.loads(r["params"]), "values": vals, "constraint": json.loads(r["constraint_json"]), "state": state})
        opts = json.loads(t["params"]).get("sampler") or {}
        opt = self._factory(t["sampler"], space, [o.direction for o in objs], backend=t["backend"], seed=t["seed"],
                            batch_size=t["batch"], params=opts, history=history or None)
        self._opts[t["id"]] = (opt, {})
        return self._opts[t["id"]]

    def _harvest(self, t: dict[str, Any], opt: Any, handles: dict[int, Any], objs: list[OB.Objective]) -> None:
        rows = [dict(r) for r in self.store.query("SELECT * FROM harness_trial WHERE task_id=? AND status='queued'", (t["id"],))]
        if not rows:
            return
        recs: dict[int, tuple[str, str]] = {}
        ids = [r["record_id"] for r in rows if r["record_id"]]
        for part in chunks(ids):
            for r in self.store.query(f"SELECT id, status, alpha_id FROM harness_sim_record WHERE id IN ({marks(len(part))})", part):
                recs[r["id"]] = (r["status"], r["alpha_id"])
        alphas = sorted({a for s, a in recs.values() if a and s in ("done", "scored", "external")})
        results = self._results(alphas) if alphas else {}
        for tr in rows:
            status, alpha = recs.get(tr["record_id"], ("missing", ""))
            if status in ("error", "cancelled", "dryrun", "missing"):
                self._finish(t, opt, handles, tr, None, f"simulation {status}")
            elif alpha and status in ("done", "scored", "external") and alpha in results:
                self._finish(t, opt, handles, tr, results[alpha], "", alpha)

    def _finish(self, t: dict[str, Any], opt: Any, handles: dict[int, Any], tr: dict[str, Any], row: dict | None, err: str, alpha: str = "") -> None:
        handle = handles.pop(tr["id"], None)
        params = json.loads(tr["params"])
        now = self.clock()
        if row is None:
            self.store.execute("UPDATE harness_trial SET status='failed', error=?, updated=? WHERE id=?", (err, now, tr["id"]))
            if handle is not None:
                opt.tell(handle, None)
            return
        objs = OB.resolve(json.loads(t["objectives"]))
        extra = {o.key: OB.k_ratio(self._pnl(alpha) or []) for o in objs if o.needs_pnl}
        values = OB.extract(row, objs, extra)
        cons = OB.constraints_from_row(row, power_pool=_power_pool(t))
        self.store.execute("UPDATE harness_trial SET status='complete', alpha_id=?, values_json=?, constraint_json=?, summary=?, updated=? WHERE id=?",
                           (alpha, _j(values), _j(cons), _j(OB.summarise(row)), now, tr["id"]))
        if handle is not None:
            opt.tell(handle, values, constraint=cons)
        else:
            opt.tell(None, values, constraint=cons, params=params)             # in flight across a restart: replay it

    def _ask(self, t: dict[str, Any], spec: T.TemplateSpec, scope: Scope, opt: Any, handles: dict[int, Any]) -> int:
        counts = self.counts(t["id"])
        in_flight = counts.get("queued", 0)
        simulated = sum(v for k, v in counts.items() if k != "pruned")
        remaining = t["budget"] - simulated
        if remaining <= 0:
            if in_flight == 0:
                self.store.execute("UPDATE harness_task SET status='done', updated=? WHERE id=?", (self.clock(), t["id"]))
                self._opts.pop(t["id"], None)
            return 0
        n = min(t["batch"], remaining, t["cores"] * t["batch"] - in_flight)
        if n < min(t["batch"], remaining):
            return 0                                                           # only top up in whole batches: keeps multi-sims full
        asked = opt.ask(n)
        if not asked:
            if in_flight == 0:
                self._note(t, "Every point in this space has been tried.")
                self.store.execute("UPDATE harness_task SET status='done', updated=? WHERE id=?", (self.clock(), t["id"]))
                self._opts.pop(t["id"], None)
            return 0
        if counts.get("pruned", 0) > MAX_PRUNE_FACTOR * t["budget"] + 50:
            self._fail(t["id"], "Most points in this template break its own constraints, so almost nothing could be simulated. Loosen them.")
            return 0
        pinned = json.loads(t["params"]).get("pinned") or {}
        prepared = _pinned_lookup(spec, pinned)
        number = sum(counts.values())
        name = f"{t['lab']}-{t['id']}"
        now = self.clock()
        for handle, params in asked:
            number += 1
            payload = R.realise(spec, params, scope, prepared)
            probs = R.problems(payload["regular"], spec)
            if probs:
                self.store.execute("INSERT INTO harness_trial (task_id, number, params, status, error, created, updated) VALUES (?,?,?,?,?,?,?)",
                                   (t["id"], number, _j(params), "pruned", "; ".join(probs), now, now))
                opt.tell(handle, None, state="PRUNED")
                continue
            rec = self.tracker.enqueue(name, payload)["record_id"]
            with self.store.connect() as c:
                tid = c.execute("INSERT INTO harness_trial (task_id, number, params, record_id, status, created, updated) VALUES (?,?,?,?,?,?,?)",
                                (t["id"], number, _j(params), rec, "queued", now, now)).lastrowid
            handles[tid] = handle
        return len(asked)

    def _note(self, t: dict[str, Any], msg: str) -> None:
        notes = json.loads(t["notes"])
        if msg not in notes:
            self.store.execute("UPDATE harness_task SET notes=? WHERE id=?", (_j(notes + [msg]), t["id"]))


def _trial_views(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [TaskRunner._trial_view(r) for r in rows]


def _power_pool(t: dict[str, Any]) -> bool:
    try:
        return bool((json.loads(t["template"]).get("constraints") or {}).get("power_pool"))
    except (ValueError, AttributeError):
        return False


def _pinned_lookup(spec: T.TemplateSpec, pinned: dict[str, Any]) -> R.Prepared:
    """A `prepared` resolver that answers only for data-field variables whose single match was pinned at creation."""
    by_var = {id(v): pinned[n] for n, v in spec.vars.items() if n in pinned}
    return lambda v: [by_var[id(v)]] if id(v) in by_var else []


# ── ranking ────────────────────────────────────────────────────────────────────────────────────
def _as_trials(views: list[dict[str, Any]]) -> list[Trial]:
    return [Trial(v["number"], v["params"], v["values"], v["constraint"], "COMPLETE") for v in views]


def rank(views: list[dict[str, Any]], directions: list[str]) -> list[dict[str, Any]]:
    """Finished trials best-first: feasible before infeasible, then by non-dominated front, then crowding."""
    if not views:
        return []
    items = [(violation(v["constraint"]), [(-x if d == "maximize" else x) for x, d in zip(v["values"], directions)]) for v in views]
    out: list[dict[str, Any]] = []
    for front in nondominated_fronts(items):
        cd = crowding(front, items)
        out.extend(views[i] for i in sorted(front, key=lambda i: (-cd[i], items[i][1])))
    return out


def pareto(views: list[dict[str, Any]], directions: list[str]) -> list[dict[str, Any]]:
    if not views:
        return []
    items = [(violation(v["constraint"]), [(-x if d == "maximize" else x) for x, d in zip(v["values"], directions)]) for v in views]
    return [views[i] for i in nondominated_fronts(items)[0]]
