"""The ONE place a simulation request is built (previously hand-built in six labs).

Defaults follow SentryEngine: NaN handling ON, pasteurization ON, FASTEXPR, unit handling VERIFY.
Payloads are in the shape ace_lib.generate_alpha produces, so Alpha Sentry's own simulate path accepts them.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Scope:
    region: str
    delay: int
    universe: str
    instrument_type: str = "EQUITY"

    @property
    def label(self) -> str:
        return f"{self.instrument_type}/{self.region}/D{self.delay}/{self.universe}"


def make_settings(scope: Scope, *, neutralization: str | None = None, decay: int | float | None = 0,
                  truncation: float | None = 0.08, universe: str | None = None, **overrides: Any) -> dict[str, Any]:
    """Settings for `scope`. None/empty neutralization -> SUBINDUSTRY; None decay/truncation -> 0 / 0.08;
    `universe` overrides the scope's (a seed alpha's own universe); extra kwargs patch single settings."""
    s: dict[str, Any] = {
        "instrumentType": scope.instrument_type, "region": scope.region, "delay": scope.delay,
        "universe": universe or scope.universe, "neutralization": neutralization or "SUBINDUSTRY",
        "decay": int(decay or 0), "truncation": float(truncation if truncation is not None else 0.08),
        "pasteurization": "ON", "testPeriod": "P0Y0M0D", "maxTrade": "OFF", "visualization": False,
        "language": "FASTEXPR", "unitHandling": "VERIFY", "nanHandling": "ON",
    }
    s.update(overrides)
    return s


def make_payload(expression: str, scope: Scope, **kw: Any) -> dict[str, Any]:
    return {"type": "REGULAR", "settings": make_settings(scope, **kw), "regular": expression}
