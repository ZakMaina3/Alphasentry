"""Planning layer: skeleton ledger (which shapes a market has already answered) and, later, yields/budget."""
