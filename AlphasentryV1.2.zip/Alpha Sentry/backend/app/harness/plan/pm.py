"""The PM (fragment D4): a model that decides which research desks (labs) get today's simulations, with a plain-language briefing.
Ported from alpha_harness.plan.pm and rebuilt on this harness.

A consultant account is a small fund: the labs are the desks, the day's simulation allowance is the capital (it resets at UTC midnight),
and the person reading is the CEO. The PM runs once or twice a day, not per click: its value is judgement, and every other part of the
harness is deterministic so that this one call can be the only expensive thing in the day.

What it optimises is YIELD (passing alphas per finished simulation), not Sharpe: ranking desks by their best result would fund the
expensive one forever; ranking by conversion funds the one that turns the allowance into product.

It cannot break anything. The model only CHOOSES DESKS and says why; it never supplies numbers:
  * every desk it names is checked against the real, ready lab set (an invented, closed or repeated lab is dropped, at most 4 are kept);
  * the simulations are then divided by plan.day.make_plan restricted to the chosen desks (yield-weighted, exploration share, capacity limits,
    minimum run size), so the budget is always respected exactly as in the ordinary plan;
  * if there is no model, it fails, answers nonsense, or nothing it chose survives, the result is the ORDINARY PLAN (plan.day.make_plan over
    every ready lab) with a rule-written briefing. The floor of this product is a good ordinary plan; the PM is upside, never a dependency.
  * the model is not called at all when there is nothing to decide (no ready lab, or today's budget is already used), so it never costs a call for nothing;
  * sentences of its briefing that talk about submitting are removed: nothing in the harness submits, and the PM never suggests it.

Differences from SentryEngine, on purpose: AH divided CORES between desks; here the scarce resource is the day's simulation budget (cores
are just the engine's slots), and the split between the chosen desks is by yield rather than even. Pure module: the model call is an injected
`complete(system, user) -> str`, readiness comes from `blockers`, and the data readers + endpoint + UI belong to D5.
"""
from __future__ import annotations

import re
from typing import Any, Callable

from app.harness.llm import LLMError, parse_json_text
from app.harness.plan.day import AUTO_LABS, make_plan
from app.harness.plan.yields import CONFIDENT_AT, TARGET_YIELD, LabYield

#: How many desks can meaningfully share one day's budget. Spreading thinner only buys diversity the levers inside each lab already provide.
MAX_FUNDED = 4
MAX_WHY = 240
MAX_BRIEFING = 600

SYSTEM = """\
You are the portfolio manager of a small quantitative research fund. The fund has a fixed number of simulations to spend today; \
whatever is not spent is gone at midnight. Your job is to choose WHICH research desks get funded today.

The person reading you is the CEO. They have no background in finance, will give this two minutes, and have stopped believing this works. \
Write to them in short, plain sentences. No jargon. Never "simply" or "just". Never promise a result.

What you are optimising is YIELD: passing alphas per finished simulation. A desk that returns three excellent alphas from 2,000 simulations \
is worse than one returning six adequate alphas from 1,000, because the simulations are what runs out.

How to think:
  - Fund what has been converting. Defund what has had a fair run and has not.
  - A desk marked "not confident" has too little evidence to judge. Give it a chance rather than writing it off on a handful of runs.
  - Do not put everything on one desk. Alphas that resemble each other cannot all be used, so spreading across different DIRECTIONS of research is worth real compute.
  - Prefer a desk that searches an axis nothing else is searching today.
  - You are shown the ORDINARY PLAN: what happens with no judgement applied. Agree with it where it is right; depart from it only for a reason you can state in one sentence.

Choose ONLY from the desks listed. Never invent one. Fund at most four. Do NOT give numbers: the system divides the simulations between the desks you choose. \
Nothing here ever submits an alpha, so never suggest submitting anything.

Return JSON only:
  "briefing"    - two or three sentences to the CEO. What today is going after, and why that is a reasonable bet given what has happened lately. Speak to them, not about them.
  "allocations" - a list of the desks you are funding, each {"lab": "<id>", "why": "<one plain sentence>"}.
"""


# ── what the PM is shown (also the fund's report on its own) ──────────────────────────────────
def brief(cfg: dict[str, Any], book: dict[str, LabYield], summary: dict[str, Any] | None = None,
          blockers: dict[str, list[str]] | None = None, capacity: dict[str, int] | None = None) -> dict[str, Any]:
    """Every desk the plan may use, whether it can run today and why not, its record, and the fund overall.

    blockers {lab: [reasons it cannot run today]} (empty / missing = ready); capacity {lab: most simulations it can still make} where 0 closes a desk.
    """
    blockers, capacity = blockers or {}, capacity or {}
    desks = []
    for lab in cfg["labs"]:
        if lab not in AUTO_LABS:
            continue
        why_not = list(blockers.get(lab) or [])
        if capacity.get(lab) == 0:
            why_not.append("it has no candidates left today")
        rec = book.get(lab)
        desks.append({"id": lab, "name": lab.title(), "searches": AUTO_LABS[lab], "ready": not why_not, "blockedBy": why_not,
                      "record": rec.to_dict() if rec else None})
    fund = summary or {"plainly": "Nothing has finished running yet, so there is nothing to judge.", "meetsTarget": False,
                       "yieldRate": 0.0, "targetYield": TARGET_YIELD, "finished": 0, "passing": 0}
    return {"desks": desks, "fund": fund}


def _prompt(b: dict[str, Any], ready: list[dict[str, Any]], ordinary: dict[str, Any]) -> str:
    """Only fixed lab ids, fixed lab descriptions and numbers computed here go into the prompt: nothing a user typed."""
    lines = ["THE DESKS YOU MAY FUND:"]
    for d in ready:
        r = d["record"]
        if r and r["finished"]:
            note = (f"{r['passing']} passing from {r['finished']} finished (yield {r['yieldRate'] * 100:.2f}%)"
                    + ("" if r["confident"] else f", NOT CONFIDENT: fewer than {CONFIDENT_AT} finished, too little evidence yet"))
        else:
            note = "no record yet: never funded, or nothing has finished"
        lines.append(f"  {d['id']}: searches {d['searches']}. Lately: {note}.")
    closed = [d for d in b["desks"] if not d["ready"]]
    if closed:
        lines.append("\nCLOSED TODAY (do not fund): " + ", ".join(f"{d['id']} ({'; '.join(d['blockedBy'])})" for d in closed))
    fund = b["fund"]
    lines += ["", f"THE FUND OVERALL: {fund.get('plainly', '')} The standard to beat is {TARGET_YIELD * 100:.1f}% "
                  f"({'met' if fund.get('meetsTarget') else 'not met'}).", "",
              f"THE ORDINARY PLAN (what happens with no judgement applied), {ordinary['remaining']:,} simulations to spend today:"]
    lines += [f"  {a['lab']}: {a['sims']:,} ({a['share'] * 100:.0f}%)" for a in ordinary["allocations"]]
    return "\n".join(lines)


# ── keeping it honest ─────────────────────────────────────────────────────────────────────────
def _norm(x: Any) -> str:
    return str(x or "").strip().lower()


def validate(raw: Any, ready_ids: set[str], closed_ids: set[str]) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    """Keep real, ready, distinct desks (at most MAX_FUNDED) in the order the model gave them; say why anything was dropped."""
    kept: list[dict[str, str]] = []
    rejected: list[dict[str, str]] = []
    for item in raw if isinstance(raw, list) else []:
        if not isinstance(item, dict):
            continue
        lab = _norm(item.get("lab"))
        if not lab:
            rejected.append({"lab": "(unnamed)", "reason": "no lab was named"})
        elif lab in closed_ids:
            rejected.append({"lab": lab, "reason": "it cannot run today"})
        elif lab not in ready_ids:
            rejected.append({"lab": lab[:40], "reason": "that is not one of the labs"})
        elif any(k["lab"] == lab for k in kept):
            rejected.append({"lab": lab, "reason": "named twice"})
        elif len(kept) >= MAX_FUNDED:
            rejected.append({"lab": lab, "reason": f"only {MAX_FUNDED} labs can be funded"})
        else:
            kept.append({"lab": lab, "why": re.sub(r"\s+", " ", str(item.get("why") or "")).strip()[:MAX_WHY]})
    return kept, rejected


def clean_briefing(text: Any) -> str:
    """The model's briefing, tidied: whitespace collapsed, any sentence about submitting removed, cut to a sentence boundary."""
    t = re.sub(r"\s+", " ", str(text or "")).strip()
    if not t:
        return ""
    sentences = [s for s in re.split(r"(?<=[.!?])\s+", t) if s and not re.search(r"\bsubmit", s, re.I)]
    out = ""
    for s in sentences:
        if len(out) + len(s) + 1 > MAX_BRIEFING:
            break
        out = f"{out} {s}".strip()
    return out


def rule_briefing(plan: dict[str, Any]) -> str:
    a = plan["allocations"]
    if not a:
        return plan["notes"][0] if plan.get("notes") else "There is nothing to run today."
    top = a[0]
    return (f"Today's {plan['planned']:,} simulations are shared across {len(a)} lab{'s' if len(a) != 1 else ''} by how well each has converted lately; "
            f"{top['lab']} gets the largest share. Labs we know little about get an exploration share so none is written off on a handful of runs.")


# ── the decision ──────────────────────────────────────────────────────────────────────────────
def allocate(cfg: dict[str, Any], book: dict[str, LabYield], spent: int, *, summary: dict[str, Any] | None = None,
             blockers: dict[str, list[str]] | None = None, capacity: dict[str, int] | None = None,
             complete: Callable[[str, str], str] | None = None) -> dict[str, Any]:
    """Today's desks, simulations and briefing. Never raises; always returns a usable plan.

    cfg/book/spent/capacity are exactly what plan.day.make_plan takes. `complete(system, user) -> str` is the model (None = no model).
    """
    b = brief(cfg, book, summary, blockers, capacity)
    ready = [d for d in b["desks"] if d["ready"]]
    ready_ids = {d["id"] for d in ready}
    closed_ids = {d["id"] for d in b["desks"] if not d["ready"]}
    every = set(cfg["labs"])
    ordinary = make_plan(cfg, book, spent, capacity=capacity, exclude=every - ready_ids)
    base = {"brief": b, "fund": b["fund"], "ordinary": ordinary, "rejected": [], "dropped": [], "usedLLM": False, "error": None}

    def floor(error: str | None = None) -> dict[str, Any]:
        return {**base, "briefing": rule_briefing(ordinary), "allocations": ordinary["allocations"], "plan": ordinary, "fromPM": False,
                "error": error}

    if not ready:
        return {**floor(), "briefing": "Nothing can run today yet. Once the data a lab needs is there, its desk opens up."}
    if not ordinary["allocations"]:
        return floor()                                            # budget used / nothing left to fund: nothing to decide, so no model call
    if complete is None:
        return floor()

    try:
        reply = complete(SYSTEM, _prompt(b, ready, ordinary))
        payload = parse_json_text(reply)
    except LLMError as e:
        return floor(f"The model could not be used: {e}")
    except Exception as e:  # noqa: BLE001      the PM is upside: losing it costs the reasoning, never the day
        return floor(f"The model could not be used: {str(e)[:200]}")
    if not isinstance(payload, dict):
        return floor("The model's answer was not the expected shape.")

    kept, rejected = validate(payload.get("allocations"), ready_ids, closed_ids)
    if not kept:
        return {**floor("Nothing the model chose could be used."), "rejected": rejected}

    chosen = make_plan(cfg, book, spent, capacity=capacity, exclude=every - {k["lab"] for k in kept})
    if not chosen["allocations"]:
        return {**floor("The labs the model chose have nothing left to run today."), "rejected": rejected}
    funded = {a["lab"] for a in chosen["allocations"]}
    dropped = [{"lab": k["lab"], "reason": "its share was below the smallest run worth making, so it was folded into the others"}
               for k in kept if k["lab"] not in funded]
    why = {k["lab"]: k["why"] for k in kept}
    allocations = [{**a, "pmWhy": why.get(a["lab"]) or None, "numbersWhy": a["why"], "why": why.get(a["lab"]) or a["why"]}
                   for a in chosen["allocations"]]
    was = {a["lab"] for a in ordinary["allocations"]}
    return {**base, "briefing": clean_briefing(payload.get("briefing")) or rule_briefing(chosen), "allocations": allocations, "plan": chosen,
            "fromPM": True, "usedLLM": True, "rejected": rejected, "dropped": dropped,
            "changes": {"added": sorted(funded - was), "removed": sorted(was - funded)}}
