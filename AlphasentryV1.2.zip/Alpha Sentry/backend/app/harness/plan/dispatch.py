"""Turning the daily plan into queued work (fragment D2).

`dispatch` runs each funded lab through a RUNNER (a function the caller supplies: how many simulations -> what was queued) and, when a
lab turns out to have fewer new candidates than it was given, hands the shortfall to the others (up to `max_rounds`). It never
simulates and never submits: runners only queue on the engine, which starts when the user starts it. Pure apart from the runners, so
the loop is tested with fakes. `record_run` / `history` keep an audit trail (table harness_plan_run).

A runner is called as ``runner(target, extra)``:
  * target - the total simulations this lab should have queued today by this plan (queue-style labs use this: candidates they already
    queued come back as duplicates, so asking for more than before yields only the new ones);
  * extra  - just the additional simulations this round (task-style labs, which create a new task, use this).
It returns ``{"queued": n, "duplicates": n, ...}`` where "queued" is NEW work only.
"""
from __future__ import annotations

import json
import time
from typing import Any, Callable

from app.harness.plan import day as DAY
from app.harness.plan.yields import LabYield
from app.harness.store import Store

Runner = Callable[[int, int], dict[str, Any]]


def dispatch(cfg: dict[str, Any], book: dict[str, LabYield], spent: int, runners: dict[str, Runner], *, max_rounds: int = 3) -> dict[str, Any]:
    first = DAY.make_plan(cfg, book, spent)
    plan, exhausted = first, set()
    asked: dict[str, int] = {}
    results: list[dict[str, Any]] = []
    queued_total, notes = 0, list(first["notes"])
    for rnd in range(1, max(1, max_rounds) + 1):
        if not plan["allocations"]:
            break
        for a in plan["allocations"]:
            lab, extra = a["lab"], a["sims"]
            runner = runners.get(lab)
            row: dict[str, Any] = {"round": rnd, "lab": lab, "asked": extra, "queued": 0, "duplicates": 0, "error": None}
            if runner is None:
                row["error"] = "This lab cannot be run by the plan."
                exhausted.add(lab)
            else:
                target = asked.get(lab, 0) + extra
                try:
                    res = runner(target, extra) or {}
                    row.update({k: res[k] for k in ("task", "note") if k in res})
                    row["queued"], row["duplicates"] = int(res.get("queued", 0)), int(res.get("duplicates", 0))
                    asked[lab] = target
                    if row["queued"] < extra:
                        exhausted.add(lab)
                        notes.append(f"{lab} only had {row['queued']} new candidate(s) for the {extra} it was given" +
                                     (f" ({row['duplicates']} already known)." if row["duplicates"] else "."))
                except Exception as e:  # noqa: BLE001      one lab failing must not cost the others their share
                    row["error"] = f"{type(e).__name__}: {getattr(e, 'detail', None) or e}"[:300]
                    exhausted.add(lab)
                    notes.append(f"{lab} could not run: {row['error']}")
            queued_total += row["queued"]
            results.append(row)
        leftover = first["remaining"] - queued_total
        if leftover < int(cfg["min_chunk"]) or exhausted >= set(cfg["labs"]):
            break
        plan = DAY.make_plan(cfg, book, spent + queued_total, exclude=exhausted)
    leftover = max(0, first["remaining"] - queued_total)
    if leftover and queued_total < first["planned"]:
        notes.append(f"{leftover:,} of today's simulations were not used: the labs ran out of new candidates. Add data, results or "
                     "another lab (or try again after more results finish).")
    return {"plan": first, "results": results, "queued": queued_total, "leftover": leftover, "rounds": max((r["round"] for r in results), default=0),
            "notes": notes}


# ── audit trail ───────────────────────────────────────────────────────────────────────────────
def record_run(store: Store, scope_label: str, outcome: dict[str, Any], clock: Callable[[], float] = time.time) -> int:
    now = clock()
    p = outcome["plan"]
    with store.connect() as c:
        return c.execute("INSERT INTO harness_plan_run (created, day, scope, budget, planned, queued, plan, results, notes) VALUES (?,?,?,?,?,?,?,?,?)",
                         (now, time.strftime("%Y-%m-%d", time.gmtime(now)), scope_label, p["budget"], p["planned"], outcome["queued"],
                          json.dumps(p), json.dumps(outcome["results"]), json.dumps(outcome["notes"]))).lastrowid


def history(store: Store, limit: int = 20) -> list[dict[str, Any]]:
    return [{"id": r["id"], "created": r["created"], "day": r["day"], "scope": r["scope"], "budget": r["budget"], "planned": r["planned"],
             "queued": r["queued"], "results": json.loads(r["results"]), "notes": json.loads(r["notes"])}
            for r in store.query("SELECT * FROM harness_plan_run ORDER BY id DESC LIMIT ?", (max(1, min(int(limit), 200)),))]
