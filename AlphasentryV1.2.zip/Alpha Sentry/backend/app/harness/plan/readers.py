"""Data readers for the planning layer (fragment D5): everything the plan, the PM and the advisor need to know about the system.

All of it comes from Alpha Sentry's and the harness' own tables with plain SQL: NO BRAIN calls and no simulations, so it is cheap and safe to
call on every refresh of the Planning tab. (A real "near miss" needs BRAIN's check list, which costs requests; here a near miss is the
cheap proxy "unsubmitted, failed Alpha Sentry's gate, |Sharpe| >= 1.0", and Repair itself does the exact reading when it runs.)
"""
from __future__ import annotations

import time
from typing import Any, Callable

from app.harness.payload import Scope
from app.harness.plan import day as DAY
from app.harness.plan import yields as Y
from app.harness.store import Store, chunks, marks

STRONG_SHARPE = 1.25
WINNER_SHARPE = 1.0
NEAR_MISS_SHARPE = 1.0


def _n(store: Store, sql: str, params: tuple = ()) -> int:
    return int(store.query(sql, params)[0][0] or 0)


def results_counts(store: Store, scope: Scope) -> dict[str, int]:
    """What the market's results look like, from Alpha Sentry's sim_results (one row per alpha)."""
    base = "FROM sim_results WHERE region=? AND delay=? AND universe=? AND alpha_id != ''"
    p = (scope.region, scope.delay, scope.universe)
    return {
        "alphas": _n(store, f"SELECT COUNT(DISTINCT alpha_id) {base}", p),
        "strong": _n(store, f"SELECT COUNT(DISTINCT alpha_id) {base} AND sharpe IS NOT NULL AND ABS(sharpe) >= ?", (*p, STRONG_SHARPE)),
        "winners": _n(store, f"SELECT COUNT(DISTINCT alpha_id) {base} AND sharpe IS NOT NULL AND ABS(sharpe) >= ?", (*p, WINNER_SHARPE)),
        "nearMisses": _n(store, f"SELECT COUNT(DISTINCT alpha_id) {base} AND COALESCE(submitted,0)=0 AND COALESCE(passed_gate,0)=0 "
                                f"AND sharpe IS NOT NULL AND ABS(sharpe) >= ?", (*p, NEAR_MISS_SHARPE)),
        "passing": _n(store, f"SELECT COUNT(DISTINCT alpha_id) {base} AND COALESCE(passed_gate,0)=1", p),
        "unsubmitted": _n(store, f"SELECT COUNT(DISTINCT alpha_id) {base} AND COALESCE(passed_gate,0)=1 AND COALESCE(submitted,0)=0", p),
        "fields": _n(store, "SELECT COUNT(*) FROM fields WHERE region=? AND delay=? AND type='MATRIX'", (scope.region, scope.delay)),
        "datasets": _n(store, "SELECT COUNT(DISTINCT dataset_id) FROM fields WHERE region=? AND delay=? AND type='MATRIX'", (scope.region, scope.delay)),
        "markets": _n(store, "SELECT COUNT(*) FROM (SELECT DISTINCT region, delay, universe FROM datasets WHERE universe != '')"),
    }


def deepened_expressions(tasks: list[dict[str, Any]]) -> set[str]:
    """Expressions that already have a deepen task (its description starts "Neighbourhood of: ")."""
    import json
    out: set[str] = set()
    for t in tasks:
        if t.get("lab") != "deepen":
            continue
        try:
            d = str(json.loads(t.get("template") or "{}").get("description") or "")
        except (ValueError, AttributeError):
            continue
        if d.startswith("Neighbourhood of: "):
            out.add(d[len("Neighbourhood of: "):].strip())
    return out


def readiness(counts: dict[str, int], labs: list[str], *, fresh_datasets: Callable[[], int] | None = None,
              undeepened: Callable[[], int] | None = None) -> dict[str, Any]:
    """{blockers: {lab: [reasons it cannot run today]}, capacity: {lab: n}} — a lab with no blocker is ready.

    `fresh_datasets` / `undeepened` are optional probes for the two checks that need more than a count; a probe that raises is ignored
    (the lab then simply counts as ready, and the lab itself says "nothing to do" when it runs)."""
    c = counts
    b: dict[str, list[str]] = {}

    def block(lab: str, why: str) -> None:
        b.setdefault(lab, []).append(why)

    if c["nearMisses"] == 0:
        block("repair", f"no unsubmitted alphas with |Sharpe| of {NEAR_MISS_SHARPE:g}+ that failed the gate in this market")
    if c["strong"] == 0:
        block("harden", f"no alphas with |Sharpe| of {STRONG_SHARPE:g}+ to test")
        block("deepen", f"no alphas with |Sharpe| of {STRONG_SHARPE:g}+ to explore around")
    if c["winners"] == 0:
        block("relocate", f"no alphas with |Sharpe| of {WINNER_SHARPE:g}+ to move to other markets")
        block("evolution", f"no alphas with |Sharpe| of {WINNER_SHARPE:g}+ to breed from")
    if c["markets"] < 2:
        block("relocate", "only one market has data downloaded")
    if c["fields"] == 0:
        for lab in ("harvest", "diversify", "pair"):
            block(lab, "no data fields are downloaded for this market (use Data Explorer first)")
    elif c["datasets"] < 2:
        block("pair", "pairing needs fields from at least two datasets")
    for lab, probe, why in (("diversify", fresh_datasets, "every dataset with fields is already used by one of your alphas"),
                            ("deepen", undeepened, "every strong alpha already has a deepen task")):
        if probe is not None and lab not in b:
            try:
                if probe() == 0:
                    block(lab, why)
            except Exception:  # noqa: BLE001
                pass
    return {"blockers": {k: v for k, v in b.items() if k in labs}, "capacity": {}}


def unscored(store: Store) -> int:
    """Simulations that finished but are not in Alpha Sentry's Results yet (status 'done'; 'scored' ones are)."""
    return _n(store, "SELECT COUNT(*) FROM harness_sim_record WHERE status='done'")


def vault_alphas(store: Store) -> int:
    try:
        return _n(store, "SELECT COUNT(DISTINCT alpha_id) FROM harness_alpha_pnl")
    except Exception:  # noqa: BLE001
        return 0


def trend(store: Store, *, days: int = 14, now: float | None = None) -> dict[str, Any]:
    """Per UTC day: simulations finished that day and how many of their alphas pass the gate (all labs and per lab). Days with nothing
    are present as zeros so a chart has no gaps. A day's `yieldRate` is passing / finished for the records created that day."""
    now = time.time() if now is None else now
    days = max(1, min(int(days), 90))
    first = DAY.day_start(now) - (days - 1) * 86400
    rows = store.query(f"SELECT task, status, alpha_id, created FROM harness_sim_record WHERE created >= ? AND status IN ({marks(len(Y.FINISHED))})",
                       (first, *Y.FINISHED))
    ids = sorted({r["alpha_id"] for r in rows if r["alpha_id"]})
    ok: dict[str, bool] = {}
    for part in chunks(ids):
        for v in store.query(f"SELECT alpha_id, MAX(COALESCE(passed_gate,0)) AS ok FROM sim_results WHERE alpha_id IN ({marks(len(part))}) GROUP BY alpha_id", part):
            ok[v["alpha_id"]] = bool(v["ok"])
    out: dict[str, dict[str, Any]] = {}
    for i in range(days):
        d = time.strftime("%Y-%m-%d", time.gmtime(first + i * 86400))
        out[d] = {"day": d, "finished": 0, "passing": 0, "byLab": {}}
    seen: set[tuple[str, str]] = set()
    for r in rows:
        d = time.strftime("%Y-%m-%d", time.gmtime(r["created"]))
        if d not in out:
            continue
        e, lab = out[d], Y.lab_of(r["task"])
        l = e["byLab"].setdefault(lab, {"finished": 0, "passing": 0})
        e["finished"] += 1
        l["finished"] += 1
        key = (d, r["alpha_id"])
        if r["alpha_id"] and ok.get(r["alpha_id"]) and key not in seen:        # an alpha counts once per day it was finished on
            seen.add(key)
            e["passing"] += 1
            l["passing"] += 1
    series = list(out.values())
    for e in series:
        e["yieldRate"] = round(e["passing"] / e["finished"], 5) if e["finished"] else 0.0
    return {"days": series, "targetYield": Y.TARGET_YIELD}


def snapshot(store: Store, scope: Scope, *, flags: dict[str, bool], engine: dict[str, Any] | None, plan: dict[str, Any] | None,
             yields: dict[str, Any] | None, tasks: list[dict[str, Any]], saturated: int = 0, counts: dict[str, int] | None = None) -> dict[str, Any]:
    """Everything plan.advisor.advise looks at, in its documented shape."""
    c = counts or results_counts(store, scope)
    return {"flags": flags, "engine": engine or {"running": False, "dry_run": False, "counts": {}},
            "plan": {k: plan[k] for k in ("budget", "spent", "remaining")} if plan else {}, "yields": yields, "tasks": tasks,
            "results": {k: c[k] for k in ("alphas", "strong", "nearMisses", "passing", "unsubmitted")},
            "unscored": unscored(store), "saturated": saturated, "vaultAlphas": vault_alphas(store)}
