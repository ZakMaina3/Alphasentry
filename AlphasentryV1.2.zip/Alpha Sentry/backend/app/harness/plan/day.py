"""The daily plan (fragment D1): how many of today's simulations each lab gets, decided by yield.

    yield  Y = passing / finished   (plan/yields.py; target 0.1%)

A lab with a good record is funded more; a lab we know little about regresses toward the target yield (a small sample is
not a verdict), so new labs get a fair exploration share instead of zero. Part of the budget is always reserved for
exploration (shared by every lab, double for labs we know little about), so a lab that was unlucky early is not starved. Nothing here runs anything: it turns numbers into a plan
(plan/dispatch.py queues it) and says in plain words why each lab got its share.

Pure functions plus two small readers: `spent_today` (what is already committed) and `PlanSettings` (a JSON file).
"""
from __future__ import annotations

import json
import math
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from app.harness.plan.yields import CONFIDENT_AT, TARGET_YIELD, LabYield
from app.harness.store import Store

#: Labs the planner can run without anyone typing anything (each reads Alpha Sentry's own data to find its inputs).
AUTO_LABS: dict[str, str] = {
    "repair": "fix near-miss alphas (needs alphas that failed one check)",
    "harden": "nudge strong alphas to see whether they are real (needs alphas with |Sharpe| above the bar)",
    "relocate": "run formulas that work in one market in the others",
    "harvest": "plain sensible patterns over the best fields in each dataset",
    "diversify": "fields only from datasets none of your alphas use",
    "pair": "cross-dataset field pairs",
    "evolution": "breed new expressions from your strongest alphas",
    "deepen": "explore around your best alpha that has not been deepened yet",
}
PRIOR_K = CONFIDENT_AT                       # the target yield counts as this many finished simulations of prior evidence
DEFAULTS: dict[str, Any] = {"daily_budget": 300, "explore_fraction": 0.3, "min_chunk": 10, "labs": list(AUTO_LABS)}
_lock = threading.Lock()


class PlanError(ValueError):
    pass


# ── settings ──────────────────────────────────────────────────────────────────────────────────
class PlanSettings:
    """Daily budget, exploration share, smallest allocation worth running, and which labs the plan may use."""

    def __init__(self, path: Path | None = None) -> None:
        self.path, self._mem = path, {}

    def config(self) -> dict[str, Any]:
        out = dict(DEFAULTS)
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8")) if self.path else self._mem
            out.update({k: raw[k] for k in DEFAULTS if k in raw})
        except Exception:  # noqa: BLE001
            pass
        out["labs"] = [x for x in out["labs"] if x in AUTO_LABS]
        return out

    def set_config(self, **kw: Any) -> dict[str, Any]:
        cur = self.config()
        for k, v in kw.items():
            if v is None:
                continue
            if k not in DEFAULTS:
                raise PlanError(f"Unknown planning setting: {k}.")
            if k == "labs":
                bad = [x for x in v if x not in AUTO_LABS]
                if bad:
                    raise PlanError(f"Unknown lab(s): {', '.join(map(str, bad))}. Choose from: {', '.join(AUTO_LABS)}.")
                cur[k] = list(dict.fromkeys(v))
                continue
            try:
                f = float(v)
            except (TypeError, ValueError):
                raise PlanError(f"{k} must be a number.") from None
            if math.isnan(f) or math.isinf(f) or f < 0:
                raise PlanError(f"{k} cannot be negative.")
            if k == "explore_fraction" and f > 1:
                raise PlanError("explore_fraction is a share between 0 and 1 (0.3 = 30%).")
            cur[k] = int(f) if k in ("daily_budget", "min_chunk") else f
        if cur["min_chunk"] < 1:
            raise PlanError("min_chunk must be at least 1.")
        with _lock:
            if self.path:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                self.path.write_text(json.dumps(cur, indent=2), encoding="utf-8")
            else:
                self._mem = dict(cur)
        return self.config()


# ── what is already spoken for today ──────────────────────────────────────────────────────────
def day_start(now: float) -> float:
    return now - now % 86400                                                    # UTC midnight, same day boundary as the LLM caps


def spent_today(store: Store, now: float | None = None) -> dict[str, int]:
    """Simulations already used or committed today: records created today (queued, running or finished; dry-runs and cancelled ones
    spend nothing) plus the not-yet-queued part of every running or paused task's budget."""
    now = time.time() if now is None else now
    records = int(store.query("SELECT COUNT(*) AS n FROM harness_sim_record WHERE created >= ? AND status NOT IN ('dryrun','cancelled')",
                              (day_start(now),))[0]["n"])
    committed = 0
    for t in store.query("SELECT id, budget FROM harness_task WHERE status IN ('running','paused')"):
        made = int(store.query("SELECT COUNT(*) AS n FROM harness_trial WHERE task_id=? AND status != 'pruned'", (t["id"],))[0]["n"])
        committed += max(0, int(t["budget"]) - made)
    return {"records": records, "committed": committed, "total": records + committed}


# ── allocation ────────────────────────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class LabInput:
    lab: str
    finished: int = 0
    passing: int = 0
    capacity: int | None = None             # most simulations this lab can still make today, if known (None = unknown)

    @property
    def smoothed(self) -> float:
        """Yield with the target as a prior: (passing + k*target) / (finished + k). No data -> exactly the target."""
        return (self.passing + PRIOR_K * TARGET_YIELD) / (self.finished + PRIOR_K)

    @property
    def confident(self) -> bool:
        return self.finished >= CONFIDENT_AT

    @property
    def raw_yield(self) -> float:
        return self.passing / self.finished if self.finished else 0.0


def _waterfill(want: dict[str, float], cap: dict[str, int | None]) -> dict[str, float]:
    """Apply per-lab capacities; what a capped lab cannot take goes to the others in proportion to what they already get."""
    want = dict(want)
    for _ in range(len(want) + 1):
        over = {k: want[k] - cap[k] for k in want if cap[k] is not None and want[k] > cap[k] + 1e-9}
        if not over:
            break
        spill = sum(over.values())
        for k in over:
            want[k] = float(cap[k])
        free = [k for k in want if cap[k] is None or want[k] < cap[k] - 1e-9]
        if not free:
            break
        base = sum(want[k] for k in free)
        for k in free:
            want[k] += spill * (want[k] / base if base > 0 else 1 / len(free))
    return want


def _round(want: dict[str, float], cap: dict[str, int | None], total: int) -> dict[str, int]:
    """Whole simulations that add up to `total` (largest remainder), never above a lab's capacity."""
    out = {k: int(math.floor(v + 1e-9)) for k, v in want.items()}
    order = sorted(want, key=lambda k: -(want[k] - out[k]))
    left = total - sum(out.values())
    while left > 0:
        moved = False
        for k in order:
            if left > 0 and (cap[k] is None or out[k] < cap[k]):
                out[k] += 1
                left -= 1
                moved = True
        if not moved:
            break
    return out


def allocate(budget: int, labs: list[LabInput], *, explore_fraction: float = 0.3, min_chunk: int = 10) -> list[dict[str, Any]]:
    """Split `budget` simulations across `labs`. Every lab that gets anything gets at least min_chunk (unless the whole budget is
    smaller than that, when the best lab takes it all). Returns one dict per funded lab, biggest first."""
    labs = [l for l in labs if l.capacity is None or l.capacity >= 1]
    budget = int(budget)
    if budget < 1 or not labs:
        return []
    explore = min(1.0, max(0.0, explore_fraction))
    weight = {l.lab: l.smoothed for l in labs}
    wsum = sum(weight.values())
    pull = {l.lab: (1.0 if l.confident else 2.0) for l in labs}                  # exploration: every lab, labs we know little about get double
    psum = sum(pull.values())
    want = {l.lab: budget * (1 - explore) * weight[l.lab] / wsum + budget * explore * pull[l.lab] / psum for l in labs}
    cap = {l.lab: l.capacity for l in labs}
    want = _waterfill(want, cap)
    total = min(budget, int(round(sum(want.values()))))
    shares = _round(want, cap, total)
    funded = {k: v for k, v in shares.items() if v >= 1}
    small = [k for k, v in funded.items() if v < min_chunk]
    if small and len(funded) > 1:
        keep = [l for l in labs if l.lab in funded and l.lab not in small] if budget >= min_chunk else []
        if not keep:                                                              # too little to split: the best lab takes it all
            keep = [max((l for l in labs if l.lab in funded), key=lambda l: l.smoothed)]
        return allocate(budget, keep, explore_fraction=explore, min_chunk=min_chunk)
    by_lab = {l.lab: l for l in labs}
    out = []
    for k, v in sorted(funded.items(), key=lambda kv: -kv[1]):
        l = by_lab[k]
        capped = l.capacity is not None and v >= l.capacity
        out.append({"lab": k, "sims": v, "share": round(v / max(1, sum(funded.values())), 3), "smoothedYield": round(l.smoothed, 5),
                    "finished": l.finished, "passing": l.passing, "confident": l.confident, "capped": capped, "why": reason(l, capped)})
    return out


def reason(l: LabInput, capped: bool = False) -> str:
    if l.confident and l.raw_yield >= TARGET_YIELD:
        why = f"Proven: {l.passing:,} of {l.finished:,} finished simulations passed ({l.raw_yield * 100:.2f}%, target {TARGET_YIELD * 100:.1f}%)."
    elif l.confident:
        why = (f"Kept small: {l.passing:,} of {l.finished:,} finished simulations passed ({l.raw_yield * 100:.2f}%, below the "
               f"{TARGET_YIELD * 100:.1f}% target), so it only gets its exploration share.")
    elif l.finished:
        why = f"Too early to judge ({l.finished:,} finished, {CONFIDENT_AT} needed): it gets an exploration share."
    else:
        why = "No history yet: it gets an exploration share so it can prove itself."
    return why + (f" Limited to the {l.capacity} candidates it has." if capped else "")


# ── the plan ──────────────────────────────────────────────────────────────────────────────────
def make_plan(cfg: dict[str, Any], book: dict[str, LabYield], spent: int, *, capacity: dict[str, int] | None = None,
              exclude: set[str] | None = None) -> dict[str, Any]:
    """Today's plan. `book` is the yield book (plan.yields.by_lab), `spent` what is already used or committed today, `capacity`
    optional per-lab limits (dispatch learns these when a lab runs out of candidates), `exclude` labs to leave out."""
    capacity, exclude = capacity or {}, exclude or set()
    chosen = [x for x in cfg["labs"] if x in AUTO_LABS and x not in exclude]
    remaining = max(0, int(cfg["daily_budget"]) - int(spent))
    notes: list[str] = []
    if not chosen:
        notes.append("No labs are switched on for the plan. Tick at least one in the plan settings.")
    if remaining == 0:
        notes.append(f"Today's budget of {int(cfg['daily_budget']):,} simulations is already used or committed ({int(spent):,}).")
    inputs = [LabInput(x, book[x].finished if x in book else 0, book[x].passing if x in book else 0, capacity.get(x)) for x in chosen]
    allocations = allocate(remaining, inputs, explore_fraction=float(cfg["explore_fraction"]), min_chunk=int(cfg["min_chunk"])) if chosen else []
    if chosen and remaining and not allocations:
        notes.append("None of the chosen labs has any candidates left today.")
    return {"budget": int(cfg["daily_budget"]), "spent": int(spent), "remaining": remaining, "allocations": allocations,
            "planned": sum(a["sims"] for a in allocations), "exploreFraction": float(cfg["explore_fraction"]),
            "labs": [{"lab": l.lab, "finished": l.finished, "passing": l.passing, "yield": round(l.raw_yield, 5),
                      "smoothedYield": round(l.smoothed, 5), "confident": l.confident} for l in inputs], "notes": notes}
