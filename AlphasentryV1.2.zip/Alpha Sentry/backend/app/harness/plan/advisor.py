"""Plain-language "what to do next" (fragment D3). Rules over a snapshot of the system; no LLM needed. An LLM can optionally rewrite the
top items as a short paragraph (`narrate`), and any failure there just returns the rule text. Nothing here acts on anything.

Snapshot (all keys optional; a missing key just means that rule stays quiet):
  flags    {name: bool}                      engine  {"running", "dry_run", "counts": {status: n}}
  plan     {"budget", "spent", "remaining"}  yields  plan.yields.summary(...)       tasks  [public task dicts]
  results  {"alphas", "strong", "nearMisses", "passing", "unsubmitted"}             unscored  finished sims not yet in Results
  saturated  number of answered alpha shapes                                        vaultAlphas  alphas with stored returns
Each item: {id, priority (1 = most urgent), title, why, tab} where tab names the SentryEngine tab that does it.
"""
from __future__ import annotations

from typing import Any, Callable

STRONG = "|Sharpe| of at least 1.25"


def _item(id_: str, priority: int, title: str, why: str, tab: str | None = None) -> dict[str, Any]:
    return {"id": id_, "priority": priority, "title": title, "why": why, "tab": tab}


def advise(s: dict[str, Any], limit: int = 8) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    flags, eng, plan = s.get("flags") or {}, s.get("engine") or {}, s.get("plan") or {}
    counts, res = eng.get("counts") or {}, s.get("results") or {}
    queued, running = int(counts.get("queued", 0)), int(counts.get("running", 0))
    tasks = s.get("tasks") or []

    if s.get("flags") is not None and not flags.get("harness_engine"):
        out.append(_item("engine-off", 1, "Turn on the SentryEngine", "Every lab and task needs “SentryEngine + labs” switched on in Control. Nothing runs without it.", "control"))
    elif eng.get("dry_run") and (queued or any(t.get("status") == "running" for t in tasks)):
        out.append(_item("dry-run", 1, "Dry-run is on", "Nothing is being simulated and tasks do not advance while dry-run is on. Switch it off in Control when you are ready for a real run.", "control"))
    elif queued and not eng.get("running"):
        out.append(_item("start-engine", 1, f"Start the engine: {queued:,} simulation(s) are waiting", "They are queued but the engine is stopped, so none of them will run.", "control"))

    if s.get("unscored"):
        out.append(_item("score", 2, f"Score {int(s['unscored']):,} finished simulation(s) into Results", "They finished but are not in Results yet, so Alpha Sentry cannot rank, tag or learn from them. “Score finished now” in Control does it.", "control"))

    for t in tasks:
        if t.get("status") == "error":
            out.append(_item(f"task-{t['id']}", 2, f"Task #{t['id']} “{t.get('name', '')}” stopped with an error", str(t.get("error") or "No reason recorded.")[:300] + " Fix the cause (usually the template) and create it again.", "tasks"))

    rem = plan.get("remaining")
    if flags.get("harness_engine") and rem and rem > 0 and not queued and not running:
        out.append(_item("run-plan", 2, f"Run today's plan: {int(rem):,} simulation(s) of today's budget are unused", "Nothing is queued or running. Queuing today's plan spreads them over the labs by yield.", "planning"))
    elif rem == 0 and plan.get("budget"):
        out.append(_item("budget-used", 4, "Today's simulation budget is fully used", "Further queuing waits for tomorrow (UTC) unless you raise the daily budget in the plan settings.", "planning"))

    if s.get("results") is not None and int(res.get("alphas", 0) or 0) == 0:
        out.append(_item("seed", 2, "Start with Harvest", "There are no results in this market yet. Harvest tries plain patterns over the best fields and gives every other lab something to work from (download data in Data Explorer first).", "labs"))
    if res.get("nearMisses"):
        out.append(_item("repair", 3, f"Repair {int(res['nearMisses']):,} near-miss alpha(s)", "They came close to passing; Repair applies the one fix each failed check calls for. Near-misses convert far better than fresh guesses.", "labs"))
    if res.get("strong"):
        out.append(_item("harden", 3, f"Harden or deepen your {int(res['strong']):,} strong alpha(s)", f"Alphas with {STRONG} are worth checking against small changes (Harden) or exploring around (Deepen) before you rely on them.", "labs"))
    if int(res.get("passing", 0) or 0) >= 3:
        out.append(_item("evolve", 4, "Evolve from your passing alphas", "With three or more passing alphas, Evolution can breed variations of them and keep what scores better.", "evolution"))
        if not flags.get("harness_vault") and int(s.get("vaultAlphas", 0) or 0) == 0:
            out.append(_item("mix", 4, "Try mixing", "Combining weakly correlated alphas can pass where each alone does not. Switch on “Returns vault + mixing” and backfill returns.", "mixing"))
    if int(res.get("unsubmitted", 0) or 0):
        out.append(_item("review", 4, f"Review {int(res['unsubmitted']):,} passing alpha(s) you have not submitted", "Look-alikes are best reviewed together, keeping the strongest of each. The harness never submits anything for you.", "planning"))

    sure = [l for l in (s.get("yields") or {}).get("labs") or [] if l.get("confident")]
    if sure:
        best = max(sure, key=lambda l: l["yieldRate"])
        if best["passing"]:
            out.append(_item("best-lab", 5, f"{best['lab']} converts best: {best['yieldRate'] * 100:.2f}% of finished simulations pass", "That is the lab to give more of the day to. The daily plan already does this.", "planning"))
        for l in sure:
            if not l["passing"] and l["finished"] >= 400:
                out.append(_item(f"dead-{l['lab']}", 3, f"{l['lab']} has produced nothing in {l['finished']:,} simulations", "Give it a different market or inputs, or leave it with its small exploration share and spend the rest elsewhere.", "planning"))
    if int(s.get("saturated", 0) or 0) >= 5:
        out.append(_item("saturated", 4, f"{int(s['saturated'])} alpha shapes in this market are already answered", "Repeating them mostly produces look-alikes. Diversify and Pair reach fields and shapes you have not used.", "labs"))

    out.sort(key=lambda i: (i["priority"], i["id"]))
    return out[:max(1, limit)]


def narrate(items: list[dict[str, Any]], complete: Callable[[str, str], str] | None) -> dict[str, Any]:
    """The top items as a short paragraph written by YOUR LLM, or the rule text if there is no LLM or it fails."""
    plain = " ".join(f"{i['title']}. {i['why']}" for i in items[:3]) or "Nothing needs attention right now."
    if not items or complete is None:
        return {"text": plain, "usedLLM": False}
    try:
        text = (complete("You are the planning assistant inside an alpha-research tool. Rewrite these recommendations as one short, friendly paragraph "
                         "(at most 90 words) in plain language. Do not invent facts, numbers or actions beyond what is listed. Never suggest submitting anything.",
                         "\n".join(f"- [{i['priority']}] {i['title']} — {i['why']}" for i in items[:5])) or "").strip()
        return {"text": text, "usedLLM": True} if text else {"text": plain, "usedLLM": False, "error": "The model returned nothing."}
    except Exception as e:  # noqa: BLE001      narration is a nicety: never lose the advice over it
        return {"text": plain, "usedLLM": False, "error": str(e)[:200]}
