"""Yield rate: how much of the simulation allowance each lab turns into alphas that pass (ported from
alpha_harness.plan.yields, rebuilt on Alpha Sentry's data).

    Y = passing alphas / finished simulations      target Y >= 0.1%

Ranking labs by yield (not by their best Sharpe) funds whichever one converts compute, the only resource being
spent. This module MEASURES; it does not allocate. Only FINISHED simulations count: work still queued has not
had its chance, and counting it would make every lab look worse the moment it was funded.

Adaptation: AH judged "submittable" from BRAIN's full check list. Alpha Sentry already decides pass/fail with its own gate
(sim_results.passed_gate), so that is the verdict here (a proxy; stricter than nothing, looser than all checks).
Records are the harness' simulation records, so Autosentry batches routed through the engine count under the lab
name "autopilot" and every lab under its own id (relocate, repair, harden, harvest, diversify, pair, mix).
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

from app.harness.store import Store, chunks, marks

TARGET_YIELD = 0.001
CONFIDENT_AT = 200                               # one good simulation is not a trend: don't defund on a sample of five
FINISHED = ("done", "scored", "external")         # 'error' / 'cancelled' / 'dryrun' never got a verdict
COUNTED = FINISHED + ("error",)                  # simulated = attempted and resolved (an error did spend an attempt)


@dataclass(frozen=True)
class LabYield:
    lab: str
    simulated: int
    finished: int
    alphas: int
    passing: int
    best_sharpe: float | None = None             # display only — never for allocation

    @property
    def yield_rate(self) -> float:
        return self.passing / self.finished if self.finished else 0.0

    def to_dict(self) -> dict[str, Any]:
        return {"lab": self.lab, "simulated": self.simulated, "finished": self.finished, "alphas": self.alphas,
                "passing": self.passing, "yieldRate": round(self.yield_rate, 5),
                "meetsTarget": self.yield_rate >= TARGET_YIELD, "bestSharpe": self.best_sharpe,
                "confident": self.finished >= CONFIDENT_AT}


def lab_of(task: str) -> str:
    """Task names may carry a day (``sweep-2026-09-08-1``); yield is judged per lab across days."""
    return (task or "").split("-", 1)[0] or "manual"


def plainly(finished: int, passing: int) -> str:
    if not finished:
        return "Nothing has finished running yet, so there is nothing to judge."
    if not passing:
        return (f"None of your last {finished:,} finished simulations passed the gate. That is normal early on — "
                "it takes volume before the good ones appear.")
    return f"{passing:,} of your last {finished:,} finished simulations passed the gate."


def by_lab(store: Store, *, days: int = 14, now: float | None = None) -> dict[str, LabYield]:
    since = (now or time.time()) - days * 86400
    rows = store.query(f"SELECT task, status, alpha_id FROM harness_sim_record WHERE created >= ? AND status IN ({marks(len(COUNTED))})",
                       (since, *COUNTED))
    per: dict[str, dict[str, Any]] = {}
    for r in rows:
        e = per.setdefault(lab_of(r["task"]), {"simulated": 0, "finished": 0, "alphas": set()})
        e["simulated"] += 1
        if r["status"] in FINISHED:
            e["finished"] += 1
        if r["alpha_id"]:
            e["alphas"].add(r["alpha_id"])
    every = sorted({a for e in per.values() for a in e["alphas"]})
    verdict: dict[str, tuple[bool, float | None]] = {}
    for part in chunks(every):
        for v in store.query(f"SELECT alpha_id, MAX(COALESCE(passed_gate,0)) AS ok, MAX(ABS(COALESCE(sharpe,0))) AS sh "
                             f"FROM sim_results WHERE alpha_id IN ({marks(len(part))}) GROUP BY alpha_id", part):
            verdict[v["alpha_id"]] = (bool(v["ok"]), float(v["sh"]) if v["sh"] else None)
    book = {}
    for lab, e in per.items():
        ids = e["alphas"]
        sharpes = [verdict[a][1] for a in ids if a in verdict and verdict[a][1]]
        book[lab] = LabYield(lab, e["simulated"], e["finished"], len(ids), sum(1 for a in ids if verdict.get(a, (False,))[0]),
                             max(sharpes) if sharpes else None)
    return book


def summary(store: Store, *, days: int = 14, now: float | None = None) -> dict[str, Any]:
    book = by_lab(store, days=days, now=now)
    finished = sum(y.finished for y in book.values())
    passing = sum(y.passing for y in book.values())
    overall = passing / finished if finished else 0.0
    return {"days": days, "labs": [y.to_dict() for y in sorted(book.values(), key=lambda y: -y.yield_rate)],
            "simulated": sum(y.simulated for y in book.values()), "finished": finished, "passing": passing,
            "yieldRate": round(overall, 5), "targetYield": TARGET_YIELD, "meetsTarget": overall >= TARGET_YIELD,
            "plainly": plainly(finished, passing)}
