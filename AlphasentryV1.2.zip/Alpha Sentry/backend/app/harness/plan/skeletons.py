"""Which shapes of alpha this market has already been asked for (ported from alpha_harness.plan.skeletons).

Counts finished work by SKELETON — the expression with data fields and numbers removed — and reports which
shapes are worked out: tried enough times to produce nothing, or already produced as many submittable alphas
as it will before they start colliding with each other. Nothing here blocks anything: it removes a shape from
the menu a lab draws from and says so in the preview.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Iterable

from app.harness.labs.exprtools import GROUPING_FIELDS, fields_in

DEAD_AFTER = 40        # tried this many times with nothing to show: the shape is answered
CROWDED_AT = 3         # submittable alphas of one shape before further ones just correlate with each other
WINDOW_DAYS = 30

_NUMBER = re.compile(r"\b\d+\.\d+|\b\d+\b")
_SPACE = re.compile(r"\s+")


def skeleton(expression: str | None) -> str:
    """An expression reduced to its shape: data fields -> F, whole numbers -> N, decimals -> D; grouping
    fields are left alone (group_rank(F, subindustry) and group_rank(F, sector) are different shapes).

    >>> skeleton("group_rank(ts_rank(ts_backfill(assets, 120), 252), subindustry)")
    'group_rank(ts_rank(ts_backfill(F,N),N),subindustry)'
    """
    if not expression:
        return ""
    text = expression.strip()
    if ";" in text:                       # only the last statement decides the shape
        text = text.rsplit(";", 1)[-1]
    for name in sorted(fields_in(text), key=len, reverse=True):
        if name in GROUPING_FIELDS:
            continue
        text = re.sub(rf"\b{re.escape(name)}\b", "F", text)
    text = _NUMBER.sub(lambda m: "D" if "." in m.group(0) else "N", text)
    return _SPACE.sub("", text)


@dataclass(frozen=True)
class ShapeRecord:
    shape: str
    tried: int
    submittable: int

    @property
    def saturated(self) -> bool:
        return self.submittable >= CROWDED_AT or (self.tried >= DEAD_AFTER and self.submittable == 0)

    @property
    def why(self) -> str:
        if self.submittable >= CROWDED_AT:
            return f"{self.submittable} alphas of this shape already passed; more of them would be too alike to submit"
        return f"tried {self.tried} times here and none passed"

    def to_dict(self) -> dict[str, Any]:
        return {"shape": self.shape, "tried": self.tried, "submittable": self.submittable,
                "saturated": self.saturated, "why": self.why}


def tally(finished: Iterable[tuple[str, bool]]) -> dict[str, ShapeRecord]:
    """finished: (expression, passed) for every completed simulation in the scope/window."""
    t: dict[str, list[int]] = {}
    for expression, passed in finished:
        shape = skeleton(expression)
        if not shape:
            continue
        e = t.setdefault(shape, [0, 0])
        e[0] += 1
        e[1] += 1 if passed else 0
    return {s: ShapeRecord(s, a, b) for s, (a, b) in t.items()}


def saturated_of(records: dict[str, ShapeRecord]) -> dict[str, ShapeRecord]:
    return {s: r for s, r in records.items() if r.saturated}


def drop_saturated(candidates: list[str], saturated: dict[str, ShapeRecord]) -> tuple[list[str], list[str]]:
    """Split into (worth running, answered) — returned, not filtered in place, so a lab can say what it left out."""
    keep: list[str] = []
    dropped: list[str] = []
    for e in candidates:
        (dropped if skeleton(e) in saturated else keep).append(e)
    return keep, dropped
