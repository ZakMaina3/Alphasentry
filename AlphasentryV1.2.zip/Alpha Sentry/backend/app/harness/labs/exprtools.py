"""Expression helpers (ported from alpha_harness.templates.validate). Regex-based and approximate by
design: used for limits and warnings, never to reject an expression outright."""
from __future__ import annotations

import re

GROUPING_FIELDS = frozenset({"country", "industry", "subindustry", "currency", "market", "sector", "exchange"})
UNCOUNTED_OPERATORS = frozenset({"ts_backfill", "group_backfill"})
NON_FIELDS = frozenset({"true", "false", "nan", "inf"})
POWER_POOL_MAX_OPERATORS = 8
POWER_POOL_MAX_FIELDS = 3
CALL = re.compile(r"\b([A-Za-z_]\w*)\s*\(")
IDENTIFIER = re.compile(r"\b[A-Za-z_]\w*\b")


def operators_in(expression: str) -> list[str]:
    """Every operator call, repeats included — the platform counts repeats."""
    return CALL.findall(expression)


def count_operators(expression: str) -> int:
    return sum(1 for n in operators_in(expression) if n not in UNCOUNTED_OPERATORS)


def fields_in(expression: str) -> set[str]:
    calls = set(operators_in(expression))
    no_str = re.sub(r"\"[^\"]*\"|'[^']*'", " ", expression)
    no_kw = re.sub(r"\b\w+\s*=(?!=)", " ", no_str)
    found = set(IDENTIFIER.findall(no_kw))
    return {f for f in found - calls if f.lower() not in NON_FIELDS and not f.isdigit()}


def unique_data_fields(expression: str) -> set[str]:
    return {f for f in fields_in(expression) if f not in GROUPING_FIELDS}
