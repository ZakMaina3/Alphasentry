"""A small expression tree for BRAIN's FASTEXPR (pure Python, no dependencies).

Used by Deepen (find the windows / operators to vary) and Evolution (mutate and cross over alphas). It understands what alpha
expressions actually use: numbers, data fields, function calls with positional and keyword arguments, + - * /, comparisons,
&& || !, `a ? b : c`, string literals and `name = expr;` statements. It is NOT a validator: BRAIN decides what is legal.
What it guarantees is that `parse(print_(parse(s)))` describes the same tree as `parse(s)` (formatting is normalised).

Nodes are frozen dataclasses with `children()` / `with_children()`, so every edit is a pure function that returns a new tree.
A *path* is a tuple of child indexes from the root (the root is a `Program` whose children are its statements).
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterator

from app.harness.labs.exprtools import GROUPING_FIELDS, NON_FIELDS


class ExprError(ValueError):
    pass


# ── nodes ──────────────────────────────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class Num:
    text: str

    @property
    def is_int(self) -> bool:
        return self.text.isdigit()


@dataclass(frozen=True)
class Name:
    id: str


@dataclass(frozen=True)
class Str:
    text: str            # including its quotes


@dataclass(frozen=True)
class Unary:
    op: str              # "-" | "!" | "+"
    operand: "Node"


@dataclass(frozen=True)
class Binary:
    op: str
    left: "Node"
    right: "Node"


@dataclass(frozen=True)
class Ternary:
    cond: "Node"
    a: "Node"
    b: "Node"


@dataclass(frozen=True)
class Call:
    name: str
    args: tuple["Node", ...]
    kwargs: tuple[str | None, ...]      # same length as args: the keyword of each argument, or None if positional


@dataclass(frozen=True)
class Assign:
    name: str
    value: "Node"


@dataclass(frozen=True)
class Program:
    statements: tuple["Node", ...]


Node = Num | Name | Str | Unary | Binary | Ternary | Call | Assign | Program


def children(n: Node) -> tuple[Node, ...]:
    if isinstance(n, Unary):
        return (n.operand,)
    if isinstance(n, Binary):
        return (n.left, n.right)
    if isinstance(n, Ternary):
        return (n.cond, n.a, n.b)
    if isinstance(n, Call):
        return n.args
    if isinstance(n, Assign):
        return (n.value,)
    if isinstance(n, Program):
        return n.statements
    return ()


def with_children(n: Node, kids: tuple[Node, ...]) -> Node:
    if isinstance(n, Unary):
        return Unary(n.op, kids[0])
    if isinstance(n, Binary):
        return Binary(n.op, kids[0], kids[1])
    if isinstance(n, Ternary):
        return Ternary(*kids)
    if isinstance(n, Call):
        return Call(n.name, tuple(kids), n.kwargs)
    if isinstance(n, Assign):
        return Assign(n.name, kids[0])
    if isinstance(n, Program):
        return Program(tuple(kids))
    return n


Path = tuple[int, ...]


def get_at(root: Node, path: Path) -> Node:
    for i in path:
        root = children(root)[i]
    return root


def replace_at(root: Node, path: Path, new: Node) -> Node:
    if not path:
        return new
    kids = list(children(root))
    kids[path[0]] = replace_at(kids[path[0]], path[1:], new)
    return with_children(root, tuple(kids))


def walk(root: Node, path: Path = ()) -> Iterator[tuple[Path, Node]]:
    """Every node, parents before children, in source order."""
    yield path, root
    for i, k in enumerate(children(root)):
        yield from walk(k, path + (i,))


def depth(n: Node) -> int:
    return 1 + max((depth(k) for k in children(n)), default=0)


# ── tokenizer ──────────────────────────────────────────────────────────────────────────────────
_TOKEN = re.compile(r"""\s*(?:
    (?P<num>(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)
  | (?P<id>[A-Za-z_$][A-Za-z_0-9$]*)
  | (?P<str>"[^"]*"|'[^']*')
  | (?P<op><=|>=|==|!=|&&|\|\||[-+*/<>=!?:(),;])
)""", re.X)


def tokenize(text: str) -> list[tuple[str, str, int]]:
    out, pos = [], 0
    text = text.rstrip()
    while pos < len(text):
        m = _TOKEN.match(text, pos)
        if not m or m.end() == pos:
            raise ExprError(f"Unexpected character {text[pos:pos + 1].strip() or text[pos:pos + 1]!r} at position {pos}.")
        kind = m.lastgroup
        out.append((kind, m.group(kind), m.start(kind)))
        pos = m.end()
    return out


# ── parser ─────────────────────────────────────────────────────────────────────────────────────
_BINARY_LEVELS = [("||",), ("&&",), ("==", "!="), ("<", ">", "<=", ">="), ("+", "-"), ("*", "/")]
PRECEDENCE = {op: i + 2 for i, ops in enumerate(_BINARY_LEVELS) for op in ops}      # ternary = 1, unary = 8
UNARY_PRECEDENCE = 8


class _Parser:
    def __init__(self, text: str) -> None:
        self.toks = tokenize(text)
        self.i = 0

    def peek(self, k: int = 0) -> tuple[str, str, int] | None:
        return self.toks[self.i + k] if self.i + k < len(self.toks) else None

    def take(self, value: str | None = None) -> tuple[str, str, int]:
        t = self.peek()
        if t is None:
            raise ExprError("The expression ends unexpectedly" + (f" (expected {value!r})." if value else "."))
        if value is not None and t[1] != value:
            raise ExprError(f"Expected {value!r} but found {t[1]!r} at position {t[2]}.")
        self.i += 1
        return t

    def program(self) -> Program:
        stmts: list[Node] = []
        while self.peek() is not None:
            if self.peek()[1] == ";":
                self.take()
                continue
            stmts.append(self.statement())
            if self.peek() is not None:
                self.take(";")
        if not stmts:
            raise ExprError("The expression is empty.")
        return Program(tuple(stmts))

    def statement(self) -> Node:
        a, b = self.peek(), self.peek(1)
        if a and b and a[0] == "id" and b[1] == "=":
            self.take()
            self.take("=")
            return Assign(a[1], self.expr())
        return self.expr()

    def expr(self) -> Node:
        cond = self.binary(2)
        if self.peek() and self.peek()[1] == "?":
            self.take("?")
            a = self.expr()
            self.take(":")
            return Ternary(cond, a, self.expr())
        return cond

    def binary(self, level: int) -> Node:
        if level > 7:
            return self.unary()
        left = self.binary(level + 1)
        while self.peek() and self.peek()[0] == "op" and PRECEDENCE.get(self.peek()[1]) == level:
            op = self.take()[1]
            left = Binary(op, left, self.binary(level + 1))
        return left

    def unary(self) -> Node:
        t = self.peek()
        if t and t[0] == "op" and t[1] in ("-", "+", "!"):
            self.take()
            return Unary(t[1], self.unary())
        return self.atom()

    def atom(self) -> Node:
        t = self.take()
        kind, val = t[0], t[1]
        if kind == "num":
            return Num(val)
        if kind == "str":
            return Str(val)
        if kind == "id":
            if self.peek() and self.peek()[1] == "(":
                self.take("(")
                args: list[Node] = []
                kws: list[str | None] = []
                while not (self.peek() and self.peek()[1] == ")"):
                    a, b = self.peek(), self.peek(1)
                    if a and b and a[0] == "id" and b[1] == "=":
                        self.take()
                        self.take("=")
                        kws.append(a[1])
                    else:
                        kws.append(None)
                    args.append(self.expr())
                    if self.peek() and self.peek()[1] == ",":
                        self.take(",")
                    elif not (self.peek() and self.peek()[1] == ")"):
                        raise ExprError(f"Expected ',' or ')' in the arguments of {val}(…).")
                self.take(")")
                return Call(val, tuple(args), tuple(kws))
            return Name(val)
        if val == "(":
            inner = self.expr()
            self.take(")")
            return inner
        raise ExprError(f"Unexpected {val!r} at position {t[2]}.")


def parse(text: str) -> Program:
    p = _Parser(text)
    prog = p.program()
    return prog


# ── printer ────────────────────────────────────────────────────────────────────────────────────
def _prec(n: Node) -> int:
    if isinstance(n, Ternary):
        return 1
    if isinstance(n, Binary):
        return PRECEDENCE[n.op]
    if isinstance(n, Unary):
        return UNARY_PRECEDENCE
    return 99


def _expr(n: Node, parent: int = 0, right: bool = False) -> str:
    if isinstance(n, Num):
        s = n.text
    elif isinstance(n, Name):
        s = n.id
    elif isinstance(n, Str):
        s = n.text
    elif isinstance(n, Call):
        parts = [(f"{k}=" if k else "") + _expr(a) for a, k in zip(n.args, n.kwargs)]
        s = f"{n.name}({', '.join(parts)})"
    elif isinstance(n, Unary):
        s = n.op + _expr(n.operand, UNARY_PRECEDENCE)
    elif isinstance(n, Binary):
        p = PRECEDENCE[n.op]
        s = f"{_expr(n.left, p)} {n.op} {_expr(n.right, p, True)}"
    elif isinstance(n, Ternary):
        s = f"{_expr(n.cond, 2)} ? {_expr(n.a)} : {_expr(n.b)}"
    else:
        raise ExprError("Cannot print this node as an expression.")
    p = _prec(n)
    need = p < parent or (p == parent and right and isinstance(n, Binary))
    return f"({s})" if need else s


def print_(n: Node) -> str:
    if isinstance(n, Program):
        return "; ".join(print_(s) for s in n.statements)
    if isinstance(n, Assign):
        return f"{n.name} = {_expr(n.value)}"
    return _expr(n)


def canon(text: str) -> str:
    """Normalised spelling of an expression: two alphas that differ only in spacing / redundant parentheses are equal."""
    return print_(parse(text))


# ── what a node is, in context (drives which edits are sensible) ───────────────────────────────
def assigned_names(prog: Program) -> set[str]:
    return {s.name for s in prog.statements if isinstance(s, Assign)}


def is_window_literal(parent: Node | None, index: int, node: Node) -> bool:
    """An integer literal in a time-series operator's argument list after the first argument is a window."""
    return (isinstance(node, Num) and node.is_int and isinstance(parent, Call) and parent.name.startswith("ts_")
            and index >= 1 and parent.kwargs[index] is None)


def classify(prog: Program) -> dict[Path, str]:
    """path -> 'window' | 'field' | 'group' | 'var' | 'const' | 'expr' | 'string' for every value node."""
    names = assigned_names(prog)
    out: dict[Path, str] = {}
    for path, node in walk(prog):
        if isinstance(node, (Program, Assign)):
            continue
        parent = get_at(prog, path[:-1]) if path else None
        idx = path[-1] if path else 0
        if isinstance(node, Num):
            out[path] = "window" if is_window_literal(parent, idx, node) else "const"
        elif isinstance(node, Name):
            low = node.id.lower()
            if node.id in names:
                out[path] = "var"
            elif low in GROUPING_FIELDS:
                out[path] = "group"
            elif low in NON_FIELDS:
                out[path] = "const"
            else:
                out[path] = "field"
        elif isinstance(node, Str):
            out[path] = "string"
        else:
            out[path] = "expr"
    return out


def calls(prog: Program) -> list[tuple[Path, Call]]:
    return [(p, n) for p, n in walk(prog) if isinstance(n, Call)]


def field_names(prog: Program) -> list[str]:
    kinds = classify(prog)
    seen: list[str] = []
    for path, node in walk(prog):
        if kinds.get(path) == "field" and node.id not in seen:      # type: ignore[union-attr]
            seen.append(node.id)                                      # type: ignore[union-attr]
    return seen


def has_free_variable(node: Node, prog: Program) -> bool:
    """Does this subtree mention a variable that `prog` assigns? (Moving it to another program would break it.)"""
    names = assigned_names(prog)
    return any(isinstance(n, Name) and n.id in names for _, n in walk(node))
