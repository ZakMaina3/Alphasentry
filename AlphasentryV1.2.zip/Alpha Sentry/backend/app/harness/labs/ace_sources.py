"""Wires the pure lab logic to Alpha Sentry's own data (sim_results, datasets, fields) through the sqlite3 gateway.

Alpha Sentry stores coverage per DATASET (not per field) and no universe per field, so field coverage is the dataset's
(0.0 = never filled in = unknown, not filtered out) and field presence is checked per region+delay.
"""
from __future__ import annotations

import json
import time
from typing import Any

from app.harness.payload import Scope
from app.harness.store import Store, chunks, default_store, marks


def _db() -> Store:
    return default_store()


def leaf_idents(expr: str) -> list[str]:
    from app.generation.service import _leaf_idents   # Alpha Sentry's own AST walker (reused, not copied)
    return _leaf_idents(expr)


# ── alphas in a scope: the ONE query every lab shares ─────────────────────────────────────────
def scoped_alphas(scope: Scope, *, min_abs_sharpe: float | None = None, neutralization: str | None = None,
                  submitted: bool | None = None, passed_gate: bool | None = None, limit: int = 500) -> list[dict]:
    """Alpha Sentry results in this region/delay/universe with an alpha id, strongest |Sharpe| first, one row per alpha.
    min_abs_sharpe=None keeps rows with no Sharpe; any number (even 0.0) requires one."""
    sql = ["SELECT alpha_id, expression, sharpe, fitness, turnover, neutralization, universe, submitted FROM sim_results",
           "WHERE region=? AND delay=? AND universe=? AND alpha_id != ''"]
    p: list[Any] = [scope.region, scope.delay, scope.universe]
    if min_abs_sharpe is not None:
        sql.append("AND sharpe IS NOT NULL AND ABS(sharpe) >= ?")
        p.append(min_abs_sharpe)
    if neutralization is not None:
        sql.append("AND neutralization=?")
        p.append(neutralization)
    if submitted is not None:
        sql.append("AND COALESCE(submitted,0)=?")
        p.append(1 if submitted else 0)
    if passed_gate is not None:
        sql.append("AND COALESCE(passed_gate,0)=?")
        p.append(1 if passed_gate else 0)
    sql.append("ORDER BY ABS(COALESCE(sharpe,0)) DESC LIMIT ?")
    p.append(limit)
    seen: set[str] = set()
    out = []
    for r in _db().query(" ".join(sql), p):
        if r["alpha_id"] in seen:
            continue
        seen.add(r["alpha_id"])
        out.append({"alpha_id": r["alpha_id"], "expression": r["expression"], "sharpe": r["sharpe"],
                    "fitness": r["fitness"], "turnover": r["turnover"], "neutralization": r["neutralization"],
                    "universe": r["universe"], "submitted": bool(r["submitted"])})
    return out


def winners(origin: Scope, min_sharpe: float, limit: int) -> list[dict]:
    return scoped_alphas(origin, min_abs_sharpe=min_sharpe, limit=limit)


def scopes() -> list[Scope]:
    rows = _db().query("SELECT DISTINCT instrument, region, delay, universe FROM datasets WHERE universe != ''")
    return [Scope(region=r["region"], delay=int(r["delay"]), universe=r["universe"],
                  instrument_type=r["instrument"] or "EQUITY") for r in rows]


def fields_in_scope(s: Scope) -> set[str]:
    return {r["field_id"] for r in _db().query("SELECT field_id FROM fields WHERE region=? AND delay=?", (s.region, s.delay))}


# ── BRAIN's own settings/checks for an alpha, cached ──────────────────────────────────────────
def _alpha_info(alpha_id: str, fetch_budget: list[int], max_age_s: float = 6 * 3600) -> dict | None:
    """Cached BRAIN settings+checks for an alpha; fetches (and caches) while the budget lasts."""
    from app.harness import brain_port
    rows = _db().query("SELECT settings_json, checks_json, status, fetched FROM harness_alpha_info WHERE alpha_id=?", (alpha_id,))
    if rows and time.time() - rows[0]["fetched"] < max_age_s:
        r = rows[0]
        return {"settings": json.loads(r["settings_json"]), "checks": json.loads(r["checks_json"]), "status": r["status"]}
    if fetch_budget[0] <= 0:
        return None
    fetch_budget[0] -= 1
    try:
        d = brain_port.alpha_detail(alpha_id)
    except Exception:  # noqa: BLE001
        return None
    _db().execute("INSERT OR REPLACE INTO harness_alpha_info (alpha_id, settings_json, checks_json, status, fetched) VALUES (?,?,?,?,?)",
                  (alpha_id, json.dumps(d["settings"]), json.dumps(d["checks"]), d["status"], time.time()))
    return d


def repair_rows(scope: Scope, limit: int = 120, max_fetch: int = 60) -> list[dict]:
    """Unsubmitted, non-passing alphas in scope with their BRAIN checks and settings attached."""
    budget, rows = [max_fetch], []
    for a in scoped_alphas(scope, min_abs_sharpe=0.0, submitted=False, passed_gate=False, limit=limit):
        info = _alpha_info(a["alpha_id"], budget)
        if not info:
            continue
        st = info["settings"]
        rows.append({"alpha_id": a["alpha_id"], "expression": a["expression"], "sharpe": a["sharpe"],
                     "fitness": a["fitness"], "turnover": a["turnover"], "decay": st.get("decay", 0),
                     "truncation": st.get("truncation", 0.08), "universe": st.get("universe") or a["universe"],
                     "neutralization": st.get("neutralization") or a["neutralization"],
                     "status": info["status"] or "UNSUBMITTED", "checks": info["checks"]})
    return rows


def strong_rows(scope: Scope, min_sharpe: float, limit: int, max_fetch: int = 30) -> list[dict]:
    """Strong alphas in scope with their own decay/truncation/neutralization (from BRAIN, cached)."""
    budget, out = [max_fetch], []
    for r in winners(scope, min_sharpe, limit):
        st = (_alpha_info(r["alpha_id"], budget) or {}).get("settings", {})
        out.append({**r, "decay": st.get("decay", 0), "truncation": st.get("truncation", 0.08),
                    "neutralization": st.get("neutralization") or r.get("neutralization")})
    return out


def legal_settings(scope: Scope) -> tuple[list[str], list[str]]:
    """(universes, neutralizations) BRAIN offers for this scope, or ([], []) if options aren't loaded."""
    try:
        from app.brain import engine
        recs = [r for r in engine.get_options().get("records", [])
                if r["instrument"] == scope.instrument_type and r["region"] == scope.region and r["delay"] == scope.delay]
    except Exception:  # noqa: BLE001
        return [], []
    return (sorted({u for r in recs for u in r["universes"]}), sorted({n for r in recs for n in r["neutralizations"]}))


# ── Harvest / Diversify / Pair sources ────────────────────────────────────────────────────────
def _field_table(scope: Scope, min_alphas: int, max_alphas: int | None, min_coverage: float) -> list[dict]:
    sql = ("SELECT f.field_id, f.dataset_id, f.description, f.alpha_count, d.coverage AS coverage FROM fields f "
           "LEFT JOIN datasets d ON d.dataset_id=f.dataset_id AND d.region=f.region AND d.delay=f.delay "
           "WHERE f.region=? AND f.delay=? AND f.type='MATRIX' AND f.alpha_count>=?")
    p: list[Any] = [scope.region, scope.delay, min_alphas]
    if max_alphas is not None:
        sql += " AND f.alpha_count<=?"
        p.append(max_alphas)
    out = []
    for r in _db().query(sql, p):
        cov = float(r["coverage"] or 0.0)
        if cov and cov < min_coverage:
            continue
        out.append({"field_id": r["field_id"], "dataset_id": r["dataset_id"], "description": r["description"],
                    "coverage": cov, "alpha_count": r["alpha_count"]})
    return out


def best_fields(scope: Scope, *, per_dataset: int = 1, min_alphas: int = 3, max_alphas: int | None = None,
                min_coverage: float = 0.6, limit: int = 200, skip: int = 0) -> list[dict]:
    """The best few fields in each dataset (least-worked first), spread across datasets."""
    by_ds: dict[str, list[dict]] = {}
    for r in _field_table(scope, min_alphas, max_alphas, min_coverage):
        by_ds.setdefault(r["dataset_id"], []).append(r)
    picked: list[dict] = []
    for rows in by_ds.values():
        rows.sort(key=lambda r: (-r["coverage"], r["alpha_count"], r["field_id"]))
        picked.extend(rows[skip: skip + per_dataset])
    picked.sort(key=lambda r: (-r["coverage"], r["alpha_count"], r["field_id"]))
    return picked[:limit]


def dataset_count(scope: Scope, min_alphas: int, max_alphas: int | None, min_coverage: float) -> int:
    return len({r["dataset_id"] for r in _field_table(scope, min_alphas, max_alphas, min_coverage)})


def lookup_fields(scope: Scope, field_ids: list[str]) -> list[dict]:
    """Named fields present in this scope, keeping the order asked for."""
    by: dict[str, dict] = {}
    for part in chunks(list(field_ids)):
        for r in _db().query(f"SELECT field_id, dataset_id, description, alpha_count FROM fields WHERE region=? AND delay=? "
                             f"AND field_id IN ({marks(len(part))})", (scope.region, scope.delay, *part)):
            by[r["field_id"]] = {"field_id": r["field_id"], "dataset_id": r["dataset_id"],
                                 "description": r["description"], "alpha_count": r["alpha_count"]}
    return [by[f] for f in field_ids if f in by]


def scope_expressions(scope: Scope) -> list[str]:
    return [r["expression"] for r in _db().query(
        "SELECT expression FROM sim_results WHERE region=? AND delay=? AND universe=? AND expression != ''",
        (scope.region, scope.delay, scope.universe))]


def dataset_of_field(scope: Scope, ids: set[str]) -> dict[str, str]:
    out: dict[str, str] = {}
    for part in chunks(sorted(ids)):
        for r in _db().query(f"SELECT field_id, dataset_id FROM fields WHERE region=? AND delay=? AND field_id IN ({marks(len(part))})",
                             (scope.region, scope.delay, *part)):
            out[r["field_id"]] = r["dataset_id"]
    return out


def fresh_fields(scope: Scope, worked: set[str], per_dataset: int, limit: int, min_coverage: float = 0.5) -> list[dict]:
    by_ds: dict[str, list[dict]] = {}
    for r in _field_table(scope, 1, None, min_coverage):
        if r["dataset_id"] not in worked:
            by_ds.setdefault(r["dataset_id"], []).append(r)
    out: list[dict] = []
    for rs in by_ds.values():
        rs.sort(key=lambda r: (-r["coverage"], r["field_id"]))
        out.extend(rs[:per_dataset])
    out.sort(key=lambda r: (-r["coverage"], r["field_id"]))
    return out[:limit]


def harvester(scope: Scope):
    from app.harness.harvest.seeds import SeedHarvester
    sat, sk = ledger_args(scope)
    return SeedHarvester(best_fields=lambda **k: best_fields(scope, **k),
                         dataset_count=lambda a, b, c: dataset_count(scope, a, b, c),
                         lookup=lambda ids: lookup_fields(scope, ids), saturated_shapes=sat, skeleton_of=sk)


def pair_fields(scope: Scope, per_dataset: int) -> list[dict]:
    """Best few fields per dataset plus the price/size anchors (close, cap, adv20) when Alpha Sentry knows them."""
    from app.harness.labs.pair import ANCHORS
    fields = best_fields(scope, per_dataset=per_dataset, min_alphas=3, min_coverage=0.5, limit=60)
    known = {f["field_id"] for f in fields}
    return fields + [a for a in lookup_fields(scope, list(ANCHORS)) if a["field_id"] not in known]


def known_operators() -> set[str] | None:
    """Operator names this account can use (from Alpha Sentry's cached operator list), or None if unavailable."""
    try:
        from app.brain import engine
        df = engine.operators_df()
        col = "name" if "name" in df.columns else df.columns[0]
        return {str(n) for n in df[col].tolist()}
    except Exception:  # noqa: BLE001
        return None


# ── Skeleton ledger (planning flag) ───────────────────────────────────────────────────────────
def shape_records(scope: Scope, days: int = 30):
    """Shapes tried in this region/delay recently, with how many passed Alpha Sentry's gate (the 'submittable' proxy)."""
    from app.harness.plan.skeletons import tally
    rows = _db().query("SELECT expression, passed_gate FROM sim_results WHERE region=? AND delay=? AND created_at>=? AND expression != ''",
                       (scope.region, scope.delay, time.time() - days * 86400))
    return tally((r["expression"], bool(r["passed_gate"])) for r in rows)


def ledger_args(scope: Scope):
    """(saturated shapes, skeleton fn) when the `harness_planning` flag is on, else (None, None)."""
    from app.harness import flags
    if not flags.enabled("harness_planning"):
        return None, None
    try:
        from app.harness.plan.skeletons import saturated_of, skeleton
        return set(saturated_of(shape_records(scope))), skeleton
    except Exception:  # noqa: BLE001      never let a bookkeeping query cost the day's work
        return None, None


# ── Template data fields ──────────────────────────────────────────────────────────────────────
def template_fields(scope: Scope, var: Any) -> list[str]:
    """Field ids a template `datafield` variable resolves to in this scope (its catalogue filters, ordered, limited).
    Alpha Sentry stores no user_count / pyramid multiplier, so those orderings fall back to alpha_count."""
    sql = ("SELECT f.field_id FROM fields f LEFT JOIN datasets d ON d.dataset_id=f.dataset_id AND d.region=f.region AND d.delay=f.delay "
           "WHERE f.region=? AND f.delay=? AND f.type=?")
    p: list[Any] = [scope.region, scope.delay, (var.field_type or "MATRIX").upper()]
    for cond, val in (("f.dataset_id=?", var.dataset), ("d.category=?", var.category), ("f.alpha_count>=?", var.min_alpha_count),
                      ("f.alpha_count<=?", var.max_alpha_count)):
        if val is not None:
            sql += f" AND {cond}"
            p.append(val)
    if var.min_coverage:
        sql += " AND (d.coverage IS NULL OR d.coverage=0 OR d.coverage>=?)"      # 0.0 = never filled in = unknown, kept
        p.append(var.min_coverage)
    if var.search:
        sql += " AND (f.description LIKE ? OR f.field_id LIKE ?)"
        p += [f"%{var.search}%"] * 2
    order = {"coverage": "COALESCE(d.coverage,0)", "field_id": "f.field_id"}.get(var.order_by, "f.alpha_count")
    sql += f" ORDER BY {order} {'DESC' if var.order_desc else 'ASC'}, f.field_id LIMIT ?"
    p.append(int(var.limit))
    return [r["field_id"] for r in _db().query(sql, p)]


# ── Deepen / Evolution sources ────────────────────────────────────────────────────────────────
def alpha_row(alpha_id: str) -> dict | None:
    """One Alpha Sentry result by alpha id (its newest row), or None."""
    rows = _db().query("SELECT alpha_id, expression, region, delay, universe, neutralization, sharpe FROM sim_results "
                       "WHERE alpha_id=? ORDER BY id DESC LIMIT 1", (alpha_id,))
    return dict(rows[0]) if rows else None


def evolution_seeds(scope: Scope, *, expressions: list[str], alpha_ids: list[str], min_sharpe: float, limit: int) -> tuple[list[str], list[str]]:
    """Starting alphas: pasted expressions first, then named alphas, then (only if neither was given) the strongest in this scope."""
    notes: list[str] = []
    out = [e.strip() for e in expressions if e and e.strip()]
    for a in alpha_ids:
        row = alpha_row(a)
        if row is None:
            notes.append(f"Alpha {a} is not in Results, so it was skipped.")
        else:
            out.append(row["expression"])
    if not out:
        out = [w["expression"] for w in winners(scope, min_sharpe, limit)]
        if not out:
            notes.append(f"No alphas with |Sharpe| >= {min_sharpe:g} exist for {scope.region} d{scope.delay} {scope.universe} yet; paste some expressions.")
    return list(dict.fromkeys(out)), notes


def evolution_fields(scope: Scope, seeds: list[str], extra: list[str] | None = None, limit: int = 60) -> list[str]:
    """Data fields a field-mutation may pick: the seeds' own, any the user named, then the best few per dataset in this scope."""
    from app.harness.labs import exprtree as X
    out: list[str] = []
    for s in seeds:
        try:
            out.extend(X.field_names(X.parse(s)))
        except X.ExprError:
            pass
    out.extend(extra or [])
    out.extend(r["field_id"] for r in best_fields(scope, per_dataset=5, min_alphas=0, min_coverage=0.5, limit=limit))
    return list(dict.fromkeys(out))[:limit]
