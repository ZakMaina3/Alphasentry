"""Power Pool selection view: which finished alphas of a task could go into the Power Pool, and what stops the rest.

Pure: rows come from the endpoint (task trials joined with Alpha Sentry's results). The limits are the Power Pool ones used elsewhere in the
harness (operators / fields in labs.exprtools, Sharpe and pool correlation in optimize.objectives).
"""
from __future__ import annotations

from typing import Any

from app.harness.labs.exprtools import (POWER_POOL_MAX_FIELDS, POWER_POOL_MAX_OPERATORS, count_operators, unique_data_fields)
from app.harness.optimize.objectives import POWER_POOL_MAX_CORR, POWER_POOL_MIN_SHARPE


def reasons(row: dict[str, Any]) -> list[str]:
    """Everything that stops this alpha qualifying ([] = qualifies). Missing numbers count against it: unknown is not a pass."""
    expr = row.get("expression") or ""
    out: list[str] = []
    ops, flds = count_operators(expr), len(unique_data_fields(expr))
    if not expr:
        out.append("expression unknown")
    if ops > POWER_POOL_MAX_OPERATORS:
        out.append(f"{ops} operators (max {POWER_POOL_MAX_OPERATORS})")
    if flds > POWER_POOL_MAX_FIELDS:
        out.append(f"{flds} data fields (max {POWER_POOL_MAX_FIELDS})")
    sh = row.get("sharpe")
    if sh is None:
        out.append("no Sharpe")
    elif abs(float(sh)) < POWER_POOL_MIN_SHARPE:
        out.append(f"Sharpe {abs(float(sh)):.2f} < {POWER_POOL_MIN_SHARPE:g}")
    pc = row.get("powerpool_corr")
    if pc is None:
        out.append("pool correlation not measured yet")
    elif abs(float(pc)) >= POWER_POOL_MAX_CORR:
        out.append(f"pool correlation {abs(float(pc)):.2f} ≥ {POWER_POOL_MAX_CORR:g}")
    return out


def selection(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Split alphas into `qualifying`, `almost` (exactly one reason against) and a count of the rest, strongest Sharpe first."""
    qual, almost, other = [], [], 0
    for r in sorted(rows, key=lambda r: -abs(r.get("sharpe") or 0.0)):
        why = reasons(r)
        item = {**r, "reasons": why}
        if not why:
            qual.append(item)
        elif len(why) == 1:
            almost.append(item)
        else:
            other += 1
    return {"qualifying": qual, "almost": almost, "other": other, "limits": {
        "maxOperators": POWER_POOL_MAX_OPERATORS, "maxFields": POWER_POOL_MAX_FIELDS,
        "minSharpe": POWER_POOL_MIN_SHARPE, "maxPoolCorrelation": POWER_POOL_MAX_CORR}}
