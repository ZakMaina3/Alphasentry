"""Evolution, part 1: the operators (pure; no database, no BRAIN). Part 2 — the population loop — is harness/evolution.py.

Mutation changes one thing about an alpha; crossover swaps a piece between two. Every offspring is checked before anyone could
queue it: it must parse, stay inside the operator / field / length / depth limits (Power Pool limits when asked), use only
operators the market offers (when that list is known), and differ from everything already tried.

Deterministic: all randomness comes from the `random.Random` the caller passes in, and every choice is made from an ordered
list, so the same seed gives the same offspring.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Callable

from app.harness.labs import exprtree as X
from app.harness.labs.exprtools import (GROUPING_FIELDS, POWER_POOL_MAX_FIELDS, POWER_POOL_MAX_OPERATORS, count_operators,
                                        unique_data_fields)

#: Window sizes people actually use (trading days). A window mutation steps to a neighbour on this ladder.
LADDER = (1, 2, 3, 5, 10, 15, 22, 30, 44, 63, 90, 126, 189, 252, 504)

#: Operators that take the same arguments and can stand in for each other (swapped only when the call has no keyword arguments).
FAMILIES: dict[str, tuple[int, tuple[str, ...]]] = {
    "ts": (2, ("ts_mean", "ts_median", "ts_decay_linear", "ts_sum", "ts_std_dev", "ts_zscore", "ts_rank", "ts_av_diff", "ts_delta", "ts_scale")),
    "ts2": (3, ("ts_corr", "ts_covariance")),
    "xs": (1, ("rank", "zscore", "scale")),
    "group": (2, ("group_rank", "group_zscore", "group_neutralize", "group_scale")),
}
WRAP_XS = FAMILIES["xs"][1]
WRAP_TS = ("ts_mean", "ts_decay_linear", "ts_zscore", "ts_rank")
ARITH = ("+", "-", "*", "/")
COMPARE = ("<", ">", "<=", ">=")


def family_of(call: X.Call) -> tuple[str, ...] | None:
    if any(call.kwargs):
        return None
    for arity, names in FAMILIES.values():
        if call.name in names and len(call.args) == arity:
            return names
    return None


@dataclass(frozen=True)
class Limits:
    max_operators: int | None = None
    max_fields: int | None = None
    max_length: int = 1000
    max_depth: int = 10
    allowed_operators: frozenset[str] | None = None        # None = not known, do not filter

    @classmethod
    def power_pool(cls, **kw) -> "Limits":
        return cls(max_operators=POWER_POOL_MAX_OPERATORS, max_fields=POWER_POOL_MAX_FIELDS, **kw)


@dataclass
class Context:
    fields: list[str]                                       # data fields a field-mutation may pick from
    limits: Limits = field(default_factory=Limits)
    ladder: tuple[int, ...] = LADDER


def check(text: str, limits: Limits) -> list[str]:
    """Why this alpha must not be queued ([] = fine)."""
    try:
        prog = X.parse(text)
    except X.ExprError as e:
        return [f"does not parse: {e}"]
    out: list[str] = []
    if isinstance(prog.statements[-1], X.Assign):
        out.append("the last statement must be the alpha itself, not an assignment")
    if len(text) > limits.max_length:
        out.append(f"is {len(text)} characters long; the limit is {limits.max_length}")
    if X.depth(prog) > limits.max_depth:
        out.append(f"is nested more than {limits.max_depth} levels deep")
    ops, flds = count_operators(text), len(unique_data_fields(text))
    if flds < 1:
        out.append("uses no data field")
    if ops < 1:
        out.append("uses no operator")
    if limits.max_operators is not None and ops > limits.max_operators:
        out.append(f"uses {ops} operators; the limit is {limits.max_operators}")
    if limits.max_fields is not None and flds > limits.max_fields:
        out.append(f"uses {flds} distinct data fields; the limit is {limits.max_fields}")
    if limits.allowed_operators is not None:
        unknown = sorted({c.name for _, c in X.calls(prog)} - limits.allowed_operators)
        if unknown:
            out.append("uses operators this market does not offer: " + ", ".join(unknown))
    return out


# ── helpers ────────────────────────────────────────────────────────────────────────────────────
def neighbour_window(value: int, rng: random.Random, ladder: tuple[int, ...] = LADDER, radius: int = 2) -> int:
    """A different window near `value`: step 1..radius places along the ladder (value need not be on it)."""
    nearest = min(range(len(ladder)), key=lambda i: (abs(ladder[i] - value), i))
    options = sorted({ladder[j] for j in range(max(0, nearest - radius), min(len(ladder), nearest + radius + 1))} - {value})
    return rng.choice(options) if options else value


def _sites(prog: X.Program, kinds: set[str]) -> list[X.Path]:
    cls = X.classify(prog)
    return [p for p, k in cls.items() if k in kinds]


def _is_wrappable(prog: X.Program, path: X.Path, node: X.Node, kind: str) -> bool:
    if kind not in ("expr", "field") or isinstance(node, (X.Num, X.Str)):
        return False
    parent = X.get_at(prog, path[:-1]) if path else None
    return not isinstance(parent, X.Program) or not isinstance(node, X.Name)        # a bare field as a whole statement is not an alpha


# ── mutations: each returns a new Program, or None when it has nothing to act on ─────────────
Mutation = Callable[[X.Program, random.Random, Context], "X.Program | None"]


def mut_window(prog: X.Program, rng: random.Random, ctx: Context) -> X.Program | None:
    sites = _sites(prog, {"window"})
    if not sites:
        return None
    path = rng.choice(sites)
    old = int(X.get_at(prog, path).text)            # type: ignore[union-attr]
    new = neighbour_window(old, rng, ctx.ladder)
    return None if new == old else X.replace_at(prog, path, X.Num(str(new)))


def mut_operator(prog: X.Program, rng: random.Random, ctx: Context) -> X.Program | None:
    sites: list[tuple[X.Path, X.Node, tuple[str, ...]]] = []
    for path, node in X.walk(prog):
        if isinstance(node, X.Call) and (fam := family_of(node)) and len(fam) > 1:
            sites.append((path, node, fam))
        elif isinstance(node, X.Binary) and node.op in ARITH + COMPARE:
            sites.append((path, node, ARITH if node.op in ARITH else COMPARE))
    if not sites:
        return None
    path, node, fam = rng.choice(sites)
    pool = [n for n in fam if n != (node.name if isinstance(node, X.Call) else node.op)]
    if isinstance(node, X.Call) and ctx.limits.allowed_operators is not None:
        pool = [n for n in pool if n in ctx.limits.allowed_operators]
    if not pool:
        return None
    pick = rng.choice(pool)
    return X.replace_at(prog, path, X.Call(pick, node.args, node.kwargs) if isinstance(node, X.Call) else X.Binary(pick, node.left, node.right))


def mut_field(prog: X.Program, rng: random.Random, ctx: Context) -> X.Program | None:
    sites = _sites(prog, {"field"})
    pool = [f for f in ctx.fields if f.lower() not in GROUPING_FIELDS]
    if not sites or not pool:
        return None
    path = rng.choice(sites)
    old = X.get_at(prog, path).id                   # type: ignore[union-attr]
    choices = [f for f in pool if f != old]
    if not choices:
        return None
    new = rng.choice(choices)
    everywhere = [p for p in sites if X.get_at(prog, p).id == old]      # type: ignore[union-attr]
    targets = everywhere if rng.random() < 0.5 else [path]
    out: X.Node = prog
    for p in targets:
        out = X.replace_at(out, p, X.Name(new))
    return out                                       # type: ignore[return-value]


def mut_wrap(prog: X.Program, rng: random.Random, ctx: Context) -> X.Program | None:
    cls = X.classify(prog)
    sites = [p for p, k in cls.items() if _is_wrappable(prog, p, X.get_at(prog, p), k)]
    if not sites:
        return None
    path = rng.choice(sites)
    node = X.get_at(prog, path)
    parent = X.get_at(prog, path[:-1]) if path else None
    if isinstance(parent, X.Call) and parent.name.startswith("group_") and path[-1] == 1:
        return None
    allowed = ctx.limits.allowed_operators
    if rng.random() < 0.6:
        names = [n for n in WRAP_XS if not (isinstance(node, X.Call) and node.name == n) and (allowed is None or n in allowed)]
        if not names:
            return None
        return X.replace_at(prog, path, X.Call(rng.choice(names), (node,), (None,)))
    names = [n for n in WRAP_TS if allowed is None or n in allowed]
    if not names:
        return None
    return X.replace_at(prog, path, X.Call(rng.choice(names), (node, X.Num(str(rng.choice((5, 10, 22, 63))))), (None, None)))


def _unwrappable(node: X.Node) -> X.Node | None:
    if isinstance(node, X.Call) and not any(node.kwargs):
        if node.name in WRAP_XS and len(node.args) == 1:
            return node.args[0]
        if node.name in WRAP_TS and len(node.args) == 2 and isinstance(node.args[1], X.Num):
            return node.args[0]
    return None


def mut_unwrap(prog: X.Program, rng: random.Random, ctx: Context) -> X.Program | None:
    sites = [(p, inner) for p, n in X.walk(prog) if (inner := _unwrappable(n)) is not None]
    if not sites:
        return None
    path, inner = rng.choice(sites)
    out = X.replace_at(prog, path, inner)
    return out if isinstance(out, X.Program) else None


def mut_negate(prog: X.Program, rng: random.Random, ctx: Context) -> X.Program | None:
    """Flip the sign of the whole alpha (or undo a flip): often turns a losing idea into a winning one."""
    last = len(prog.statements) - 1
    node = prog.statements[last]
    if isinstance(node, X.Assign):
        return None
    new = node.operand if isinstance(node, X.Unary) and node.op == "-" else X.Unary("-", node)
    return X.replace_at(prog, (last,), new)         # type: ignore[return-value]


MUTATIONS: list[tuple[str, Mutation, float]] = [
    ("window", mut_window, 3.0), ("operator", mut_operator, 2.0), ("field", mut_field, 2.0),
    ("wrap", mut_wrap, 1.5), ("unwrap", mut_unwrap, 1.0), ("negate", mut_negate, 0.5),
]


def mutate(prog: X.Program, rng: random.Random, ctx: Context) -> tuple[str, X.Program] | None:
    """One random mutation (weighted); if the chosen kind has nothing to act on, the next kind is tried."""
    pool = list(MUTATIONS)
    while pool:
        total = sum(w for _, _, w in pool)
        r, acc = rng.random() * total, 0.0
        for i, (name, fn, w) in enumerate(pool):
            acc += w
            if r <= acc:
                break
        pool.pop(i)
        out = fn(prog, rng, ctx)
        if out is not None and out != prog:
            return name, out
    return None


def crossover(a: X.Program, b: X.Program, rng: random.Random, ctx: Context) -> X.Program | None:
    """Replace a piece of `a` with a piece of `b` of the same kind (window ↔ window, field ↔ field, group ↔ group, sub-expression ↔
    sub-expression). Sub-expressions that mention one of b's own variables are not moved, since `a` cannot see them."""
    ca, cb = X.classify(a), X.classify(b)
    kinds = ["expr", "window", "field", "group"]
    rng.shuffle(kinds)
    for kind in kinds:
        pa = [p for p, k in ca.items() if k == kind]
        pb = [p for p, k in cb.items() if k == kind and not (kind == "expr" and X.has_free_variable(X.get_at(b, p), b) and not X.assigned_names(a) >= X.assigned_names(b))]
        if kind == "expr":
            pa = [p for p in pa if not (len(p) == 1 and len(a.statements) > 1 and p[0] != len(a.statements) - 1)]
        if not pa or not pb:
            continue
        path_a, path_b = rng.choice(pa), rng.choice(pb)
        out = X.replace_at(a, path_a, X.get_at(b, path_b))
        if out != a and out != b:
            return out                                  # type: ignore[return-value]
    return None


@dataclass
class Offspring:
    expression: str
    how: str                    # e.g. "window", "operator", "crossover"
    parents: list[int]          # indexes into the parents list that was passed in


def make_offspring(parents: list[str], rng: random.Random, ctx: Context, seen: set[str], *, crossover_rate: float = 0.4,
                   tries: int = 60) -> Offspring | None:
    """One new, valid, never-seen alpha bred from `parents` (best first). Returns None when `tries` attempts all failed
    (the population has run out of room to move)."""
    progs = []
    for p in parents:
        try:
            progs.append(X.parse(p))
        except X.ExprError:
            progs.append(None)
    usable = [i for i, p in enumerate(progs) if p is not None]
    if not usable:
        return None
    for _ in range(tries):
        i = rng.choice(usable)
        j = rng.choice(usable)
        if len(usable) > 1 and i != j and rng.random() < crossover_rate:
            child, how, par = crossover(progs[i], progs[j], rng, ctx), "crossover", [i, j]
            if child is not None and rng.random() < 0.3:              # often mutate the child as well: crossover alone recombines, it does not explore
                m = mutate(child, rng, ctx)
                child = m[1] if m else child
        else:
            m = mutate(progs[i], rng, ctx)
            child, how, par = (m[1] if m else None), (m[0] if m else ""), [i]
        if child is None:
            continue
        text = X.print_(child)
        if X.canon(text) in seen or check(text, ctx.limits):
            continue
        return Offspring(text, how, par)
    return None
