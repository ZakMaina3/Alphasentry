"""Relocate: run an idea that works somewhere else (ported from alpha_harness.labs.relocate).

The expression is held fixed and only the settings move (market, universe, grouping, delay). A
destination that lacks any data field the formula uses is REFUSED, because a simulation against a
missing field fails and still spends quota. `plan()` is free and is exactly what `run` would queue.

The logic is pure: Alpha Sentry's data (winning alphas, scopes, fields per scope, identifier extraction) is
injected as callables, so it is unit-testable and the Alpha Sentry wiring lives in `ace_sources`.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Iterable

from app.harness.payload import Scope, make_payload

DEFAULT_MIN_SHARPE = 1.0
MAX_SIMULATIONS = 5_000
GROUPING_FIELDS = frozenset({"country", "industry", "subindustry", "currency", "market", "sector", "exchange"})
NON_FIELDS = frozenset({"true", "false", "nan", "inf"})


@dataclass
class Move:
    alpha_id: str
    expression: str
    origin: str
    destination: Scope
    neutralization: str
    possible: bool
    missing: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "alphaId": self.alpha_id, "expression": self.expression, "origin": self.origin,
            "destination": self.destination.label, "neutralization": self.neutralization,
            "possible": self.possible, "missing": self.missing,
            "why": (f"The same formula, judged against {self.destination.region} instead." if self.possible
                    else f"Not possible here — {', '.join(self.missing[:3])} does not exist in {self.destination.region}."),
        }


def data_fields(expression: str, leaf_idents: Callable[[str], Iterable[str]]) -> set[str]:
    """Data fields only: grouping fields and literals are available everywhere."""
    return {f for f in leaf_idents(expression)
            if f not in GROUPING_FIELDS and f.lower() not in NON_FIELDS and not str(f).isdigit()}


def build_request(expression: str, dest: Scope, neutralization: str, *, decay: int = 0, truncation: float = 0.08) -> dict:
    """Payload for the same formula in another scope (NaN handling ON, per AH's rule)."""
    return make_payload(expression, dest, neutralization=neutralization, decay=decay, truncation=truncation)


def plan(*, origin: Scope, winners: list[dict], scopes: list[Scope],
         fields_in_scope: Callable[[Scope], set[str]], leaf_idents: Callable[[str], Iterable[str]],
         neutralizations: list[str] | None = None, target: int = 500) -> dict[str, Any]:
    """Which winners can travel, and where. Free: nothing here calls BRAIN.

    winners: [{alpha_id, expression, ...}] already filtered to the origin and min Sharpe.
    scopes: every scope Alpha Sentry knows about (the origin is excluded here).
    """
    groupings = neutralizations or ["SUBINDUSTRY"]
    destinations = [s for s in scopes if s.label != origin.label]
    if not destinations:
        return {"moves": [], "requests": [], "note": "Alpha Sentry has only one market's data, so there is nowhere else to try yet. "
                "Load a second market's fields in Data Explorer first."}
    if not winners:
        return {"moves": [], "requests": [], "note": f"Nothing in {origin.label} has scored well enough to be worth carrying elsewhere yet."}

    cache: dict[str, set[str]] = {}

    def have(s: Scope) -> set[str]:
        if s.label not in cache:
            cache[s.label] = fields_in_scope(s)
        return cache[s.label]

    moves: list[Move] = []
    requests: list[dict] = []
    for a in winners:
        expr = str(a.get("expression") or "")
        if not expr:
            continue
        wanted = data_fields(expr, leaf_idents)
        for dest in destinations:
            missing = wanted - have(dest)
            for g in groupings:
                m = Move(str(a.get("alpha_id", "")), expr, origin.label, dest, g, not missing, sorted(missing))
                moves.append(m)
                if m.possible and len(requests) < min(target, MAX_SIMULATIONS):
                    requests.append(build_request(expr, dest, g))
    possible = sum(1 for m in moves if m.possible)
    return {
        "moves": [m.to_dict() for m in moves], "requests": requests, "alphas": len(winners),
        "destinations": [d.label for d in destinations], "possible": possible, "blocked": len(moves) - possible,
        "note": None if possible else "None of these formulas can run in the other markets — they use data those markets do not have.",
    }
