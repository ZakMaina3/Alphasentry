"""Diversify: look deliberately where your own alphas are not (ported from alpha_harness.labs.diversify).

Optimises distance, not score. Distance is measured by dataset: two fields in one dataset come from the
same vendor feed and move together, so a dataset you have never touched is genuinely new ground. It
needs no PnL and no correlation matrix, so it works on day one. Expression building is left to the
SeedHarvester; this lab only chooses where to look.
"""
from __future__ import annotations

from typing import Any, Callable, Iterable

from app.harness.harvest.seeds import SeedHarvester
from app.harness.labs.exprtools import unique_data_fields

MIN_COVERAGE = 0.5


def worked_datasets(expressions: Iterable[str], dataset_of_field: Callable[[set[str]], dict[str, str]]) -> set[str]:
    """Which datasets this consultant's own alphas already draw on."""
    used: set[str] = set()
    for e in expressions:
        used |= unique_data_fields(e or "")
    if not used:
        return set()
    return {d for d in dataset_of_field(used).values() if d}


def plan(*, scope: Any, expressions: Iterable[str], dataset_of_field: Callable[[set[str]], dict[str, str]],
         fresh_fields: Callable[[set[str], int, int], list[dict]], harvester: SeedHarvester, target: int = 1000,
         per_dataset: int = 1, patterns: list[str] | None = None, windows: list[int] | None = None,
         neutralization: str = "SUBINDUSTRY") -> dict[str, Any]:
    """Fields from datasets this consultant has never worked, ready to run. `fresh_fields(worked,
    per_dataset, limit)` returns the best field in each untouched dataset."""
    worked = worked_datasets(expressions, dataset_of_field)
    fresh = fresh_fields(worked, per_dataset, max(1, target))
    if not fresh:
        return {"harvest": None, "fields": [], "workedDatasets": len(worked), "freshDatasets": 0,
                "note": ("You have already touched every dataset in this market. Try another market, or use "
                         "Combine to get more out of what you have." if worked
                         else "No data has been downloaded for this market yet.")}
    h = harvester.harvest(scope, target=target, fields=[f["field_id"] for f in fresh], patterns=patterns,
                          windows=windows, neutralization=neutralization)
    n = len({f["dataset_id"] for f in fresh})
    return {"harvest": h, "fields": fresh, "workedDatasets": len(worked), "freshDatasets": n,
            "note": (f"These come from {n} datasets you have never used. Being different from your own alphas is "
                     "the point — anything too close to them cannot be submitted.")}
