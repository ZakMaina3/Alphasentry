"""Deepen: take an alpha that worked and build a template that explores its neighbourhood (pure; the endpoint supplies the data).

What varies, in order of how much sense it makes to try:
  windows     every look-back window moves along the usual ladder (5, 10, 22, 63, 126, 252 ...), a few steps each way
  operators   a time-series / group / cross-sectional operator is swapped for a close relative (ts_mean <-> ts_median ...)
  wrapper     the whole alpha optionally wrapped in rank / zscore / scale (the empty choice means "no wrapper")
  settings    decay and neutralization, only when asked

The ORIGINAL alpha is always one point of the generated space (every variable lists its original value first and the empty wrapper
choice means no wrapper), so a deepen task re-tests the winner as well as its neighbours — and the tracker de-duplicates that one
if it was already simulated. If the space is bigger than the budget, it is shrunk deterministically (fewer steps, then fewer
operator sites, then no wrapper) until it fits, rather than being cut off arbitrarily.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from app.harness.labs import exprtree as X
from app.harness.labs import ga

WRAPPERS = ("", "rank", "zscore", "scale")
NEUTRALIZATIONS = ("SUBINDUSTRY", "INDUSTRY", "SECTOR", "MARKET")
DECAYS = (0, 2, 4, 8)


@dataclass
class Options:
    radius: int = 2                    # ladder steps each side of a window
    windows: bool = True
    operators: bool = True
    wrapper: bool = True
    tie_equal_windows: bool = True     # the same literal used twice moves together
    max_operator_sites: int = 2
    vary_decay: bool = False
    vary_neutralization: bool = False
    neutralization: str = "SUBINDUSTRY"
    decay: int = 0
    max_simulations: int = 200


@dataclass
class Deepened:
    template: dict[str, Any]
    origin: dict[str, Any]             # variable -> the original alpha's value (the point that reproduces it)
    size: int
    notes: list[str] = field(default_factory=list)


def window_grid(value: int, radius: int, ladder: tuple[int, ...] = ga.LADDER) -> list[int]:
    """The original window first, then its neighbours on the ladder, nearest first."""
    nearest = min(range(len(ladder)), key=lambda i: (abs(ladder[i] - value), i))
    near = [ladder[j] for j in sorted(range(max(0, nearest - radius), min(len(ladder), nearest + radius + 1)),
                                       key=lambda j: (abs(j - nearest), j)) if ladder[j] != value]
    return [value] + near


def _size(variables: dict[str, list[Any]], settings: dict[str, list[Any]]) -> int:
    n = 1
    for v in list(variables.values()) + list(settings.values()):
        n *= max(1, len(v))
    return n


def _build(expression: str, o: Options, radius: int, op_sites: int, wrapper: bool, win_vars: int | None = None) -> tuple[str, dict[str, list[Any]], dict[str, list[Any]], list[str]]:
    prog = X.parse(expression)
    if isinstance(prog.statements[-1], X.Assign):
        raise ValueError("The last statement of this alpha is an assignment, so there is no alpha to deepen.")
    notes: list[str] = []
    variables: dict[str, list[Any]] = {}
    tree: X.Node = prog

    if o.windows:
        by_value: dict[int, str] = {}
        n = 0
        for path, kind in X.classify(prog).items():
            if kind != "window":
                continue
            value = int(X.get_at(prog, path).text)                 # type: ignore[union-attr]
            if o.tie_equal_windows and value in by_value:
                name = by_value[value]
            elif win_vars is not None and n >= win_vars:
                continue                                           # shrunk: this window keeps its original value
            else:
                n += 1
                name = f"w{n}"
                by_value[value] = name
                variables[name] = window_grid(value, radius)
            tree = X.replace_at(tree, path, X.Name("$" + name))
        if not variables:
            notes.append("This alpha has no look-back windows to vary.")

    if o.operators:
        sites = 0
        for path, node in X.walk(prog):
            if sites >= op_sites:
                break
            if isinstance(node, X.Call) and (fam := ga.family_of(node)) and len(fam) > 1:
                sites += 1
                name = f"op{sites}"
                variables[name] = [node.name] + [m for m in fam if m != node.name][:3]
                inner = X.get_at(tree, path)                          # may already carry window placeholders below it
                tree = X.replace_at(tree, path, X.Call("$" + name, inner.args, inner.kwargs))        # type: ignore[union-attr]
        if not sites:
            notes.append("No operator here has a close relative to swap in.")

    text = X.print_(tree)
    if wrapper:
        last = text.rsplit("; ", 1)
        outer = X.parse(expression).statements[-1]
        present = outer.name if isinstance(outer, X.Call) and outer.name in WRAPPERS and len(outer.args) == 1 else None
        choices = [w for w in WRAPPERS if w != present]
        variables["outer"] = choices
        last[-1] = f"$outer({last[-1]})"
        text = "; ".join(last)

    settings: dict[str, list[Any]] = {          # the original's own settings are always carried over, swept only when asked
        "decay": [o.decay] + ([d for d in DECAYS if d != o.decay] if o.vary_decay else []),
        "neutralization": [o.neutralization] + ([n for n in NEUTRALIZATIONS if n != o.neutralization] if o.vary_neutralization else [])}
    return text, variables, settings, notes


def deepen(expression: str, options: Options | None = None, *, name: str = "") -> Deepened:
    """Alpha expression -> a template (a plain dict `templates.spec.parse` accepts) whose space contains the alpha itself."""
    o = options or Options()
    radius, op_sites, wrapper = max(1, o.radius), max(0, o.max_operator_sites), o.wrapper
    shrunk: list[str] = []
    win_vars: int | None = None
    while True:
        text, variables, settings, notes = _build(expression, o, radius, op_sites, wrapper, win_vars)
        size = _size(variables, settings)
        if size <= o.max_simulations:
            break
        if radius > 1:
            radius -= 1
            shrunk.append("fewer window steps")
        elif op_sites > 0:
            op_sites -= 1
            shrunk.append("fewer operator swaps")
        elif wrapper:
            wrapper = False
            shrunk.append("no wrapper")
        elif (cur := win_vars if win_vars is not None else sum(1 for n in variables if n.startswith("w"))) > 1:
            win_vars = cur - 1
            shrunk.append("fewer windows varied")
        else:
            notes.append(f"Even the smallest neighbourhood has {size} points, more than the {o.max_simulations} allowed; "
                         "the task will only run the first part of it.")
            break
    if shrunk:
        notes.append("The neighbourhood was larger than the budget, so it was shrunk (" + ", ".join(dict.fromkeys(shrunk)) + ").")
    if not variables and not settings:
        notes.append("Nothing could be varied, so there is nothing to deepen.")

    v_spec: dict[str, Any] = {}
    origin: dict[str, Any] = {}
    for n, values in variables.items():
        if n.startswith("w"):
            v_spec[n] = {"type": "int", "grid": values}
        else:
            v_spec[n] = {"type": "choice", "values": values}
        origin[n] = values[0] if n != "outer" else ""
    template: dict[str, Any] = {
        "name": name or "deepen " + (expression if len(expression) <= 40 else expression[:37] + "…"),
        "description": "Neighbourhood of: " + expression,
        "expr": text,
        "vars": v_spec,
        "settings": {k: v if len(v) > 1 else v[0] for k, v in settings.items()},
        "constraints": {"max_simulations": max(1, min(o.max_simulations, 10_000))},
    }
    if "outer" in v_spec:                                      # the original is the empty wrapper
        v_spec["outer"]["values"] = [""] + [w for w in v_spec["outer"]["values"] if w]
    return Deepened(template, origin, size, notes)
