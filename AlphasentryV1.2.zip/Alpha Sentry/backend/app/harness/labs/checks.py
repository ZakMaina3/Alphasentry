"""Check-result helpers (ported from alpha_harness.plan.yields). Works on BRAIN's check list:
[{"name": ..., "result": "PASS|FAIL|WARNING|PENDING", ...}] given as JSON text or a list."""
from __future__ import annotations

import json
from typing import Any

IGNORED_CHECKS = frozenset({"MATCHES_COMPETITION", "MATCHES_PYRAMID", "MATCHES_THEMES", "CLUSTER_TEST",
                            "OSMOSIS_ALLOCATION", "POWER_POOL_DESCRIPTION_LENGTH", "POWER_POOL_DESCRIPTION_FORMAT"})
FAILING = frozenset({"FAIL", "WARNING"})
FIXABLE_CHECKS = frozenset({"HIGH_TURNOVER", "LOW_TURNOVER", "LOW_FITNESS", "CONCENTRATED_WEIGHT",
                            "LOW_SUB_UNIVERSE_SHARPE", "SELF_CORRELATION"})


def _load(checks: Any) -> list | None:
    if not checks:
        return None
    if isinstance(checks, str):
        try:
            checks = json.loads(checks)
        except (json.JSONDecodeError, TypeError):
            return None
    return checks if isinstance(checks, list) and checks else None


def judged_results(checks: Any) -> list[str] | None:
    """Result of every check that describes the alpha itself; None = nothing to judge
    (callers treat that as 'not shown to be good', never as 'fine')."""
    items = _load(checks)
    if items is None:
        return None
    judged = [str(c.get("result", "")).upper() for c in items
              if isinstance(c, dict) and str(c.get("name", "")).upper() not in IGNORED_CHECKS]
    return judged or None


def failed_checks(checks: Any) -> set[str]:
    items = _load(checks)
    if items is None:
        return set()
    return {str(c.get("name", "")).upper() for c in items
            if isinstance(c, dict) and str(c.get("result", "")).upper() in FAILING
            and str(c.get("name", "")).upper() not in IGNORED_CHECKS}
