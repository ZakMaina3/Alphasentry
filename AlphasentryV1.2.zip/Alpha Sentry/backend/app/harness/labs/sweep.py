"""Template lab (grid sweep): try EVERY combination of a template exactly once. Pure planning; the endpoint creates the task.

A sweep is a task with the exhaustive sampler. What this module adds is the part that matters before you spend anything: how
big the grid is, whether it fits the template's simulation cap and your budget, and what will never be tried if it does not.
"""
from __future__ import annotations

import math
from typing import Any

from app.harness.optimize import space as sp
from app.harness.templates import realise as R
from app.harness.templates import spec as T


class SweepError(ValueError):
    pass


def plan(spec: T.TemplateSpec, prepared: R.Prepared | None = None, *, budget: int | None = None, batch: int = 10) -> dict[str, Any]:
    """What a sweep over `spec` would do. `budget` (optional) is the most simulations you are willing to spend."""
    space = R.build_space(spec, prepared)
    if not space:
        raise SweepError("Nothing in this template varies, so there is nothing to sweep.")
    size = sp.grid_size(space)
    if size is None:
        bad = sorted(n for n, s in space.items() if sp.grid_values(s) is None)
        raise SweepError("A sweep needs every variable to be a list or have a step, so each combination can be counted. "
                         "Add `step` (or a `grid`) to: " + ", ".join(bad) + ". To search ranges, use a Search task instead.")
    cap = spec.constraints.max_simulations
    limit = min(cap, int(budget)) if budget else cap
    run = min(size, limit)
    warnings: list[str] = []
    if size > limit:
        why = "the template's max_simulations" if limit == cap and (not budget or cap <= budget) else "your budget"
        warnings.append(f"The grid has {size} combinations but {why} allows {limit}, so {size - limit} "
                        f"({round(100 * (size - limit) / size)}%) will never be tried and the rest are taken in grid order. "
                        "Narrow a list, or raise the limit, to cover everything.")
    batch = max(1, int(batch))
    return {"gridSize": size, "budget": run, "fits": size <= limit, "untried": max(0, size - limit),
            "batches": math.ceil(run / batch), "capped": limit < size, "warnings": warnings,
            "dimensions": {n: (s["kind"], len(sp.grid_values(s) or [])) for n, s in space.items()}}
