"""What a task is trying to maximise, and what it must not violate (ported from alpha_harness.optimize.objectives).

OBJECTIVES are numbers read from a finished alpha's in-sample statistics (Alpha Sentry's sim_results row). CONSTRAINTS follow
Optuna's convention: a value <= 0 is feasible, > 0 is a violation and its size says by how much, so a sampler prefers a
nearly-passing alpha over a badly-failing one.

Adaptation: SentryEngine read each constraint from BRAIN's own check list (value + limit). Alpha Sentry already stores the numbers
behind its gate, so constraints here are computed from those with Alpha Sentry's gate thresholds (|Sharpe|/|Fitness| by delay,
turnover < 0.70, correlations < 0.70, IS-test failures). `train_fitness` is not offered: Alpha Sentry stores no train block.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from itertools import accumulate
from typing import Any

from app.harness.scoring import MAX_CORR, MAX_TURNOVER, gate_thresholds


class ObjectiveError(ValueError):
    pass


@dataclass(frozen=True)
class Objective:
    key: str
    label: str
    direction: str            # "maximize" | "minimize"
    summary: str
    failure_value: float      # used when the alpha produced no number: deliberately terrible
    needs_pnl: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {"key": self.key, "label": self.label, "direction": self.direction, "summary": self.summary, "needsPnl": self.needs_pnl}


OBJECTIVES: dict[str, Objective] = {o.key: o for o in (
    Objective("sharpe", "Sharpe", "maximize", "Return per unit of risk. The single number BRAIN cares about most.", -10.0),
    Objective("fitness", "Fitness", "maximize", "BRAIN's composite of Sharpe, returns and turnover. A good default.", -10.0),
    Objective("returns", "Returns", "maximize", "Annualised return before costs.", -10.0),
    Objective("turnover", "Turnover", "minimize", "How much of the book trades each day. Lower is cheaper but usually costs Sharpe.", 10.0),
    Objective("margin", "Margin", "maximize", "Profit per dollar traded; survives transaction costs better than raw returns.", -10.0),
    Objective("drawdown", "Drawdown", "minimize", "Worst peak-to-trough loss. Minimise it when an alpha has to be survivable.", 10.0),
    Objective("sharpe_per_turnover", "Sharpe per unit turnover", "maximize", "Sharpe divided by turnover: one number for the trade-off.", -10.0),
    Objective("k_ratio", "K-Ratio", "maximize", "How steadily the profit line climbs (needs the daily returns vault).", -10.0, needs_pnl=True),
    Objective("calmar", "Calmar", "maximize", "Yearly return divided by the worst drawdown.", -10.0),
)}
DEFAULT_OBJECTIVES = ("fitness", "turnover")


def catalogue() -> list[dict[str, Any]]:
    return [o.to_dict() for o in OBJECTIVES.values()]


def resolve(keys: list[str]) -> list[Objective]:
    unknown = [k for k in keys if k not in OBJECTIVES]
    if unknown:
        raise ObjectiveError(f"Unknown objective(s): {', '.join(unknown)}. Available: {', '.join(sorted(OBJECTIVES))}.")
    if not keys:
        raise ObjectiveError("A task needs at least one objective.")
    return [OBJECTIVES[k] for k in keys]


def k_ratio(daily_pnl: list[float]) -> float | None:
    """Kestner's K-Ratio (2003): slope of cumulative PnL over its standard error, over sqrt(days)."""
    n = len(daily_pnl)
    if n < 3:
        return None
    y = list(accumulate(daily_pnl))
    x_mean, y_mean = (n + 1) / 2, sum(y) / n
    xs = [i - x_mean for i in range(1, n + 1)]
    sxx = sum(x * x for x in xs)
    slope = sum(x * (v - y_mean) for x, v in zip(xs, y)) / sxx
    sse = sum((v - y_mean - slope * x) ** 2 for x, v in zip(xs, y))
    if sse <= 1e-12 * (sum((v - y_mean) ** 2 for v in y) or 1.0):      # a straight line (R² ≈ 1): K-Ratio is undefined, not huge
        return None
    return slope / (math.sqrt(sse / (n - 2) / sxx) * math.sqrt(n))


def _value(row: dict[str, Any], key: str) -> float | None:
    def num(k: str) -> float | None:
        v = row.get(k)
        return None if v is None or (isinstance(v, float) and (math.isnan(v) or math.isinf(v))) else float(v)
    if key == "sharpe_per_turnover":
        s, t = num("sharpe"), num("turnover")
        return None if s is None or not t else s / t
    if key == "calmar":
        r, d = num("returns"), num("drawdown")
        return None if r is None or not d else r / d
    return num(key)


def extract(row: dict[str, Any] | None, objectives: list[Objective], extra: dict[str, float | None] | None = None) -> list[float]:
    """One number per objective. A missing number becomes the objective's failure value (never zero, which would make a
    broken simulation look mediocre instead of bad)."""
    out: list[float] = []
    for o in objectives:
        raw = extra[o.key] if extra is not None and o.key in extra else (_value(row, o.key) if row else None)
        out.append(o.failure_value if raw is None else float(raw))
    return out


#: Power Pool selection numbers. Kept in ONE place so they are easy to correct if BRAIN's programme rules change: verify them
#: against the Power Pool page on the BRAIN platform before relying on a Power Pool task.
POWER_POOL_MIN_SHARPE = 1.0
POWER_POOL_MAX_CORR = 0.5


def constraints_from_row(row: dict[str, Any] | None, power_pool: bool = False) -> dict[str, float]:
    """Violation magnitudes, named like BRAIN's checks. 0.0 = passed; otherwise how far past the limit.

    With `power_pool=True` the target is Power Pool membership rather than the normal submission gate: |Sharpe| must reach
    POWER_POOL_MIN_SHARPE (instead of the delay's gate), correlation with the pool must stay under POWER_POOL_MAX_CORR (instead of
    0.70), and the normal fitness requirement is not applied. Turnover, self/prod correlation and IS tests still count."""
    if not row:
        return {"NO_RESULT": 1.0}
    if power_pool:
        out: dict[str, float] = {}
        sh, turn = row.get("sharpe"), row.get("turnover")
        out["LOW_SHARPE"] = 1.0 if sh is None else max(0.0, POWER_POOL_MIN_SHARPE - abs(float(sh)))
        if turn is not None:
            out["HIGH_TURNOVER"] = max(0.0, float(turn) - MAX_TURNOVER)
        for name, key, lim in (("SELF_CORRELATION", "self_corr", MAX_CORR), ("PROD_CORRELATION", "prod_corr", MAX_CORR),
                               ("POWER_POOL_CORRELATION", "powerpool_corr", POWER_POOL_MAX_CORR)):
            if row.get(key) is not None:
                out[name] = max(0.0, abs(float(row[key])) - lim)
        if row.get("tests_failed"):
            out["IS_TESTS"] = float(row["tests_failed"])
        return out
    delay = row.get("delay")
    thr = gate_thresholds(1 if delay is None else int(delay))              # delay 0 is a real value, not "missing"
    out: dict[str, float] = {}
    sh, fit, turn = row.get("sharpe"), row.get("fitness"), row.get("turnover")
    out["LOW_SHARPE"] = 1.0 if sh is None else max(0.0, thr["sharpe"] - abs(float(sh)))
    out["LOW_FITNESS"] = 1.0 if fit is None else max(0.0, thr["fitness"] - abs(float(fit)))
    if turn is not None:
        out["HIGH_TURNOVER"] = max(0.0, float(turn) - MAX_TURNOVER)
    for name, key in (("SELF_CORRELATION", "self_corr"), ("PROD_CORRELATION", "prod_corr"), ("POWER_POOL_CORRELATION", "powerpool_corr")):
        if row.get(key) is not None:
            out[name] = max(0.0, abs(float(row[key])) - MAX_CORR)
    if row.get("tests_failed"):
        out["IS_TESTS"] = float(row["tests_failed"])
    return out


def feasible(violations: dict[str, float]) -> bool:
    return all(v <= 0.0 for v in violations.values())


def summarise(row: dict[str, Any] | None) -> dict[str, Any]:
    """The per-trial result the UI shows, with nothing dropped."""
    v = constraints_from_row(row)
    return {"alphaId": (row or {}).get("alpha_id"), "stats": {k: (row or {}).get(k) for k in
            ("sharpe", "fitness", "turnover", "returns", "margin", "drawdown", "self_corr", "prod_corr")},
            "constraint": v, "feasible": feasible(v), "failedChecks": [k for k, x in v.items() if x > 0]}
