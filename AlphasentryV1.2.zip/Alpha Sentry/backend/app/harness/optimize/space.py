"""Search spaces, described declaratively (same shape SentryEngine uses, so a space can be shown to the user,
replayed when a study is rebuilt, and compared against its template).

    {"name": {"kind": "categorical", "choices": [...]},
     "name": {"kind": "int",   "low": 5, "high": 250, "step": 5, "log": False},
     "name": {"kind": "float", "low": 0.01, "high": 0.2, "step": None, "log": False}}
"""
from __future__ import annotations

import json
import math
import random
from typing import Any

Space = dict[str, dict[str, Any]]
KINDS = ("categorical", "int", "float")


class SpaceError(ValueError):
    pass


def check_space(space: Space) -> None:
    if not space:
        raise SpaceError("A search space needs at least one parameter.")
    for name, s in space.items():
        kind = s.get("kind")
        if kind not in KINDS:
            raise SpaceError(f"{name!r}: unknown kind {kind!r}. Use one of {', '.join(KINDS)}.")
        if kind == "categorical":
            if not s.get("choices"):
                raise SpaceError(f"{name!r}: a categorical needs at least one choice.")
            continue
        lo, hi = s.get("low"), s.get("high")
        if lo is None or hi is None or not lo <= hi:
            raise SpaceError(f"{name!r}: needs low <= high.")
        step = s.get("step")
        if step is not None and step <= 0:
            raise SpaceError(f"{name!r}: step must be positive.")
        if s.get("log"):
            if lo <= 0:
                raise SpaceError(f"{name!r}: a log-scaled range must be above zero.")
            if step not in (None, 1) or (kind == "float" and step is not None):
                raise SpaceError(f"{name!r}: a log-scaled range cannot also have a step.")


def _snap(s: dict[str, Any], v: float) -> float | int:
    lo, hi, step = s["low"], s["high"], s.get("step")
    if s["kind"] == "int":
        step = int(step or 1)
        v = lo + round((v - lo) / step) * step
        return int(min(max(v, lo), lo + ((hi - lo) // step) * step))
    if step:
        v = lo + round((v - lo) / step) * step
        v = min(v, lo + math.floor((hi - lo) / step + 1e-9) * step)
    return float(min(max(v, lo), hi))


def from_unit(s: dict[str, Any], u: float) -> Any:
    """A point u in [0, 1] -> a legal value of this parameter."""
    u = min(max(u, 0.0), 1.0)
    if s["kind"] == "categorical":
        ch = s["choices"]
        return ch[min(int(u * len(ch)), len(ch) - 1)]
    lo, hi = s["low"], s["high"]
    if hi == lo:
        return _snap(s, lo)
    v = math.exp(math.log(lo) + u * (math.log(hi) - math.log(lo))) if s.get("log") else lo + u * (hi - lo)
    return _snap(s, v)


def to_unit(s: dict[str, Any], v: Any) -> float:
    """A value -> its position in [0, 1] (categoricals: the centre of their slot)."""
    if s["kind"] == "categorical":
        ch = s["choices"]
        try:
            i = ch.index(v)
        except ValueError:
            return 0.5
        return (i + 0.5) / len(ch)
    lo, hi = s["low"], s["high"]
    if hi == lo:
        return 0.5
    x = (math.log(v) - math.log(lo)) / (math.log(hi) - math.log(lo)) if s.get("log") else (v - lo) / (hi - lo)
    return min(max(float(x), 0.0), 1.0)


def random_params(space: Space, rng: random.Random) -> dict[str, Any]:
    return {n: from_unit(s, rng.random()) for n, s in space.items()}


def grid_values(s: dict[str, Any]) -> list[Any] | None:
    """Every legal value, or None if the parameter is continuous."""
    if s["kind"] == "categorical":
        return list(s["choices"])
    lo, hi, step = s["low"], s["high"], s.get("step")
    if s["kind"] == "int":
        return list(range(lo, hi + 1, int(step or 1)))
    if step:
        n = int(math.floor((hi - lo) / step + 1e-9))
        return [float(lo + i * step) for i in range(n + 1)]
    return None


def grid_size(space: Space) -> int | None:
    """Number of distinct points, or None when any parameter is continuous."""
    total = 1
    for s in space.values():
        g = grid_values(s)
        if g is None:
            return None
        total *= max(1, len(g))
    return total


def param_key(params: dict[str, Any]) -> str:
    return json.dumps(params, sort_keys=True, default=str)


def in_space(space: Space, params: dict[str, Any]) -> bool:
    """Whether every parameter is present and legal (used by tests and when replaying stored trials)."""
    for n, s in space.items():
        if n not in params:
            return False
        v = params[n]
        if s["kind"] == "categorical":
            if v not in s["choices"]:
                return False
        else:
            if not (s["low"] - 1e-9 <= v <= s["high"] + 1e-9):
                return False
            step = s.get("step") or (1 if s["kind"] == "int" else None)
            if step and abs((v - s["low"]) / step - round((v - s["low"]) / step)) > 1e-6:
                return False
    return True
