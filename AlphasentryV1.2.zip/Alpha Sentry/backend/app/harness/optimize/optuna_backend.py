"""Optuna adapter: the same ask / tell / replay interface as BuiltinOptimizer, backed by Optuna.

Loaded only when Optuna is installed (nothing imports it otherwise). It follows SentryEngine's own, tested
plumbing (distributions, ask, constraint-then-tell, replay via create_trial). It could NOT be run where this was
written (no Optuna there), so it is covered by the shared contract tests in tests/test_optimize.py, which run
against it automatically on any machine that has Optuna and skip otherwise.
"""
from __future__ import annotations

from typing import Any

from app.harness.optimize import space as sp
from app.harness.optimize.builtin import Handle

SAMPLER_NAMES = ("random", "brute", "qmc", "nsga2", "nsga3", "tpe", "cmaes")


def available() -> bool:
    try:
        import optuna  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        return False


def _distribution(spec: dict[str, Any]):
    from optuna.distributions import CategoricalDistribution, FloatDistribution, IntDistribution
    if spec["kind"] == "categorical":
        return CategoricalDistribution(tuple(spec["choices"]))
    if spec["kind"] == "int":
        return IntDistribution(low=spec["low"], high=spec["high"], step=spec.get("step") or 1, log=spec.get("log", False))
    return FloatDistribution(low=spec["low"], high=spec["high"], step=spec.get("step"), log=spec.get("log", False))


def _make_sampler(name: str, *, seed, batch_size: int, options: dict[str, Any], n_objectives: int):
    from optuna.samplers import BruteForceSampler, CmaEsSampler, NSGAIIISampler, NSGAIISampler, QMCSampler, RandomSampler, TPESampler
    notes: list[str] = []
    if n_objectives > 1 and name == "cmaes":
        raise ValueError("CMA-ES optimises a single number, but this study has several objectives. "
                         "Choose NSGA-II, NSGA-III or TPE, or reduce to one objective.")
    if name in ("nsga2", "nsga3"):
        pop = int(options.get("population_size") or batch_size * 8)
        pop = max(batch_size, round(pop / batch_size) * batch_size)           # whole batches per generation
        cls = NSGAIISampler if name == "nsga2" else NSGAIIISampler
        return cls(population_size=pop, mutation_prob=options.get("mutation_prob"),
                   crossover_prob=float(options.get("crossover_prob") or 0.9), seed=seed), notes
    if name == "tpe":
        liar = batch_size > 1
        if liar:
            notes.append("constant_liar on: several trials are asked for before any result comes back.")
        return TPESampler(n_startup_trials=int(options.get("n_startup_trials") or 20), multivariate=bool(options.get("multivariate", True)),
                          group=bool(options.get("group", True)), constant_liar=liar, seed=seed), notes
    if name == "cmaes":
        return CmaEsSampler(n_startup_trials=int(options.get("n_startup_trials") or 10), sigma0=options.get("sigma0"), seed=seed), notes
    if name == "qmc":
        return QMCSampler(qmc_type=str(options.get("qmc_type") or "sobol"), scramble=bool(options.get("scramble", True)),
                          seed=seed, warn_independent_sampling=False), notes
    if name == "random":
        return RandomSampler(seed=seed), notes
    if name == "brute":
        return BruteForceSampler(seed=seed), notes
    raise ValueError(f"{name!r} is not a sampler. Choose one of: {', '.join(sorted(SAMPLER_NAMES))}.")


class OptunaOptimizer:
    backend = "optuna"

    def __init__(self, sampler: str, space: sp.Space, directions: list[str] | None = None, *, seed: int | None = None,
                 batch_size: int = 10, params: dict[str, Any] | None = None) -> None:
        import optuna
        sp.check_space(space)
        optuna.logging.set_verbosity(optuna.logging.WARNING)
        self.space, self.directions = space, list(directions or ["maximize"])
        self.sampler, self.batch_size = sampler, batch_size
        s, self.notes = _make_sampler(sampler, seed=seed, batch_size=batch_size, options=params or {}, n_objectives=len(self.directions))
        self._study = optuna.create_study(directions=self.directions, sampler=s)
        self._dist = {n: _distribution(spec) for n, spec in space.items()}
        self._live: dict[int, Any] = {}
        self._n = 0

    def ask(self, n: int) -> list[tuple[Handle, dict[str, Any]]]:
        out = []
        for _ in range(n):
            try:
                t = self._study.ask(self._dist)
            except Exception:  # noqa: BLE001      e.g. BruteForceSampler has run out of grid
                break
            h = Handle(self._n)
            self._n += 1
            self._live[h.number] = t
            out.append((h, dict(t.params)))
        return out

    def tell(self, handle: Handle | None, values: list[float] | None, *, constraint: dict[str, float] | None = None,
             state: str | None = None, params: dict[str, Any] | None = None) -> None:
        from optuna.trial import TrialState, create_trial
        con = {str(k): float(v) for k, v in (constraint or {}).items()}
        if handle is not None:
            t = self._live.pop(handle.number, None)
            if t is None:
                return
            if state == "PRUNED":
                self._study.tell(t, state=TrialState.PRUNED, skip_if_finished=True)
            elif values is None or state == "FAIL":
                self._study.tell(t, state=TrialState.FAIL, skip_if_finished=True)
            else:
                if hasattr(t, "set_constraint"):                       # Optuna 5's named constraints
                    for k, v in con.items():
                        t.set_constraint(k, v)
                self._study.tell(t, [float(v) for v in values], skip_if_finished=True)
            return
        if params is None:
            raise ValueError("Replaying a trial needs its parameters.")
        if values is None:
            return                                                     # a failed replayed trial teaches the sampler nothing
        dist = {k: v for k, v in self._dist.items() if k in params}
        kwargs: dict[str, Any] = dict(params={k: params[k] for k in dist}, distributions=dist,
                                      values=[float(v) for v in values], state=TrialState.COMPLETE)
        try:
            self._study.add_trial(create_trial(constraints=con or None, **kwargs))
        except TypeError:
            self._study.add_trial(create_trial(**kwargs))

    @classmethod
    def from_history(cls, sampler: str, space: sp.Space, directions: list[str], history: list[dict[str, Any]], **kw: Any):
        opt = cls(sampler, space, directions, **kw)
        for h in history:
            opt.tell(None, h.get("values"), constraint=h.get("constraint"), state=h.get("state"), params=h["params"])
        return opt
