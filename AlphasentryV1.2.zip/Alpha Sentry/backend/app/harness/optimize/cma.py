"""Separable CMA-ES (diagonal covariance) as a stateless function of the finished trials (E5).

Single objective, numeric dimensions in the unit cube. State (mean, step size, diagonal covariance, evolution paths) is recomputed from
the finished trials every time, in trial-number order, `lam` trials per generation, so an optimizer rebuilt after a restart
lands in exactly the same state and results arriving late or out of order never corrupt it. Ros & Hansen (2008) learning rates.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

SIGMA0, SIGMA_MIN, SIGMA_MAX = 0.3, 0.01, 0.5


@dataclass
class State:
    mean: list[float]
    sigma: float
    cov: list[float]                       # diagonal of C
    ps: list[float] = field(default_factory=list)
    pc: list[float] = field(default_factory=list)
    generation: int = 0


def default_lambda(n: int) -> int:
    return max(8, 4 + int(3 * math.log(max(n, 1))))


def initial(n: int) -> State:
    return State([0.5] * n, SIGMA0, [1.0] * n, [0.0] * n, [0.0] * n)


def update(st: State, xs: list[list[float]], lam: int) -> State:
    """One generation. `xs` are the lam points sorted best first (unit coordinates)."""
    n = len(st.mean)
    mu = max(1, lam // 2)
    w = [math.log(mu + 0.5) - math.log(i + 1) for i in range(mu)]
    sw = sum(w)
    w = [x / sw for x in w]
    mueff = 1.0 / sum(x * x for x in w)
    cs = (mueff + 2) / (n + mueff + 5)
    ds = 1 + 2 * max(0.0, math.sqrt((mueff - 1) / (n + 1)) - 1) + cs
    cc = (4 + mueff / n) / (n + 4 + 2 * mueff / n)
    c1 = min(1.0, (2.0 / ((n + 1.3) ** 2 + mueff)) * (n + 2) / 3)               # separable: faster rates, (n+2)/3
    cmu = min(1.0 - c1, (2 * (mueff - 2 + 1 / mueff) / ((n + 2) ** 2 + mueff)) * (n + 2) / 3)
    chi = math.sqrt(n) * (1 - 1 / (4 * n) + 1 / (21 * n * n))
    old = st.mean
    mean = [sum(w[i] * xs[i][d] for i in range(mu)) for d in range(n)]
    step = [(mean[d] - old[d]) / st.sigma for d in range(n)]
    ps = [(1 - cs) * st.ps[d] + math.sqrt(cs * (2 - cs) * mueff) * step[d] / math.sqrt(st.cov[d]) for d in range(n)]
    nps = math.sqrt(sum(x * x for x in ps))
    g = st.generation + 1
    hs = 1.0 if nps / math.sqrt(1 - (1 - cs) ** (2 * g)) / chi < 1.4 + 2 / (n + 1) else 0.0
    pc = [(1 - cc) * st.pc[d] + hs * math.sqrt(cc * (2 - cc) * mueff) * step[d] for d in range(n)]
    cov = []
    for d in range(n):
        rank_mu = sum(w[i] * ((xs[i][d] - old[d]) / st.sigma) ** 2 for i in range(mu))
        c = (1 - c1 - cmu) * st.cov[d] + c1 * (pc[d] ** 2 + (1 - hs) * cc * (2 - cc) * st.cov[d]) + cmu * rank_mu
        cov.append(min(max(c, 1e-6), 1e3))
    sigma = min(max(st.sigma * math.exp((cs / ds) * (nps / chi - 1)), SIGMA_MIN), SIGMA_MAX)
    return State(mean, sigma, cov, ps, pc, g)


def replay(n: int, ranked_generations: list[list[list[float]]], lam: int) -> State:
    st = initial(n)
    for xs in ranked_generations:
        st = update(st, xs, lam)
    return st
