"""Sobol low-discrepancy sequence (Joe–Kuo direction numbers, first 14 dimensions) with a random digital shift (E5).

Pure Python, deterministic for a given seed. `Sobol(dim, rng)` yields points in [0,1)^dim; the digital shift (XOR with a random
word per dimension) keeps every dimension's first 2^k points evenly stratified while making different seeds give different sets.
Dimensions beyond MAX_DIM are not covered: the caller falls back to random draws for those.
"""
from __future__ import annotations

import random

BITS = 30
# (s, a, m...) per dimension 2..14, from the Joe–Kuo "new-joe-kuo-6.21201" table. Dimension 1 is van der Corput.
JOE_KUO: tuple[tuple[int, int, tuple[int, ...]], ...] = (
    (1, 0, (1,)), (2, 1, (1, 3)), (3, 1, (1, 3, 1)), (3, 2, (1, 1, 1)), (4, 1, (1, 1, 3, 3)), (4, 4, (1, 3, 5, 13)),
    (5, 2, (1, 1, 5, 5, 17)), (5, 4, (1, 1, 5, 5, 5)), (5, 7, (1, 1, 7, 11, 19)), (5, 11, (1, 1, 5, 1, 1)),
    (5, 13, (1, 1, 1, 3, 11)), (5, 14, (1, 3, 5, 5, 31)), (6, 1, (1, 3, 3, 9, 7, 49)),
)
MAX_DIM = len(JOE_KUO) + 1


def _directions(dim: int) -> list[int]:
    """BITS direction integers (already scaled by 2^BITS) for dimension index `dim` (0-based)."""
    if dim == 0:
        return [1 << (BITS - i) for i in range(1, BITS + 1)]
    s, a, m = JOE_KUO[dim - 1]
    v = [0] * (BITS + 1)
    for i in range(1, s + 1):
        v[i] = m[i - 1] << (BITS - i)
    for i in range(s + 1, BITS + 1):
        x = v[i - s] ^ (v[i - s] >> s)
        for k in range(1, s):
            if (a >> (s - 1 - k)) & 1:
                x ^= v[i - k]
        v[i] = x
    return v[1:]


class Sobol:
    def __init__(self, dim: int, rng: random.Random | None = None) -> None:
        if not 1 <= dim <= MAX_DIM:
            raise ValueError(f"Sobol supports 1..{MAX_DIM} dimensions, got {dim}.")
        self.dim, self._v = dim, [_directions(d) for d in range(dim)]
        self._x = [0] * dim
        self._n = 0
        self._shift = [rng.getrandbits(BITS) if rng else 0 for _ in range(dim)]

    def next(self) -> list[float]:
        """The next point. The first call returns the (shifted) origin, as the Gray-code construction does."""
        if self._n > 0:
            c = 0                                   # index of the lowest zero bit of n-1
            n = self._n - 1
            while n & 1:
                n >>= 1
                c += 1
            for d in range(self.dim):
                self._x[d] ^= self._v[d][c]
        self._n += 1
        return [((self._x[d] ^ self._shift[d]) / (1 << BITS)) for d in range(self.dim)]

    def skip(self, n: int) -> None:
        for _ in range(n):
            self.next()
