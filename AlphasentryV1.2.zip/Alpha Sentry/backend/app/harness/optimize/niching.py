"""Reference-point niching for the built-in NSGA-III (E5): Das–Dennis reference points on the normalised objective space,
association of each solution to its nearest reference line, and the niche-preserving ordering inside a front."""
from __future__ import annotations

import math
import random
from itertools import combinations


def reference_points(m: int, divisions: int) -> list[list[float]]:
    """Das–Dennis: all points with coordinates k/divisions summing to 1 (m objectives)."""
    if m == 1:
        return [[1.0]]
    pts = []
    for bars in combinations(range(divisions + m - 1), m - 1):
        prev, parts = -1, []
        for b in bars:
            parts.append(b - prev - 1)
            prev = b
        parts.append(divisions + m - 2 - prev)
        pts.append([p / divisions for p in parts])
    return pts


def default_divisions(m: int, pop: int) -> int:
    d = 1
    while len(reference_points(m, d + 1)) <= max(pop, m) and d < 12:
        d += 1
    return d


def normalise(losses: list[list[float]]) -> list[list[float]]:
    m = len(losses[0])
    ideal = [min(r[k] for r in losses) for k in range(m)]
    nad = [max(r[k] for r in losses) for k in range(m)]
    return [[(r[k] - ideal[k]) / ((nad[k] - ideal[k]) or 1.0) for k in range(m)] for r in losses]


def _distance_to_line(p: list[float], ref: list[float]) -> float:
    nr = math.sqrt(sum(x * x for x in ref)) or 1.0
    t = sum(a * b for a, b in zip(p, ref)) / (nr * nr)
    return math.sqrt(sum((a - t * b) ** 2 for a, b in zip(p, ref)))


def order_by_niche(fronts: list[list[int]], norm: dict[int, list[float]], refs: list[list[float]], rng: random.Random) -> list[int]:
    """All indices, best first: fronts in order; inside a front, repeatedly take a member of the least-crowded reference niche
    (the one closest to its line first). `norm` holds normalised losses by index."""
    count = [0] * len(refs)
    order: list[int] = []
    for front in fronts:
        assoc: dict[int, tuple[int, float]] = {}
        for i in front:
            best = min(range(len(refs)), key=lambda r: _distance_to_line(norm[i], refs[r]))
            assoc[i] = (best, _distance_to_line(norm[i], refs[best]))
        left = set(front)
        while left:
            niches = {assoc[i][0] for i in left}
            low = min(count[r] for r in niches)
            pick_niche = rng.choice(sorted(r for r in niches if count[r] == low))
            members = sorted((i for i in left if assoc[i][0] == pick_niche), key=lambda i: assoc[i][1])
            chosen = members[0] if low == 0 else rng.choice(members)
            order.append(chosen)
            left.discard(chosen)
            count[pick_niche] += 1
    return order
