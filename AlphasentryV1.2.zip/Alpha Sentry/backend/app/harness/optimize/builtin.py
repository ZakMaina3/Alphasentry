"""The built-in optimizer: pure Python, no dependencies, fully testable.

It speaks the same ask / tell / replay interface as the Optuna adapter, so the scheduler and labs above never
know which one they have. Samplers (names as SentryEngine uses them):

  random   uniform draws                            brute  every grid point once
  qmc      scrambled Sobol sequence (Joe-Kuo, first 14 dimensions; further dimensions are random)
  nsga2    elitist GA: constraint-dominance non-dominated sort, crowding distance, SBX crossover, polynomial mutation
  nsga3    as nsga2, but ties inside a front are broken by reference-point niching on normalised objectives (Das-Dennis points)
  cmaes    separable (diagonal-covariance) CMA-ES, single objective, recomputed from the finished trials so it is restart-safe
  tpe      joint (multivariate) Parzen-window Bayesian sampler with constant-liar for pending trials

Conventions: objectives are given per `directions` ("maximize"/"minimize"); a constraint value <= 0 is feasible and
a larger value is a bigger violation (feasible beats infeasible, then smaller violation wins) — Optuna's convention.
No sampler proposes a point it has already proposed, unless the space is exhausted (then ask() returns fewer points).
"""
from __future__ import annotations

import itertools
import math
import random
from dataclasses import dataclass, field
from typing import Any

from app.harness.optimize import cma, niching
from app.harness.optimize import space as sp
from app.harness.optimize.sobol import MAX_DIM as SOBOL_DIMS
from app.harness.optimize.sobol import Sobol

DEFAULTS: dict[str, dict[str, Any]] = {
    "nsga2": {"population_size": 80, "mutation_prob": None, "crossover_prob": 0.9},
    "nsga3": {"population_size": 80, "mutation_prob": None, "crossover_prob": 0.9, "divisions": None},
    "cmaes": {"population_size": None},
    "tpe": {"n_startup_trials": 20},
    "qmc": {}, "random": {}, "brute": {},
}
KNOWN = ("random", "brute", "qmc", "nsga2", "nsga3", "tpe", "cmaes")
MAX_POOL = 600          # most recent finished trials considered when ranking (keeps sorting cheap)


@dataclass
class Trial:
    number: int
    params: dict[str, Any]
    values: list[float] | None = None
    constraint: dict[str, float] = field(default_factory=dict)
    state: str = "RUNNING"            # RUNNING | COMPLETE | FAIL | PRUNED


@dataclass(frozen=True)
class Handle:
    number: int


def violation(constraint: dict[str, float] | None) -> float:
    return sum(max(0.0, float(v)) for v in (constraint or {}).values())


def _dominates(a: tuple[float, list[float]], b: tuple[float, list[float]]) -> bool:
    """Constraint-dominance on (violation, losses) with every loss minimised."""
    (va, la), (vb, lb) = a, b
    if va == 0 and vb > 0:
        return True
    if va > 0 and vb == 0:
        return False
    if va > 0 and vb > 0:
        return va < vb
    return all(x <= y for x, y in zip(la, lb)) and any(x < y for x, y in zip(la, lb))


def nondominated_fronts(items: list[tuple[float, list[float]]]) -> list[list[int]]:
    n = len(items)
    dominated_by = [0] * n
    dominates: list[list[int]] = [[] for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            if _dominates(items[i], items[j]):
                dominates[i].append(j)
                dominated_by[j] += 1
            elif _dominates(items[j], items[i]):
                dominates[j].append(i)
                dominated_by[i] += 1
    fronts = [[i for i in range(n) if dominated_by[i] == 0]]
    while fronts[-1]:
        nxt = []
        for i in fronts[-1]:
            for j in dominates[i]:
                dominated_by[j] -= 1
                if dominated_by[j] == 0:
                    nxt.append(j)
        fronts.append(nxt)
    return [f for f in fronts if f]


def crowding(front: list[int], items: list[tuple[float, list[float]]]) -> dict[int, float]:
    dist = {i: 0.0 for i in front}
    if len(front) <= 2:
        return {i: math.inf for i in front}
    for m in range(len(items[front[0]][1])):
        order = sorted(front, key=lambda i: items[i][1][m])
        lo, hi = items[order[0]][1][m], items[order[-1]][1][m]
        dist[order[0]] = dist[order[-1]] = math.inf
        if hi == lo:
            continue
        for k in range(1, len(order) - 1):
            dist[order[k]] += (items[order[k + 1]][1][m] - items[order[k - 1]][1][m]) / (hi - lo)
    return dist


class BuiltinOptimizer:
    backend = "builtin"

    def __init__(self, sampler: str, space: sp.Space, directions: list[str] | None = None, *, seed: int | None = None,
                 batch_size: int = 10, params: dict[str, Any] | None = None) -> None:
        if sampler not in KNOWN:
            raise ValueError(f"{sampler!r} is not a sampler. Choose one of: {', '.join(sorted(KNOWN))}.")
        sp.check_space(space)
        self.space, self.names = space, list(space)
        self.directions = list(directions or ["maximize"])
        if len(self.directions) > 1 and sampler == "cmaes":
            raise ValueError("CMA-ES optimises a single number, but this study has several objectives. "
                             "Choose NSGA-II, NSGA-III or TPE, or reduce to one objective.")
        self.sampler, self.batch_size = sampler, batch_size
        self.notes: list[str] = []
        self.effective = sampler
        if sampler == "nsga3":
            self.notes.append("NSGA-III here uses reference-point niching on normalised objectives; Optuna's version differs in detail.")
        if sampler == "cmaes":
            self.notes.append("CMA-ES here is the separable (diagonal) variant; list/categorical values are sampled outside the "
                              "distribution. Optuna's CMA-ES models the full covariance.")
        if sampler == "qmc":
            self.notes.append("Quasi-random uses a scrambled Sobol sequence"
                              + (f" (first {SOBOL_DIMS} dimensions; the rest are random)." if len(space) > SOBOL_DIMS else "."))
        if sampler == "tpe":
            self.notes.append("TPE here uses a joint product-kernel estimate; Optuna's TPE differs in detail (grouping, priors).")
        self.options = {**DEFAULTS.get(self.effective, {}), **(params or {})}
        self.rng = random.Random(seed)
        self.trials: list[Trial] = []
        self._seen: set[str] = set()
        for _ in self.names:
            self.rng.random()          # kept from the Halton days: seeded runs of every other sampler reproduce exactly as before E5
        nd = min(len(self.names), SOBOL_DIMS)
        self._sobol = Sobol(nd, self.rng) if sampler == "qmc" else None
        self._cma_names = [n for n in self.names if space[n]["kind"] != "categorical"]
        self._cma: cma.State | None = None
        self._cma_lam = int(self.options.get("population_size") or cma.default_lambda(max(1, len(self._cma_names))))
        self._refs: list[list[float]] | None = None
        self._grid = None
        if self.effective == "brute":
            grids = [sp.grid_values(s) for s in space.values()]
            if any(g is None for g in grids):
                raise ValueError("An exhaustive search needs every number to have a step, so there is a finite grid.")
            self._grid = itertools.product(*grids)
        self._ordered: list[Trial] = []
        self._rank: dict[int, tuple[int, float]] = {}

    # ── public interface ──────────────────────────────────────────────────────────
    def ask(self, n: int) -> list[tuple[Handle, dict[str, Any]]]:
        self._prepare()
        out: list[tuple[Handle, dict[str, Any]]] = []
        pending = [t for t in self.trials if t.state == "RUNNING"]
        for _ in range(n):
            params = self._propose(pending)
            if params is None:
                break
            t = Trial(len(self.trials), params)
            self.trials.append(t)
            self._seen.add(sp.param_key(params))
            pending.append(t)
            out.append((Handle(t.number), dict(params)))
        return out

    def tell(self, handle: Handle | None, values: list[float] | None, *, constraint: dict[str, float] | None = None,
             state: str | None = None, params: dict[str, Any] | None = None) -> None:
        """Report a result. handle=None replays a trial whose live handle did not survive a restart (params required)."""
        if handle is None:
            if params is None:
                raise ValueError("Replaying a trial needs its parameters.")
            t = Trial(len(self.trials), dict(params))
            self.trials.append(t)
            self._seen.add(sp.param_key(t.params))
        else:
            t = self.trials[handle.number]
        if state in ("FAIL", "PRUNED") or values is None:
            t.state = state if state in ("FAIL", "PRUNED") else "FAIL"
            return
        if len(values) != len(self.directions):
            raise ValueError(f"Expected {len(self.directions)} objective value(s), got {len(values)}.")
        t.values, t.constraint, t.state = [float(v) for v in values], dict(constraint or {}), "COMPLETE"

    @classmethod
    def from_history(cls, sampler: str, space: sp.Space, directions: list[str], history: list[dict[str, Any]], **kw: Any):
        """Recreate an optimizer from stored trials [{params, values, constraint, state}] (all terminal states)."""
        opt = cls(sampler, space, directions, **kw)
        for h in history:
            opt.tell(None, h.get("values"), constraint=h.get("constraint"), state=h.get("state"), params=h["params"])
        return opt

    # ── helpers ───────────────────────────────────────────────────────────────────
    def _loss(self, t: Trial) -> list[float]:
        return [(-v if d == "maximize" else v) for v, d in zip(t.values or [], self.directions)]

    def _done(self) -> list[Trial]:
        return [t for t in self.trials if t.state == "COMPLETE"][-MAX_POOL:]

    def _prepare(self) -> None:
        """Rank finished trials best-first (front number, then crowding) once per ask() round."""
        self._ordered, self._rank = [], {}
        if self.effective == "cmaes":
            self._prepare_cma()
            return
        if self.effective not in ("nsga2", "nsga3", "tpe"):
            return
        done = self._done()
        if not done:
            return
        items = [(violation(t.constraint), self._loss(t)) for t in done]
        fronts = nondominated_fronts(items)
        if self.effective == "nsga3":
            self._prepare_nsga3(done, items, fronts)
            return
        for fno, front in enumerate(fronts):
            cd = crowding(front, items)
            for i in sorted(front, key=lambda i: -cd[i]):
                self._rank[done[i].number] = (fno, -cd[i])        # lower is better
                self._ordered.append(done[i])

    def _prepare_nsga3(self, done: list[Trial], items: list[tuple[float, list[float]]], fronts: list[list[int]]) -> None:
        m = len(self.directions)
        if self._refs is None:
            pop = int(self.options.get("population_size") or 80)
            self._refs = niching.reference_points(m, int(self.options.get("divisions") or niching.default_divisions(m, pop)))
        norm = dict(enumerate(niching.normalise([it[1] for it in items])))
        # the niche tie-break needs its own random stream so ranking never disturbs the sampling stream
        order = niching.order_by_niche(fronts, norm, self._refs, random.Random(len(done)))
        front_of = {i: f for f, fr in enumerate(fronts) for i in fr}
        for pos, i in enumerate(order):
            self._rank[done[i].number] = (front_of[i], pos)
            self._ordered.append(done[i])

    def _prepare_cma(self) -> None:
        """Recompute the CMA-ES state from every finished trial (generation = lam consecutive trials, best first)."""
        names, lam = self._cma_names, self._cma_lam
        done = sorted((t for t in self.trials if t.state == "COMPLETE"), key=lambda t: t.number)
        gens = []
        for k in range(len(done) // lam):
            chunk = done[k * lam:(k + 1) * lam]
            chunk.sort(key=lambda t: (violation(t.constraint), self._loss(t)[0]))
            gens.append([[sp.to_unit(self.space[n], t.params[n]) for n in names] for t in chunk])
        self._cma = cma.replay(len(names), gens, lam) if names else None
        self._ordered = sorted(done, key=lambda t: (violation(t.constraint), self._loss(t)[0]))[:MAX_POOL]

    def _unique(self, make) -> dict[str, Any] | None:
        size = sp.grid_size(self.space)
        if size is not None and len(self._seen) >= size:
            return None                                   # every point already proposed
        p = None
        for _ in range(30):
            p = make()
            if sp.param_key(p) not in self._seen:
                return p
        for _ in range(30):                               # converged: look elsewhere before repeating
            p = sp.random_params(self.space, self.rng)
            if sp.param_key(p) not in self._seen:
                return p
        if size is not None:                              # a finite space: pick straight from what is left, never a repeat
            return self._unseen_point()
        return p                                          # continuous: a repeat is free, the tracker dedups identical simulations

    def _unseen_point(self) -> dict[str, Any] | None:
        grids = [sp.grid_values(s) for s in self.space.values()]
        free: list[dict[str, Any]] = []
        for combo in itertools.product(*grids):
            p = dict(zip(self.names, combo))
            if sp.param_key(p) not in self._seen:
                free.append(p)
                if len(free) >= 2000:
                    break
        return self.rng.choice(free) if free else None

    def _propose(self, pending: list[Trial]) -> dict[str, Any] | None:
        e = self.effective
        if e == "brute":
            for combo in self._grid:
                p = dict(zip(self.names, combo))
                if sp.param_key(p) not in self._seen:
                    return p
            return None
        make = {"random": self._random, "qmc": self._sobol_point, "nsga2": self._nsga2, "nsga3": self._nsga2, "cmaes": self._cmaes,
                "tpe": lambda: self._tpe(pending)}[e]
        return self._unique(make)

    def _random(self) -> dict[str, Any]:
        return sp.random_params(self.space, self.rng)

    def _sobol_point(self) -> dict[str, Any]:
        u = self._sobol.next()                                  # type: ignore[union-attr]
        return {name: sp.from_unit(self.space[name], u[d] if d < len(u) else self.rng.random()) for d, name in enumerate(self.names)}

    def _cmaes(self) -> dict[str, Any]:
        st = self._cma
        if st is None:
            return self._random()
        out: dict[str, Any] = {}
        x = {n: min(max(self.rng.gauss(st.mean[d], st.sigma * math.sqrt(st.cov[d])), 0.0), 1.0) for d, n in enumerate(self._cma_names)}
        for n in self.names:
            s_ = self.space[n]
            if s_["kind"] != "categorical":
                out[n] = sp.from_unit(s_, x[n])
            elif self._ordered and self.rng.random() < 0.7:
                out[n] = self._ordered[0].params[n]             # keep the best trial's choice most of the time
            else:
                out[n] = self.rng.choice(s_["choices"])
        return out

    # ── NSGA-II ───────────────────────────────────────────────────────────────────
    def _nsga2(self) -> dict[str, Any]:
        pop = int(self.options.get("population_size") or 80)
        if len(self._ordered) < min(pop, 20):
            return self._random()                          # not enough finished trials yet to breed from
        pool = self._ordered[:pop]
        a, b = self._tournament(pool), self._tournament(pool)
        pc = float(self.options.get("crossover_prob") or 0.9)
        child = self._crossover(a.params, b.params) if self.rng.random() < pc else dict(a.params)
        return self._mutate(child)

    def _tournament(self, pool: list[Trial]) -> Trial:
        x, y = self.rng.choice(pool), self.rng.choice(pool)
        return x if self._rank[x.number] <= self._rank[y.number] else y

    def _crossover(self, pa: dict[str, Any], pb: dict[str, Any], eta: float = 20.0) -> dict[str, Any]:
        out = {}
        for n, s in self.space.items():
            if s["kind"] == "categorical" or self.rng.random() < 0.5:
                out[n] = pa[n] if self.rng.random() < 0.5 else pb[n]
                continue
            x1, x2 = sp.to_unit(s, pa[n]), sp.to_unit(s, pb[n])
            u = self.rng.random()
            beta = (2 * u) ** (1 / (eta + 1)) if u <= 0.5 else (1 / (2 * (1 - u))) ** (1 / (eta + 1))
            c = 0.5 * ((1 + beta) * x1 + (1 - beta) * x2) if self.rng.random() < 0.5 else 0.5 * ((1 - beta) * x1 + (1 + beta) * x2)
            out[n] = sp.from_unit(s, c)
        return out

    def _mutate(self, p: dict[str, Any], eta: float = 20.0) -> dict[str, Any]:
        pm = self.options.get("mutation_prob") or 1.0 / max(1, len(self.names))
        out = dict(p)
        for n, s in self.space.items():
            if self.rng.random() >= pm:
                continue
            if s["kind"] == "categorical":
                out[n] = self.rng.choice(s["choices"])
                continue
            u = self.rng.random()
            delta = (2 * u) ** (1 / (eta + 1)) - 1 if u < 0.5 else 1 - (2 * (1 - u)) ** (1 / (eta + 1))
            out[n] = sp.from_unit(s, sp.to_unit(s, p[n]) + delta)
        return out

    # ── TPE (joint / multivariate Parzen estimate) ───────────────────────────────────
    def _tpe(self, pending: list[Trial]) -> dict[str, Any]:
        n_start = int(self.options.get("n_startup_trials") or 20)
        ordered = self._ordered
        if len(ordered) < n_start:
            return self._random()
        k = max(1, min(25, math.ceil(0.1 * len(ordered))))
        good = [self._coords(t.params) for t in ordered[:k]]
        bad = [self._coords(t.params) for t in ordered[k:]] + [self._coords(t.params) for t in pending]   # constant liar
        h_good, h_bad = self._bandwidths(good), self._bandwidths(bad)
        best, best_score = None, -1.0
        for _ in range(int(self.options.get("n_candidates") or 24)):
            c = self._draw(good, h_good)
            score = self._density(c, good, h_good) / max(self._density(c, bad, h_bad), 1e-300)
            if score > best_score:
                best, best_score = c, score
        return self._decode(best)

    LAMBDA = 0.2         # chance a categorical differs from the kernel centre (Aitchison–Aitken)

    def _coords(self, params: dict[str, Any]) -> list[Any]:
        return [params[n] if self.space[n]["kind"] == "categorical" else sp.to_unit(self.space[n], params[n]) for n in self.names]

    def _decode(self, c: list[Any]) -> dict[str, Any]:
        return {n: (v if self.space[n]["kind"] == "categorical" else sp.from_unit(self.space[n], v)) for n, v in zip(self.names, c)}

    def _bandwidths(self, pts: list[list[Any]]) -> list[float]:
        n = max(1, len(pts))
        out = []
        for d, name in enumerate(self.names):
            if self.space[name]["kind"] == "categorical":
                out.append(0.0)
            else:
                out.append(max(0.04, 1.06 * (self._std([p[d] for p in pts]) or 0.2) * n ** -0.2))
        return out

    def _draw(self, pts: list[list[Any]], h: list[float]) -> list[Any]:
        if not pts or self.rng.random() < 1.0 / (len(pts) + 1):            # the uniform prior component
            return [self.rng.choice(self.space[n]["choices"]) if self.space[n]["kind"] == "categorical" else self.rng.random() for n in self.names]
        centre = self.rng.choice(pts)
        out: list[Any] = []
        for d, name in enumerate(self.names):
            s = self.space[name]
            if s["kind"] == "categorical":
                ch = s["choices"]
                out.append(centre[d] if (len(ch) == 1 or self.rng.random() >= self.LAMBDA) else self.rng.choice([c for c in ch if c != centre[d]]))
            else:
                out.append(min(max(self.rng.gauss(centre[d], h[d]), 0.0), 1.0))
        return out

    def _density(self, c: list[Any], pts: list[list[Any]], h: list[float]) -> float:
        prior = 1.0
        for d, name in enumerate(self.names):
            if self.space[name]["kind"] == "categorical":
                prior /= len(self.space[name]["choices"])
        if not pts:
            return prior
        total = prior
        for p in pts:
            k = 1.0
            for d, name in enumerate(self.names):
                s = self.space[name]
                if s["kind"] == "categorical":
                    kk = len(s["choices"])
                    k *= (1.0 - self.LAMBDA) if (c[d] == p[d] or kk == 1) else self.LAMBDA / (kk - 1)
                else:
                    z = (c[d] - p[d]) / h[d]
                    k *= math.exp(-0.5 * z * z) / (h[d] * 2.5066282746)
            total += k
        return total / (len(pts) + 1.0)

    @staticmethod
    def _std(xs: list[float]) -> float:
        if len(xs) < 2:
            return 0.0
        m = sum(xs) / len(xs)
        return math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1))


def pareto_front(trials: list[Trial], directions: list[str]) -> list[Trial]:
    """The non-dominated, feasible-first set of finished trials (first front)."""
    done = [t for t in trials if t.state == "COMPLETE" and t.values]
    if not done:
        return []
    items = [(violation(t.constraint), [(-v if d == "maximize" else v) for v, d in zip(t.values, directions)]) for t in done]
    return [done[i] for i in nondominated_fronts(items)[0]]
