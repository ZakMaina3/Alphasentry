"""Optimizers for the search labs. One interface, two interchangeable backends:

  builtin  pure Python (random, brute, qmc=Sobol, nsga2, nsga3, tpe, cmaes=separable) — always available, fully tested
  optuna   the real thing, used automatically when Optuna is installed

    opt = make_optimizer("nsga2", space, ["maximize", "minimize"], seed=7)
    for handle, params in opt.ask(10): ...
    opt.tell(handle, [fitness, turnover], constraint={"LOW_SHARPE": 0.0})
    opt = make_optimizer(..., history=[{params, values, constraint, state}, ...])     # rebuild after a restart

Choose with backend="auto" (default: Optuna if installed), "builtin" or "optuna"; the environment variable
ACE_HARNESS_OPTIMIZER overrides "auto".
"""
from __future__ import annotations

import os
from typing import Any

from app.harness.optimize import optuna_backend
from app.harness.optimize import space as sp
from app.harness.optimize.builtin import BuiltinOptimizer, Handle, Trial, pareto_front, violation  # noqa: F401

SAMPLERS: dict[str, dict[str, Any]] = {
    "nsga2": {"label": "NSGA-II", "multiObjective": True, "recommended": True,
              "summary": "Evolves a population toward the best trade-offs. Fills whole batches, so no slot is wasted."},
    "nsga3": {"label": "NSGA-III", "multiObjective": True, "recommended": True,
              "summary": "Like NSGA-II, better with three or more objectives (reference-point niching keeps the trade-offs spread out)."},
    "tpe": {"label": "TPE (Bayesian)", "multiObjective": True,
            "summary": "Learns which values did well and tries more like them. Strong on small budgets."},
    "cmaes": {"label": "CMA-ES", "multiObjective": False,
              "summary": "Adapts a search distribution; single objective only (built-in backend: separable variant)."},
    "qmc": {"label": "Quasi-random", "multiObjective": True, "summary": "Even coverage of the space; ignores results."},
    "random": {"label": "Random", "multiObjective": True, "summary": "Uniform draws. A fair baseline."},
    "brute": {"label": "Exhaustive", "multiObjective": True, "summary": "Every grid point once. Needs a step on every number."},
}


def catalogue() -> list[dict[str, Any]]:
    return [{"name": k, **v} for k, v in SAMPLERS.items()]


def default_backend() -> str:
    env = os.environ.get("ACE_HARNESS_OPTIMIZER", "").strip().lower()
    if env in ("builtin", "optuna"):
        return env
    return "optuna" if optuna_backend.available() else "builtin"


def make_optimizer(sampler: str, space: sp.Space, directions: list[str] | None = None, *, backend: str = "auto",
                   seed: int | None = None, batch_size: int = 10, params: dict[str, Any] | None = None,
                   history: list[dict[str, Any]] | None = None):
    chosen = default_backend() if backend == "auto" else backend
    if chosen == "optuna" and not optuna_backend.available():
        raise RuntimeError("The Optuna backend was requested but Optuna is not installed.")
    cls = optuna_backend.OptunaOptimizer if chosen == "optuna" else BuiltinOptimizer
    kw = dict(seed=seed, batch_size=batch_size, params=params)
    return (cls.from_history(sampler, space, list(directions or ["maximize"]), history, **kw) if history
            else cls(sampler, space, directions, **kw))
