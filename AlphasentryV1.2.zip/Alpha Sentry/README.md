# Alpha Sentry

A local‑first **alpha research studio** for WorldQuant BRAIN. It turns your own BRAIN
session into a fast, AI‑driven research pipeline — research an idea, generate and validate
expressions, simulate them against a strict success gate, and analyse what worked — all on
your machine, with everything grounded in your live account.

Full guide from installation to every screen: **docs/USER_GUIDE.md**.

## Run

**Windows:** double‑click **`run.bat`** in the project root.

It creates a private Python environment, installs the backend and frontend dependencies on
first launch, starts the backend and the UI, and opens the app in your browser. Later
launches are quick.

- UI: **http://localhost:5173**
- API: **http://127.0.0.1:8766** (the UI talks to it automatically)

Two windows open — one for the backend, one for the frontend. Close them to stop the app.
(Running only the frontend gives `ECONNREFUSED 8766` — the backend must be running too;
`run.bat` starts both.)

## First use

Open **Settings** and:
1. Add at least one **LLM API key** (Claude / Gemini / OpenAI / DeepSeek / Groq / …) and
   press **Test key** to confirm it works.
2. Complete the BRAIN **login** (uses your own session — no account, nothing stored
   server‑side).
3. Set your **tags** and pick light/dark.

Everything else — datasets, fields, operators, regions/universes — is fetched live.

## Screens

| Area | Screen | What it does |
|---|---|---|
| Overview | **Command Center** | Live success rate, submittable count, diversity, next best actions. |
| Research | **Data Explorer** | Pick a context, fetch datasets/fields (VECTOR/MATRIX aware), family‑prefix facet, presets, select‑all/random. |
| | **Knowledge Graph** | Cross‑region dataset/field twins the studio learns from every fetch. |
| | **Research Lab** | LLM research (and research‑paper ingestion) → grounded hypotheses → push to build. |
| | **Strategy Atlas** | Per‑category strategy exploration, seeded to your device so it's uniquely yours. |
| | **Prompt Library** | Saved dataset‑focused prompts. |
| Build | **Template Studio** | `{field}`/`{field2}` templates, live syntax check, Tab operator autocomplete, LLM suggestions. |
| | **Autosentry** | Autonomous engine: hypotheses → templates → batches of 10 simulated → full BRAIN check (incl. correlations) → LLM refines → repeat until an alpha passes *everything*; runs until you Stop. Winners are parked in the Vault, never auto-submitted. |
| | **Alpha Translation** | Fast Expression → Python Alpha following your editable guideline (`data/pyalpha_guideline.md`), simulate it and the original side by side, send platform errors back to the LLM to fix. |
| | **Generation** | Deep single‑field extraction or ≤2‑category multi‑field, validated + repaired, steered by a personal diversity engine. |
| Run | **Simulation** | Run across universes/neutralizations with the success gate (delay‑0 held to Sharpe 2.69 / Fitness 1.5), your own tags, settable concurrency. |
| | **SuperAlpha** | Build & count selections (≥10 components), combos, simulate — its own separated workspace. |
| Analyse | **Results & Analytics** | Per‑metric verdicts, filter/sort/CSV, operator‑fitness insights. |
| | **Correlation & Portfolio** | Pairwise PnL correlation → the largest set you can submit together. |
| | **Operator / Region atlases** | Operators with your usage overlaid; market notes and cross‑region transfer. |
| System | **Success & Donation** | Your verified success record; the app is free, donation unlocks scale only. |

## The success gate

An alpha is a verified success only when **every** metric passes, in absolute value:
`|Sharpe|`, `|Fitness|`, `|Turnover| < 0.70`, no in‑sample test failures, and — with the
submission check — self / prod / powerpool correlation `< 0.70`. Thresholds default by
delay (delay 0: Sharpe 2.69 / Fitness 1.5; else 1.58 / 1.0) and are editable.

## Structure

```
backend/      FastAPI, one self‑contained module per feature (app/modules/*)
  vendor/     the BRAIN engine (ace_lib, session_manager, …), so the backend is standalone
frontend/     React + Vite + TypeScript UI (src/features/* = one folder per screen)
data/         local database, caches, saved prompts, licence (git‑ignored)
run.bat       one‑click launcher for backend + frontend
```

The BRAIN session (`session.pkl`) and your API keys (`~/secrets/ace_keys.json`) live
outside the app and never leave your machine.

## Desktop icon (Windows)

1. Run `run.bat` once (installs Python/Node packages) - or skip it, the launcher does the same on first use.
2. Double-click `Install Desktop Icon.bat` -> creates **Alpha Sentry** and **Stop Alpha Sentry** on your Desktop.
3. Click **Alpha Sentry**: it starts the backend hidden (one port, 8766), builds the interface the first time,
   and opens it in its own window. Closing the window leaves the backend (and any Autosentry) running;
   **Stop Alpha Sentry** ends it. Logs are in `logs\`. Re-run step 2 if you move the folder.
`run.bat` still starts the two-window dev mode (it now only watches `backend\app` for reloads).
