"""Fast standalone build with PyInstaller (onedir) — an alternative to build_nuitka.py.

PyInstaller COLLECTS files (no C compilation), so it builds in minutes. Same dependency-driven
size as Nuitka, weaker tamper-resistance (bundled bytecode). Output dirs are kept separate from
the Nuitka build so both can run at once.

    python build_pyinstaller.py            # build + zip
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path

REPO = Path(__file__).resolve().parent
BACKEND = REPO / "backend"
VENDOR = BACKEND / "vendor"
ENTRY = BACKEND / "_ace_entry.py"
WORK = REPO / "pyi_work"
DIST = REPO / "pyi_dist"
SPEC = REPO / "pyi_spec"
SEP = ";" if os.name == "nt" else ":"

VENDOR_MODULES = ["ace_lib", "session_manager", "keys", "validator", "llm_providers",
                  "wqb_llm", "helpful_functions", "platform_log", "wqb_data"]

DEFAULT_UPDATE_URL = "https://api.github.com/repos/ngari-qds/ace-studio/releases/latest"


def _arg(flag: str, default: str) -> str:
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return sys.argv[i + 1]
    return default


def sign_and_stamp(app_dir: Path, version: str) -> None:
    """Stamp version + update pointers next to the exe, then Ed25519-sign the whole tree with the
    maintainer's key (reusing package.py's signer) so the in-app updater can verify it."""
    print(f"[2/4] stamping v{version} + signing…", flush=True)
    import package as pk  # exposes _load_seed, _sign_tree, _sign_ns

    seed = pk._load_seed()
    pub = pk._sign_ns["public_from_seed"](seed)
    (app_dir / "version.txt").write_text(version, encoding="utf-8")
    (app_dir / "public_key.hex").write_text(pub.hex(), encoding="utf-8")

    # Always the GitHub releases API — NOT the repo's update_url.txt (that points at the source
    # zipball for the old updater and would return a binary zip to the new JSON check).
    (app_dir / "update_url.txt").write_text(DEFAULT_UPDATE_URL, encoding="utf-8")
    tok = REPO / "update_token.txt"
    if tok.exists():
        (app_dir / "update_token.txt").write_text(tok.read_text().strip(), encoding="utf-8")

    pk._sign_tree(app_dir, seed)                       # writes MANIFEST.json + MANIFEST.sig
    ok, msg = pk._sign_ns["verify_tree"](app_dir)
    if not ok:
        raise SystemExit(f"post-sign verify FAILED: {msg}")
    print(f"      signed with key {pub.hex()[:16]}… — verify: {msg}", flush=True)


def _plat_tag() -> str:
    sysname = {"windows": "win", "darwin": "mac", "linux": "linux"}.get(platform.system().lower(), "os")
    arch = "x64" if platform.machine().lower() in ("amd64", "x86_64") else platform.machine().lower()
    return f"{sysname}-{arch}"


def run_pyinstaller() -> Path:
    print("[1/3] collecting with PyInstaller…", flush=True)
    for d in (WORK, DIST, SPEC):
        if d.exists():
            shutil.rmtree(d, ignore_errors=True)

    args = [
        sys.executable, "-m", "PyInstaller",
        "--noconfirm", "--clean", "--onedir",
        "--name=alpha-sentry",
        f"--distpath={DIST}", f"--workpath={WORK}", f"--specpath={SPEC}",
        f"--paths={BACKEND}", f"--paths={VENDOR}",
        # bundled assets (unpacked under _internal / sys._MEIPASS at runtime)
        f"--add-data={REPO / 'frontend' / 'dist'}{SEP}frontend/dist",
        *([f"--add-data={REPO / 'seed'}{SEP}seed"] if (REPO / "seed").is_dir() else []),   # shipped knowledge data (harness seed)
        # whole backend + the SDKs (data files + dynamic submodules PyInstaller can miss)
        "--collect-submodules=app",
        "--collect-submodules=uvicorn",
        "--collect-all=anthropic",
        "--collect-all=openai",
        "--collect-all=google",
        "--collect-submodules=pydantic",
    ]
    for m in VENDOR_MODULES:
        if (VENDOR / f"{m}.py").exists():
            args.append(f"--hidden-import={m}")
    ico = REPO / "build" / "alpha-sentry.ico"
    if os.name == "nt" and ico.exists():
        args.append(f"--icon={ico}")
    args.append(str(ENTRY))

    env = dict(os.environ)
    env["PYTHONPATH"] = os.pathsep.join([str(BACKEND), str(VENDOR), env.get("PYTHONPATH", "")])
    t0 = time.time()
    subprocess.run(args, cwd=BACKEND, env=env, check=True)
    print(f"      PyInstaller finished in {time.time() - t0:.0f}s", flush=True)

    app_dir = DIST / "alpha-sentry"
    exe = app_dir / ("alpha-sentry.exe" if os.name == "nt" else "alpha-sentry")
    if not exe.exists():
        raise SystemExit(f"no exe at {exe}")
    return app_dir


def zip_release(app_dir: Path) -> Path:
    print("[3/4] zipping…", flush=True)
    zpath = REPO / f"Alpha-Sentry-pyi-{_plat_tag()}.zip"
    if zpath.exists():
        zpath.unlink()
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in app_dir.rglob("*"):
            if p.is_file():
                z.write(p, Path("Alpha Sentry") / p.relative_to(app_dir))
    return zpath


def main() -> None:
    if not (REPO / "frontend" / "dist" / "index.html").exists():
        raise SystemExit("frontend/dist missing — build the frontend first.")
    version = _arg("--version", "0.0.0-dev")
    app_dir = run_pyinstaller()
    sign_and_stamp(app_dir, version)
    unpacked = sum(p.stat().st_size for p in app_dir.rglob("*") if p.is_file()) / 1024 / 1024
    zpath = zip_release(app_dir)
    zmb = zpath.stat().st_size / 1024 / 1024
    print(f"\n[4/4] DONE (v{version}).\n  Folder:  {app_dir}\n  Unpacked: {unpacked:.0f} MB\n  Zip:      {zpath} ({zmb:.0f} MB)")


if __name__ == "__main__":
    main()
