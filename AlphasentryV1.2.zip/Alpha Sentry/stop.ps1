# ============================================================================
#  Alpha Sentry - stop the background backend started by the "Alpha Sentry" shortcut.
#  Asks first, and tells you if an Autosentry is currently running (stopping ends it).
#  Use  -Force  to skip the question.
# ============================================================================
param([switch]$Force)
$ErrorActionPreference = 'SilentlyContinue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Port = 8766
$PidFile = Join-Path $Root '.ace.pid'
try { Add-Type -AssemblyName System.Windows.Forms } catch { }

function Get-Listeners {
    $ids = @()
    try { $ids += (Get-NetTCPConnection -LocalPort $Port -State Listen).OwningProcess } catch { }
    return ($ids | Where-Object { $_ } | Select-Object -Unique)
}

$pids = @()
if (Test-Path $PidFile) { $pids += [int](Get-Content $PidFile | Select-Object -First 1) }
$pids += Get-Listeners
$pids = $pids | Where-Object { $_ } | Select-Object -Unique

if (-not $pids) {
    if (-not $Force) { [System.Windows.Forms.MessageBox]::Show('Alpha Sentry is not running.', 'Alpha Sentry', 'OK', 'Information') | Out-Null }
    Remove-Item $PidFile -Force
    exit 0
}

# Is an engine running right now?
$busy = @()
foreach ($e in @(@('autopilot', 'Autosentry'), @('superpilot', 'Supersentry'))) {
    try {
        $s = Invoke-RestMethod "http://127.0.0.1:$Port/api/$($e[0])/status" -TimeoutSec 3
        if ($s.running) { $busy += $e[1] }
    } catch { }
}

if (-not $Force) {
    $msg = 'Stop Alpha Sentry?'
    if ($busy.Count) { $msg += "`r`n`r`n" + ($busy -join ' and ') + ' is running and will be stopped.' }
    $r = [System.Windows.Forms.MessageBox]::Show($msg, 'Alpha Sentry', 'YesNo', $(if ($busy.Count) { 'Warning' } else { 'Question' }))
    if ($r -ne 'Yes') { exit 0 }
}

foreach ($p in $pids) { & taskkill.exe /PID $p /T /F | Out-Null }   # /T = the whole process tree (uvicorn + workers)
Start-Sleep -Milliseconds 800
foreach ($p in (Get-Listeners)) { & taskkill.exe /PID $p /T /F | Out-Null }
Remove-Item $PidFile -Force
